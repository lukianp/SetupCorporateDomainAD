<#
.SYNOPSIS
  Re-points existing scheduled tasks at a different account, safely. Built for the swap OFF a personal
  named account and ONTO a service account once AD provides one. Dry run until -Apply.

.DESCRIPTION
  Changing a task's run-as account looks like a one-liner and is not. Set-ScheduledTask on a task whose
  logon type is Password DROPS THE STORED PASSWORD unless -User and -Password are supplied again. The
  task keeps running until the next reboot on its cached session, then starts failing with 0x80070569,
  which reads exactly like a missing batch-logon right. People then spend an afternoon on the wrong
  fault. So this script re-registers from exported XML with the credential supplied, rather than
  patching the live object.

  What it does, in order:
    1. Resolves the new account and confirms it holds "Log on as a batch job" - directly or through a
       group. It will NOT write security policy on an uncertain read (see Test-HoldsRight).
    2. Exports every matching task's XML to a timestamped backup folder. That backup is the rollback.
    3. Records each task's ENABLED STATE, because re-registering resets it and a task that comes back
       enabled when it was deliberately disabled is a bad surprise.
    4. Rewrites <UserId>, re-registers with -User/-Password, restores the enabled state.
    5. Grants the new account Modify on the textfile directory and Read+Execute on the script roots
       the tasks actually reference - a service account that cannot write its .prom file fails silently.
    6. VERIFIES by re-reading each task back and reporting the account it now holds.

  Nothing is changed without -Apply.

.PARAMETER NewAccount   DOM\name to move the tasks to. Required.
.PARAMETER TaskFilter   Regex on task name. Default '.' (every non-Microsoft task at -TaskPath).
.PARAMETER TaskPath     Task folder. Default '\'.
.PARAMETER OldAccount   Only touch tasks currently running as this account. Safer than a name regex.
.PARAMETER PromDir      Textfile directory to grant Modify on.
.PARAMETER GrantRights  Also grant batch-logon if the new account provably lacks it.
.PARAMETER Apply        Make changes.

.EXAMPLE
  # see what would change - every task currently running as the personal account
  .\Set-TaskAccount.ps1 -NewAccount 'FOSTST\svcCRMMonitoringSTG' -OldAccount 'FOSTST\e-lpoleschtschuk1'

.EXAMPLE
  .\Set-TaskAccount.ps1 -NewAccount 'FOSTST\svcCRMMonitoringSTG' -OldAccount 'FOSTST\e-lpoleschtschuk1' -Apply

.EXAMPLE
  # just the STG set
  .\Set-TaskAccount.ps1 -NewAccount 'FOSTST\svcCRMMonitoringSTG' -TaskFilter '_STG$' -Apply
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string] $NewAccount,
    [string] $TaskFilter = '.',
    [string] $TaskPath   = '\',
    [string] $OldAccount,
    [string] $PromDir    = 'D:\Win\Ops\WMITextfileExport',
    [switch] $GrantRights,
    [switch] $Apply,
    [switch] $Sanitize
)
$ErrorActionPreference = 'Continue'
$Version = '1.0'
$stamp   = Get-Date -Format 'yyyyMMdd-HHmmss'
if (-not $TaskPath.EndsWith('\')) { $TaskPath = "$TaskPath\" }
New-Item -ItemType Directory -Force -Path C:\Migration | Out-Null
$BackupDir  = "C:\Migration\taskbackup-$stamp"
$ReportPath = "C:\Migration\SETACCOUNT-$env:COMPUTERNAME-$stamp.txt"

# ------------------------------------------------------------------ plumbing
$R = New-Object System.Collections.ArrayList
$Blockers = New-Object System.Collections.ArrayList
$Warns    = New-Object System.Collections.ArrayList
$Changes  = New-Object System.Collections.ArrayList
function RptLine { param($t = '') [void]$R.Add($t) }
function RptHead { param($t) RptLine ''; RptLine ('=' * 78); RptLine "  $t"; RptLine ('=' * 78) }
function RptSub  { param($t) RptLine ''; RptLine ("-- $t " + ('-' * [Math]::Max(0, 74 - $t.Length))) }
function RptKV   { param($k, $v) RptLine ("  {0,-30}: {1}" -f $k, $v) }
function Blocker { param($t, $fix = '') [void]$Blockers.Add([pscustomobject]@{ P = $t; F = $fix }); Write-Host "  BLOCKER $t" -ForegroundColor Red }
function Warn    { param($t, $fix = '') [void]$Warns.Add([pscustomobject]@{ P = $t; F = $fix }); Write-Host "  WARN    $t" -ForegroundColor Yellow }
function Changed { param($t) [void]$Changes.Add($t); Write-Host "  DONE    $t" -ForegroundColor Green }
function TrimTo  { param($s, [int]$n = 100) $t = ("$s" -replace '\s+', ' ').Trim(); if ($t.Length -le $n) { $t } else { $t.Substring(0, $n - 2) + '..' } }
$script:Map = @{}
function Mask { param($s)
    if (-not $Sanitize -or -not $s) { return $s }
    $t = "$s"
    foreach ($k in ($script:Map.Keys | Sort-Object Length -Descending)) { $t = [regex]::Replace($t, [regex]::Escape($k), $script:Map[$k], 'IgnoreCase') }
    return [regex]::Replace($t, 'S-1-5-21-[\d-]+-(\d+)', 'SID-x-$1') }
function Test-Resolves { param([string]$Principal)
    try { return (New-Object System.Security.Principal.NTAccount($Principal)).Translate([System.Security.Principal.SecurityIdentifier]).Value }
    catch { return $null } }
function Should-Do { param([string]$What)
    if (-not $Apply) { RptLine ("    would: {0}" -f (Mask $What)); return $false }
    return $true }

function Test-HoldsRight {
    <#
      Three states, not a boolean. A service account usually holds a right through a group, and a
      direct-name check calls that "NO" and invites a needless write to local security policy.
        YES / NO / UNKNOWN (a holder is a group this host cannot expand - never write policy on that)
    #>
    param([string]$Account, [string[]]$Holders)
    $sam = ($Account -split '\\')[-1]
    foreach ($h in $Holders) {
        if ($h -ieq $Account -or (($h -split '\\')[-1]) -ieq $sam) {
            return [pscustomobject]@{ Verdict = 'YES'; Via = 'held directly' } }
    }
    $unresolved = @()
    foreach ($h in $Holders) {
        $g = ($h -split '\\')[-1]
        $members = $null
        try { $members = @(Get-LocalGroupMember -Group $g -ErrorAction Stop) }
        catch { $unresolved += $h; continue }
        foreach ($m in $members) {
            $mn = "$($m.Name)"
            if ($mn -ieq $Account -or (($mn -split '\\')[-1]) -ieq $sam) {
                return [pscustomobject]@{ Verdict = 'YES'; Via = "held via $h" } }
            if ("$($m.ObjectClass)" -match '(?i)group') { $unresolved += "$h -> $mn" }
        }
    }
    if ($unresolved.Count) {
        return [pscustomobject]@{ Verdict = 'UNKNOWN'
                                  Via = ("could not expand: " + (($unresolved | Select-Object -Unique -First 4) -join ', ')) }
    }
    return [pscustomobject]@{ Verdict = 'NO'; Via = '' }
}

function Grant-BatchLogon {
    param([string]$Principal)
    $sid = Test-Resolves $Principal
    if (-not $sid) { return 'skipped - the account does not resolve' }
    $stem = Join-Path $env:TEMP ('ur-' + [guid]::NewGuid().ToString('N'))
    $cfg = "$stem.inf"; $db = "$stem.sdb"
    try {
        $null = & secedit /export /areas USER_RIGHTS /cfg $cfg /quiet 2>&1
        if (-not (Test-Path -LiteralPath $cfg)) { return 'FAILED - secedit could not export the current policy' }
        $lines = @(Get-Content -LiteralPath $cfg)
        $idx = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\s*SeBatchLogonRight\s*=') { $idx = $i; break } }
        if ($idx -ge 0) {
            if ($lines[$idx] -match [regex]::Escape($sid)) { return 'already held' }
            $lines[$idx] = $lines[$idx].TrimEnd() + ",*$sid"
        } else {
            $pr = -1
            for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\s*\[Privilege Rights\]') { $pr = $i; break } }
            if ($pr -lt 0) { return 'FAILED - no [Privilege Rights] section in the exported policy' }
            $lines = @($lines[0..$pr]) + @("SeBatchLogonRight = *$sid") + @($lines[($pr + 1)..($lines.Count - 1)])
        }
        # UTF-16 or secedit rejects it silently - looks like the grant worked and then did nothing
        $lines | Set-Content -LiteralPath $cfg -Encoding Unicode
        $out = & secedit /configure /db $db /cfg $cfg /areas USER_RIGHTS /quiet 2>&1
        if ($LASTEXITCODE -ne 0) { return ("FAILED - " + (TrimTo ($out -join ' ') 70)) }
        return 'granted'
    } catch { return ("FAILED - " + (TrimTo $_.Exception.Message 70)) }
    finally { Remove-Item "$stem.*" -Force -ErrorAction SilentlyContinue }
}

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this in an ELEVATED PowerShell.' }

Write-Host ''
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ("  Set-TaskAccount {0}  on {1}" -f $Version, $env:COMPUTERNAME) -ForegroundColor Cyan
Write-Host ("  MODE: {0}" -f $(if ($Apply) { 'APPLY' } else { 'DRY RUN - add -Apply to change anything' })) -ForegroundColor $(if ($Apply) { 'Yellow' } else { 'DarkGray' })
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ''

RptHead "SCHEDULED TASK ACCOUNT CHANGE - $(Mask $env:COMPUTERNAME)"
RptKV 'Generated'    (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
RptKV 'Script'       "Set-TaskAccount $Version"
RptKV 'New account'  (Mask $NewAccount)
RptKV 'Old account'  $(if ($OldAccount) { Mask $OldAccount } else { '(any)' })
RptKV 'Task filter'  $TaskFilter
RptKV 'Task path'    $TaskPath
RptKV 'Backups'      $BackupDir
RptKV 'Mode'         $(if ($Apply) { 'APPLY' } else { 'DRY RUN' })

# ================================================================== 1. the new account
RptSub '1. the account we are moving to'
$newSid = Test-Resolves $NewAccount
RptKV 'Resolves' $(if ($newSid) { $newSid } else { '*** NO - NONE_MAPPED ***' })
if (-not $newSid) {
    Blocker "$(Mask $NewAccount) does not resolve on this host" 'Check the name and the domain. Nothing can be re-pointed at an account that does not exist.'
} else {
    $sam = ($NewAccount -split '\\')[-1]
    try {
        $hit = ([adsisearcher]"(&(objectCategory=user)(sAMAccountName=$sam))").FindOne()
        if ($hit) {
            $uac = [int]$hit.Properties['useraccountcontrol'][0]
            if ($uac -band 2) { Blocker "$(Mask $sam) is DISABLED in AD" 'Enable it before moving tasks onto it' }
            if ($uac -band 65536) { RptLine '     password never expires: yes' }
            else { Warn "$(Mask $sam) has an EXPIRING password" 'Every task on it stops at the next expiry. Get PasswordNeverExpires set, or diarise the rotation.' }
            $lo = "$($hit.Properties['userworkstations'])"
            if ($lo) {
                $inList = (($lo -split ',') -contains $env:COMPUTERNAME)
                RptLine ("     LogOnTo=[{0}] includes {1}: {2}" -f (Mask $lo), (Mask $env:COMPUTERNAME), $inList)
                if (-not $inList) { Blocker "$(Mask $sam) has a 'Log On To' list excluding $(Mask $env:COMPUTERNAME)" 'Tasks will register and then fail to launch with error 1329' }
            } else { RptLine '     LogOnTo=(unrestricted)' }
        } else { RptLine '     (not found via LDAP - could be a gMSA or a different directory)' }
    } catch { RptLine ("     (LDAP lookup unavailable: {0})" -f (TrimTo $_.Exception.Message 60)) }
}

# batch-logon
$inf = Join-Path $env:TEMP ('ur-' + [guid]::NewGuid().ToString('N') + '.inf')
$null = & secedit /export /areas USER_RIGHTS /cfg $inf /quiet 2>&1
$pol = @(Get-Content -LiteralPath $inf -ErrorAction SilentlyContinue)
Remove-Item $inf -ErrorAction SilentlyContinue
function ResolveP { param($p) $v = "$p".Trim()
    if ($v -match '^\*?(S-1-[0-9-]+)$') { try { return (New-Object System.Security.Principal.SecurityIdentifier($Matches[1])).Translate([System.Security.Principal.NTAccount]).Value } catch { return $Matches[1] } }
    return $v }
$bl = @($pol | Where-Object { $_ -match '^\s*SeBatchLogonRight\s*=' })
$batch = @()
if ($bl) { $batch = @((($bl[0] -split '=', 2)[1] -split ',') | ForEach-Object { ResolveP $_ } | Where-Object { $_ }) }
RptLine ''
RptKV 'SeBatchLogonRight' (($batch | ForEach-Object { Mask $_ }) -join ', ')
$rightChk = Test-HoldsRight -Account $NewAccount -Holders $batch
RptKV 'Holds batch-logon' $rightChk.Verdict
if ($rightChk.Via) { RptLine ("     {0}" -f $rightChk.Via) }
if ($rightChk.Verdict -eq 'NO') {
    if ($GrantRights -and (Should-Do "grant 'Log on as a batch job' to $NewAccount")) {
        $res = Grant-BatchLogon $NewAccount
        RptLine ("     grant: {0}" -f $res)
        if ($res -eq 'granted') { Changed "granted SeBatchLogonRight to $(Mask $NewAccount)" }
        elseif ($res -like 'FAILED*') { Blocker "could not grant batch-logon" $res }
    } else {
        Warn "$(Mask $NewAccount) does not hold 'Log on as a batch job'" 'Pass -GrantRights to have this script grant it, or grant it by hand. Without it every task fails at launch with 0x80070569.'
    }
} elseif ($rightChk.Verdict -eq 'UNKNOWN') {
    Warn "cannot confirm whether $(Mask $NewAccount) holds 'Log on as a batch job'" `
         'It may hold it through a domain group this host cannot expand. Not granted automatically - writing security policy on a guess is worse. If tasks fail at launch with 0x80070569, grant it by hand.'
}

# ================================================================== 2. which tasks
RptSub '2. tasks in scope'
$all = @(Get-ScheduledTask -ErrorAction SilentlyContinue |
         Where-Object { $_.TaskPath -eq $TaskPath -and $_.TaskPath -notlike '\Microsoft*' })
$targets = @()
foreach ($t in $all) {
    if ($t.TaskName -notmatch $TaskFilter) { continue }
    $uid = "$($t.Principal.UserId)"
    if ($OldAccount) {
        $oSam = ($OldAccount -split '\\')[-1]
        if (-not ($uid -ieq $OldAccount -or (($uid -split '\\')[-1]) -ieq $oSam)) { continue }
    }
    $targets += [pscustomobject]@{
        Name      = $t.TaskName
        UserId    = $uid
        LogonType = "$($t.Principal.LogonType)"
        Enabled   = [bool]$t.Settings.Enabled
        State     = "$($t.State)"
    }
}
RptKV 'Tasks at this path' $all.Count
RptKV 'Matching'           $targets.Count
if (-not $targets.Count) {
    Blocker 'no tasks matched' "Check -TaskFilter '$TaskFilter'$(if ($OldAccount) { " and -OldAccount $(Mask $OldAccount)" }). Nothing to do."
} else {
    RptLine ''
    RptLine ("     {0,-52} {1,-28} {2,-9} {3}" -f 'TASK', 'CURRENTLY RUNS AS', 'ENABLED', 'LOGON')
    foreach ($t in $targets) {
        RptLine ("     {0,-52} {1,-28} {2,-9} {3}" -f (TrimTo (Mask $t.Name) 50), (TrimTo (Mask $t.UserId) 26), $t.Enabled, $t.LogonType)
    }
    $samePrincipal = @($targets | Where-Object { $_.UserId -ieq $NewAccount }).Count
    if ($samePrincipal) { RptLine ''; RptLine ("     {0} of these already run as the new account and will be skipped" -f $samePrincipal) }
}

# ================================================================== 3. what the tasks need to reach
RptSub '3. access the new account will need'
$roots = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($t in $targets) {
    $x = ''
    try { $x = Export-ScheduledTask -TaskName $t.Name -TaskPath $TaskPath -ErrorAction Stop } catch { continue }
    foreach ($m in [regex]::Matches("$x", '(?i)([A-Za-z]:\\[^"''<>\r\n]*?\\)[^\\"''<>\r\n]*\.(ps1|exe|cmd|bat)')) {
        [void]$roots.Add($m.Groups[1].Value.TrimEnd('\'))
    }
}
RptKV 'Script folders in use' $roots.Count
foreach ($rt in ($roots | Sort-Object)) { RptLine ("     {0}" -f (Mask $rt)) }
RptKV 'Textfile directory' (Mask $PromDir)
RptLine ''
RptLine '    A service account that cannot WRITE the textfile directory produces no .prom file and no'
RptLine '    error anybody sees - the task exits 0 and the metric just never appears. Checked below.'

# ================================================================== 4. apply
RptSub '4. changes'
$cred = $null
if ($Apply -and $targets.Count -and $Blockers.Count -eq 0) {
    $cred = Get-Credential -UserName $NewAccount -Message "Password for $NewAccount"
    if (-not $cred) { Blocker 'no credential supplied' 'A Password-logon task cannot be re-registered without it' }
}

if ($Blockers.Count -and $Apply) {
    RptLine '    SKIPPED - fix the blockers above, then re-run with -Apply.'
} else {
    # 4a. permissions first, so the account can work the moment the tasks flip
    if ($newSid) {
        foreach ($d in @($PromDir)) {
            if (-not (Test-Path -LiteralPath $d)) { Warn "$d does not exist" 'Nothing to grant on; check -PromDir'; continue }
            $has = $false
            try { $has = [bool](@((Get-Acl -LiteralPath $d).Access | Where-Object {
                    "$($_.IdentityReference)" -like "*$(($NewAccount -split '\\')[-1])" -and
                    "$($_.AccessControlType)" -eq 'Allow' -and "$($_.FileSystemRights)" -match 'Modify|FullControl|Write' }).Count) } catch {}
            RptLine ("    write access {0,-34}: {1}" -f (Mask $d), $(if ($has) { 'yes' } else { 'NO' }))
            if (-not $has -and (Should-Do "grant Modify on $d to $NewAccount")) {
                $o = & icacls $d /grant "$($NewAccount):(OI)(CI)M" 2>&1
                if ($LASTEXITCODE -eq 0) { Changed "granted Modify on $(Mask $d)" }
                else { Blocker "could not grant Modify on $(Mask $d)" (TrimTo ($o -join ' ') 80) }
            }
        }
        foreach ($rt in ($roots | Sort-Object)) {
            if (-not (Test-Path -LiteralPath $rt)) { continue }
            $has = $false
            try { $has = [bool](@((Get-Acl -LiteralPath $rt).Access | Where-Object {
                    "$($_.IdentityReference)" -like "*$(($NewAccount -split '\\')[-1])" -and "$($_.AccessControlType)" -eq 'Allow' }).Count) } catch {}
            RptLine ("    read+exec    {0,-34}: {1}" -f (TrimTo (Mask $rt) 32), $(if ($has) { 'yes' } else { 'not explicit (may inherit)' }))
            if (-not $has -and (Should-Do "grant Read+Execute on $rt to $NewAccount")) {
                $o = & icacls $rt /grant "$($NewAccount):(OI)(CI)RX" 2>&1
                if ($LASTEXITCODE -eq 0) { Changed "granted Read+Execute on $(Mask $rt)" }
                else { Warn "could not grant Read+Execute on $(Mask $rt)" (TrimTo ($o -join ' ') 70) }
            }
        }
        $global:LASTEXITCODE = 0
    }

    # 4b. the account change itself
    RptLine ''
    if ($Apply) { New-Item -ItemType Directory -Force -Path $BackupDir | Out-Null }
    foreach ($t in $targets) {
        if ($t.UserId -ieq $NewAccount) { RptLine ("    {0,-52} already on the new account - skipped" -f (TrimTo (Mask $t.Name) 50)); continue }
        RptLine ("    {0,-52} {1} -> {2}" -f (TrimTo (Mask $t.Name) 50), (Mask $t.UserId), (Mask $NewAccount))
        if (-not (Should-Do "re-point $($t.Name)")) { continue }
        try {
            $xml = Export-ScheduledTask -TaskName $t.Name -TaskPath $TaskPath -ErrorAction Stop
            # the backup IS the rollback - written before anything is touched
            $safe = ($t.Name -replace '[\\/:*?"<>|]', '_')
            "$xml" | Set-Content -LiteralPath (Join-Path $BackupDir "$safe.xml") -Encoding utf8
            $new = "$xml" -replace '<UserId>[^<]*</UserId>', "<UserId>$NewAccount</UserId>"
            $p = @{ TaskName = $t.Name; TaskPath = $TaskPath; Xml = $new; Force = $true; ErrorAction = 'Stop' }
            # ALWAYS pass the credential, not only when LogonType says Password. Re-registering without
            # it is what leaves a task that runs until the next reboot and then fails with 0x80070569.
            $p.User     = $cred.UserName
            $p.Password = $cred.GetNetworkCredential().Password
            Register-ScheduledTask @p | Out-Null
            # re-registering resets the enabled flag - put it back the way it was
            if ($t.Enabled) { Enable-ScheduledTask  -TaskName $t.Name -TaskPath $TaskPath -ErrorAction SilentlyContinue | Out-Null }
            else            { Disable-ScheduledTask -TaskName $t.Name -TaskPath $TaskPath -ErrorAction SilentlyContinue | Out-Null }
            Changed "re-pointed $(Mask $t.Name) (enabled=$($t.Enabled) preserved)"
        } catch {
            Blocker "failed to re-point $(Mask $t.Name)" (TrimTo $_.Exception.Message 90)
            RptLine ("       FAILED - {0}" -f (TrimTo $_.Exception.Message 70))
        }
    }
}

# ================================================================== 5. verify
RptSub '5. verify - read back what the tasks now hold'
if (-not $Apply) {
    RptLine '    (dry run - nothing changed, nothing to verify)'
} else {
    $bad = 0
    foreach ($t in $targets) {
        $now = $null
        try { $now = Get-ScheduledTask -TaskName $t.Name -TaskPath $TaskPath -ErrorAction Stop } catch {}
        if (-not $now) { RptLine ("    {0,-52} GONE - restore from $BackupDir" -f (TrimTo (Mask $t.Name) 50)); $bad++; continue }
        $uid = "$($now.Principal.UserId)"
        $ok  = ($uid -ieq $NewAccount -or (($uid -split '\\')[-1]) -ieq (($NewAccount -split '\\')[-1]))
        $en  = [bool]$now.Settings.Enabled
        RptLine ("    {0,-52} {1,-28} enabled={2} {3}" -f (TrimTo (Mask $t.Name) 50), (TrimTo (Mask $uid) 26), $en, $(if ($ok) { 'OK' } else { '*** NOT CHANGED ***' }))
        if (-not $ok) { $bad++ }
        if ($en -ne $t.Enabled) { Warn "$(Mask $t.Name) enabled state changed ($($t.Enabled) -> $en)" 'Set it back by hand' }
    }
    if ($bad) { Blocker "$bad task(s) did not end up on the new account" "Roll back from $BackupDir with Register-ScheduledTask -Xml" }
}

# ================================================================== verdict
RptSub 'VERDICT'
if ($Blockers.Count -eq 0) {
    RptLine $(if ($Apply) { '  DONE - every matched task now runs as the new account.' } else { '  GO - nothing blocks the change. Re-run with -Apply.' })
} else {
    RptLine ("  NO-GO - {0} blocker(s):" -f $Blockers.Count)
    $idx = 0
    foreach ($b in $Blockers) { $idx++; RptLine ("   {0,2}. {1}" -f $idx, (Mask $b.P)); if ($b.F) { RptLine ("       fix: {0}" -f (Mask $b.F)) } }
}
if ($Warns.Count) {
    RptLine ''; RptLine '  Warnings:'
    $idx = 0
    foreach ($w in $Warns) { $idx++; RptLine ("   {0,2}. {1}" -f $idx, (Mask $w.P)); if ($w.F) { RptLine ("       {0}" -f (Mask $w.F)) } }
}
if ($Changes.Count) {
    RptLine ''; RptLine '  Changed this run:'
    foreach ($c in $Changes) { RptLine "    + $(Mask $c)" }
}

RptSub 'after this'
RptLine '  1. The tasks hold the new password from now. They do NOT need a reboot to pick it up.'
RptLine '  2. Watch for the first .prom file to appear or refresh. That is the only real confirmation'
RptLine '     the new account can actually do the work - registration succeeding proves nothing.'
RptLine "  3. Backups of every original task XML are in $BackupDir. Roll one back with:"
RptLine '        Register-ScheduledTask -Xml (Get-Content <backup>.xml -Raw) -TaskName <name> -TaskPath ''\'' -User <old> -Password <pw> -Force'
RptLine '  4. Remove the personal account from any ACL this script granted it, once you are satisfied.'
RptHead 'END OF REPORT'
RptLine '  Paste this whole report back to continue.'

$reportText = ($R -join "`r`n")
$reportText | Set-Content -LiteralPath $ReportPath -Encoding utf8
Write-Host $reportText
try { $reportText | Set-Clipboard; Write-Host "`nReport on the CLIPBOARD and saved to: $ReportPath" -ForegroundColor Cyan }
catch { Write-Host "`nReport saved to: $ReportPath" -ForegroundColor Cyan }
