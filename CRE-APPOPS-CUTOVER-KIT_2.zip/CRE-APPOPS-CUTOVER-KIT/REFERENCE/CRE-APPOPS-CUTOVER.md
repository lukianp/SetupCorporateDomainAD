# SRVCRE1APPOPS01 to new CRE server: cutover script sequence

Grafana 10.4.19 + Prometheus 2.8.1 + exporter + scheduled tasks. TSDB 3.41 GB, 10 scrape endpoints.

CRE is the smallest full stack in the estate and has no production impact, so it proves the sequence
for the PROD APPOPS lift. Run it here first.

Every script is read only or dry run until you pass `-Apply`. Every one prints a pasteable report to
`C:\Migration` and nothing needs to leave the perimeter.

---

## What you already have, and the one thing that was missing

| Need | Script | State |
|---|---|---|
| Baseline the old server | `suite\Invoke-ServerCapture.ps1` | existing |
| Prove the new server can host it | `suite\Compare-ServerBaseline.ps1` | existing |
| Move Grafana content | `Export-GrafanaContent.ps1` + `Import-GrafanaContent.ps1` | existing, proved on CRE |
| Move the scheduled tasks | `Import-CrossEnvTasks.ps1` v3.7 | existing |
| Fix the new host's exporter | `suite\Repair-MonitoringHost.ps1` | existing |
| Acceptance test the new host | `suite\Test-MonitoringHost.ps1` | existing |
| Validate textfile output | `Test-PromFiles.ps1` | existing |
| Swap the task account later | `Set-TaskAccount.ps1` | existing |
| **Move Prometheus config and targets** | **`Migrate-PrometheusConfig.ps1`** | **new** |
| **Prove new Prometheus matches old** | **`Migrate-PrometheusConfig.ps1 -Mode Compare`** | **new** |

The gap was Prometheus. Nothing captured the scrape config, nothing placed it on the new host, and
nothing answered the question the whole parallel run plan rests on: does the new instance return the
same data as the old one. `-Mode Compare` is the cutover gate.

---

## Step 1. Baseline the old server

On `SRVCRE1APPOPS01`:

```powershell
.\suite\Invoke-ServerCapture.ps1 -GrafanaApiKey <admin service account token>
.\Migrate-PrometheusConfig.ps1 -Mode Export
.\Export-GrafanaContent.ps1 -Url http://localhost:9091 -Token <same token> -OutputPath C:\Migration\grafana-export
.\Test-PromFiles.ps1
```

Capture 2.0 (02/09/2026) reads NSSM service definitions from the registry, detects the Grafana and
Prometheus ports itself, reports Grafana edition and licence, copies custom.ini and prometheus.yml
with secrets masked, classifies every down scrape target, lists who is connected to each port, and
probes the Azure managed identity. Paste `CAPTURE-REPORT.txt`, the Prometheus export report and the
Grafana `SUMMARY` block. Nothing else has to leave the server.

`-Mode Export` captures:

- `prometheus.yml` verbatim
- every file_sd target JSON and rule file the config references, resolved relative to the config
- the service definition including the real binary and flags, read out of the NSSM registry values
  when NSSM wraps it
- the live target list with per target health, to `targets.csv`
- **the complete metric family list**, to `metric-names.txt`

That last file is the acceptance baseline. A dashboard panel goes blank when the metric family behind
it stops existing, so diffing that list is what actually predicts breakage.

Copy `C:\Migration\promcapture-*` and the server capture folder to the new server.

## Step 2. Build the new server

Same drive letters, same paths. `D:\Win\Apps\`, `D:\Win\Ops\`. Do not reinstate SMB1 or PowerShell v2.

Install at the versions the capture recorded. Then:

```powershell
.\suite\Compare-ServerBaseline.ps1 -CaptureFolder C:\Migration\capture-SRVCRE1APPOPS01-<stamp>
```

Must return GO before you go further.

## Step 3. Install the exporter

```powershell
.\suite\Repair-MonitoringHost.ps1 -Apply
```

`collector.textfile.directories` is a YAML **list**, not a scalar. If the service will not start, this
script parses the binary's own stderr and names the collector it rejected. The Service Control Manager
will not tell you. Note `cs` was removed from windows_exporter and its metrics moved to `cpu_info` and
`memory`, so `cs` in the enabled list stops the service dead.

## Step 4. Place the Prometheus config

```powershell
.\Migrate-PrometheusConfig.ps1 -Mode Import -CaptureFolder C:\Migration\promcapture-<...> -AddRenameBridge
```

Read the report, then re-run with `-Apply`.

It places `prometheus.yml` and every referenced target and rule file, backing up anything it replaces.
It flags any target JSON that names the old server, without blanket replacing it, because during a
parallel run the old box is a legitimate target of itself and you have to decide per entry.

**It does not rewrite the YAML.** PowerShell has no dependable YAML parser and text surgery on YAML
produces files that load and mean something different. It shows you the `metric_relabel_configs` block
and where it goes. You add it under each windows_exporter scrape job by hand. Then Prometheus
validates it by refusing to start, which is the only validator that counts.

```powershell
Restart-Service <prometheus service>
Start-Sleep 10
Invoke-WebRequest http://localhost:9090/-/healthy -UseBasicParsing
```

## Step 5. Start the parallel run and write down the time

Both instances now scrape the same targets. The new TSDB starts accumulating.

**Record the start time.** The earliest safe cutover is that time plus the retention window, which the
export recorded from the service flags.

## Step 6. Move the Grafana content

```powershell
.\Import-GrafanaContent.ps1
```

Point the new Grafana's Prometheus datasource at its own local instance, not the old one. Then check
every datasource tests green and no panel is blank that is populated on the old server.

## Step 7. Move the scheduled tasks

Copy the script trees to a staging folder **outside** the live root:

```powershell
robocopy \\SRVCRE1APPOPS01\D$\Win\Ops D:\Win\_CRE-source /E /COPY:DAT /R:1 /W:1 /NFL /NDL
```

`/COPY:DAT`, not `/COPYALL`. Source ACLs bring across entries naming the old server's local groups and
that environment's SIDs, which arrive as unresolved SIDs and can lock the service account out of its
own folder.

Then import. This is a straight lift onto a host with no competing task set, so both suffixes blank:

```powershell
.\Import-CrossEnvTasks.ps1 -TasksFolder C:\Migration\capture-SRVCRE1APPOPS01-<stamp>\tasks `
    -SourceEnv CRE -TaskSuffix '' -PromSuffix '' `
    -ScriptsRoot 'D:\Win\Ops' -StagingRoot 'D:\Win\_CRE-source' `
    -SourceHost SRVCRE1APPOPS01
```

Dry run first. Everything registers disabled. Enable one at a time and judge each on its output, never
on its state: several feeders on this estate are long running by design and sit at `Running` for ever
while working correctly.

```powershell
.\suite\Test-MonitoringHost.ps1 -CaptureFolder C:\Migration\capture-SRVCRE1APPOPS01-<stamp> `
    -PrometheusUrl http://localhost:9090 -GrafanaUrl http://localhost:3000
.\Test-PromFiles.ps1
```

One malformed `.prom` file makes the exporter reject that file whole and sets
`windows_textfile_scrape_error` to 1. wmi_exporter 0.4.3 tolerated it. The current version does not.

## Step 8. The cutover gate

Run this during the parallel run, and again immediately before the DNS repoint:

```powershell
.\Migrate-PrometheusConfig.ps1 -Mode Compare `
    -OldUrl http://SRVCRE1APPOPS01:9090 -NewUrl http://localhost:9090
```

It returns GO or NO-GO on three checks:

| Check | Blocker when |
|---|---|
| Scrape targets | A target up on old is down or missing on new |
| Metric families | A family exists on old and has no counterpart on new, allowing for the `wmi_` to `windows_` rename |
| Canary values | Target counts, job counts or textfile counts diverge beyond tolerance |

A target up on old and down on new is almost always the inbound 9182 rule on that host still naming
the old Prometheus IP. Fix the firewall, not the config.

Head series is **expected** to differ during a parallel run because the new TSDB is younger. The
script says so rather than failing you for it.

Do not book the repoint until this returns GO. Run it again on the day, because a firewall rule or a
target file can change between the decision and the window.

## Step 9. Repoint and observe

Repoint the DNS alias. Confirm from a client:

```powershell
Resolve-DnsName grafana.<domain>
Clear-DnsClientCache
```

Leave the old server running and untouched for 14 days. Then stop the services. Stop them, do not
uninstall. A powered off server that can come back is worth more than a tidy one that cannot.

---

## Verified before shipping

`-Mode Compare` was run end to end against two mock Prometheus instances with deliberately divergent
data. It correctly identified a target that regressed from up to down, a target missing from the new
config entirely, a metric family with no counterpart, and counted three `wmi_` to `windows_` renames
as renames rather than losses. Against a matching pair it returned GO with no false positives.

---

## Findings from the old server run, 02/09/2026

Scripts 1 to 4 were run on `SRVCRE1APPOPS01`. Script 1 was v1.0 and misread the two NSSM wrapped
services, so its Grafana and Prometheus sections are wrong (version shown as the NSSM banner, home
shown as `D:\Win\Apps`, config not found, TSDB 0 B, no targets). v1.1 reads the real binary and flags
from `HKLM:\SYSTEM\CurrentControlSet\Services\<name>\Parameters`. Re-run script 1 before the capture
folder is used for `6_Compare-ServerBaseline`.

### Check first

- `AD-Domain-Services` is an installed feature. Run
  `(Get-CimInstance Win32_ComputerSystem).DomainRole` before anything else. 4 or 5 means the box is a
  domain controller and this is not a monitoring server migration until that is understood.
  0 to 3 means the feature is installed but unused and can be ignored.

### Grafana

- Grafana Enterprise 10.4.19, not OSS. Check the licence binding before assuming the new host can run
  Enterprise. Server Admin, Statistics and licensing, note the licensed hostname and expiry.
- Listens on 9091. That is why PROD's datasource points at `srvcre1appmon01:9091`. That target is a
  different host and still has to be traced.
- Real config is `D:\Win\Apps\Grafana\conf\custom.ini`. Service wrapper is
  `D:\Win\Apps\svc-10.4.19.0\nssm.exe`.
- `D:\Win\Apps\Grafanabackup\` is a second copy. Do not migrate it. Record it and leave it on the old box.
- Export: 3 datasources, 6 folders, 34 dashboards, 1 legacy notification channel, 1 unified rule.
  410 queries, 168 empty, 250 referencing metrics that do not exist on this Prometheus, 1 critical,
  4 serious, 4 API failures. `ANALYSIS.md` in the export folder lists them and has to be read before
  the import.
- Azure Monitor datasource authenticates with the VM's system assigned managed identity. Display name
  is the VM name. See the managed identity section below.
- A developer is editing dashboards in this Grafana now. Use Route B for CRE: stop Grafana, copy
  `grafana.db`, start Grafana, same version on both sides. That keeps version history, users and API
  keys and takes under a minute of interruption. If Route A (JSON export) is used instead, re-run
  `3_Export-GrafanaContent` immediately before the import, not days before.

### Prometheus

- NSSM wrapped. Config `D:\Win\Apps\Prometheus\prometheus.yml`. No retention flag, so 15 days. No
  TSDB path flag, so `D:\Win\Apps\Prometheus\data`. Parallel run is therefore 15 days minimum.
- 2 static jobs plus 2 file_sd jobs (`wmi`, `XperidoDocProd`). Target files `manualServers.json` and
  `octopusWMIServers.json`.
- 12 targets, 3 up, 9 down. Of the 9: `SERVERURL1:PORT` and `SERVERURL2:PORT` are literal
  placeholders, 6 hosts do not resolve in DNS, and `srvcre1appmon01.foscre.org.uk:9182` refuses
  connections. The last one is the CRE feeder host and is a real fault that predates the migration.
  Fix or record it before the gate is run, otherwise `13_Test-CutoverGate` compares against a broken
  baseline.
- 373 metric families, 154 `wmi_*`. The rename bridge is required.

### Scheduled tasks

- 3 tasks, all disabled, all under personal accounts: `Compass` (`FOSCRE\e-sadegunle`, 0x8007010B),
  `DataEraser` (`FOSCRE\rkumar2`, 0xE0434352), `SmartFirm` (`FOSCRE\e-egentleman`).
  Register entries, not migration items. `FOSCRE\rkumar2` holds SeBatchLogonRight by name on the old
  box. Do not carry that grant across.
- No Grafana or Prometheus feeder tasks on this box. Nothing from `7_` step onward depends on tasks
  for CRE APPOPS.

### Host

- Two business certificates with private keys: `CN=efileapi.financial-ombudsman.org.uk` (expires
  2027-02-07) and `CN=efileapi-stg.financial-ombudsman.org.uk` (expires 2026-12-27). Find what uses
  them before the old box is stopped. If nothing on the new host needs them, do not export them.
- WinHTTP proxy `internet.fosnpe.org.uk:8080`. Carries across, and IMDS must bypass it.
- SMB1 enabled on the old box. Do not enable on the new one.
- Azure CLI, Azure PowerShell, SSDT, SSIS, ShareGate, UMRA are installed. Developer tooling, out of
  scope for the monitoring lift. Confirm with the developer whether any of it is used from this box.
- `D:\Win\Ops\WMITextfileExport` holds an 81 MB file from 2019. Do not copy it.
- `4_Test-PromFiles` clean.

### Managed identity for the App Insights datasource

The system assigned identity dies with the VM. Use a user assigned identity for the parallel run:

1. Create a user assigned managed identity in the same subscription and resource group as the App
   Insights resource. Name it for the function, not the server, for example `mi-grafana-cre`.
2. Grant it the same roles the old VM's identity has on the App Insights resource and its Log
   Analytics workspace (`Monitoring Reader` is the usual one; read the old identity's assignments
   first and copy them).
3. Attach it to the old VM and the new VM. Both VMs then hold it for the whole parallel run.
4. On the new Grafana, set the Azure Monitor datasource to Managed Identity. In `custom.ini` under
   `[azure]`: `managed_identity_enabled = true` and `managed_identity_client_id = <client id of the
   user assigned identity>`. Without the client id Grafana asks IMDS for the system assigned one.
5. IMDS is `169.254.169.254`. Add it to the proxy bypass list on the new host or the token call goes to
   `internet.fosnpe.org.uk:8080` and fails. Check with
   `Invoke-RestMethod -Headers @{Metadata='true'} -Uri 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https://management.azure.com/' -NoProxy`.
6. Test the datasource in Grafana. Then repoint. The developer's dashboards need no change because
   the datasource uid is preserved by both routes.
7. Repeat per environment. Each APPOPS lift gets its own user assigned identity.

### Octopus and the fleet exporters

Octopus pushed wmi_exporter 0.4.3 to every scrape target in 2018. Decision: leave the fleet as is.

- Nothing in this lift touches the target servers. Prometheus pulls from them and the rename bridge
  translates `wmi_*` to `windows_*` at scrape time.
- Only the new monitoring hosts get windows_exporter, through `7_Repair-MonitoringHost.ps1`.
- Re-rolling the fleet is the BAU upgrade tranche, not this change.
- One check is required now: open the 2018 Octopus project and confirm its target list or role does
  not include the new monitoring hosts. If a later deploy of that project could land wmi_exporter
  0.4.3 on `vmcreappops01` (or whatever the new name is), it would overwrite windows_exporter on 9182
  and the new host would silently regress. Exclude the new hosts from the role, or disable the step.
