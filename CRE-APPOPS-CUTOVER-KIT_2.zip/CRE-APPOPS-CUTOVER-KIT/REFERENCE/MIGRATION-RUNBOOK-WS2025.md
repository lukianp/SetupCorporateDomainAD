# Moving the monitoring estate onto fresh Windows Server 2025 shells

Version 1.0 — 2026-08-10. Source of truth: the consolidated discovery report (`EstateTopology.html`,
9 servers, 0 integrity issues).

This is the build-and-cutover runbook. It assumes brand-new Windows Server 2025 servers with
nothing on them, and that everything the old servers do has to keep working afterwards.

---

## The one decision to make before anything else: move first, upgrade second

The versions in use are old enough that "move it" and "upgrade it" are two genuinely different
projects:

| Component | Running today | Current | Status |
|---|---|---|---|
| Grafana | 10.4.19 | 13.1.3 | 10.4 security support **ended June 2025** |
| Prometheus | 2.8.1 (CRE, SYS), **2.4.3** (PROD) | 3.13 LTS | both are pre-3.x |
| windows_exporter | **0.4.3** (still branded `wmi_exporter`) | 0.31.7 | predates the metric rename |

**Do the move as a like-for-like lift, then upgrade as a separate tranche.** Grafana and Prometheus
are both single static Go binaries with no OS dependencies, so the versions you run today will run
on Server 2025 unchanged. If you move and upgrade in one step and a dashboard comes up blank, you
will not be able to tell whether the server move or the version jump caused it — and with 25 GB of
production history at stake, that is not a debugging session anyone wants.

The one place this rule cannot hold is the exporter. See step 5.

---

## Step 0 — Three things to settle before a single server is built

**0.1 Find out what alerts today.** This is the largest remaining unknown, and it is the thing most
likely to fail silently after cutover. Re-run `Discover-MonitoringServer.ps1` v0.9.0 on
`SRVCRE1APPOPS01`, `SRVSYS1APPOPS01` and `SRVFOSAPPOPS01`. v0.8.0 could not open `grafana.db` while
Grafana was running, so the previous report's "no alerting configured" is a blank, not a finding.

**0.2 Alertmanager — resolved 2026-08-17: not in use.** The live PROD Prometheus config has an
empty alertmanager target list; the `alertmanager:9093` line in `prometheus.yml` is the
commented-out stock example (earlier "does not resolve — critical" finding withdrawn; discovery
0.11.1 ignores comments). Grafana legacy alerting is the only alerting engine, so the item to
carry is the legacy → unified alerting conversion (see DASHBOARDS-GOLD-STANDARD.md §4), not an
Alertmanager move.

**0.3 Get service accounts created.** 22 scheduled tasks run with a stored password. Windows never
exports those passwords — not in the task XML, not anywhere. Each one has to be re-entered by hand
on the new server, or replaced with a group managed service account (gMSA), which is the better
answer because it removes the re-entry step permanently. Three accounts are involved:
`fostst\svcCRMMonitoringSTG`, `fostst\svcCRMMonitoringPRV`, and `FOSCRE\e-sadegunle` — that last one
is **a named person's account running a production monitoring feed** (`\ops\Compass site check`).
Fix that as part of this work; it will not survive them leaving the company.

---

## Step 1 — Build the shells

Build seven servers. The old estate is nine, but `SRVCREAPPMON01` has nothing on it at all and is a
decommission candidate rather than a migration, and STG has no Grafana or Prometheus to move.

| New server | Replaces | Role |
|---|---|---|
| CRE monitoring | `SRVCRE1APPOPS01` | Grafana + Prometheus + exporter + 3 tasks |
| SYS monitoring | `SRVSYS1APPOPS01` | Grafana + Prometheus + exporter + 3 tasks |
| PROD monitoring | `SRVFOSAPPOPS01` | Grafana + Prometheus + exporter |
| CRE exporter host | `SRVCRE1APPMON01` | exporter only |
| STG exporter host | `SRVSTG1APPMON01` | exporter + 9 tasks (4 feed monitoring) |
| SYS exporter host | `SRVSYS1APPMON01` | exporter + 8 tasks (4 feed monitoring) |
| STG / TRN task hosts | `SRVSTG1APPOPS01`, `SRVTRNAPPOPS01` | 1 task each |

On each shell:

1. Join the domain, into the same AD site and subnet as the server it replaces.
2. **Create the same drive letters and the same folder paths.** The estate uses `D:\Win\Apps\...`
   and `D:\Win\Ops\...`. Reproducing those exactly removes an entire category of work: every
   scheduled task XML, every service definition and every script path then imports unedited. This
   is the single highest-value thing on this list.
3. Install NSSM (or WinSW) — Grafana and Prometheus have no native Windows service, and every
   service in the estate today is NSSM-wrapped.
4. Confirm Windows PowerShell 5.1 is present. Every scheduled task script targets it
   (`C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe`).
5. Set the PowerShell execution policy the task scripts need, and copy across any code-signing
   trust they rely on.
6. Register the new server with Octopus Deploy (`Tentacle.exe` was observed talking to
   `10.51.3.18:10943`) on the same environment and roles. Deployments do not follow a rebuild.
7. Add the new server to the backup policy. Backup agents were observed (`s2RCM.exe`,
   `svagentsRCM.exe` to `:443`) and backup coverage never follows a rebuild automatically.
8. If the server it replaces is in a DFS replication group (`dfsrs.exe` traffic was observed), add
   the new server to that group. Copying the files is not the same as joining the replication.
9. Reissue certificates. The old ones do not travel.

**Do not** install Grafana or Prometheus from a fresh download expecting to configure them by hand.
Both are lifted from the old server in steps 3 and 4.

---

## Step 2 — Open the firewalls first, and leave them open

This is the step that gets missed, and it is the one that causes a silent monitoring outage.

Each Prometheus reaches out to every exporter it scrapes. From `firewall-worklist.csv`:

- PROD (`SRVFOSAPPOPS01`) scrapes **25** host:port pairs
- SYS (`SRVSYS1APPOPS01`) scrapes **20**
- CRE (`SRVCRE1APPOPS01`) scrapes **8**

**Add the NEW server's IP to every one of those exporter firewalls before cutover, and leave the old
server's IP in place until the old server is decommissioned.** Both must be allowed at once, because
the Prometheus migration runs the two side by side (step 4).

106 hosts are referenced by the estate but have never been discovered, about 50 of them exporter
hosts on `:9182`. The monitored estate is roughly 60 servers, not 9. `firewall-worklist.csv` is the
real worklist — treat it as the deliverable for the network team, and get it moving early because it
is the longest-lead item in this whole plan.

---

## Step 3 — Carry Grafana forward

Grafana is small, stateful and easy — as long as two files move together.

1. Install the **same version, 10.4.19**, to the same path on the new server.
2. Stop the Grafana service on the old server.
3. Copy **both** of these, together, in the same operation:
   - `data\grafana.db` — the entire Grafana state: dashboards, datasources, users, alert rules,
     contact points
   - `conf\grafana.ini` — including the `[security] secret_key`
4. Copy `data\plugins\` and `conf\provisioning\` as well.
5. Start Grafana on the new server. Do not let it generate a new config.

**Why both files must move together.** Grafana encrypts datasource passwords and alert-channel
secrets using `secret_key` from `grafana.ini`. Move the database without the matching key and every
datasource comes up unable to authenticate, with no obvious error. All three servers are currently
running the **default** `secret_key`, which means a fresh install would happen to work — but do not
rely on that. Copy the file. (Separately: rotating that key off the default is worth doing after the
migration settles, as its own piece of work.)

6. **Set `root_url`.** None of the three Grafanas has it set, so alert and panel links currently
   contain the machine name. On the new server set it to the DNS alias, not the new machine name, or
   every link in every alert email will point at a server nobody can reach after the next move.
7. `SRVFOSAPPOPS01` (PROD) has **two** Grafana installs — `Grafana` (running) and `Grafana-9.4`
   (stopped). Confirm which data directory belongs to the running service before you copy anything,
   and decide explicitly whether 9.4 comes across or gets left behind.
8. All three have the image renderer present. Migrate the renderer service or plugin too, or
   emailed alert screenshots stop rendering.

---

## Step 4 — Carry Prometheus forward (parallel run, age out)

This is the approach already agreed, and Server 2025 does not change it.

1. Install the **same Prometheus version** on the new server — 2.8.1 for CRE and SYS, 2.4.3 for
   PROD. (Yes, PROD is the oldest. Normalising versions is an upgrade decision, not a move
   decision.)
2. Copy `prometheus.yml` and every file in `rule_files` across unchanged.
3. **Start the new Prometheus with an empty TSDB and let it run alongside the old one.** Both scrape
   the same targets. This is why step 2 has to allow both IPs.
4. Leave them both running for the length of your retention window. The new server accumulates
   history while the old one still holds it.
5. Take a snapshot of the old TSDB (`/api/v1/admin/tsdb/snapshot`) before cutover and keep it. It is
   your rollback and your archive — it is not part of the normal path.
6. At cutover, repoint the DNS alias and repoint the Grafana datasource.

The three TSDBs are 3.57 GB (CRE), 8.86 GB (SYS) and 25.44 GB (PROD). The parallel run means you
never have to copy any of that under time pressure.

---

## Step 5 — Carry the exporters forward, and mind the metric rename

**This is the one place where "move without upgrading" is not available, and it will break
dashboards if it is not handled.**

The estate runs `wmi_exporter` **0.4.3** — a 2018 build, from before the project was renamed. Every
scrape job in the estate is literally called `wmi`, and every metric is named `wmi_*`. The current
exporter is `windows_exporter` 0.31.7, and **v0.13.0 renamed every metric prefix from `wmi_` to
`windows_`.** Its documented support floor is Windows Server 2016 and later.

So: a fresh Server 2025 shell realistically needs a current exporter, and a current exporter emits
metric names that no existing dashboard panel or alert rule refers to. Every panel goes blank at
once and it looks exactly like the migration broke monitoring.

The bridge is to rename the metrics back on ingest. Add this to each scrape job in `prometheus.yml`
on the new servers:

```yaml
    metric_relabel_configs:
      - source_labels: [__name__]
        regex: 'windows_(.*)'
        target_label: __name__
        replacement: 'wmi_${1}'
```

New exporters then land in the TSDB under the old names, existing dashboards and alert rules keep
working, and history stays continuous. Renaming the dashboards properly becomes a scheduled piece of
follow-up work rather than a cutover emergency, and you remove the relabel rule at the end of it.

Before committing to this, **test exporter 0.4.3 on one Server 2025 box** (use SYS, not PROD). It is
an eight-year-old binary reading WMI classes from a much older Windows. If it happens to work you
have the option of a pure like-for-like move; if it does not, the relabel bridge above is the plan.

---

## Step 6 — Carry the scheduled tasks forward

The tasks are not an afterthought here: **9 tasks across 3 servers produce monitoring data** that
ends up on Grafana dashboards. They are as much a part of the monitoring estate as Prometheus is,
and they must keep running throughout.

25 tasks are migration-relevant (47 Microsoft and per-user tasks were excluded as noise).

1. Import the exported task XML on the new server (`Register-ScheduledTask -Xml`). The discovery
   package contains one per task, plus a generated `Restore-ScheduledTasks.ps1`.
2. Copy the scripts each task calls, to the same paths. Under `D:\Win\Ops\...`: the
   `AdhocServiceMetricsExporter`, `PhoenixConfigExporter` (sanitation and self), and
   `PhoenixD365MetricsExporter` trees.
3. **Re-enter 22 passwords, or move those tasks to a gMSA.** No password comes across in the XML.
4. Grant the target's service accounts access to the file shares the tasks use. Four tasks reach
   UNC paths: `\\SRVSTG1APPFIL01\Filestore`, `\\srvsys1appfil01\Filestore`,
   `\\srvoat1appfil01\Filestore`.
5. **13 tasks last finished in a FAILED state. Do not migrate them broken.** Decide per task: fix it
   or retire it. Moving a failing task to a new server just moves the failure somewhere less
   familiar.
6. **7 tasks are disabled.** Decide whether they migrate at all — a disabled task is often something
   nobody wanted to be the one to delete.
7. Confirm the textfile output directory (`D:\Win\Ops\WMITextfileExport`) exists on the new server
   and that the exporter is configured to read it. This is the path the metrics-producing tasks
   write into; if it is missing, the tasks succeed and the metrics silently never appear.

---

## Step 7 — Cutover, in this order

Run one environment end to end before starting the next. **CRE first** — it has the smallest TSDB
(3.57 GB), the fewest scrape targets (8) and no production impact. Then SYS, then STG's task and
exporter hosts, then PROD last.

Per environment:

1. Confirm the new Prometheus has been running in parallel for a full retention window and its
   target list shows all targets UP.
2. Confirm the new Grafana loads every dashboard and every datasource tests green.
3. **Prove one alert end to end.** Fire a test alert from the new server and confirm it arrives —
   in the inbox, in the channel, wherever it is meant to land. This is the single most important
   verification step in the entire migration. SMTP relays and webhook receivers routinely allowlist
   the sending IP, so a new server can be scraping perfectly and monitoring correctly while nobody
   is being told about anything. Nothing about the configuration looks wrong when this fails.
4. Repoint the DNS alias.
5. Watch for one full business cycle, including overnight — several scheduled tasks only run
   overnight and will not have exercised anything until then.
6. Stop the services on the old server, but leave it powered on and its firewall rules in place for
   a rollback window.
7. Only then decommission, and remove the old IPs from the exporter firewalls.

---

## Step 8 — The upgrade tranche (separate piece of work)

Once all seven servers are running on Server 2025 and stable, upgrade as its own project:

- **Prometheus 2.x → 3.13 LTS.** Going through 2.55 first is the documented TSDB gate. Under the
  parallel-run approach there is an easier option: the replacement instance can simply start fresh
  on 3.13 LTS and age in, because you are not carrying the data files across.
- **Grafana 10.4.19 → 13.x.** Grafana has no LTS; only the latest version and one or two behind get
  fixes. 10.4 has had no security support since June 2025, so this is a security item, not just
  housekeeping. Grafana 12 removed Angular plugin support entirely — run discovery with
  `-GrafanaToken <viewer token>` first to find out how many dashboards use Angular panels, because
  that number decides how big this job is. Back up `grafana.db` before every step.
- **windows_exporter → 0.31.x** across the estate, then rename dashboards and alert rules from
  `wmi_*` to `windows_*` and remove the relabel bridge from step 5.

---

## Still open

1. **STG's Grafana and Prometheus have never been found.** Neither STG box runs them. Five
   `*appmon01` servers are referenced by scrape configs but have no discovery package —
   `srvfosappmon01`, `srvcre2appmon01`, `srvfoskfxmon01`, `srvoat1appmon01`, `srvtrnappmon01`. Run
   discovery there next; the missing fourth instance is most likely one of them.
2. **OAT and TRN are in the estate** (`srvoat1appmon01`, `SRVTRNAPPOPS01`) but were never in the
   original scope of four environments. Confirm whether they are in or out.
3. **Grafana service-account tokens** (Viewer role is enough) for all three servers. Without them
   the dashboard Angular scan cannot run, and that number sizes the Grafana upgrade.
4. **106 undiscovered hosts.** Everything in step 2 depends on that list being right.

---

## Sources

- [Grafana end-of-life dates (endoflife.date)](https://endoflife.date/grafana)
- [Prometheus end-of-life dates (endoflife.date)](https://endoflife.date/prometheus)
- [windows_exporter (prometheus-community)](https://github.com/prometheus-community/windows_exporter)
- [Migrating from wmi_exporter to windows_exporter — Grafana community](https://community.grafana.com/t/migrating-from-prometheus-wmi-exporter-to-windows-exporter/32238)
- [Strategies for upgrading self-managed Grafana](https://grafana.com/docs/grafana/latest/upgrade-guide/when-to-upgrade/)
