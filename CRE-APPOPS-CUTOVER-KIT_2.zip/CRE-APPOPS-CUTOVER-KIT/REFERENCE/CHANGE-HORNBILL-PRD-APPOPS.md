# Hornbill change request: PROD monitoring platform lift and shift to Windows Server 2025

Copy each block into the matching Hornbill field. Placeholders in `<angle brackets>` need your
values. Written 2026-08-28.

Source server: `SRVFOSAPPOPS01` (fos.org.uk). Target server: `vmfosappmon01`.

This change moves Grafana, Prometheus and the Grafana related scheduled tasks. `SRVFOSAPPOPS01` is
decommissioned after the rollback window closes.

---

## Summary (one line)

Lift and shift of the production monitoring platform (Grafana 10.4.19, Prometheus 2.4.3, 39
scheduled tasks) from SRVFOSAPPOPS01 to a new Windows Server 2025 host vmfosappmon01, using a
parallel run and a DNS repoint, with no software version changes.

## Change type / category

Normal change (CAB approved). Production. High risk.

## Description

`SRVFOSAPPOPS01` is the production monitoring platform. Discovery established what it hosts:

- **Grafana 10.4.19**, running as a service, serving the production dashboards.
- **A second, stopped Grafana install** (`Grafana-9.4`) alongside the running one. Copying the wrong
  data directory migrates a dead database.
- **Prometheus 2.4.3** with a **25.31 GB** TSDB. This is a 2018 release and is the oldest Prometheus
  in the estate. CRE and SYS run 2.8.1.
- **windows_exporter (wmi_exporter 0.4.3)** on :9182, so this server is itself a scrape target.
- **26 scrape endpoints**, of which 25 have never been discovered. The estate wide endpoint census
  found 20 dead endpoints and 17 with no DNS.
- **39 real scheduled tasks**: 31 hold stored passwords, 13 are disabled.
- **A cross domain Grafana datasource** pointing at `srvcre1appmon01.foscre.org.uk:9091`, so
  production dashboards depend on a CRE host.
- **Legacy Grafana alerting**, not unified alerting. Alert definitions exist in the database.
  `alertmanager:9093` is present in the Prometheus config but commented out.
- **No `root_url` set**, so links in alert emails point at raw machine names.

Prometheus operates by **pull**. It reaches out to every monitored host on :9182. Nothing is pushed.
Moving Prometheus to a new IP address therefore affects every monitored host, not just this one.
That is the dominant risk in this change and it drives the sequencing below.

Software versions do not change in this change. Grafana stays on 10.4.19 and Prometheus stays on
2.4.3. The version upgrade is a separate tranche documented in `UPGRADE-PATH.md`. One exception is
forced: wmi_exporter 0.4.3 is not supported on Windows Server 2025 and its supported replacement
renames every metric from `wmi_*` to `windows_*`. A compatibility rule absorbs this.

## Reason for change

End of support Windows Server OS. The 2018 era metrics agent is unsupported on current Windows.
Final server in the monitoring migration programme. The four APPMON feeder hosts have already
migrated and proved the task migration method.

## Impact assessment

**Business services: none.** This platform monitors business services. It does not serve them.

**Monitoring visibility during the parallel run: none.** The old server stays authoritative and
keeps scraping throughout Phases 1 and 2. The new server runs alongside it.

**Monitoring visibility at cutover:** the DNS repoint switches users to the new Grafana. Dashboards
served by the new instance show history only from the date the new Prometheus started scraping.
Anyone looking back beyond that window must use the old server, which stays powered for 14 days.

**Users affected:** everyone who opens a production dashboard, at the moment of the DNS repoint.
The change is visible to them only as a shorter history window.

**Alert delivery:** legacy Grafana alerting is carried across. Alert rules move with the Grafana
content. Notification channels must be verified individually because a channel that fails silently
looks identical to a channel with nothing to report.

**The 39 scheduled tasks:** 13 are already disabled. The remaining 26 pause at their cutover and
resume on their next scheduled run.

## Risk assessment

**High.** This change moves the component that every other server and every dashboard user points
at. Controls, in order of the damage they prevent:

1. **Fleet wide firewall dependency.** Every monitored host has an inbound rule on :9182. Any rule
   scoped to the old server's IP address stops matching when Prometheus moves, and that target goes
   down. This affects up to 103 referenced hosts. The survey is Phase 0.2 and it gates the change
   date. If the rules are GPO managed this becomes a separate change request with its own lead time.
2. **Hostname references across the estate.** Bookmarks, alert notification links, embedded panels,
   scripts calling the Prometheus API and any other Grafana's datasource all name this server. A DNS
   alias put in place before the move (Phase 0.3) reduces this to one change with a one minute
   rollback. Without it, every reference must be found by hand and some will be missed.
3. **The wrong Grafana data directory.** Two Grafana installs exist on the box. Phase 0.7 identifies
   the running service's data directory by reading the service definition, not by assuming.
4. **Prometheus 2.4.3 on Server 2025.** A 2018 Go binary has not been validated on this OS. Phase
   1.2 proves it starts and scrapes before anything depends on it. If it does not start, the
   decision to hold the version is revisited before the window, not during it.
5. **Metric rename.** wmi_exporter 0.4.3 to windows_exporter renames every metric. The compatibility
   rule is in place on the new server before the first dashboard is opened against it.
6. **Cross domain datasource.** Production dashboards read from `srvcre1appmon01.foscre.org.uk:9091`.
   Port 9091 is the Pushgateway default. Phase 0.9 establishes what actually listens there and
   whether the new server can reach it across the domain boundary.
7. **Stored passwords.** 31 tasks hold passwords Windows never exports. Each is re entered or moved
   to a gMSA. `Set-ScheduledTask` drops a stored password unless the credential is supplied again,
   so tasks are re registered from XML, not patched in place.
8. **Personal account in production.** `CaseCount2018`, `CaseCount2019` and `CaseCount2020` run as
   `SOUTH-QUAY\e-sadegunle`, a named individual in a third domain. Phase 0.6 replaces this.
9. **Silent failure.** Acceptance is current data on a production dashboard. It is never "the
   service started" and never "the task shows Running".

## Affected configuration items

- `SRVFOSAPPOPS01` (migrated, then decommissioned after the rollback window)
- `vmfosappmon01` (new WS2025 host)
- DNS: new alias records for Grafana and Prometheus, repointed at cutover
- Firewall: inbound :9182 rules on every monitored host that scopes by source IP
- Firewall: inbound :3000 (Grafana) and :9090 (Prometheus) on the new host
- `srvcre1appmon01.foscre.org.uk` (cross domain datasource dependency, no change made to it)
- Every `*APPMON*` host currently scraped, as a scrape target definition
- CMDB: new CI for `vmfosappmon01`; CI class correction on the old server if it is recorded wrongly

---

# Implementation plan

## Phase 0: pre implementation

No service impact. Nothing in this phase touches the running platform. **The window is not booked
until every step here is complete and recorded on the change.**

### 0.1 Capture the old server

Run on `SRVFOSAPPOPS01`:

```powershell
.\suite\Invoke-ServerCapture.ps1
```

This produces a report and a manifest under `C:\Migration\`. Every later phase reads from it. Attach
the report to the change record.

### 0.2 Firewall survey across the monitored fleet

**Start this first. It has the longest lead time and it gates the change date.**

Run on each monitored host, or centrally against the host list in `firewall-worklist.csv`:

```powershell
Get-NetFirewallRule -Enabled True -Direction Inbound |
  Where-Object { ($_ | Get-NetFirewallPortFilter).LocalPort -eq 9182 } |
  ForEach-Object {
    [pscustomobject]@{
      Host   = $env:COMPUTERNAME
      Rule   = $_.DisplayName
      Remote = ($_ | Get-NetFirewallAddressFilter).RemoteAddress -join ','
      Action = $_.Action
      Policy = $_.PolicyStoreSourceType     # Local or GroupPolicy
    }
  }
```

Sort the results into three buckets:

| Result | Action |
|---|---|
| `RemoteAddress = Any` | None. The move is transparent for that host. |
| Old server IP only | Add the new server IP before cutover. Remove the old one after decommission. |
| Subnet containing both | Confirm the new IP is inside it. Then none. |

`PolicyStoreSourceType = GroupPolicy` on any host means this is a GPO change with its own approval
path. Raise it the day you find it.

Record the count in each bucket on the change. If the "old server IP only" bucket is not empty, the
rules must be added and verified before Phase 3.

### 0.3 DNS aliases

Request two CNAME records now:

```
grafana.<domain>      -> SRVFOSAPPOPS01     (repointed to vmfosappmon01 at cutover)
prometheus.<domain>   -> SRVFOSAPPOPS01     (repointed to vmfosappmon01 at cutover)
```

Set the TTL to 300 seconds at least 24 hours before the cutover window so the repoint takes effect
quickly and the rollback is equally quick.

Then move users onto the alias before the migration. Publish the alias, update documented links, and
leave the old hostname working. This is what turns an estate wide hunt into a single DNS change.

Sweep for hardcoded references:

```powershell
Get-ChildItem D:\Win, C:\scripts -Recurse -Include *.ps1,*.json,*.config,*.yml,*.yaml,*.md -EA 0 |
  Select-String -Pattern 'SRVFOSAPPOPS01' -SimpleMatch -EA 0 |
  Select-Object Path, LineNumber, Line
```

Run the same sweep on the CRE and SYS monitoring servers. A datasource in another Grafana pointing
at this one will not appear in any local search.

### 0.4 Confirm versions and record them

On `SRVFOSAPPOPS01`:

```powershell
# Grafana: which install is the RUNNING one
Get-CimInstance Win32_Service | Where-Object { $_.Name -match 'grafana' } |
  Select-Object Name, State, StartMode, PathName

# Prometheus
Get-CimInstance Win32_Service | Where-Object { $_.Name -match 'prometheus' } |
  Select-Object Name, State, StartMode, PathName
```

Write both version numbers and both binary paths onto the change record. The new server is built to
match these exactly.

### 0.5 Task triage

39 tasks is too many to move without a decision on each. Produce the list:

```powershell
Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\Microsoft*' } | ForEach-Object {
  $i = $_ | Get-ScheduledTaskInfo
  $a = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' | '
  [pscustomobject]@{
    Task        = $_.TaskName
    Enabled     = $_.Settings.Enabled
    RunAs       = $_.Principal.UserId
    LastRun     = $i.LastRunTime
    LastResult  = ('0x{0:X8}' -f $i.LastTaskResult)
    Placeholder = [bool]($a -match '#\{')
    Action      = $a
  }
} | Sort-Object LastRun | Export-Csv C:\Migration\appops-tasks.csv -NoTypeInformation
```

Classify every row into one of three outcomes and record the outcome and a named owner:

- **Migrate.** Currently working and still wanted.
- **Migrate disabled.** Currently disabled. It moves in its disabled state and is not enabled as
  part of this change.
- **Retire.** Not wanted, or already broken. It does not go to the new server. It is recorded in
  `BROKEN-TASKS-REGISTER.md`.

Anything with `Placeholder = True` holds an unsubstituted Octopus variable and has never run
successfully. Anything with a `LastRun` older than the current release is a register entry, not a
migration item. Nothing migrates broken.

### 0.6 Replace the personal account

`CaseCount2018`, `CaseCount2019` and `CaseCount2020` run as `SOUTH-QUAY\e-sadegunle`. Request a
service account to replace it. A personal account does not go to the new server under any outcome.
If the owner states the tasks are no longer needed, retire them at 0.5 instead.

The same individual also holds `\ops\Compass site check` on `SRVCRE1APPOPS01`. Raise both together.

### 0.7 Identify the Grafana data to move, and decide how

Read the running service definition from 0.4 and locate its data directory. Do not assume the
default path and do not use the `Grafana-9.4` directory.

Decide between two routes and record the decision:

**Route A: content export.** Use `Export-GrafanaContent.ps1` and `Import-GrafanaContent.ps1`. Moves
dashboards, folders, datasources and alert rules. Version independent. Already proved on CRE. Does
not move users, org membership, API keys, dashboard version history, annotations or starred
dashboards.

**Route B: copy `grafana.db`.** Moves everything including the above. Requires Grafana to be stopped
for the copy. The database is only safe onto the same or a newer Grafana version, never older.

Choose Route A unless API keys are in active use by scripts elsewhere, because a reissued key means
finding and updating every consumer. Find out which:

```powershell
Get-ChildItem D:\Win, C:\scripts -Recurse -Include *.ps1,*.json,*.config,*.yml,*.yaml -EA 0 |
  Select-String -Pattern 'Bearer\s+[A-Za-z0-9_=-]{20,}|/api/auth|glsa_' -EA 0 |
  Select-Object Path, LineNumber
```

### 0.8 Prometheus history decision

The programme default is **parallel run with age out**: the new Prometheus starts with an empty TSDB
and accumulates history while the old server keeps running. No 25.31 GB data copy, no outage to copy
it, and the old server stays authoritative until cutover.

Confirm the retention period so you know how long the parallel run must last before the new server
holds a useful window:

```powershell
# read the retention flag from the service definition
(Get-CimInstance Win32_Service | Where-Object { $_.Name -match 'prometheus' }).PathName
```

Record the retention period and set the parallel run duration to match it, or to the longest period
anyone actually queries, whichever is shorter. Take a filesystem snapshot of the TSDB before cutover
as the backup of last resort.

### 0.9 Resolve the cross domain datasource

Production Grafana reads from `srvcre1appmon01.foscre.org.uk:9091`. Establish three things and record
them:

1. What listens on 9091 on that host. Port 9091 is the Pushgateway default, not an exporter port.
2. Which dashboards or panels use that datasource.
3. Whether `vmfosappmon01` can reach that host and port across the domain boundary.

```powershell
Test-NetConnection srvcre1appmon01.foscre.org.uk -Port 9091
```

If the new server cannot reach it, those panels break at cutover and the cause will not be obvious.

### 0.10 Inventory the alerting

The estate runs legacy Grafana alerting, not unified alerting. Extract the notification channels
with discovery v0.10.1 and list, for each channel, who receives it and by what transport. Attach the
list to the change.

Note for the record: legacy alerting is removed in Grafana 11. This change does not upgrade Grafana,
so nothing breaks here. The unified alerting migration is a prerequisite of the later upgrade tranche
and must happen on 10.4 before that tranche starts.

### 0.11 Build the target server

Build `vmfosappmon01` to the build sheet:

- Windows Server 2025, domain joined to `fos.org.uk`
- **Identical drive letters and identical paths.** `D:\Win\Apps\`, `D:\Win\Ops\`. A missing `D:`
  invalidates every task action and every config path at once.
- Roles and features from the capture package script. **Do not reinstate SMB1. Do not reinstate
  PowerShell v2.**
- Platform agents enrolled per standard build
- Sized for 39 scheduled tasks plus Prometheus plus Grafana. The old box carries a 25.31 GB TSDB, so
  size `D:` for the retention period plus headroom.

### 0.12 Preflight

```powershell
.\suite\Compare-ServerBaseline.ps1 -CaptureFolder C:\Migration\capture-SRVFOSAPPOPS01-<stamp>
```

This must return GO before the window is booked. It reports every path, right, account and feature
present on the old server and missing on the new one, with numbered remediation.

---

## Phase 1: build and start the parallel run

No service impact. The old server continues to serve production throughout.

### 1.1 Install windows_exporter on the new server

Install the current windows_exporter on :9182. Create `D:\Win\Ops\WMITextfileExport`.

`collector.textfile.directories` is a **list** in the YAML config, not a scalar. Write it as a list.

```yaml
collectors:
  enabled: cpu,cs,logical_disk,net,os,service,system,textfile
collector:
  textfile:
    directories:
      - D:\Win\Ops\WMITextfileExport
```

If the service fails to start, the Service Control Manager does not say which collector name it
rejected. Run the binary in the foreground to get the real error, or run:

```powershell
.\suite\Repair-MonitoringHost.ps1 -Apply
```

That script parses the binary's own stderr, identifies the rejected collector by name and retries.
Note that the `cs` collector was removed from windows_exporter. Its metrics moved to `cpu_info` and
`memory`. If `cs` is in the enabled list the service will not start.

### 1.2 Install Prometheus 2.4.3 and prove it runs

Install Prometheus at the version recorded at 0.4, to the same path as the old server.

**Prove it starts on Server 2025 before going further.** This binary predates this OS by seven years.

```powershell
Start-Service prometheus
Start-Sleep 10
Invoke-WebRequest http://localhost:9090/-/healthy -UseBasicParsing | Select-Object StatusCode
```

If it does not start or does not stay up, stop. Escalate the version decision to the change owner
before the window. Do not silently substitute a different version during the window.

### 1.3 Install Grafana 10.4.19

Install Grafana at the version recorded at 0.4, to the same path as the old server. Start the
service. Confirm it answers:

```powershell
Invoke-WebRequest http://localhost:3000/api/health -UseBasicParsing | Select-Object -Expand Content
```

Set `root_url` in the Grafana config to the DNS alias from 0.3. The old server has no `root_url`
set, which is why alert email links point at raw machine names. Fixing this on the new server is a
deliberate improvement. Record it on the change so it is not mistaken for a fault later.

### 1.4 Configure scraping on the new Prometheus

Copy the scrape configuration and the file_sd target JSON from the old server. Add the metric
compatibility rule so dashboards querying `wmi_*` keep working against `windows_*`:

```yaml
metric_relabel_configs:
  - source_labels: [__name__]
    regex: 'windows_(.*)'
    target_label: __name__
    replacement: 'wmi_${1}'
    action: replace
```

Confirm the exact form against `MIGRATION-RUNBOOK-WS2025.md`, which carries the version proved on
CRE.

Add `vmfosappmon01` to its own target list.

### 1.5 Start the parallel run and record the start time

Start Prometheus on the new server. From this moment both instances scrape the same targets and the
new TSDB begins accumulating history.

**Write the start time on the change record.** The earliest safe cutover date is that time plus the
retention window from 0.8.

Confirm the target list is healthy:

```powershell
$t = (Invoke-WebRequest http://localhost:9090/api/v1/targets -UseBasicParsing).Content | ConvertFrom-Json
$t.data.activeTargets | Group-Object health | Select-Object Name, Count
$t.data.activeTargets | Where-Object health -ne 'up' |
  Select-Object @{n='Target';e={$_.labels.instance}}, lastError
```

Every target that is up on the old server must be up on the new one. Any target up on the old and
down on the new is a firewall rule from 0.2 that was missed. Fix it now, not at cutover.

Targets that are down on **both** servers are pre existing cruft. Record them in the cruft register
with an owner. Do not fix them as part of this change.

---

## Phase 2: migrate content and tasks

No service impact. Users are still on the old server.

### 2.1 Export the Grafana content

On `SRVFOSAPPOPS01`:

```powershell
.\Export-GrafanaContent.ps1
```

This produces dashboards, folders, datasources and alert rules. Review the export before importing.

### 2.2 Import to the new Grafana

On `vmfosappmon01`:

```powershell
.\Import-GrafanaContent.ps1
```

Then verify, panel by panel, on the highest traffic dashboards first:

- Every datasource shows green in Grafana's datasource test page.
- The cross domain datasource from 0.9 resolves and returns data.
- No panel shows "No data" that shows data on the old server.

A panel that is blank on the new server and populated on the old one is either the metric rename
rule (1.4) or a scrape target that is down (1.5). Check both before assuming anything else.

### 2.3 Migrate the scheduled tasks

Copy the script trees from the old server to a staging folder on the new one, **outside** the live
root:

```powershell
robocopy \\SRVFOSAPPOPS01\D$\Win\Ops D:\Win\_APPOPS-source /E /COPY:DAT /R:1 /W:1 /NFL /NDL
```

Use `/COPY:DAT`, not `/COPYALL` and not `/SEC`. Copying the source ACLs brings across entries naming
the old server's local groups and that environment's SIDs. They arrive as unresolved SIDs and can
lock the service account out of its own folder.

Then import the tasks. This is a straight lift onto a host with no competing task set, so both
suffixes are blanked:

```powershell
.\Import-CrossEnvTasks.ps1 -TasksFolder C:\Migration\capture-SRVFOSAPPOPS01-<stamp>\tasks `
    -SourceEnv FOS -TaskSuffix '' -PromSuffix '' `
    -ScriptsRoot 'D:\Win\Ops' -StagingRoot 'D:\Win\_APPOPS-source' `
    -SourceHost SRVFOSAPPOPS01 `
    -IncludeTask '<regex matching the migrate list from 0.5>'
```

Run it without `-Apply` first. Read section 2 of the report and confirm the task list matches the
0.5 decisions exactly. Then run it again with `-Apply`.

Every task registers **disabled**. The script grants "Log on as a batch job", grants the task
accounts Modify on the textfile directory, and re points every absolute path inside the copied
scripts as well as inside the task XML.

Supply the stored passwords when prompted. 31 tasks hold them and Windows never exports them.

### 2.4 Enable the tasks one at a time

Enable one task. Wait for its output. Confirm it. Then enable the next.

Do not enable in bulk. If something is wrong you want one failure to diagnose, not 26.

Judge each task on its **output**, not its state. Several feeders on this estate are long running
loops by design. They sit at `Running` for ever and log a Task Scheduler event 322 every five
minutes while working correctly. A task at `Running` with fresh output is healthy. A task at
`Running` with stale output is not.

```powershell
.\suite\Test-MonitoringHost.ps1 -CaptureFolder C:\Migration\capture-SRVFOSAPPOPS01-<stamp> `
    -PrometheusUrl http://localhost:9090 -GrafanaUrl http://localhost:3000
```

This pairs Task Scheduler events by InstanceId to get real durations and exit codes, diffs the
textfile output against the old server's baseline, and checks Prometheus target health and the
Grafana API in one pass.

### 2.5 Validate the textfile output

```powershell
.\Test-PromFiles.ps1
```

One malformed `.prom` file causes windows_exporter to reject that file whole and set
`windows_textfile_scrape_error` to 1. wmi_exporter 0.4.3 was forgiving about this. The current
version is not. Run this before anyone relies on the new server.

### 2.6 Let history accumulate

Leave both servers running until the new Prometheus holds the retention window recorded at 0.8.

---

## Phase 3: cutover window

Approximately 1 hour. Book it away from 21:00, when the SharePoint Online check on
`SRVFOSAPPMON01` runs.

**Do not share this window with the `SRVFOSAPPMON01` to `vmprdappmon01` change.** Both changes
affect production monitoring. If a dashboard goes blank afterwards you must be able to attribute it.

3.1 Confirm the new Prometheus target list is fully healthy. Repeat the check from 1.5.

3.2 Confirm the new Grafana answers on its own hostname and that a known dashboard renders with
current data.

3.3 Repoint the DNS aliases from 0.3 to `vmfosappmon01`.

3.4 Confirm resolution from a client machine:

```powershell
Resolve-DnsName grafana.<domain>
Clear-DnsClientCache
```

3.5 Open the production dashboards through the alias. Confirm current data.

3.6 Leave the old server running and untouched. Do not stop any service on it in this window.

---

## Phase 4: observation and decommission

4.1 Observe for one full business cycle including overnight runs.

4.2 Confirm alert delivery end to end. Trigger one alert deliberately and confirm it arrives at its
destination. A notification channel that fails silently looks exactly like a quiet system.

4.3 Hold the old server for a **14 day rollback window**, powered on, services running, scraping.
Its scrape entries are additive and harmless.

4.4 At the end of the rollback window, stop the Grafana and Prometheus services on
`SRVFOSAPPOPS01`. **Stop them. Do not uninstall.** A powered off server that can come back is worth
more than a tidy one that cannot.

4.5 After a further clean period, decommission. Remove the old server's scrape target entries, remove
the old firewall rules identified at 0.2, and close the CMDB record.

4.6 Close out the 0.5 task decisions and the 0.6 account replacement in
`BROKEN-TASKS-REGISTER.md` and `SERVICE-ACCOUNTS.md`.

---

## Test / verification plan

Each item is pass or fail. There is no partial pass.

| # | Test | Pass criterion |
|---|---|---|
| 1 | Prometheus target health | Every target up on the old server is up on the new server |
| 2 | Firewall survey | Zero hosts remain in the "old server IP only" bucket |
| 3 | Grafana datasources | Every datasource tests green, including the cross domain one |
| 4 | Dashboard render | No panel blank on the new server that shows data on the old server |
| 5 | Metric rename | A dashboard querying `wmi_*` returns data from the new server |
| 6 | Scheduled tasks | Each migrated task has one successful manual run and one successful scheduled run |
| 7 | Textfile output | `Test-PromFiles.ps1` reports zero errors; `windows_textfile_scrape_error` is 0 |
| 8 | Alert delivery | One deliberately triggered alert arrives at its configured destination |
| 9 | DNS repoint | The alias resolves to the new server from a client machine |
| 10 | History window | The new Prometheus holds the retention period recorded at 0.8 |
| 11 | 48 hours post cutover | No missing data gaps on production dashboards |

## Backout plan

Backout is a DNS change and takes about one minute.

1. Repoint the DNS aliases back to `SRVFOSAPPOPS01`.
2. Clear the client DNS cache.
3. Confirm the dashboards render from the old server.

The old server is unmodified throughout Phases 1, 2 and 3. It keeps scraping, keeps its full 25.31 GB
of history, and keeps serving Grafana. Nothing is stopped on it until Phase 4.4, which is 14 days
after cutover.

The only backout that is not a DNS change is a scheduled task that has been cut over and then fails.
Re enable it on the old server. The task XML backups are in the capture package and in the
`C:\Migration\taskbackup-*` folder written by `Set-TaskAccount.ps1`.

No data loss is possible in this change. Nothing is deleted and nothing is moved. Everything is
copied.

## Proposed schedule

| Phase | When | Impact |
|---|---|---|
| 0 (pre implementation) | `<date range>` | None |
| 0.2 firewall survey | Start immediately. Gates everything. | None |
| 1 (build, start parallel run) | `<date>` | None |
| 2 (content and tasks) | `<date range>` | None |
| Parallel run | `<start>` to `<start + retention period>` | None |
| 3 (cutover window) | `<date>` `<time>` to `<time + 1h>` | Users switch to the new Grafana |
| 4 (observation) | Cutover + 14 days | None |
| Decommission | `<cutover + 14 days>` onward | None |

## Downtime

**None.** The parallel run means both platforms are live throughout. The cutover is a DNS repoint.

The only user visible effect is that dashboards served by the new instance show history from the
parallel run start date rather than the full 25.31 GB history. Anyone needing older data uses the old
server, which stays available for 14 days.

## Communication

| Who | When | What |
|---|---|---|
| Monitoring and ops team | Before Phase 1, and at cutover | The platform is moving. Both instances are live during the parallel run. History window shortens at cutover. |
| Networks or whoever owns firewall rules | At 0.2, immediately | The :9182 survey and any GPO managed rules |
| DNS owner | At 0.3, immediately | Alias creation, TTL reduction, and the cutover repoint |
| Dashboard users | One week before cutover, and on the day | The alias to use, and the shorter history window |
| Task owners identified at 0.5 | Before the window | Their keep or retire decision |
| `e-sadegunle` and their manager | At 0.6 | Personal account replacement for the CaseCount tasks |
| CRE monitoring owner | At 0.9 | The cross domain datasource dependency |
| Change record | Before window approval | Outcomes of 0.2, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9 |

## Attachments / evidence

- Discovery and capture package for `SRVFOSAPPOPS01` (`Invoke-ServerCapture.ps1`, Phase 0.1)
- `APPOPS-LIFT-PLAN.md`, the technical analysis this change is built on
- `MIGRATION-RUNBOOK-WS2025.md`, the build and metric compatibility detail
- `UPGRADE-PATH.md`, confirming the version upgrade is out of scope for this change
- `SERVICE-ACCOUNTS.md`, the account inventory across all environments
- `BROKEN-TASKS-REGISTER.md`, the task keep or retire decisions
- `DASHBOARDS-GOLD-STANDARD.md`, the dashboard baseline
- 0.2 firewall survey results with the three bucket counts
- 0.5 task triage CSV with an owner and an outcome against every one of the 39 rows
- 0.12 `Compare-ServerBaseline.ps1` GO result
