# APPMON cutover — the things that actually broke, and the fix for each

Every item below was hit for real on **vmcreappmon01** (CRE, 19–20 Aug 2026). None of them is
environment-specific: expect all of them again on the SYS, STG and PROD replacements. Work down the
list *before* declaring a cutover done, or run `Repair-AppmonHost.ps1` which does items 1 and 2–4.

The short version: **a new Windows Server 2025 build does not inherit the two things the old box had
set up by hand years ago** — the batch-logon right for the service accounts, and a valid exporter
config. Everything else was a consequence of those two.

---

## 1. Scheduled tasks never run — "Log on as a batch job" is missing  ← the big one

**Symptom.** Every task shows Last Run `30/11/1999`, Last Result `0x41303 "has never run"`, and Next
Run looks normal. Hard-setting the action paths changes nothing (the action is never reached).
Task Scheduler History shows, every few minutes:

```
Event 101  Task Scheduler failed to start "\<task>" for user "FOSCRE\svc...".
           Additional Data: Error Value: 2147943785      →  0x80070569 LOGON FAILURE
```

**Cause.** Registering a task with a stored password is *supposed* to grant the account
"Log on as a batch job" automatically. On WS2025 it does not. The right holds only the Windows
defaults (`BUILTIN\Administrators`, `Backup Operators`, `Performance Log Users`), so Task Scheduler
cannot create the logon session and refuses the launch before touching the action.

**Fix.** Grant it to **every** account used by any migrated task, then re-save each task so it
re-registers its password. `Repair-AppmonHost.ps1` does this and verifies it took. Manually:
secpol.msc → Local Policies → User Rights Assignment → *Log on as a batch job*.

**Also check** whether a GPO manages that right — if it does, a local grant is reverted at the next
policy refresh and the tasks stop again hours later with no obvious trigger:

```powershell
gpresult /scope computer /v > C:\Migration\gp.txt
Select-String C:\Migration\gp.txt -Pattern 'batch job|SeBatchLogonRight'
```

On CRE it was **not** GPO-managed, so the local grant persists. Re-check per environment — SYS/STG/PROD
may sit in different OUs. Also confirm no account is in *Deny log on as a batch job*.

**Accounts seen on CRE:** `FOSCRE\svcCRMMonitoringCRE` (monitoring feeds), `FOSCRE\Svcd365integCRE`
(the `Tools-MdsCrmIntegration-*` tasks). Each environment has its own equivalents — read them off the
tasks rather than assuming.

---

## 2. Exporter service will not start — the config file did not exist

**Symptom.** Service registered, `Start-Service` fails, SCM event **7024** "terminated with the
following service-specific error", 7036 shows running→stopped within a second.

**Cause on CRE.** The service's `--config.file` pointed at
`C:\Program Files\wmi_exporter\config.yaml` **which had never been created**. The exporter starts,
cannot load its config, exits immediately.

> Correction to an earlier diagnosis: the service binary path was **correctly quoted** all along.
> A regex bug in `Diagnose-AppmonHost.ps1` truncated the quoted path at the first space and reported
> `Config file 'C:\Program' does not exist`, which read like an unquoted-path fault. Fixed in the
> diagnostic (it now parses quoted paths and flags genuinely unquoted ones separately). Quoting is
> still worth verifying — see 2b — but the missing file was the actual cause.

**Fix.** Create the config (see 3 for the correct shape), then start the service.

### 2b. Quoting, while you are there
Both paths must be quoted inside the service binary path, or a path containing spaces breaks:

```powershell
(Get-CimInstance Win32_Service -Filter "Name='windows_exporter'").PathName
# want exactly:
# "C:\Program Files\wmi_exporter\wmi_exporter.exe" --config.file="C:\Program Files\wmi_exporter\config.yaml"
```

---

## 3. `config.yaml` — `directories` must be a YAML **list**

**Symptom.**

```
ERROR Failed to load configuration err="failed to load configuration file: configuration file
validation error: yaml: unmarshal errors:\n line 5: cannot unmarshal !!str `D:\Win\...` into []string"
```

**Cause.** windows_exporter 0.31.x types `collector.textfile.directories` as `[]string`. A scalar is
rejected and the service will not start. (This was wrong in the first version of our own build guide —
now corrected everywhere.)

```yaml
collectors:
  enabled: cpu,cpu_info,logical_disk,memory,net,os,physical_disk,service,system,textfile
collector:
  textfile:
    directories:            # LIST, not a scalar
      - D:\Win\Ops\WMITextfileExport
web:
  listen-address: ":9182"
log:
  level: warn
```

Backslashes are fine unquoted in a YAML plain scalar. Add `iis` / `msmq` / `mssql` to
`collectors.enabled` on hosts with those roles, and consider `collector.service.include` to cut
cardinality (see EXPORTER-WS2025-BUILD.md).

### 3b. `unknown collector cs` — the collector list from the old box is not portable

**Symptom.** Config loads, then the process exits immediately. Nothing useful in the SCM event; the
error only appears if you run the binary in the foreground:

```
level=ERROR source=main.go:166 msg="couldn't enable collectors" err="unknown collector cs"
```

**Cause.** `cs` ("computer system") existed in wmi_exporter 0.4.x and was **removed** from
windows_exporter. Its metrics were split: `cs_physical_memory_bytes` → `memory`
(`windows_memory_physical_total_bytes`), `cs_logical_processors` → `cpu_info`
(`windows_cpu_logical_processor`). Any collector list copied off a 2012 box will contain it, and the
exporter fails closed on one unknown name — it does not skip it.

**Fix.** Drop `cs`, add `cpu_info` (keep `memory`, which you already have):

```powershell
$c = 'C:\Program Files\wmi_exporter\config.yaml'
(Get-Content $c -Raw) -replace '(?m)^(\s*enabled:\s*).*$', '$1cpu,cpu_info,logical_disk,memory,net,os,physical_disk,service,system,textfile' |
  Set-Content $c -Encoding ascii
Restart-Service windows_exporter
```

`Repair-AppmonHost.ps1` v2.1 does this automatically: if the service will not start it runs the
binary in the foreground, parses every `unknown collector X` out of stderr, removes those names and
retries (up to 6 rounds), then reports which it dropped. So the same class of fault on SYS/STG/PROD —
whatever name it turns out to be — is self-healing.

The gold dashboards are unaffected: every query already asks for
`(wmi_x or windows_x or renamed_x)`, so `cs_logical_processors` and `windows_cpu_logical_processor`
both resolve.

---

## 4. The exporter binary and the textfile directory

- `D:\Win\Ops\WMITextfileExport` must exist **before** the service starts, or the textfile collector
  fails. Create it empty — do **not** copy the old `.prom` files across; a file appearing there is
  your proof a task ran.
- Confirm the binary really is the new one: `& '<path>\wmi_exporter.exe' --version` must print
  `windows_exporter, version 0.31.x`. On CRE the exe is still *named* `wmi_exporter.exe` in
  `C:\Program Files\wmi_exporter\` but is genuinely windows_exporter 0.31.8 — confusing but fine.
  (`--version` writes to **stderr**; that is not an error.)
- A downloaded exe may carry the mark-of-the-web and be refused as a service: `Unblock-File`.

---

## 5. Task actions still contain Octopus `#{InstallDirectory}` placeholders

**Symptom.** Task action reads
`powershell -file "#{InstallDirectory}\content\AppInsightsExporter.ps1"`.

**Cause.** An Octopus deployment wrote the task without substituting its variable. The path has never
existed on any server, so the task has been dead since that deployment.

**Fix.** Re-point at the real path (`D:\Win\Ops\<Exporter>\content\<Script>.ps1`, Start-in the same
folder) — **but first check the old server**: if it has the same placeholder, the task was already
dead there and re-pointing it would restart a job nobody has run for years. On CRE,
`AppInsightsExporter` was exactly this (dead since ~2020, still retrying every 2 minutes and filling
the event log).

Note the path has no drive letter, so it is resolved relative to the task's Start-in folder — setting
Start-in correctly does **not** rescue it.

**Decision taken on CRE:** migrate it like-for-like, leave it **disabled and annotated**, and let the
owning application team review or delete it. Fixing it silently restarts a dead job; deleting it
removes the owner's evidence. See `BROKEN-TASKS-REGISTER.md` for the entry, the evidence-capture
snippet and the annotation snippet.

Find them all at once:

```powershell
Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\Microsoft*' } | ForEach-Object {
  $a = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments) $($_.WorkingDirectory)" }) -join ' '
  if ($a -match '#\{') { $_.TaskName }
}
```

---

## 6. Disabled tasks cannot be started on demand

`Start-ScheduledTask` on a disabled task does nothing and `LastTaskResult` stays `0x41303`, which
looks identical to the logon failure in item 1. Order is **enable → run → check**, one task at a time.
(The original stand-up guide had this backwards; corrected.)

---

## 7. Triggers that came across disabled or expired

After enabling, a task with a Next Run of blank while its siblings show a time has a disabled or
expired trigger. On CRE this affected `MirrorExporter` and `PhoenixMetricsGatherer`. Check the
Triggers tab: trigger enabled, no expiry date in the past.

---

## 8. `Running` forever is NORMAL for the feeders — judge them on output, not state

**Correction to an earlier version of this document.** We spent most of the CRE cutover treating
"task stuck at Running with a stream of event 322s" as the fault. It is not. The capture from the
still-working `SRVSYS1APPMON01` settles it:

```
\AdhocServiceStatusExporter-ScheduledTask        Running   288x event 322 in 24h
\PhoenixConfigExporter-sanitation-ScheduledTask  Running   288x event 322 in 24h
\PhoenixConfigExporter-self-ScheduledTask        Running   287x event 322 in 24h
```

…on a server whose `.prom` files were 0–10 minutes old at the time. 288 refusals in 24 hours is
exactly one per 5 minutes: **the feeders are long-running loops**, the 5-minute trigger is a watchdog
that restarts them if they ever die, and every "refused" launch is the watchdog correctly finding the
process already alive. A healthy APPMON host looks like this.

Two of them (`PhoenixMetricsGatherer`, `TestsIngestion`) have no recurring trigger at all — Boot and
Registration only, so `Next Run` is legitimately blank. That is also normal, and not an import defect.

**So the real test is the textfile directory, never the task state.** Compare against the baseline
captured from the old server:

| file | size | refreshed every |
|---|---|---|
| `adhoc_metrics.prom` | ~1 KB | ~2 min |
| `phoenix_metrics.prom` | ~0.6 KB | ~2 min |
| `sanitation_phoenix_config.prom` | ~230 KB | ~10 min |
| `self_phoenix_config.prom` | ~240 KB | ~2 min |

### 8b. When it IS broken: idle process, no output

The genuine fault looks similar but differs in two measurable ways — **CPU** and **output**. A healthy
loop burns CPU periodically and refreshes its `.prom`. On CRE the seven processes had ~0.5 s of CPU
*total* across 45 minutes (that is PowerShell startup and nothing else) and the textfile directory
never received a byte. That is a process that started and blocked immediately, not one that is looping.

**Cause — and this is NOT DPAPI.** An earlier version of this document said the Phoenix scripts store
their credentials with DPAPI and that the secrets therefore have to be re-created by hand on every
target. That was wrong, and it sent us looking in the wrong place for most of the CRE cutover. The
actual code, identical in all three trees:

```powershell
$SecurePassword = $userPassword | ConvertTo-SecureString -AsPlainText -Force
$Credentials    = New-Object System.Management.Automation.PSCredential -ArgumentList $userName, $SecurePassword
```

`-AsPlainText -Force` is the *opposite* of DPAPI: nothing is encrypted at rest and nothing is bound to
a machine or an account. The password arrives as an ordinary string in `$userPassword` / `$plainPassword`
and is only wrapped in a SecureString because `PSCredential` demands one.

**What this means for a cutover:**

- **There is no secret to re-create.** Skip that step entirely — it does not exist.
- **The credential travels with the file tree.** Whatever supplies `$userPassword` is a file you copy.
  Find it before you copy anything, because it is also **environment-specific** — the SYS tree carries
  SYS's D365 endpoint and account, and dropping CRE's copy onto a SYS box is a silent misconfiguration
  rather than an error.
- **The hang path is still real, by a different route.** Every Phoenix tree ships
  `Modules\Microsoft.Xrm.Data.PowerShell\Microsoft.Xrm.Data.PowerShell.psm1`, which contains
  `Get-Credential` and `Read-Host`. If the password variable is empty or wrong — because the config
  file did not come across, or came across from the wrong environment — the module falls back to
  prompting, and in session 0 that prompt blocks forever. Same symptom, different cause.

Find where the password actually comes from before the cutover:

```powershell
Select-String -Path D:\Win\Ops\*\content\*.ps1, D:\Win\Ops\*\*\content\Modules\*\*.psm1 `
  -Pattern '\$userPassword|\$plainPassword|\$userName|ConvertFrom-Json|Get-Content.*config' -Context 3,1
Get-ChildItem D:\Win\Ops -Recurse -Include *.json, *.config, *.xml, *.ini -ErrorAction SilentlyContinue |
  Where-Object Length -lt 100KB | Select-Object FullName, Length, LastWriteTime
```

> **Note for the change record and the handover.** These service-account passwords sit in clear text
> in files on `D:\`, and the cutover copies them between servers. That is worth raising with whoever
> owns the Phoenix scripts — not as a blocker for the migration, but it should not pass unremarked,
> and the copies now exist in more places than they did.

**Fix.** Kill the stuck instances, then re-create the secrets as the task account:

```powershell
Get-ScheduledTask | Where-Object State -eq 'Running' | Stop-ScheduledTask
```

The Phoenix scripts store credentials with DPAPI/SecureString, bound to the machine **and** the account
that encrypted them. Whatever the old box saved will not decrypt on the new one. Re-create them on the
target, signed in as the task account:

```powershell
runas /user:FOSCRE\svcCRMMonitoringCRE powershell.exe
# then run each script's credential-setup step (look for Export-Clixml / ConvertFrom-SecureString /
# Get-Credential inside D:\Win\Ops\PhoenixConfigExporter\... and PhoenixD365MetricsExporter\...)
```

Skip this and every Phoenix task either reports success and produces nothing, or hangs as above.

To find which secret a script wants, grep its tree before you run it:

```powershell
Select-String -Path D:\Win\Ops\*\content\*.ps1 -Pattern 'Get-Credential|Import-Clixml|ConvertTo-SecureString|ConvertFrom-SecureString'
```

A script that calls `Get-Credential` with no `-ErrorAction`/no stored fallback is a task that *will*
hang on a headless box. Worth patching those to fail fast rather than block.

---

## 9. Nothing appears in Grafana until Prometheus scrapes the new box

Add the new hostname to `D:\Win\Apps\Prometheus\Servers\*.json` on that environment's APPOPS server,
with the `Environment` label and the role flags, alongside the old entry. Then check the Targets page.
Leave the old server's feeder tasks running until the new one has completed a full overnight cycle;
disable them on the old box only after that, or both write the same metrics and every Phoenix panel
shows two series.

---

## 10. Co-hosting two environments — renaming the folder is not the same as re-pointing the scripts

Applies where one APPMON box has to run a second environment's feeders because that environment never
got a new server. Three things have to be separated, and each one has a way of looking done when it
isn't:

| | separated by | looks done but isn't when… |
|---|---|---|
| Task names | `_STG` suffix on the task name **and** the `<URI>` inside the XML | you rename the task but not the URI — Task Scheduler keeps the old identity and the two sets fight over it |
| Script trees | a second copy of each component folder | see below — this is the one that bites |
| `.prom` output | `_stg` suffix on the filename | the *filename* is unique but the *metrics inside* are not — see item 11 |

**The one that bites.** Copying the tree to `D:\Win\Ops\PhoenixConfigExporter_STG\` and re-pointing the
task action at it is only half the job. The feeder scripts open their own config by **absolute path**:

```powershell
$cfg = Get-Content 'D:\Win\Ops\PhoenixConfigExporter\config.json' -Raw | ConvertFrom-Json
```

That line does not care where the script was copied to. The STG task launches STG's copy of the
script, which reads the **host environment's** config, connects to the host environment's D365
endpoint with the host environment's credential, writes a `_stg.prom` file full of the wrong
environment's data — and exits 0. Every check you would normally run says healthy: task succeeded,
file is fresh, metrics are being scraped. Only the values are wrong, and only someone who knows what
STG's numbers should look like would notice.

So the path rewrite has to run over the **contents of the copied scripts**, not just the task XML.
`Import-CrossEnvTasks.ps1` does both from one function so the two cannot drift apart, and prints
every substitution. What it deliberately does **not** rewrite is a path assembled at runtime:

```powershell
$root = 'D:\Win\Ops'                       # literal survives the rewrite untouched
$path = Join-Path $root 'PhoenixConfigExporter'   # ...and lands on the wrong environment
```

There is no safe automatic answer to that, so grep the copied tree afterwards and read the hits:

```powershell
Select-String -Path 'D:\Win\Ops\STG\*' -Pattern 'D:\Win\Ops' -Recurse -SimpleMatch |
  Select-Object Path, LineNumber, Line
```

**Two folders that must NOT be renamed or copied**: the textfile directory
(`D:\Win\Ops\WMITextfileExport`) is shared on purpose — the `_stg` filename suffix is what keeps the
two sets apart, and one exporter collects both. Rename it per environment and the incoming feeders
write into a directory nothing reads. Same for a shared `bin`/`tools` folder holding the exporter.

**Layout.** Either works; nested is the recommendation:

```
D:\Win\Ops\STG\PhoenixConfigExporter\        # nested   - one folder to ACL, back up, and delete later
D:\Win\Ops\PhoenixConfigExporter_STG\        # suffixed - environment visible in the folder name
```

Nested wins on one concrete thing: a script doing `Split-Path $PSScriptRoot -Parent` to find a sibling
component still lands inside the STG tree. Under the suffixed layout the parent is `D:\Win\Ops` and
that sibling lookup silently crosses into the host environment — the same failure as the absolute
path above, arriving by a different route.

**Copy with `/COPY:DAT`, not `/COPYALL`.** Copying the source ACLs drags across ACEs naming the old
server's local groups and that environment's SIDs. They arrive as unresolved SIDs and can lock the
account that has to run the job out of its own folder. Let the destination inherit.

---

## Order of operations for the next environment

1. Build the server, same drive letters and paths as the old one (a missing `D:` invalidates every
   task action and the exporter config at once).
2. **Grant "Log on as a batch job"** to the task accounts, and check for a GPO that manages it.
3. Install windows_exporter 0.31.8, create `config.yaml` with `directories` as a **list** and a
   0.31-valid collector list (**no `cs`**), create the textfile directory, register the service with
   both paths quoted, start it, confirm `/metrics`. If it will not start, run the binary in the
   foreground — that is the only place the real error appears.
4. Copy the script trees from the old server; grep them for the old hostname and for `#{`.
5. Register the tasks disabled; fix any `#{...}` actions that the owner has agreed to fix, and leave
   the rest disabled and annotated in `BROKEN-TASKS-REGISTER.md`.
6. Re-create the DPAPI secrets as the task account **before** enabling anything — a task started
   without them hangs rather than failing, and then blocks its own next run (event 322).
7. Enable → run → verify each task in turn (result `0`, fresh `.prom`, state back to `Ready` within
   a couple of minutes).
8. Add the scrape target on the APPOPS box; confirm the host appears UP and Server Detail shows data.
9. Run `Diagnose-AppmonHost.ps1` as the acceptance check — it should come back with no criticals.

## Tooling

| Script | Does |
|---|---|
| `Diagnose-AppmonHost.ps1` | Read-only. Everything above, checked and ranked as "prime suspects". Run it as the acceptance test. `-TestLogon` proves the account can create a batch logon; `-StartTasks` forces a launch and captures the History event. |
| `Repair-AppmonHost.ps1` | v2.1. Applies items 1, 2, 3, 3b and 4 (rights, service, config, unsupported-collector self-heal, textfile dir, firewall) and prints one pasteable text report. Flags any task Running > 10 minutes as item 8. `-WhatIf` supported; refuses to run on a machine that is not an APPMON host. |
| `Test-PromFiles.ps1` | Validates `.prom` files against the stricter 0.31 parser before the exporter rejects them. |
| `STANDUP-NEW-APPMON.md` | The step-by-step build guide, now including Step 3b (the batch-logon right). |
