# Migrated-but-broken scheduled tasks — handover register

Policy for the APPMON cutovers: a task that was already broken on the old server is **migrated
like-for-like, left disabled, and annotated** — not fixed and not deleted. Fixing it would restart a
job that has not run in production for years without the owning team knowing; deleting it removes the
evidence they need to make that call. So it comes across, it is marked, and the owner decides.

Record every one of these here as each environment is cut over.

---

## CRE — `\AppInsightsExporter-ScheduledTask`

| | |
|---|---|
| Source server | `SRVFOSCREAPPMON01` |
| Target server | `vmcreappmon01` |
| Migrated | 20/08/2026, like-for-like |
| State on target | Path re-pointed 20/08/2026 to `D:\Win\Ops\AppInsightsExporter\content\` (script exists). No longer like-for-like — see note. |
| Verdict | **Broken before migration. Not a cutover fault.** |
| Owner | *(unassigned — application team that deployed it via Octopus)* |

**Why it is broken.** The task action carries an unsubstituted Octopus Deploy variable:

```
powershell -file "#{InstallDirectory}\content\AppInsightsExporter.ps1"
```

Octopus writes the scheduled-task definition as part of a deployment and is supposed to replace
`#{InstallDirectory}` with the real install path. On this deployment it did not, so the action points
at a literal folder named `#{InstallDirectory}` that has never existed on any server. Two consequences:

- The path has **no drive letter**, so it is resolved relative to the task's Start-in folder. Getting
  Start-in right does not rescue it — the `#{InstallDirectory}` segment still has to exist.
- PowerShell cannot find the script, exits non-zero, and the task fails on every single trigger. Its
  trigger repeats roughly every 2 minutes, so it has been writing a failure into
  `Microsoft-Windows-TaskScheduler/Operational` every 2 minutes for years. That is a large share of
  the event-log noise on the old box.

**The same placeholder is present on the old server** — which is how we concluded the task has been
dead since its last successful run (around 2020, confirm from `LastRunTime` before quoting the date).
Nothing in the cutover caused this.

**What the owner needs to decide.** Either the AppInsights feed is still wanted — in which case the
Octopus project needs fixing and re-deploying, not the task hand-editing — or it was superseded and
the task should be deleted. Before they decide, check whether anything actually consumes it: if no
Grafana dashboard or Prometheus rule references an AppInsights-derived metric, and no `.prom` file
with that name exists on any APPMON host, then nothing has depended on it for six years.

### Update 20/08/2026 — the placeholder has since been removed

The 13:19 report shows this task's action is now
`powershell -file "D:\Win\Ops\AppInsightsExporter\content\AppInsightsExporter.ps1"` with
`script [exists=True]`, so the path was re-pointed during the cutover and the placeholder is gone.
That changes the register entry in two ways:

- It is **no longer like-for-like**. Reverting it to the broken placeholder purely for fidelity would
  be silly; keeping the corrected path and recording the change here is the honest version.
- "Broken" is now a **claim about its history, not its current configuration**. The evidence the owner
  needs is the old server's copy of the task, not this one — capture that before `SRVFOSCREAPPMON01`
  is decommissioned, because after that the proof is gone.

```powershell
# ON THE OLD SERVER, while it still exists
Export-ScheduledTask -TaskName 'AppInsightsExporter-ScheduledTask' |
  Set-Content C:\Migration\OLD-AppInsightsExporter.xml -Encoding utf8
(Get-ScheduledTask -TaskName 'AppInsightsExporter-ScheduledTask' | Get-ScheduledTaskInfo).LastRunTime
```

The exported XML carries the `#{InstallDirectory}` action verbatim and is the artefact to attach to
the handover. Until the owner rules on it, the task stays **disabled** on the new server.

### Capture the evidence in one paste

```powershell
$n = 'AppInsightsExporter-ScheduledTask'
$t = Get-ScheduledTask -TaskName $n
$i = Get-ScheduledTaskInfo -TaskName $n
'--- ACTIONS ---'; $t.Actions | Format-List Execute, Arguments, WorkingDirectory
'--- TRIGGERS ---'; $t.Triggers | Format-List *
'--- STATE ---'
"state={0} enabled={1} runAs={2}" -f $t.State, $t.Settings.Enabled, $t.Principal.UserId
"lastRun={0} lastResult=0x{1:X8} nextRun={2} missed={3}" -f $i.LastRunTime, $i.LastTaskResult, $i.NextRunTime, $i.NumberOfMissedRuns
'--- DOES THE SCRIPT EXIST ANYWHERE ---'
Get-ChildItem D:\Win\Ops -Recurse -Filter 'AppInsightsExporter.ps1' -ErrorAction SilentlyContinue |
  Select-Object FullName, Length, LastWriteTime
```

### Mark it, do not fix it

```powershell
$n = 'AppInsightsExporter-ScheduledTask'
Stop-ScheduledTask  -TaskName $n -ErrorAction SilentlyContinue   # clear any stuck Running instance
Disable-ScheduledTask -TaskName $n

$t = Get-ScheduledTask -TaskName $n
$t.Description = @'
BROKEN ON ARRIVAL - migrated like-for-like from SRVFOSCREAPPMON01 on 20/08/2026 and deliberately NOT repaired.
The action path contains an unsubstituted Octopus variable "#{InstallDirectory}", so the script has never been
found on any server; last successful run was years ago. Left registered and disabled so the owning application
team can review or delete it. Do not enable without fixing the Octopus project first.
Ref: APPMON-CUTOVER-GOTCHAS.md item 5 / BROKEN-TASKS-REGISTER.md
'@
Set-ScheduledTask -InputObject $t -User 'FOSCRE\svcCRMMonitoringCRE' -Password '<password>'
```

> **Gotcha.** `Set-ScheduledTask` on a task whose logon type is *Password* drops the stored password
> unless you pass `-User`/`-Password` again — the task then fails to launch with `0x80070569`, which
> looks exactly like the batch-logon-right fault from item 1 of the gotchas list. If you would rather
> not re-enter the password, skip the `Description` edit entirely and record the note here and in the
> change record instead; a disabled task plus this register is enough for handover.

---

## SYS + STG — the whole task set, blocked on a deleted service account

| | |
|---|---|
| Source servers | `SRVSYS1APPMON01`, `SRVSTG1APPMON01` |
| Target server | `vmsysappmon01` (STG is co-hosted here — there is no new STG box) |
| Account | `fostst\svcCRMMonitoringPRV` |
| Verdict | **Not a cutover fault. The account no longer exists in AD.** |
| Owner | *(unassigned — whoever owns the 25/06/2026 service-account change)* |

**What happened.** Every task in both sets registers as `fostst\svcCRMMonitoringPRV`. Importing them
fails with `0x80070534` (`ERROR_NONE_MAPPED`) — Windows could not translate the name to a SID, which
is what it says when the principal has been deleted, not when a password is wrong.
`Diagnose-TaskImport.ps1` confirmed it: the name resolves nowhere on the host, nowhere in `fostst`,
and under none of the trusts (`FOSNPE`, `FOSNPEAMB`, `FOSTST`). Around forty service accounts were
bulk-changed on **25/06/2026 15:42**; of that family only `svcCRMMonitoringMOD` survives.

**One account, two environments.** The STG dry run on 26/08/2026 hit the identical blocker, which
establishes that SYS and STG share this account. Restoring it unblocks both at once; there is no
separate STG fix to find.

**Why the old SYS box still works.** `SRVSYS1APPMON01` is running on logon sessions established
before the deletion. Those survive until it reboots — at which point the old server fails too, and
the fallback disappears. This is a clock, not a steady state.

**The decision, in order of preference.**

1. **Restore from the AD Recycle Bin.** Preserves the original SID, so every existing ACL, `Log On
   To` entry and batch-logon grant keeps working and nothing else has to be touched.
2. Recreate with the same name — new SID, so rights and ACLs must be re-granted everywhere.
3. Owner confirms it was retired deliberately and names the replacement; re-run the import with
   `-Account 'DOM\name'`.

Do **not** borrow another environment's service account to get past this. Those trees carry
per-environment config with a plaintext credential, so a borrowed account plus a shared tree points
one environment's jobs at another's system and reports success doing it.

### Interim workaround on `vmsysappmon01` — record it, then remove it

The four SYS tasks currently on the new box are registered to a **personal named admin account**
(`e-lpoleschtschuk1`), not a service account, and the textfile directory
`D:\Win\Ops\WMITextfileExport` was **empty** at the time of the dry run. Treat this as temporary:

- It stops the moment that account's password changes, and dies with the account if the person moves
  on or it is disabled.
- Monitoring output then becomes attributable to an individual rather than to a service identity,
  which is an audit finding waiting to happen.
- The empty textfile directory means the feeders were not yet producing output at that point, so the
  workaround was not actually delivering metrics either.

Revert to the service account as soon as it exists, and note the interim period in the change record.

---

## PROD — `SRVFOSAPPMON01`, four tasks that stopped years before the migration

Discovered 28/08/2026. This box was missing from the original ingestion, so none of this was known
when the programme was scoped.

| Task | State | Last real run | Output age | Verdict |
|---|---|---|---|---|
| `\PhoenixConfigExporter-sanitation-ScheduledTask` | **Disabled** | never | `sanitation_phoenix_config.prom` **1311 days** | dead since ~Jan 2023 |
| `\PhoenixConfigExporter-self-ScheduledTask` | **Disabled** | never | `self_phoenix_config.prom` **1311 days** | dead since ~Jan 2023 |
| `\AdhocServiceStatusExporter-ScheduledTask` | Running | result `0x800710E0` | `adhoc_metrics.prom` **211 days** | started once, never finished |
| `\Tools-MdsCrmIntegration-DeltaMerge` | **Disabled** | 16/07/2024 | n/a | dormant 13 months |
| `\Tools-MdsCrmIntegration-ReconciliationReport` | **Disabled** | 16/07/2024 | n/a | dormant 13 months |

All run as `SOUTH-QUAY\svcCRMMonitoringPRD` or `SOUTH-QUAY\Svcd365integPRD` — a **fourth domain**,
not seen anywhere else in this estate.

**Why this matters beyond PROD.** The two PhoenixConfigExporter feeders are the same pair that exist
on SYS and STG. Here, in production, they have been disabled and producing nothing for three and a
half years. That is strong evidence the missing `.prom` output on `vmsysappmon01` is **inherited
breakage, not a cutover fault** — the feeders were dead estate-wide long before anyone touched them.
Confirm per environment before closing that out, but do not debug the migration for it.

`0x800710E0` is *launch refused because an instance was already running* — not a permissions fault.
With output 211 days old, that reads as a process that started once and hung. Trace it with
`Trace-StuckTask.ps1` **while the old server is still up**; after cutover the evidence is gone.

**What the owner needs to decide, before cutover night:** for each of the five, keep or retire. If
keep, it is fixed on the old server where people still recognise the environment. If retire, it is
recorded here and not carried across. Nothing migrates broken.

Two of the five still produce: `PhoenixMetricsGatherer` (current) and `SharePointOnline
-ScheduledTask` (result `0x0`, daily, the only cleanly succeeding task on the box). Those are the
acceptance test for `vmprdappmon01` — not the three above.

> **Note the task name.** `SharePointOnline -ScheduledTask` contains a space before the dash. It is
> the one that matters most and the one most likely to be mangled by a script that splits on spaces.

---

## Template for SYS / STG / PROD

Find every candidate on the **old** server before you migrate anything:

```powershell
Get-ScheduledTask | Where-Object { $_.TaskPath -notlike '\Microsoft*' } | ForEach-Object {
  $i = $_ | Get-ScheduledTaskInfo
  $a = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments)" }) -join ' | '
  [pscustomobject]@{
    Task       = $_.TaskName
    Enabled    = $_.Settings.Enabled
    LastRun    = $i.LastRunTime
    LastResult = ('0x{0:X8}' -f $i.LastTaskResult)
    Placeholder= [bool]($a -match '#\{')
    Action     = $a
  }
} | Sort-Object LastRun | Format-Table -AutoSize
```

Anything with `Placeholder = True`, or a `LastRun` older than the current release, is a register entry
rather than a migration item. Decide it **before** cutover night, not during it.
