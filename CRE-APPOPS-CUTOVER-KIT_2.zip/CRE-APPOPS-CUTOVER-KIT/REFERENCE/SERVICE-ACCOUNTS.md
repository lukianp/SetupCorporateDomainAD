# Service accounts by environment

Assembled 2026-08-28 from the SRVFOSAPPMON01 discovery, the SYS/STG import dry runs, the
`Diagnose-TaskImport` output and the earlier consolidated discovery. Confidence is marked per row —
**do not treat an unverified row as fact**; two accounts in this table have already turned out not
to exist, and one of them failed a cutover mid-window.

---

## Monitoring feeders — `svcCRMMonitoring*`

The four APPMON task sets (AdhocServiceStatusExporter, PhoenixConfigExporter self + sanitation,
PhoenixMetricsGatherer) run under one account per environment.

| Env | Account | Domain | Status | Evidence |
|---|---|---|---|---|
| PROD | `svcCRMMonitoringPRD` | **SOUTH-QUAY** | **UNVERIFIED** | discovery 28/08/2026 |
| CRE | `svcCRMMonitoringCRE` | FOSCRE | working | CRE cutover completed |
| SYS | `svcCRMMonitoringPRV` | fostst | **DELETED FROM AD** | `NONE_MAPPED`, confirmed by `Diagnose-TaskImport` |
| STG | `svcCRMMonitoringSTG` | fostst | **DOES NOT RESOLVE** | import dry run 27/08/2026 |
| ? | `svcCRMMonitoringMOD` | fostst | survives | only survivor of the June bulk change |

**The naming breaks on SYS.** Every other environment uses `svcCRMMonitoring<ENV>` —
`CRE`, `STG`, `PRD`. SYS uses `PRV`. Worth knowing when searching AD or a ticket history: looking
for `svcCRMMonitoringSYS` will find nothing, and it does not mean the account was renamed.

**Both missing accounts are in `fostst.org.uk`.** Around forty service accounts in that domain were
bulk-changed on **25/06/2026 15:42**; of the monitoring family only `svcCRMMonitoringMOD` came
through. PROD's and CRE's accounts live in different domains and were not in scope of that change —
which is the most likely reason CRE migrated cleanly and SYS did not.

---

## Application and integration tasks

| Env | Account | Domain | Runs | Status |
|---|---|---|---|---|
| PROD | `Svcd365integPRD` | **SOUTH-QUAY** | `Tools-MdsCrmIntegration` DeltaMerge + ReconciliationReport | **UNVERIFIED** |
| STG | `Svcd365integTST` | FOSTST | same two tasks | resolves (SID …-12600) |
| SYS + STG | `svcd365test` | FOSTST | `D365ConfigurationTests`, `…MessagesMgmt` | resolves (SID …-14775) |
| SYS + STG | `svcapptest` | FOSTST | `TestsIngestion` | resolves (SID …-14774) |

`svcd365test` and `svcapptest` are shared between SYS and STG because both environments sit in
`fostst.org.uk`. They survived the June bulk change.

---

## Service accounts on services, not tasks

| Env | Account | Domain | Service |
|---|---|---|---|
| PROD | `svcOctTen` | **south-quay** | OctopusDeploy Tentacle on SRVFOSAPPMON01 |

Not a scheduled-task account. Its Tentacle registration is re-established against the new host at
migration, not copied — a copied Tentacle thumbprint does not transfer.

---

## Personal accounts running production work

These are single points of failure: they cannot be re-registered once the person leaves, and they
stop at the next password change.

| Where | Account | Domain | Runs | Status |
|---|---|---|---|---|
| `vmsysappmon01` | `e-lpoleschtschuk1` | FOSTST | the SYS and STG feeder sets | **interim workaround, live now** |
| SRVFOSAPPOPS01 | `e-sadegunle` | SOUTH-QUAY | CaseCount2018 / 2019 / 2020 | pre-existing |
| SRVCRE1APPOPS01 | `e-sadegunle` | SOUTH-QUAY | `\ops\Compass site check` | pre-existing |
| SRVSYS1APPMON01 | `e-ddoubtfire` | FOSTST | "DD test d365" | dead — logon failure; retire |
| SRVFOSAPPMON01 | `e-ndesilva` | SOUTH-QUAY | *author* of `SharePointOnline -ScheduledTask` only | task runs as a service account — no action |

The `vmsysappmon01` entry is the one with a clock on it: it was adopted deliberately to prove the
pipeline while `svcCRMMonitoringPRV` and `svcCRMMonitoringSTG` are missing, and it should be
reverted with `Set-TaskAccount.ps1` the moment a replacement account exists.

Note the same individual (`e-sadegunle`) holds production feeds in **two** environments across a
domain boundary.

---

## Domains in play

| Domain | Holds |
|---|---|
| `fos.org.uk` | PROD machines |
| `foscre.org.uk` | CRE machines and accounts |
| `fostst.org.uk` | SYS + STG machines and accounts |
| `SOUTH-QUAY` | **accounts only** — every PROD task and service account |
| `FOSNPE`, `FOSNPEAMB` | trusts swept while diagnosing the SYS failure; no monitoring accounts found |

`SRVFOSAPPMON01` is joined to `fos.org.uk` but every account on it is `SOUTH-QUAY`. No other
environment does this, and it is the reason PROD's Phase 0 gate is an account-resolution check.

---

## Verify before you rely on any row

Run from a host in the same network position as the target server — a trust that resolves from the
old subnet is not proof it resolves from the new one.

```powershell
$accts = @(
  'SOUTH-QUAY\svcCRMMonitoringPRD', 'SOUTH-QUAY\Svcd365integPRD', 'south-quay\svcOctTen',
  'FOSCRE\svcCRMMonitoringCRE',
  'fostst\svcCRMMonitoringPRV', 'fostst\svcCRMMonitoringSTG', 'fostst\svcCRMMonitoringMOD',
  'FOSTST\svcd365test', 'FOSTST\svcapptest', 'FOSTST\Svcd365integTST'
)
foreach ($a in $accts) {
  $sid = try { (New-Object System.Security.Principal.NTAccount($a)).Translate(
                 [System.Security.Principal.SecurityIdentifier]).Value } catch { '*** NONE_MAPPED ***' }
  '{0,-42} {1}' -f $a, $sid
}
'' ; nltest /domain_trusts
```

A name that resolves is not the whole answer. Also check, for any account you are about to depend on:

- **Enabled?** A disabled account resolves perfectly and then fails at launch.
- **`Log On To` list?** If one is set and the new server is not in it, tasks register and then fail
  with error 1329.
- **Password expiry?** An expiring password takes every task on that account down at once, months
  after the migration, with no obvious link back to it.

`Import-CrossEnvTasks.ps1` checks all three during its dry run.

---

## What this table says to do

1. **Verify the three SOUTH-QUAY accounts before the PROD change is scheduled.** Two sibling
   accounts have already vanished without notice. This is Phase 0.1 of `CHANGE-HORNBILL-PRD.md` and
   it is a gate, not a checkbox.
2. **`svcCRMMonitoringPRV` and `svcCRMMonitoringSTG` need an owner decision** — restore from the AD
   Recycle Bin (preserves the SID, so every ACL and right survives), recreate, or name the
   replacement. This blocks SYS and STG independently; they are **not** the same account, despite an
   earlier reading in this project that said they were.
3. **Find out what the June bulk change was.** Forty accounts in one domain, one survivor in this
   family, no notification to the people depending on them. Whatever process did that will do it
   again, and the next time it may hit `fos.org.uk`.
4. **Retire the personal accounts from production feeds** — `e-sadegunle` in two environments,
   `e-lpoleschtschuk1` as the current interim on `vmsysappmon01`.
