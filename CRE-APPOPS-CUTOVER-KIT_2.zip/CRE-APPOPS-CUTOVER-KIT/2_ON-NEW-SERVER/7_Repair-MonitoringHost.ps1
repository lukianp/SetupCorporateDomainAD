<#
.SYNOPSIS
  Applies the known, mechanical fixes to a rebuilt monitoring host, driven by the OLD server's
  capture manifest so it restores what was actually there rather than what we assume. Idempotent.
  Nothing is written without -Apply.

.DESCRIPTION
  Fix 1  "Log on as a batch job" for every account used by a migrated task. Registering a task with
         a stored password is supposed to grant this; on Server 2025 it does not, so tasks are
         refused at launch with 0x80070569 and report 0x41303 "has never run". Verified after the
         grant, because secedit reports success and changes nothing when a GPO owns the setting.
  Fix 2  Directories from the manifest, and Modify for each task account on the textfile directory.
         An admin-created folder leaves the service accounts read-only and every feed then reports
         success while producing nothing.
  Fix 3  Firewall: inbound rules for the ports the old server was listening on.
  Fix 4  windows_exporter: service with BOTH paths quoted, config.yaml with directories as a YAML
         LIST, and a start loop that reads "unknown collector X" out of the binary's own stderr,
         drops X and retries. That is what 'cs' needed - it existed in wmi_exporter 0.4.x and was
         removed from windows_exporter, and the service fails closed on one unknown name.
  Fix 5  -RegisterTasks re-registers every task from the captured XML, DISABLED, prompting once per
         account. Disabled on purpose: enable them one at a time afterwards.
  Fix 6  -ApplyEnvironment restores machine environment variables and PATH entries from the manifest.

  Grafana and Prometheus are reported on but never rewritten - a config file with ten years of local
  decisions in it is not something a script should overwrite. It tells you exactly what to change.

.PARAMETER CaptureFolder  The folder from Invoke-ServerCapture on the OLD server.
.PARAMETER Apply          Make the changes. Without it this is a dry run.
.PARAMETER RegisterTasks  Also register the captured tasks (disabled).
.PARAMETER CollectorList  collectors.enabled for a NEW config.yaml. Add iis / msmq / mssql per role.

.EXAMPLE
  .\Repair-MonitoringHost.ps1 -CaptureFolder C:\Migration\capture-SRVSYS1APPMON01-...
  .\Repair-MonitoringHost.ps1 -CaptureFolder <folder> -Apply
  .\Repair-MonitoringHost.ps1 -CaptureFolder <folder> -Apply -RegisterTasks
#>
[CmdletBinding(SupportsShouldProcess = $true)]
param(
    [string]   $CaptureFolder,
    [string]   $ServiceName    = 'windows_exporter',
    [string]   $ExporterExe,
    [string]   $ExporterConfig,
    [string]   $PromDir        = 'D:\Win\Ops\WMITextfileExport',
    [string]   $ScriptsRoot    = 'D:\Win\Ops',
    [string[]] $Accounts,
    [string]   $CollectorList  = 'cpu,cpu_info,logical_disk,memory,net,os,physical_disk,service,system,textfile',
    [switch]   $Apply,
    [switch]   $RegisterTasks,
    [switch]   $ApplyEnvironment,
    [switch]   $SkipRights,
    [switch]   $SkipService,
    [switch]   $Sanitize,
    [switch]   $Force
)
$ErrorActionPreference = 'Continue'
$SuiteVersion = '1.0'
Import-Module (Join-Path $PSScriptRoot 'FOSMigrate.psm1') -Force -ErrorAction Stop
Assert-FosAdmin
New-FosReport -Sanitize:$Sanitize
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
New-Item -ItemType Directory -Force -Path C:\Migration | Out-Null

Write-Host ''
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ("  Repair-MonitoringHost {0}   RUNNING ON: {1}" -f $SuiteVersion, $env:COMPUTERNAME) -ForegroundColor Cyan
Write-Host ("  MODE: {0}" -f $(if ($Apply) { 'APPLY - changes will be made' } else { 'DRY RUN - add -Apply to change anything' })) -ForegroundColor $(if ($Apply) { 'Yellow' } else { 'DarkGray' })
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host '  If that is not the server you are fixing, STOP.' -ForegroundColor DarkGray
Write-Host ''

# ------------------------------------------------------------------ inputs
$MO = $null
if ($CaptureFolder) {
    $mf = Join-Path $CaptureFolder 'manifest.json'
    if (Test-Path -LiteralPath $mf) { $MO = Import-FosManifest $mf }
    else { Add-FosFinding -Severity warn -Area 'input' -Problem "no manifest.json in $CaptureFolder - running on discovery only" }
}
if ($MO) {
    if (-not $Accounts)   { $Accounts = @($MO.taskAccounts) }
    if ($MO.exporter) {
        if (-not $PSBoundParameters.ContainsKey('PromDir') -and $MO.exporter.textfileDir) { $PromDir = "$($MO.exporter.textfileDir)" }
        if (-not $ExporterExe -and $MO.exporter.exe) { $ExporterExe = "$($MO.exporter.exe)" }
        if (-not $ExporterConfig -and $MO.exporter.configFile) { $ExporterConfig = "$($MO.exporter.configFile)" }
        # rebuild the old collector list, minus anything this exporter version dropped
        if ($MO.exporter.collectors -and -not $PSBoundParameters.ContainsKey('CollectorList')) {
            $keep = @(@($MO.exporter.collectors) | Where-Object { $_ -and $_ -ne 'cs' })
            if (@($MO.exporter.collectors) -contains 'cs') { foreach ($a in 'cpu_info', 'memory') { if ($keep -notcontains $a) { $keep += $a } } }
            $CollectorList = ($keep -join ',')
        }
    }
}
# discovery fallback
$tasksHere = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft*' })
if (-not $Accounts) {
    $Accounts = @($tasksHere | ForEach-Object { "$($_.Principal.UserId)" } |
        Where-Object { $_ -and $_ -notmatch '^(?:NT AUTHORITY\\)?(SYSTEM|LOCAL SERVICE|NETWORK SERVICE)$' } | Sort-Object -Unique)
}
$svcAll = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'exporter|grafana|prometheus' })
if (-not $Accounts.Count -and -not $svcAll.Count -and -not $Force) {
    throw "This does not look like a monitoring host: no task accounts and no exporter/grafana/prometheus service. Use -Force to override."
}
if ($Sanitize) {
    Add-FosMask $env:COMPUTERNAME 'THIS-HOST'
    if ($MO) { Add-FosMask "$($MO.host)" 'OLD-HOST' }
    $i = 0; foreach ($a in $Accounts) { $i++; Add-FosMask (ConvertTo-FosSam $a) "SVCACCT-$i"; Add-FosMask (("$a" -split '\\')[0]) 'DOM' }
}

Add-FosHead 'MONITORING HOST REPAIR'
Add-FosKV 'Generated'  (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Add-FosKV 'Script'     "Repair-MonitoringHost $SuiteVersion"
Add-FosKV 'Server'     (Get-FosMask $env:COMPUTERNAME)
Add-FosKV 'Mode'       $(if ($Apply) { 'APPLY' } else { 'DRY RUN' })
Add-FosKV 'From capture' $(if ($MO) { "$(Get-FosMask $MO.host) @ $($MO.capturedAt)" } else { '(none - discovery only)' })
Add-FosKV 'Task accounts' (Get-FosMask ($Accounts -join ', '))
Add-FosKV 'Textfile dir'  $PromDir
Add-FosKV 'Collector list' $CollectorList

function Should-Do { param([string]$Target, [string]$Action)
    if (-not $Apply) { Add-FosLine ("    would: {0} - {1}" -f $Action, (Get-FosMask $Target)); return $false }
    return $PSCmdlet.ShouldProcess($Target, $Action) }

# ================================================================== Fix 1: rights
if (-not $SkipRights -and $Accounts.Count) {
    Start-FosStep 'batch logon right'
    Add-FosSub 'Fix 1 - log on as a batch job'
    $batch = Get-FosUserRight 'SeBatchLogonRight'
    $deny  = Get-FosUserRight 'SeDenyBatchLogonRight'
    foreach ($b in $batch) { Add-FosLine "    holds: $(Get-FosMask $b)" }
    foreach ($d in $deny)  { Add-FosLine "    DENY : $(Get-FosMask $d)" }
    Add-FosLine ''
    $need = @()
    foreach ($a in $Accounts) {
        $has = Test-FosInList $a $batch
        $den = Test-FosInList $a $deny
        Add-FosLine ("    {0,-34} right={1,-5} deny={2}" -f (Get-FosMask $a), $has, $den)
        if ($den) { Add-FosFinding -Severity blocker -Area 'rights' -Problem "$a is in DENY log on as a batch job" -Fix 'Deny always wins - remove it there (usually a GPO) before anything else' }
        elseif (-not $has) { $need += $a }
    }
    if ($need.Count) {
        if (Should-Do 'SeBatchLogonRight' "Grant to $($need -join ', ')") {
            $null = Grant-FosUserRight -Name 'SeBatchLogonRight' -Accounts $need -Confirm:$false
        }
    } else { Add-FosLine '    nothing to grant' }
    $gpo = Test-FosRightIsGpoManaged
    Add-FosKV 'Managed by GPO' $(if ($null -eq $gpo) { 'unknown (gpresult timed out)' } elseif ($gpo) { 'YES' } else { 'no - a local grant persists' })
    if ($gpo -eq $true) { Add-FosFinding -Severity warn -Area 'rights' -Problem 'a GPO manages this right' -Fix 'The local grant is reverted at the next policy refresh and the tasks stop hours later with no obvious trigger. Get the accounts into the GPO.' }
}

# ================================================================== Fix 2: directories and ACLs
Start-FosStep 'directories and ACLs'
Add-FosSub 'Fix 2 - directories and write access'
$dirs = @($ScriptsRoot, $PromDir)
if ($MO) { foreach ($t in @($MO.appTrees)) { if ("$($t.root)" -and $dirs -notcontains "$($t.root)") { $dirs += "$($t.root)" } } }
foreach ($d in $dirs) {
    if (-not $d) { continue }
    if (Test-Path -LiteralPath $d) { Add-FosLine "    exists: $d"; continue }
    if (Should-Do $d 'Create directory') {
        New-Item -ItemType Directory -Force -Path $d | Out-Null
        Add-FosFinding -Severity done -Area 'dirs' -Problem "created $d" }
}
if (Test-Path -LiteralPath $PromDir) {
    foreach ($a in $Accounts) {
        $sam = ConvertTo-FosSam $a
        $has = $false
        try { $has = [bool](@((Get-Acl -LiteralPath $PromDir).Access | Where-Object {
                "$($_.IdentityReference)" -like "*$sam" -and "$($_.AccessControlType)" -eq 'Allow' -and "$($_.FileSystemRights)" -match 'Modify|FullControl|Write' }).Count) } catch {}
        if ($has) { Add-FosLine ("    write access {0,-28}: yes" -f (Get-FosMask $sam)); continue }
        Add-FosLine ("    write access {0,-28}: NO" -f (Get-FosMask $sam))
        if (Should-Do $PromDir "Grant Modify to $a") {
            $o = & icacls $PromDir /grant "$($a):(OI)(CI)M" 2>&1
            if ($LASTEXITCODE -eq 0) { Add-FosFinding -Severity done -Area 'dirs' -Problem "granted Modify on $PromDir to $a" }
            else { Add-FosFinding -Severity blocker -Area 'dirs' -Problem "could not grant Modify on $PromDir to $a" -Fix (Format-FosTrim ($o -join ' ') 90) }
        }
    }
}

# ================================================================== Fix 3: firewall
Start-FosStep 'firewall'
Add-FosSub 'Fix 3 - inbound firewall rules'
$wantPorts = @(9182)
if ($MO) {
    foreach ($l in @($MO.listeners)) {
        if ("$($l.address)" -in '127.0.0.1', '::1') { continue }
        if ([int]$l.port -in 135, 139, 445, 3389, 5985, 5986, 47001, 0) { continue }
        if ($wantPorts -notcontains [int]$l.port) { $wantPorts += [int]$l.port }
    }
}
foreach ($port in $wantPorts) {
    $existing = @()
    try { $existing = @(Get-NetFirewallPortFilter -ErrorAction Stop | Where-Object { $_.LocalPort -contains "$port" } |
                        Get-NetFirewallRule -ErrorAction SilentlyContinue |
                        Where-Object { $_.Enabled -eq 'True' -and $_.Direction -eq 'Inbound' }) } catch {}
    if ($existing) { Add-FosLine ("    port {0,-6} allowed by '{1}'" -f $port, (Format-FosTrim $existing[0].DisplayName 50)); continue }
    Add-FosLine ("    port {0,-6} NO INBOUND RULE" -f $port)
    if (Should-Do "TCP $port inbound" 'Create firewall rule') {
        New-NetFirewallRule -DisplayName "Monitoring inbound TCP $port" -Direction Inbound -Protocol TCP -LocalPort $port -Action Allow -Profile Domain | Out-Null
        Add-FosFinding -Severity done -Area 'firewall' -Problem "created inbound rule for TCP $port" }
}

# ================================================================== Fix 4: exporter
if (-not $SkipService) {
    Start-FosStep 'exporter service'
    Add-FosSub 'Fix 4 - windows_exporter'
    $svc = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq $ServiceName -or $_.Name -match 'exporter' }) | Select-Object -First 1
    if (-not $ExporterExe) {
        if ($svc -and "$($svc.PathName)" -match '^"([^"]+\.exe)"') { $ExporterExe = $Matches[1] }
        elseif ($svc -and "$($svc.PathName)" -match '^(\S+\.exe)') { $ExporterExe = $Matches[1] }
        else { foreach ($c in 'C:\Program Files\windows_exporter\windows_exporter.exe', 'C:\Program Files\wmi_exporter\wmi_exporter.exe') { if (Test-Path -LiteralPath $c) { $ExporterExe = $c; break } } }
    }
    if (-not $ExporterConfig) {
        if ($ExporterExe) { $ExporterConfig = Join-Path (Split-Path -Parent $ExporterExe) 'config.yaml' }
    }
    Add-FosKV 'Exe'    (Get-FosMask $ExporterExe)
    Add-FosKV 'Config' (Get-FosMask $ExporterConfig)

    if (-not $ExporterExe -or -not (Test-Path -LiteralPath $ExporterExe)) {
        Add-FosFinding -Severity blocker -Area 'exporter' -Problem 'exporter exe not found' -Fix 'Install windows_exporter 0.31.x, or pass -ExporterExe "<path>"'
    } else {
        $ver = (& $ExporterExe --version 2>&1 | Out-String)     # stderr by design; not an error
        Add-FosKV 'Version' (Format-FosTrim $ver 70)
        if ($ver -match '(?i)^wmi_exporter,?\s*version\s*0\.[0-4]\.') {
            Add-FosFinding -Severity blocker -Area 'exporter' -Problem 'this is the OLD wmi_exporter binary' -Fix 'Replace with windows_exporter 0.31.x before going further' }
        if (Get-Item -LiteralPath $ExporterExe -Stream Zone.Identifier -ErrorAction SilentlyContinue) {
            if (Should-Do $ExporterExe 'Unblock-File') { Unblock-File -LiteralPath $ExporterExe; Add-FosFinding -Severity done -Area 'exporter' -Problem 'removed mark-of-the-web from the exporter exe' } }

        $goodYaml = @"
collectors:
  enabled: $CollectorList
collector:
  textfile:
    directories:
      - $PromDir
web:
  listen-address: ":9182"
log:
  level: warn
"@
        if (-not (Test-Path -LiteralPath $ExporterConfig)) {
            if (Should-Do $ExporterConfig 'Create config.yaml') {
                $goodYaml | Set-Content -LiteralPath $ExporterConfig -Encoding ascii
                Add-FosFinding -Severity done -Area 'exporter' -Problem "created $ExporterConfig" }
        } else {
            $cfgTxt = Get-Content -LiteralPath $ExporterConfig -Raw
            # [ \t] not \s: \s matches newlines, so a CORRECT list form would match and be re-mangled
            if ($cfgTxt -match '(?m)^[ \t]*directories:[ \t]*\S') {
                if (Should-Do $ExporterConfig 'Rewrite directories: as a YAML list') {
                    Copy-Item -LiteralPath $ExporterConfig -Destination "$ExporterConfig.bak" -Force
                    $fixed = [regex]::Replace($cfgTxt, '(?m)^([ \t]*)directories:[ \t]*(\S.*)$',
                        { param($m) "$($m.Groups[1].Value)directories:`r`n$($m.Groups[1].Value)  - $($m.Groups[2].Value.Trim())" })
                    $fixed | Set-Content -LiteralPath $ExporterConfig -Encoding ascii
                    Add-FosFinding -Severity done -Area 'exporter' -Problem "rewrote directories: as a YAML list (backup at $ExporterConfig.bak)" }
            }
        }

        $binPath = '"{0}" --config.file="{1}"' -f $ExporterExe, $ExporterConfig
        if (-not $svc) {
            if (Should-Do $ServiceName 'Create service') {
                New-Service -Name $ServiceName -DisplayName 'windows_exporter (Prometheus metrics agent)' -BinaryPathName $binPath -StartupType Automatic | Out-Null
                Add-FosFinding -Severity done -Area 'exporter' -Problem "created service '$ServiceName'" }
        } elseif ("$($svc.PathName)" -ne $binPath) {
            Add-FosLine ("    service path differs:`n      now  {0}`n      want {1}" -f (Get-FosMask $svc.PathName), (Get-FosMask $binPath))
            if (Should-Do $ServiceName 'Correct the service binary path') {
                if ("$($svc.State)" -eq 'Running') { Stop-Service $svc.Name -Force -ErrorAction SilentlyContinue; Start-Sleep 2 }
                $o = & sc.exe config $svc.Name binPath= $binPath start= auto 2>&1
                if ($LASTEXITCODE -eq 0) { Add-FosFinding -Severity done -Area 'exporter' -Problem 'corrected the service binary path' }
                else { Add-FosFinding -Severity blocker -Area 'exporter' -Problem "sc config failed: $(Format-FosTrim ($o -join ' ') 80)" } }
        }

        if ($Apply) {
            $svcTarget = $(if ($svc) { $svc.Name } else { $ServiceName })
            $dropped = @()
            for ($round = 0; $round -lt 6; $round++) {
                if ((Get-Service $svcTarget -ErrorAction SilentlyContinue).Status -eq 'Running') { break }
                try { Start-Service $svcTarget -ErrorAction Stop; Start-Sleep 4 } catch {}
                if ((Get-Service $svcTarget -ErrorAction SilentlyContinue).Status -eq 'Running') {
                    Add-FosFinding -Severity done -Area 'exporter' -Problem ("started $svcTarget" + $(if ($dropped) { " after dropping unsupported collector(s): $($dropped -join ',')" } else { '' })); break }
                # the SCM never tells you why. The binary does - in the foreground, on stderr.
                $eo = "$env:TEMP\exp-probe-out.txt"; $ee = "$env:TEMP\exp-probe-err.txt"
                Remove-Item $eo, $ee -ErrorAction SilentlyContinue
                try {
                    $pp = Start-Process -FilePath $ExporterExe -ArgumentList "--config.file=`"$ExporterConfig`"" -NoNewWindow -PassThru -RedirectStandardOutput $eo -RedirectStandardError $ee
                    Start-Sleep 5
                    if (-not $pp.HasExited) { Stop-Process -Id $pp.Id -Force }
                } catch {}
                $msg = ''
                foreach ($f in $ee, $eo) { if (Test-Path $f) { $msg += (Get-Content $f -Raw) } }
                $bad = @([regex]::Matches($msg, '(?i)unknown collector[:\s]+"?([A-Za-z0-9_]+)') | ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique)
                if (-not $bad.Count) {
                    Add-FosFinding -Severity blocker -Area 'exporter' -Problem "the service will not start: $(Format-FosTrim $msg 200)" -Fix 'That message is the real reason - usually YAML, a flag, a missing directory, or port 9182 already held'
                    Add-FosLine '    foreground output:'
                    foreach ($l in ("$msg" -split "`r?`n" | Select-Object -First 12)) { if ($l.Trim()) { Add-FosLine "      $l" } }
                    break }
                $cfgTxt = Get-Content -LiteralPath $ExporterConfig -Raw
                $line = [regex]::Match($cfgTxt, '(?m)^(\s*enabled:\s*)(.+)$')
                if (-not $line.Success) { Add-FosFinding -Severity blocker -Area 'exporter' -Problem "cannot find 'enabled:' in the config to remove $($bad -join ',')"; break }
                $keep = @($line.Groups[2].Value -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ -and $bad -notcontains $_ })
                # 'cs' did not disappear, it was split: physical memory -> memory, logical processors -> cpu_info
                if ($bad -contains 'cs') { foreach ($a in 'cpu_info', 'memory') { if ($keep -notcontains $a) { $keep += $a } } }
                $dropped += $bad
                $cfgTxt = $cfgTxt -replace [regex]::Escape($line.Value), ($line.Groups[1].Value + ($keep -join ','))
                $cfgTxt | Set-Content -LiteralPath $ExporterConfig -Encoding ascii
                Add-FosFinding -Severity done -Area 'exporter' -Problem "removed collector(s) this exporter version does not have: $($bad -join ', ')"
            }
        }
    }
    $svc2 = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -eq $ServiceName -or $_.Name -match 'exporter' }) | Select-Object -First 1
    Add-FosKV 'Service state' $(if ($svc2) { "$($svc2.Name) - $($svc2.State) ($($svc2.StartMode))" } else { 'NOT INSTALLED' })
    if ($svc2 -and "$($svc2.State)" -ne 'Running') { Add-FosFinding -Severity blocker -Area 'exporter' -Problem "the exporter service is $($svc2.State)" -Fix 'Re-run with -Apply; the start loop captures the binary''s own error' }
    if ($ExporterConfig -and (Test-Path -LiteralPath $ExporterConfig)) {
        Add-FosLine ''
        Add-FosLine '  config.yaml verbatim:'
        foreach ($l in (Get-Content -LiteralPath $ExporterConfig)) { Add-FosLine "    $l" }
    }
    try {
        $m = (Invoke-WebRequest 'http://localhost:9182/metrics' -UseBasicParsing -TimeoutSec 20).Content -split "`n"
        Add-FosKV 'Metric lines served' $m.Count
        Add-FosKV 'Textfile files exposed' @($m | Where-Object { $_ -match '_textfile_mtime_seconds' -and $_ -notmatch '^#' }).Count
    } catch { Add-FosFinding -Severity warn -Area 'exporter' -Problem 'nothing answered on http://localhost:9182/metrics' }
}

# ================================================================== Fix 5: task registration
if ($RegisterTasks) {
    Start-FosStep 'task registration'
    Add-FosSub 'Fix 5 - register the captured tasks (DISABLED)'
    $xmlDir = $(if ($CaptureFolder) { Join-Path $CaptureFolder 'tasks' } else { $null })
    if (-not $xmlDir -or -not (Test-Path -LiteralPath $xmlDir)) {
        Add-FosFinding -Severity blocker -Area 'tasks' -Problem 'no tasks folder in the capture' -Fix 'Run Invoke-ServerCapture on the old server and copy the whole capture folder across'
    } else {
        $credCache = @{}
        foreach ($x in @(Get-ChildItem -LiteralPath $xmlDir -Filter *.xml | Sort-Object Name)) {
            [xml]$doc = Get-Content -LiteralPath $x.FullName -Raw
            $uri = "$($doc.Task.RegistrationInfo.URI)"
            if (-not $uri) { $uri = '\' + $x.BaseName }
            $tn = Split-Path $uri -Leaf
            $tp = Split-Path $uri -Parent
            if (-not $tp) { $tp = '\' }
            if ($tp -ne '\' -and -not $tp.EndsWith('\')) { $tp = "$tp\" }
            $uid = "$($doc.Task.Principals.Principal.UserId)"
            $lt  = "$($doc.Task.Principals.Principal.LogonType)"
            if (Get-ScheduledTask -TaskName $tn -TaskPath $tp -ErrorAction SilentlyContinue) {
                Add-FosLine ("    exists, skipped: {0}" -f (Get-FosMask $uri)); continue }
            if (-not (Should-Do $uri "Register as $uid ($lt), disabled")) { continue }
            try {
                $xmlText = Get-Content -LiteralPath $x.FullName -Raw
                if ($lt -match 'Password') {
                    if (-not $credCache.ContainsKey($uid)) { $credCache[$uid] = Get-Credential -UserName $uid -Message "Password for scheduled task account $uid" }
                    $c = $credCache[$uid]
                    Register-ScheduledTask -TaskName $tn -TaskPath $tp -Xml $xmlText -User $c.UserName -Password $c.GetNetworkCredential().Password -Force | Out-Null
                } else {
                    Register-ScheduledTask -TaskName $tn -TaskPath $tp -Xml $xmlText -Force | Out-Null
                }
                Disable-ScheduledTask -TaskName $tn -TaskPath $tp -ErrorAction SilentlyContinue | Out-Null
                Add-FosFinding -Severity done -Area 'tasks' -Problem "registered $uri (disabled)"
            } catch { Add-FosFinding -Severity blocker -Area 'tasks' -Problem "failed to register $uri" -Fix (Format-FosTrim $_.Exception.Message 90) }
        }
        Add-FosLine ''
        Add-FosLine '  Registered DISABLED on purpose. Enable ONE task, wait for its .prom, then the next.'
    }
}

# ================================================================== Fix 6: environment
if ($ApplyEnvironment -and $MO) {
    Start-FosStep 'environment'
    Add-FosSub 'Fix 6 - machine environment variables from the old server'
    $skip = '^(Path|PATHEXT|TEMP|TMP|windir|ComSpec|NUMBER_OF_PROCESSORS|OS|PROCESSOR_|PSModulePath|USERNAME|DriverData)'
    foreach ($v in @($MO.environment.variables)) {
        if ("$($v.name)" -match $skip) { continue }
        $cur = [Environment]::GetEnvironmentVariable("$($v.name)", 'Machine')
        if ("$cur" -eq "$($v.value)") { continue }
        if (Should-Do "$($v.name)" "Set machine env var to '$($v.value)'") {
            [Environment]::SetEnvironmentVariable("$($v.name)", "$($v.value)", 'Machine')
            Add-FosFinding -Severity done -Area 'environment' -Problem "set $($v.name)=$($v.value)" }
    }
}

# ================================================================== Grafana / Prometheus: advise, never overwrite
if ($MO -and ($MO.grafana -or $MO.prometheus)) {
    Add-FosSub 'Grafana / Prometheus - reported, not rewritten'
    Add-FosLine '  A config with ten years of local decisions in it is not something a script should'
    Add-FosLine '  overwrite. Here is what the OLD server had; change it by hand and restart the service.'
    if ($MO.grafana) {
        Add-FosLine ''
        Add-FosKV 'Grafana version (old)' $MO.grafana.version
        Add-FosKV 'http_port (old)'       $MO.grafana.configuredPort
        Add-FosKV 'root_url (old)'        (Get-FosMask $MO.grafana.rootUrl)
        Add-FosKV 'database (old)'        "$($MO.grafana.database.type) $($MO.grafana.database.path)"
        Add-FosKV 'alerting (old)'        $MO.grafana.alertingMode
        Add-FosKV 'plugins (old)'         (@($MO.grafana.plugins) -join ', ')
        Add-FosLine ''
        Add-FosLine '  Minimum custom.ini to reproduce the old server:'
        Add-FosLine '    [server]'
        Add-FosLine "    http_port = $($MO.grafana.configuredPort)"
        if ($MO.grafana.rootUrl) { Add-FosLine "    root_url = $($MO.grafana.rootUrl)" }
        if ("$($MO.grafana.database.type)") { Add-FosLine '    [database]'; Add-FosLine "    type = $($MO.grafana.database.type)"; if ($MO.grafana.database.path) { Add-FosLine "    path = $($MO.grafana.database.path)" } }
        Add-FosLine '  Grafana reads defaults.ini then custom.ini. If custom.ini is absent it runs entirely'
        Add-FosLine '  on defaults - port 3000, sqlite in the default location - which looks like a fresh install.'
    }
    if ($MO.prometheus) {
        Add-FosLine ''
        Add-FosKV 'Prometheus version (old)' $MO.prometheus.version
        Add-FosKV 'retention (old)'          $MO.prometheus.retention
        Add-FosKV 'scrape jobs (old)'        (@($MO.prometheus.scrapeJobs) -join ', ')
        Add-FosKV 'targets (old)'            @($MO.prometheus.targets).Count
        Add-FosLine ''
        Add-FosLine '  Do not forget to add THIS host to the file_sd JSON on the APPOPS server, with the'
        Add-FosLine '  same Environment label as its neighbours, alongside the old entry - not instead of it.'
    }
}

Add-FosFindingSummary
Add-FosSub 'next'
if (-not $Apply) {
    Add-FosLine '  This was a DRY RUN. Re-run with -Apply to make the changes above.'
} else {
    Add-FosLine '  1. Re-run Invoke-ServerCapture here, then Compare-ServerBaseline against the old manifest.'
    Add-FosLine '  2. Re-create nothing for credentials until you have checked HOW they are stored: a script'
    Add-FosLine '     using ConvertTo-SecureString -AsPlainText has a portable secret that travels with the'
    Add-FosLine '     files, and there is nothing to re-create.'
    Add-FosLine '  3. Enable ONE task. Wait for its .prom file. Then the next.'
    Add-FosLine '  4. Test-MonitoringHost.ps1 for the runtime acceptance test.'
}
Add-FosHead 'END OF REPORT'
Add-FosLine '  Paste this whole report back to continue.'
$null = Write-FosReport -Path "C:\Migration\REPAIR-$env:COMPUTERNAME-$stamp.txt"
