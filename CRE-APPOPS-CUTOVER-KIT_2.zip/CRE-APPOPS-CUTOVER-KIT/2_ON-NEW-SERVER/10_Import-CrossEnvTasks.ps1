<#
.SYNOPSIS
  Imports one environment's APPMON scheduled tasks onto a host that already serves a DIFFERENT
  environment: renames the task set with a suffix, suffixes the .prom output so both sets can share
  one textfile directory and one exporter, and checks they will not collide. Dry run until -Apply.

.DESCRIPTION
  There is no new STG box, so STG's feeders are co-hosted. Both environments ship identically named
  tasks writing identically named .prom files, so three things get separated:

   1. TASK NAMES     "PhoenixConfigExporter-self-ScheduledTask" becomes
                     "PhoenixConfigExporter-self-ScheduledTask_STG" (-TaskSuffix). The <URI> inside
                     the XML is rewritten to match, or Task Scheduler keeps the old identity.

   2. SCRIPT TREES   Both want D:\Win\Ops\PhoenixConfigExporter\, so the incoming set gets its own
                     copy and every path is rewritten - in the task XML AND inside the scripts, since
                     a feeder that opens its config by absolute path ignores where the script was
                     copied to. Not cosmetic: those trees hold the per-environment config carrying
                     the D365 endpoint and a plaintext credential, so a shared tree points STG's jobs
                     at the other environment's system and reports success doing it.

                     Two layouts, -Layout picks one:
                       Nested   (default)  D:\Win\Ops\STG\PhoenixConfigExporter\
                       Suffixed            D:\Win\Ops\PhoenixConfigExporter_STG\
                     Nested is the recommendation - one folder to ACL, back up and delete when a real
                     STG box arrives, and a script doing Split-Path $PSScriptRoot -Parent still finds
                     its STG siblings. Under Suffixed that same lookup lands on the HOST environment's
                     copy. Suffixed is supported because the folder name then says which environment
                     it is at a glance, which some teams prefer.

                     -SharedFolder names the folders that are NOT copied or renamed under either
                     layout: the textfile directory (shared on purpose) and any shared bin/tools.

   3. .prom NAMES    adhoc_metrics.prom becomes adhoc_metrics_stg.prom (-PromSuffix), so both sets
                     write into ONE directory and ONE exporter collects them all. The feeder scripts
                     choose their own output filename, so this is done by patching the STG COPY of
                     the scripts - every change is backed up and printed.

  AND THE ONE A FILENAME DOES NOT FIX. Renaming the file does not rename the metrics inside it. The
  exporter concatenates every .prom into one scrape response, so if both files carry
  phoenix_config_items{item="x"} with identical labels, Prometheus does not get two series - it
  rejects the WHOLE scrape as duplicate, taking this host's own metrics down with it. Section 3e
  parses the .prom files actually present and reports any metric+labelset appearing in more than one
  file. Run it again after STG's first output lands; that check is the one that matters.

  Carries the CRE and SYS lessons: every account is resolved before anything is registered (the SYS
  import died on a deleted account reported as NONE_MAPPED), the AD Log On To list is checked against
  THIS host, the batch-logon right is checked AND granted, and everything registers DISABLED.

.PARAMETER CaptureFolder  Capture/discovery folder from the SOURCE server (holds tasks\*.xml).
.PARAMETER SourceEnv      Incoming environment. Default STG.
.PARAMETER TaskSuffix     Appended to every imported task name. Default _STG.
.PARAMETER PromSuffix     Appended to every .prom filename the incoming scripts write. Default _stg.
.PARAMETER PromDir        Textfile directory. Defaults to the SHARED one, since the suffix separates them.
.PARAMETER Layout         Nested (D:\Win\Ops\STG\Foo) or Suffixed (D:\Win\Ops\Foo_STG). Default Nested.
.PARAMETER FolderSuffix   Suffixed layout only. Defaults to the task suffix (_STG).
.PARAMETER SharedFolder   Folders the incoming env should RUN THIS HOST'S COPY of. Minimal by design.
.PARAMETER ExcludeTask    Regex of task names never to import. Defaults to Windows housekeeping tasks.
.PARAMETER IncludeTask    Regex whitelist - if set, only matching task names are imported.
.PARAMETER SourceHost     Old server name, used only to print the robocopy lines.
.PARAMETER StagingRoot    A wholesale copy of the old server's D:\Win\Ops, parked OUTSIDE the live
                          root. The script picks out only the components the task set references and
                          places each one under its destination name. Must not sit inside D:\Win\Ops.
.PARAMETER ScriptsRoot    Where the incoming tree lives HERE. Default D:\Win\Ops\STG.
.PARAMETER Account        Override the task account (when the XML account is gone or renamed).
.PARAMETER SkipPromPatch  Do not patch .prom filenames in the incoming script tree.
.PARAMETER SkipPathPatch  Do not re-point absolute paths inside the incoming script tree.
.PARAMETER Apply          Make changes. Without it, everything is a dry run.

.EXAMPLE
  # dry run - prints the robocopy lines for the trees these tasks need
  .\Import-CrossEnvTasks.ps1 -CaptureFolder C:\scripts\SRVSTG1APPMON01 -SourceHost SRVSTG1APPMON01

.EXAMPLE
  # copy the old D:\Win\Ops wholesale to a staging folder, then let the script take what it needs
  robocopy \\SRVSTG1APPMON01\D$\Win\Ops D:\Win\_STG-source /E /COPY:DAT /R:1 /W:1
  .\Import-CrossEnvTasks.ps1 -CaptureFolder C:\scripts\SRVSTG1APPMON01 -StagingRoot D:\Win\_STG-source
  .\Import-CrossEnvTasks.ps1 -CaptureFolder C:\scripts\SRVSTG1APPMON01 -StagingRoot D:\Win\_STG-source -Apply

.EXAMPLE
  # D:\Win\Ops\PhoenixConfigExporter_STG\ instead of D:\Win\Ops\STG\PhoenixConfigExporter\
  .\Import-CrossEnvTasks.ps1 -CaptureFolder C:\scripts\SRVSTG1APPMON01 -Layout Suffixed

.EXAMPLE
  .\Import-CrossEnvTasks.ps1 -CaptureFolder C:\scripts\SRVSTG1APPMON01 -Layout Suffixed -Apply
  .\Import-CrossEnvTasks.ps1 -CheckSeriesOnly          # re-run the duplicate-series check any time
#>
[CmdletBinding()]
param(
    [string] $CaptureFolder,
    [string] $TasksFolder,
    [string] $SourceEnv         = 'STG',
    [string] $TaskSuffix,
    [string] $PromSuffix,
    [string] $TaskFolder        = '\',
    [string] $SourceScriptsRoot = 'D:\Win\Ops',
    [string] $ScriptsRoot,
    [ValidateSet('Nested', 'Suffixed')]
    [string] $Layout            = 'Nested',
    [string] $FolderSuffix,
    # Deliberately minimal. Marking a folder shared means the incoming environment RUNS THIS HOST'S
    # COPY of it - wrong config, wrong endpoint, wrong credential, and it reports success. A folder
    # wrongly copied is a wasted 20MB; a folder wrongly shared is a silent cross-environment fault.
    # The textfile directory is added automatically. Everything else has to be opted in by name.
    [string[]] $SharedFolder    = @('bin'),
    # Windows generates per-user tasks that have no business being migrated. They carry the SIDs of
    # accounts on the OLD machine, so they arrive as unresolvable principals and look like real
    # blockers. STG's capture had four of them and they produced four of the five blockers.
    [string] $ExcludeTask       = '^(Optimize Start Menu Cache Files|MicrosoftEdgeUpdate|GoogleUpdate|OneDrive|User_Feed_Synchronization|CreateExplorerShellUnelevated|\.NET Framework NGEN|Adobe Acrobat Update)',
    [string] $IncludeTask,
    [string] $SourceHost,
    [string] $StagingRoot,
    [string] $PromDir           = 'D:\Win\Ops\WMITextfileExport',
    [string] $Account,
    [string] $ExporterConfig,
    [switch] $SkipPromPatch,
    [switch] $SkipPathPatch,
    [switch] $CheckSeriesOnly,
    [switch] $Apply,
    [switch] $Force,
    [switch] $Sanitize
)
$ErrorActionPreference = 'Continue'
$Version = '3.6'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
if (-not $TaskSuffix)  { $TaskSuffix  = "_$($SourceEnv.ToUpper())" }
if (-not $PromSuffix)  { $PromSuffix  = "_$($SourceEnv.ToLower())" }
if (-not $TaskFolder.EndsWith('\')) { $TaskFolder = "$TaskFolder\" }
$SourceScriptsRoot = $SourceScriptsRoot.TrimEnd('\', '/')
if ($Layout -eq 'Suffixed') {
    if (-not $FolderSuffix) { $FolderSuffix = $TaskSuffix }
    if (-not $ScriptsRoot)  { $ScriptsRoot  = $SourceScriptsRoot }
} else {
    if (-not $ScriptsRoot)  { $ScriptsRoot  = Join-Path $SourceScriptsRoot $SourceEnv }
}
$ScriptsRoot = $ScriptsRoot.TrimEnd('\', '/')
if (-not $TasksFolder -and $CaptureFolder) { $TasksFolder = Join-Path $CaptureFolder 'tasks' }
if (-not $SourceHost -and $CaptureFolder) {
    $leaf = Split-Path $CaptureFolder -Leaf
    if ($leaf -match '^[A-Za-z][A-Za-z0-9-]{3,}$') { $SourceHost = $leaf }
}
if (-not $SourceHost) { $SourceHost = '<OLD-SERVER>' }

# Folders under the source root that BOTH environments share. They are never renamed and never
# copied: the textfile directory is shared on purpose (the .prom suffix keeps the files apart), and
# a shared bin/tools folder holds the exporter, not per-environment code. Renaming either would
# quietly undo the whole design - the incoming feeders would write into a directory no exporter reads.
$script:SharedSet = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($s in @($SharedFolder)) { if ($s) { [void]$script:SharedSet.Add($s.Trim('\', '/')) } }
if ("$PromDir" -like "$SourceScriptsRoot\*") {
    $pl = ("$PromDir".Substring($SourceScriptsRoot.Length).TrimStart('\', '/') -split '[\\/]')[0]
    if ($pl) { [void]$script:SharedSet.Add($pl) }
}

# ONE pattern, used both to LIST the components a task set references and to REWRITE them. Two
# separate expressions would eventually disagree about what counts as a component, and the copy plan
# would then name a folder the rewrite never touches. See Convert-EnvPath for why it is shaped so.
$script:PathRx = [regex]::Escape($SourceScriptsRoot) +
    '[\\/](?:(?<comp>[^\\/<>"'']+)(?<tail>[\\/])|(?<comp>[^\\/<>"''\s]+)(?<tail>)(?=["''<>\s]|$))'
New-Item -ItemType Directory -Force -Path C:\Migration | Out-Null
$ReportPath = "C:\Migration\CROSSENV-$SourceEnv-$env:COMPUTERNAME-$stamp.txt"

# ------------------------------------------------------------------ plumbing
$R = New-Object System.Collections.ArrayList
$Blockers = New-Object System.Collections.ArrayList
$Warns    = New-Object System.Collections.ArrayList
$Changes  = New-Object System.Collections.ArrayList
function RptLine { param($t = '') [void]$R.Add($t) }
function RptHead { param($t) RptLine ''; RptLine ('=' * 78); RptLine "  $t"; RptLine ('=' * 78) }
function RptSub  { param($t) RptLine ''; RptLine ("-- $t " + ('-' * [Math]::Max(0, 74 - $t.Length))) }
function RptKV   { param($k, $v) RptLine ("  {0,-30}: {1}" -f $k, $v) }
function Blocker { param($t, $fix = '') [void]$Blockers.Add([pscustomobject]@{ P = $t; F = $fix }); Write-Host "  BLOCKER $t" -ForegroundColor Red }
function Warn    { param($t, $fix = '') [void]$Warns.Add([pscustomobject]@{ P = $t; F = $fix }); Write-Host "  WARN    $t" -ForegroundColor Yellow }
function Changed { param($t) [void]$Changes.Add($t); Write-Host "  DONE    $t" -ForegroundColor Green }
function TrimTo  { param($s, [int]$n = 100) $t = ("$s" -replace '\s+', ' ').Trim(); if ($t.Length -le $n) { $t } else { $t.Substring(0, $n - 2) + '..' } }
$script:T0 = Get-Date
function Step { param($w) Write-Host ("  [{0,4:n0}s] {1} ..." -f (New-TimeSpan -Start $script:T0 -End (Get-Date)).TotalSeconds, $w) -ForegroundColor DarkGray }
$script:Map = @{}
function Mask { param($s)
    if (-not $Sanitize -or -not $s) { return $s }
    $t = "$s"
    foreach ($k in ($script:Map.Keys | Sort-Object Length -Descending)) { $t = [regex]::Replace($t, [regex]::Escape($k), $script:Map[$k], 'IgnoreCase') }
    return [regex]::Replace($t, 'S-1-5-21-[\d-]+-(\d+)', 'SID-x-$1') }
function Test-Resolves { param([string]$Principal)
    try { return (New-Object System.Security.Principal.NTAccount($Principal)).Translate([System.Security.Principal.SecurityIdentifier]).Value }
    catch { return $null } }
function Should-Do { param([string]$What)
    if (-not $Apply) { RptLine ("    would: {0}" -f (Mask $What)); return $false }
    return $true }
function Find-StagedComponent {
    <#
      Locates one component inside the staging copy. Tolerant about depth on purpose: the natural
      thing to do is copy the whole of D:\Win\Ops off the old box in one go, and that lands as
      <staging>\<Comp> or <staging>\Ops\<Comp> depending on whether robocopy was given the folder or
      its contents. Both are found, so nobody has to get the copy command exactly right.
    #>
    param([string]$Component)
    if (-not $StagingRoot) { return $null }
    $direct = Join-Path $StagingRoot $Component
    if (Test-Path -LiteralPath $direct -PathType Container) { return $direct }
    foreach ($depth in 1..3) {
        $pattern = "$StagingRoot\" + ('*\' * $depth) + $Component
        $hit = @(Get-Item -Path $pattern -ErrorAction SilentlyContinue | Where-Object { $_.PSIsContainer }) | Select-Object -First 1
        if ($hit) { return $hit.FullName }
    }
    return $null
}
function Test-HoldsRight {
    <#
      Does $Account hold a right, given the list of principals that hold it?

      Name-matching alone is not enough and gets this backwards in the most common case. A named
      admin account almost never appears in SeBatchLogonRight itself - it holds the right because
      BUILTIN\Administrators does and the account is a member. A direct-name check calls that "NO",
      and then the grant writes the person's own account into local security policy to fix a problem
      that did not exist. That is why this returns three states, not a boolean.

        YES     - held directly, or through a local group whose membership we could read
        NO      - every holder expanded cleanly and the account is in none of them
        UNKNOWN - a holder is a group we could not expand (a domain group, or Get-LocalGroupMember
                  failing on orphaned SIDs). The caller must NOT write policy on this.
    #>
    param([string]$Account, [string[]]$Holders)
    $sam = ($Account -split '\\')[-1]
    foreach ($h in $Holders) {
        if ($h -ieq $Account -or (($h -split '\\')[-1]) -ieq $sam) {
            return [pscustomobject]@{ Verdict = 'YES'; Via = 'held directly' } }
    }
    $unresolved = @()
    foreach ($h in $Holders) {
        $g = ($h -split '\\')[-1]
        $members = $null
        try { $members = @(Get-LocalGroupMember -Group $g -ErrorAction Stop) }
        catch { $unresolved += $h; continue }
        foreach ($m in $members) {
            $mn = "$($m.Name)"
            if ($mn -ieq $Account -or (($mn -split '\\')[-1]) -ieq $sam) {
                return [pscustomobject]@{ Verdict = 'YES'; Via = "held via $h" } }
            # a group inside the group - we are not walking domain group nesting from here
            if ("$($m.ObjectClass)" -match '(?i)group') { $unresolved += "$h -> $mn" }
        }
    }
    if ($unresolved.Count) {
        return [pscustomobject]@{ Verdict = 'UNKNOWN'
                                  Via = ("could not expand: " + (($unresolved | Select-Object -Unique -First 4) -join ', ')) }
    }
    return [pscustomobject]@{ Verdict = 'NO'; Via = '' }
}
function Grant-BatchLogon {
    <#
      Adds SeBatchLogonRight ("Log on as a batch job") to the local policy. This is the fault that
      stopped CRE dead - item 1 of the gotchas - and until now this script only WARNED about it, which
      meant the last step of the import was still a manual one nobody had written down.

      Grants by SID, not by name: the exported policy stores SIDs, and a name added as text is dropped
      silently by secedit if it cannot resolve it at import time.

      Returns a human-readable outcome string; never throws.
    #>
    param([string]$Principal)
    $sid = Test-Resolves $Principal
    if (-not $sid) { return 'skipped - the account does not resolve' }
    $stem = Join-Path $env:TEMP ('ur-' + [guid]::NewGuid().ToString('N'))
    $cfg = "$stem.inf"; $db = "$stem.sdb"
    try {
        $null = & secedit /export /areas USER_RIGHTS /cfg $cfg /quiet 2>&1
        if (-not (Test-Path -LiteralPath $cfg)) { return 'FAILED - secedit could not export the current policy' }
        $lines = @(Get-Content -LiteralPath $cfg)
        $idx = -1
        for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\s*SeBatchLogonRight\s*=') { $idx = $i; break } }
        if ($idx -ge 0) {
            if ($lines[$idx] -match [regex]::Escape($sid)) { return 'already held' }
            $lines[$idx] = $lines[$idx].TrimEnd() + ",*$sid"
        } else {
            $pr = -1
            for ($i = 0; $i -lt $lines.Count; $i++) { if ($lines[$i] -match '^\s*\[Privilege Rights\]') { $pr = $i; break } }
            if ($pr -lt 0) { return 'FAILED - no [Privilege Rights] section in the exported policy' }
            $lines = @($lines[0..$pr]) + @("SeBatchLogonRight = *$sid") + @($lines[($pr + 1)..($lines.Count - 1)])
        }
        # MUST be UTF-16. secedit writes its export as Unicode and silently rejects a UTF-8 .inf,
        # which looks exactly like the grant having worked and then not taken effect.
        $lines | Set-Content -LiteralPath $cfg -Encoding Unicode
        $out = & secedit /configure /db $db /cfg $cfg /areas USER_RIGHTS /quiet 2>&1
        if ($LASTEXITCODE -ne 0) { return ("FAILED - " + (TrimTo ($out -join ' ') 70)) }
        return 'granted'
    } catch { return ("FAILED - " + (TrimTo $_.Exception.Message 70)) }
    finally { Remove-Item "$stem.*" -Force -ErrorAction SilentlyContinue }
}
function Backup-Once { param([string]$Path)
    # Two patches run over the same files. Backing up on each one would leave the .bak holding the
    # half-patched version, which is useless to revert to - so the FIRST backup is kept and is the
    # pristine copy that came off the old server.
    $bak = "$Path.bak"
    if (-not (Test-Path -LiteralPath $bak)) { Copy-Item -LiteralPath $Path -Destination $bak -Force } }

# ------------------------------------------------------------------ the two transformations
function Add-PromSuffix {
    <#
      Rewrites .prom filenames in script text. Only touches LITERAL names: a dynamic name such as
      "$prefix.prom" cannot be suffixed by string surgery ("$prefix_stg.prom" would make PowerShell
      look for a variable called $prefix_stg), so those are reported for a human instead of guessed at.
      Returns @{ Text; Changes[]; Manual[] }.
    #>
    param([string]$Text, [string]$Suffix)
    $promChanges = New-Object System.Collections.ArrayList
    $manual  = New-Object System.Collections.ArrayList
    $esc = [regex]::Escape($Suffix)
    # 'lead' catches the end of a variable expression immediately before the name: $prefix.prom,
    # ${x}.prom, $($x).prom. Suffixing those textually would produce "$prefix_stg.prom", which
    # PowerShell reads as a variable named $prefix_stg - a silent breakage. Those are reported, not
    # rewritten. A literal name after a path variable ("$dir\adhoc.prom") has no lead and IS rewritten.
    $out = [regex]::Replace($Text, '(?<lead>[\$\}\)]?)(?<base>[A-Za-z0-9_\-.]*)\.prom\b', {
        param($m)
        $lead = $m.Groups['lead'].Value
        $b = $m.Groups['base'].Value
        if ($lead -or -not $b) { [void]$manual.Add($m.Value); return $m.Value }   # dynamic - leave alone
        if ($b -match "$esc`$") { return $m.Value }                               # already suffixed
        [void]$promChanges.Add("$b.prom -> $b$Suffix.prom")
        return "$b$Suffix.prom"
    })
    return @{ Text = $out; Changes = @($promChanges); Manual = @($manual) }
}

$script:PathHits = New-Object System.Collections.ArrayList
function Convert-EnvPath {
    <#
      THE single place any D:\Win\Ops\... path is re-pointed at the incoming environment's own copy.
      Used on the task XML AND on the text inside the copied scripts, because a feeder that opens
      "D:\Win\Ops\PhoenixConfigExporter\config.json" by absolute path reads the HOST environment's
      config no matter where the script itself was copied to - it connects to the wrong system and
      reports success doing it. That is the failure this function exists to prevent.

      Nested   : D:\Win\Ops\Foo\x.ps1 -> D:\Win\Ops\STG\Foo\x.ps1
      Suffixed : D:\Win\Ops\Foo\x.ps1 -> D:\Win\Ops\Foo_STG\x.ps1

      Shared folders are left alone in both layouts. Re-running is safe: a path already pointing at
      the destination is recognised and skipped rather than prefixed or suffixed twice.
    #>
    param([string]$Text)
    if (-not $Text) { return $Text }
    $ev = {
        param($m)
        $comp = $m.Groups['comp'].Value
        $tail = $m.Groups['tail'].Value
        if (-not $comp) { return $m.Value }
        if ($script:SharedSet.Contains($comp)) { return $m.Value }
        if ($Layout -eq 'Suffixed') {
            if ($comp -match ([regex]::Escape($FolderSuffix) + '$')) { return $m.Value }   # already done
            [void]$script:PathHits.Add("$SourceScriptsRoot\$comp\ -> $SourceScriptsRoot\$comp$FolderSuffix\")
            return "$SourceScriptsRoot\$comp$FolderSuffix$tail"
        }
        # Nested. "D:\Win\Ops\STG" itself is the destination, so a path already through it is done.
        if ("$SourceScriptsRoot\$comp" -ieq $ScriptsRoot) { return $m.Value }
        [void]$script:PathHits.Add("$SourceScriptsRoot\$comp\ -> $ScriptsRoot\$comp\")
        return "$ScriptsRoot\$comp$tail"
    }
    # ONE pass, two ordered branches - not two passes. Two passes re-matched their own output:
    # "...Foo</WorkingDirectory>" came back as "...Foo_STG<_STG/WorkingDirectory>" because the closing
    # tag's "/" read as a path separator, and "My Folder\x.ps1" came back as "My_STG Folder_STG\".
    #
    #   branch 1  component followed by a real separator. Greedy, so a folder name containing a space
    #             is read whole ("D:\Win\Ops\My Folder\x.ps1" -> comp = "My Folder").
    #   branch 2  path that ENDS at the component - <WorkingDirectory>D:\Win\Ops\Foo</...>, "D:\Win\Ops\Foo".
    #             Only reached when branch 1 found no separator, so it cannot re-cut branch 1's work.
    #
    # Both classes exclude < > " ' so an XML tag or a closing quote can never be eaten as path text.
    # The one case neither can resolve is an UNQUOTED bare path whose folder name contains a space -
    # genuinely ambiguous, and already broken on Windows, so it is left for the grep at the end of 5b.
    return [regex]::Replace($Text, $script:PathRx, $ev, 'IgnoreCase')
}

function Get-PromSeries {
    <# Parses a .prom file into metric-name + normalised-labelset keys, for collision detection. #>
    param([string]$Path)
    $keys = New-Object System.Collections.ArrayList
    foreach ($line in (Get-Content -LiteralPath $Path -ErrorAction SilentlyContinue)) {
        $l = $line.Trim()
        if (-not $l -or $l.StartsWith('#')) { continue }
        if ($l -match '^(?<name>[A-Za-z_:][A-Za-z0-9_:]*)(?<labels>\{.*\})?\s+\S+') {
            $name = $Matches['name']; $lbl = "$($Matches['labels'])"
            if ($lbl) {
                $pairs = @([regex]::Matches($lbl.Trim('{', '}'), '([A-Za-z_][A-Za-z0-9_]*)\s*=\s*"((?:[^"\\]|\\.)*)"') |
                           ForEach-Object { "$($_.Groups[1].Value)=$($_.Groups[2].Value)" } | Sort-Object)
                $lbl = '{' + ($pairs -join ',') + '}'
            }
            [void]$keys.Add("$name$lbl")
        }
    }
    return @($keys)
}

if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw 'Run this in an ELEVATED PowerShell.' }

$cs = Get-CimInstance Win32_ComputerSystem
if ($Sanitize) { $script:Map[$env:COMPUTERNAME] = 'THIS-HOST'; $script:Map["$($cs.Domain)"] = 'DOM.LOCAL' }

Write-Host ''
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ("  Import-CrossEnvTasks {0}  {1} -> {2}" -f $Version, $SourceEnv, $env:COMPUTERNAME) -ForegroundColor Cyan
Write-Host ("  MODE: {0}" -f $(if ($CheckSeriesOnly) { 'SERIES CHECK ONLY' } elseif ($Apply) { 'APPLY' } else { 'DRY RUN - add -Apply to change anything' })) -ForegroundColor $(if ($Apply -and -not $CheckSeriesOnly) { 'Yellow' } else { 'DarkGray' })
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ''

RptHead "CROSS-ENVIRONMENT TASK IMPORT - $SourceEnv onto $(Mask $env:COMPUTERNAME)"
RptKV 'Generated'      (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
RptKV 'Script'         "Import-CrossEnvTasks $Version"
RptKV 'This host'      ("{0}  ({1})" -f (Mask $env:COMPUTERNAME), (Mask $cs.Domain))
RptKV 'Incoming env'   $SourceEnv
RptKV 'Task suffix'    $TaskSuffix
RptKV '.prom suffix'   $PromSuffix
RptKV 'Task folder'    $TaskFolder
RptKV 'Layout'         $(if ($Layout -eq 'Suffixed') { "Suffixed - $SourceScriptsRoot\<Component>$FolderSuffix\" } else { "Nested - $ScriptsRoot\<Component>\" })
RptKV 'Scripts root'   ("{0}  (rewritten from {1})" -f $ScriptsRoot, $SourceScriptsRoot)
RptKV 'Shared folders' (($script:SharedSet | Sort-Object) -join ', ')
RptKV 'Textfile dir'   ("{0}  (SHARED - the suffix keeps the files apart)" -f $PromDir)
RptKV 'Mode'           $(if ($CheckSeriesOnly) { 'SERIES CHECK ONLY' } elseif ($Apply) { 'APPLY' } else { 'DRY RUN' })

# ================================================================== 3e (standalone mode)
function Invoke-SeriesCheck {
    RptSub '3e. DUPLICATE SERIES - the check a filename cannot do for you'
    if (-not (Test-Path -LiteralPath $PromDir)) { RptLine "    $PromDir does not exist yet"; return }
    $files = @(Get-ChildItem -LiteralPath $PromDir -File -Filter *.prom -ErrorAction SilentlyContinue)
    if (-not $files.Count) { RptLine '    (no .prom files present yet - re-run this check once both sets have produced output)'; return }
    $owner = @{}
    $dupes = @{}
    foreach ($f in $files) {
        foreach ($k in (Get-PromSeries $f.FullName)) {
            if ($owner.ContainsKey($k) -and $owner[$k] -ne $f.Name) {
                if (-not $dupes.ContainsKey($k)) { $dupes[$k] = New-Object System.Collections.ArrayList; [void]$dupes[$k].Add($owner[$k]) }
                if ($dupes[$k] -notcontains $f.Name) { [void]$dupes[$k].Add($f.Name) }
            } else { $owner[$k] = $f.Name }
        }
    }
    RptKV 'Files scanned'   $files.Count
    RptKV 'Distinct series' $owner.Count
    RptKV 'COLLIDING series' $dupes.Count
    if ($dupes.Count) {
        RptLine ''
        RptLine '    These exact metric+label combinations appear in more than one file. The exporter'
        RptLine '    concatenates all of them into ONE scrape, so Prometheus rejects the WHOLE response'
        RptLine "    as duplicate - taking this host's own metrics down with $SourceEnv's."
        RptLine ''
        $n = 0
        foreach ($k in ($dupes.Keys | Select-Object -First 25)) {
            $n++
            RptLine ("      {0}" -f (TrimTo $k 96))
            RptLine ("        in: {0}" -f ((@($dupes[$k])) -join ', '))
        }
        if ($dupes.Count -gt 25) { RptLine ("      ... and $($dupes.Count - 25) more") }
        Blocker "$($dupes.Count) metric series are emitted identically by two environments" "The .prom CONTENT must differ, not just the filename. Either have the $SourceEnv scripts add an Environment=`"$SourceEnv`" label to every metric they write, or give $SourceEnv its own exporter instance on a second port so Prometheus scrapes it as a separate target."
    } else {
        RptLine ''
        RptLine '    No collisions: every series is unique across the files present. Both environments'
        RptLine '    can share this directory and one exporter safely.'
    }
}

if ($CheckSeriesOnly) {
    Invoke-SeriesCheck
    RptHead 'END OF REPORT'
    $reportText = ($R -join "`r`n")
    $reportText | Set-Content -LiteralPath $ReportPath -Encoding utf8
    Write-Host $reportText
    try { $reportText | Set-Clipboard; Write-Host "`nReport on the CLIPBOARD and saved to: $ReportPath" -ForegroundColor Cyan } catch {}
    return
}

if (-not $TasksFolder -or -not (Test-Path -LiteralPath $TasksFolder)) {
    throw "No tasks folder. Pass -CaptureFolder <folder containing tasks\> or -TasksFolder <folder of *.xml>." }

# ================================================================== 1. this host today
Step 'existing workload'
RptSub '1. what this host already runs'
$existingTasks = @(Get-ScheduledTask -ErrorAction SilentlyContinue |
    Where-Object { $_.TaskPath -notlike '\Microsoft*' -and $_.TaskName -notmatch '^(MicrosoftEdgeUpdate|GoogleUpdate|OneDrive|Optimize Start Menu)' })
RptKV 'Existing tasks' $existingTasks.Count
foreach ($t in ($existingTasks | Sort-Object TaskPath, TaskName)) {
    RptLine ("     {0,-56} {1,-9} {2}" -f (Mask "$($t.TaskPath)$($t.TaskName)"), $t.State, (Mask "$($t.Principal.UserId)")) }
$hostProm = @()
if (Test-Path -LiteralPath $PromDir) {
    $hostProm = @(Get-ChildItem -LiteralPath $PromDir -File -ErrorAction SilentlyContinue)
    RptLine ''
    RptLine ("  textfile directory {0}:" -f $PromDir)
    foreach ($f in $hostProm) { RptLine ("     {0,-44} {1,9} bytes  {2} min old" -f $f.Name, $f.Length, [int](New-TimeSpan -Start $f.LastWriteTime -End (Get-Date)).TotalMinutes) }
    if (-not $hostProm.Count) { RptLine '     (empty)' }
}

# ================================================================== 2. incoming set
Step 'reading incoming XMLs'
RptSub "2. the incoming $SourceEnv task set (renamed with $TaskSuffix)"
$incoming = @()
$excluded = @()
foreach ($x in @(Get-ChildItem -Path (Join-Path $TasksFolder '*.xml') -ErrorAction SilentlyContinue)) {
    $raw = Get-Content -LiteralPath $x.FullName -Raw
    $uid = ''; $lt = ''; $uri = ''
    if ($raw -match '<UserId>([^<]*)</UserId>')       { $uid = $Matches[1].Trim() }
    if ($raw -match '<LogonType>([^<]*)</LogonType>') { $lt  = $Matches[1] }
    if ($raw -match '<URI>([^<]*)</URI>')             { $uri = $Matches[1] }
    $orig = $(if ($uri) { Split-Path $uri -Leaf } else { [System.IO.Path]::GetFileNameWithoutExtension($x.Name) })
    $why = ''
    if     ($ExcludeTask -and $orig -match $ExcludeTask)     { $why = 'Windows-generated - excluded' }
    elseif ($IncludeTask -and $orig -notmatch $IncludeTask)  { $why = 'not matched by -IncludeTask' }
    if ($why) { $excluded += [pscustomobject]@{ Name = $orig; Why = $why; UserId = $uid }; continue }
    $new  = $(if ($orig.EndsWith($TaskSuffix)) { $orig } else { "$orig$TaskSuffix" })
    $incoming += [pscustomobject]@{ File = $x.FullName; Orig = $orig; NewName = $new; UserId = $uid; LogonType = $lt; Raw = $raw }
}
RptKV 'Tasks found' ("{0} to import, {1} excluded" -f $incoming.Count, $excluded.Count)
foreach ($i in $incoming) { RptLine ("     {0,-46} -> {1}" -f (Mask $i.Orig), (Mask "$TaskFolder$($i.NewName)")) }
if (-not $incoming.Count) { Blocker "no task XML files in $TasksFolder" 'Point -TasksFolder at the exported *.xml' }
if ($excluded.Count) {
    RptLine ''
    RptLine '  NOT imported - listed so nothing is dropped silently:'
    foreach ($e in ($excluded | Sort-Object Name)) {
        RptLine ("     {0,-64} {1}" -f (TrimTo (Mask $e.Name) 62), $e.Why)
        if ($e.UserId) { RptLine ("       ran as {0}" -f (Mask $e.UserId)) }
    }
    RptLine '     These are per-user Windows housekeeping tasks. They are recreated by the OS where they'
    RptLine "     are wanted, and they carry the OLD machine's account SIDs, which is why importing them"
    RptLine '     produces unresolvable-principal blockers that have nothing to do with your migration.'
    RptLine '     Override with -ExcludeTask if you disagree; -IncludeTask <regex> to whitelist instead.'
}
$incomingAccounts = @($incoming | ForEach-Object { $_.UserId } | Where-Object { $_ } | Sort-Object -Unique)
if ($Sanitize) { $n = 0; foreach ($a in $incomingAccounts) { $n++; $script:Map[(($a -split '\\')[-1])] = "SVCACCT-$n" } }

# ================================================================== 3. collisions
Step 'collision analysis'
RptSub '3. COLLISIONS'
RptLine '  3a. task names'
foreach ($i in $incoming) {
    $clash = @($existingTasks | Where-Object { $_.TaskName -eq $i.NewName -and $_.TaskPath -eq $TaskFolder })
    if ($clash.Count) {
        RptLine ("     {0,-52} ALREADY EXISTS" -f (Mask $i.NewName))
        if (-not $Force) { Blocker "$(Mask $i.NewName) already exists at $TaskFolder" 'Re-run with -Force to replace it' }
    } else {
        $sameOrig = @($existingTasks | Where-Object { $_.TaskName -eq $i.Orig })
        RptLine ("     {0,-52} free{1}" -f (Mask $i.NewName), $(if ($sameOrig.Count) { "  (this host's own '$($i.Orig)' is untouched)" } else { '' }))
    }
}

RptLine ''
RptLine '  3b. script trees - what these tasks actually reference, and where it has to land here'
$compSet = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::OrdinalIgnoreCase)
foreach ($i in $incoming) {
    foreach ($m in [regex]::Matches($i.Raw, $script:PathRx, 'IgnoreCase')) {
        $cv = $m.Groups['comp'].Value.Trim()
        # a component already carrying the suffix is a re-run, not a second folder to copy
        if ($cv -and $FolderSuffix) { $cv = [regex]::Replace($cv, [regex]::Escape($FolderSuffix) + '$', '') }
        if ($cv -and -not ($Layout -eq 'Nested' -and $cv -ieq $SourceEnv)) { [void]$compSet.Add($cv) }
    }
}
$targetTrees = @()
foreach ($cv in ($compSet | Sort-Object)) {
    $isShared = $script:SharedSet.Contains($cv)
    $dest = $(if ($isShared) { "$SourceScriptsRoot\$cv" }
              elseif ($Layout -eq 'Suffixed') { "$SourceScriptsRoot\$cv$FolderSuffix" }
              else { "$ScriptsRoot\$cv" })
    $exists = Test-Path -LiteralPath $dest
    $fileCount = $(if ($exists) { @(Get-ChildItem -LiteralPath $dest -Recurse -File -ErrorAction SilentlyContinue).Count } else { 0 })
    $targetTrees += [pscustomobject]@{ Comp = $cv; Dest = $dest; Shared = $isShared; Exists = $exists; Files = $fileCount }
}
if (-not $targetTrees.Count) {
    RptLine "     (no $SourceScriptsRoot paths found in the task XML - nothing to re-point)"
} else {
    RptLine ("     {0,-30} {1,-46} {2}" -f 'COMPONENT', 'MUST EXIST HERE AS', 'STATE')
    foreach ($tt in $targetTrees) {
        $state = $(if ($tt.Shared -and -not $tt.Exists) { '*** SHARED but NOT ON THIS HOST ***' }
                   elseif ($tt.Shared) { "SHARED - $SourceEnv will run THIS host's copy" }
                   elseif ($tt.Exists -and $tt.Files) { "present, $($tt.Files) file(s)" }
                   elseif ($tt.Exists) { 'present but EMPTY' }
                   else { 'MISSING' })
        RptLine ("     {0,-30} {1,-46} {2}" -f (Mask $tt.Comp), (Mask $tt.Dest), $state)
    }
    # A shared component is not a free pass - it is a decision, and until now it was not checked.
    foreach ($tt in ($targetTrees | Where-Object { $_.Shared })) {
        if (-not $tt.Exists -or -not $tt.Files) {
            Blocker "$(Mask $tt.Comp) is marked shared but is not on this host" `
                    "Nothing here provides it, so the $SourceEnv tasks would launch into a path that does not exist. Either drop it from -SharedFolder so it gets copied as $SourceEnv's own, or install it."
        } else {
            Warn "$(Mask $tt.Comp) is shared - $SourceEnv's tasks will execute this host's copy" `
                 "Right only if it holds environment-NEUTRAL code. If it carries any config, endpoint or credential, take it off -SharedFolder so $SourceEnv gets its own."
        }
    }
}
$missingTrees = @($targetTrees | Where-Object { -not $_.Shared -and (-not $_.Exists -or -not $_.Files) })

# --- staging: cherry-pick the needed components out of a wholesale copy of the old D:\Win\Ops -----
$stageOk = $false
if ($StagingRoot) {
    $StagingRoot = $StagingRoot.TrimEnd('\', '/')
    RptLine ''
    RptKV '  staging root' (Mask $StagingRoot)
    if (-not (Test-Path -LiteralPath $StagingRoot -PathType Container)) {
        Blocker "-StagingRoot $(Mask $StagingRoot) does not exist" 'Finish the copy off the old server first, then re-run'
    }
    # The guard that matters. A staging folder sitting under D:\Win\Ops would make the component
    # search find THIS host's own trees and copy them onto themselves under a _STG name - the incoming
    # environment would end up running the host's scripts and every check would call it healthy.
    elseif ("$StagingRoot\" -like "$SourceScriptsRoot\*" -or $StagingRoot -ieq $SourceScriptsRoot) {
        Blocker "-StagingRoot is inside $SourceScriptsRoot" "Stage OUTSIDE the live root - D:\Win\_$($SourceEnv.ToUpper())-source is fine. Staged under it, the component search finds this host's own trees instead of $SourceEnv's."
    }
    else {
        $stageOk = $true
        RptLine ("     {0,-30} {1}" -f 'COMPONENT', 'FOUND IN STAGING AS')
        foreach ($tt in $targetTrees) {
            if ($tt.Shared) {
                RptLine ("     {0,-30} not taken - shared with this host, and a stale copy of its old" -f (Mask $tt.Comp))
                RptLine ("     {0,-30} .prom files would be scraped as live data" -f '')
                continue
            }
            $src = Find-StagedComponent $tt.Comp
            $tt | Add-Member -NotePropertyName Src -NotePropertyValue $src -Force
            RptLine ("     {0,-30} {1}" -f (Mask $tt.Comp), $(if ($src) { Mask $src } else { '*** NOT FOUND IN THE STAGED COPY ***' }))
            if (-not $src -and -not $tt.Exists) {
                Blocker "$(Mask $tt.Comp) is not in the staged copy" "The task set references it, so it has to come across. Check the copy finished, or copy that one folder by hand."
            }
        }
    }
}

if ($missingTrees.Count -and -not $stageOk) {
    Blocker ("{0} {1} script tree(s) are not on this host yet" -f $missingTrees.Count, $SourceEnv) `
            "Copy them with the robocopy lines printed below, then re-run. The tasks cannot be re-pointed at a tree that is not there."
    RptLine ''
    RptLine "     COPY PLAN - run these from an elevated prompt on $(Mask $env:COMPUTERNAME):"
    RptLine ''
    RptLine '     Either one wholesale copy into a staging folder and let this script cherry-pick:'
    RptLine ''
    RptLine ('       robocopy "\\{0}\{1}" "D:\Win\_{2}-source" /E /COPY:DAT /R:1 /W:1 /NFL /NDL' -f `
             (Mask $SourceHost), ($SourceScriptsRoot -replace '^([A-Za-z]):', '$1$'), $SourceEnv.ToUpper())
    RptLine ('       .\Import-CrossEnvTasks.ps1 {0} -StagingRoot "D:\Win\_{1}-source"' -f `
             $(if ($Layout -eq 'Suffixed') { '-Layout Suffixed' } else { '' }), $SourceEnv.ToUpper())
    RptLine ''
    RptLine "     NOTE the destination. Copying onto $SourceScriptsRoot itself would overwrite this host's"
    RptLine "     OWN scripts with $SourceEnv's - same folder names, different environment. Stage elsewhere."
    RptLine ''
    RptLine '     ...or place each component yourself:'
    RptLine ''
    foreach ($tt in $missingTrees) {
        RptLine ('       robocopy "\\{0}\{1}\{2}" "{3}" /E /COPY:DAT /R:1 /W:1 /NFL /NDL' -f `
                 (Mask $SourceHost), ($SourceScriptsRoot -replace '^([A-Za-z]):', '$1$'), $tt.Comp, (Mask $tt.Dest))
    }
    RptLine ''
    RptLine '     /COPY:DAT on purpose - data, attributes, timestamps, but NOT the source ACLs. Copying'
    RptLine "     the ACLs (/COPYALL or /SEC) drags across ACEs naming the old server's local groups and"
    RptLine '     that environment SIDs, which then show as unresolved SIDs here and can lock the account'
    RptLine '     that has to run the job out of its own folder. Let the destination inherit instead.'
    if ($SourceHost -eq '<OLD-SERVER>') {
        RptLine ''
        RptLine "     (pass -SourceHost SRV$($SourceEnv.ToUpper())1APPMON01 to have the real name printed here)"
    }
}
RptLine ''
RptLine ("     path rewrite: {0}" -f $(if ($Layout -eq 'Suffixed') { "$SourceScriptsRoot\<Component>\  ->  $SourceScriptsRoot\<Component>$FolderSuffix\" } else { "$SourceScriptsRoot\<Component>\  ->  $ScriptsRoot\<Component>\" }))
RptLine  '     applied to the task XML AND to the text inside the copied scripts, because a feeder that'
RptLine  '     opens its config by absolute path would otherwise read this environment''s config and'
RptLine  '     report success while talking to the wrong system.'

RptLine ''
RptLine "  3c/3d. .prom filenames - suffixing with '$PromSuffix' so one directory serves both"
$srcProm = @()
if ($CaptureFolder) {
    $mf = Join-Path $CaptureFolder 'manifest.json'
    if (Test-Path -LiteralPath $mf) {
        try { $mo = Get-Content -LiteralPath $mf -Raw | ConvertFrom-Json
              if ($mo.exporter) { $srcProm = @($mo.exporter.promFiles | ForEach-Object { "$($_.name)" }) } } catch {}
    }
}
foreach ($f in $srcProm) {
    $base = [System.IO.Path]::GetFileNameWithoutExtension($f)
    $newF = "$base$PromSuffix.prom"
    $clash = @($hostProm | Where-Object { $_.Name -eq $f }).Count
    RptLine ("     {0,-40} -> {1,-40} {2}" -f $f, $newF, $(if ($clash) { "(would have collided with this host's file)" } else { '' }))
}
if (-not $srcProm.Count) { RptLine '     (no .prom baseline in the capture - the patch below works off the script text regardless)' }

Invoke-SeriesCheck

# ================================================================== 4. accounts
Step 'accounts'
RptSub '4. accounts'
$useAccount = $Account
$acctResolves = @{}
# Validate the override FIRST. Until v3.4 this ran after the loop below, so -Account - the documented
# fix for an unresolvable principal - left the original account's blocker standing and registration
# was skipped anyway. The switch told you to use it and then ignored you.
$overrideOk = $false
if ($useAccount) {
    $osid = Test-Resolves $useAccount
    $acctResolves[$useAccount] = [bool]$osid
    $overrideOk = [bool]$osid
    RptKV 'Override account' ("{0}  {1}" -f (Mask $useAccount), $(if ($osid) { $osid } else { 'DOES NOT RESOLVE' }))
    if (-not $osid) { Blocker "-Account $(Mask $useAccount) does not resolve" 'Fix the name before applying' }
    else { RptLine ("     every incoming task will be registered as this account, replacing whatever the XML names") }
    RptLine ''
}
foreach ($a in $incomingAccounts) {
    $sid = Test-Resolves $a
    $acctResolves[$a] = [bool]$sid
    RptLine ("     {0,-40} {1}" -f (Mask $a), $(if ($sid) { $sid } else { '*** NONE_MAPPED - not on this domain ***' }))
    if (-not $sid) {
        if ($overrideOk) {
            RptLine ("        superseded by -Account {0} - not a blocker" -f (Mask $useAccount))
            Warn "$(Mask $a) does not exist; tasks will run as $(Mask $useAccount) instead" `
                 "Temporary. Record it, and switch back once the real service account is restored - a personal account takes the jobs with it when its password changes."
        } else {
            Blocker "$(Mask $a) does not resolve on this host" "Find the current name, then re-run with -Account 'DOM\name'. Do NOT borrow another environment's service account."
        }
    } else {
        $sam = ($a -split '\\')[-1]
        try {
            $hit = ([adsisearcher]"(&(objectCategory=user)(sAMAccountName=$sam))").FindOne()
            if ($hit) {
                $uac = [int]$hit.Properties['useraccountcontrol'][0]
                if ($uac -band 2) { Blocker "$(Mask $sam) is DISABLED in AD" 'Enable it, or register disabled and log it in BROKEN-TASKS-REGISTER.md' }
                $lo = "$($hit.Properties['userworkstations'])"
                if ($lo) {
                    $inList = (($lo -split ',') -contains $env:COMPUTERNAME)
                    RptLine ("        LogOnTo=[{0}] includes {1}: {2}" -f (Mask $lo), (Mask $env:COMPUTERNAME), $inList)
                    if (-not $inList) { Blocker "$(Mask $sam) has a 'Log On To' list excluding $(Mask $env:COMPUTERNAME)" "Add $env:COMPUTERNAME to it, or the tasks register and then fail to launch with 1329" }
                } else { RptLine '        LogOnTo=(unrestricted)' }
            }
        } catch {}
    }
}
$inf = Join-Path $env:TEMP ('ur-' + [guid]::NewGuid().ToString('N') + '.inf')
$null = & secedit /export /areas USER_RIGHTS /cfg $inf /quiet 2>&1
$pol = @(Get-Content -LiteralPath $inf -ErrorAction SilentlyContinue)
Remove-Item $inf -ErrorAction SilentlyContinue
function ResolveP { param($p) $v = "$p".Trim()
    if ($v -match '^\*?(S-1-[0-9-]+)$') { try { return (New-Object System.Security.Principal.SecurityIdentifier($Matches[1])).Translate([System.Security.Principal.NTAccount]).Value } catch { return $Matches[1] } }
    return $v }
$bl = @($pol | Where-Object { $_ -match '^\s*SeBatchLogonRight\s*=' })
$batch = @()
if ($bl) { $batch = @((($bl[0] -split '=', 2)[1] -split ',') | ForEach-Object { ResolveP $_ } | Where-Object { $_ }) }
RptLine ''
RptKV 'SeBatchLogonRight' (($batch | ForEach-Object { Mask $_ }) -join ', ')
$checkAccts = @($(if ($useAccount) { $useAccount } else { $incomingAccounts }))
foreach ($a in $checkAccts) {
    $sam = ($a -split '\\')[-1]
    # NOT $r - that is the report buffer $R, and PowerShell variable names are case-insensitive.
    # Assigning to $r here would have replaced the entire report with a single verdict object.
    $rightChk = Test-HoldsRight -Account $a -Holders $batch
    RptLine ("     {0,-40} holds batch-logon: {1}" -f (Mask $a), $rightChk.Verdict)
    if ($rightChk.Via) { RptLine ("        {0}" -f $rightChk.Via) }
    if ($rightChk.Verdict -eq 'UNKNOWN') {
        Warn "cannot confirm whether $(Mask $sam) holds 'Log on as a batch job'" `
             "It may hold it through a domain group this host cannot expand. NOT granted automatically - writing a security-policy change on a guess is worse than leaving it. If the tasks fail at launch with 0x80070569, grant it by hand: secpol.msc > Local Policies > User Rights Assignment > Log on as a batch job."
        continue
    }
    if ($rightChk.Verdict -eq 'NO') {
        if (Should-Do "grant 'Log on as a batch job' to $a") {
            $res = Grant-BatchLogon $a
            RptLine ("        grant: {0}" -f $res)
            if ($res -eq 'granted') { Changed "granted SeBatchLogonRight to $(Mask $a)" }
            elseif ($res -like 'FAILED*') { Blocker "could not grant batch-logon to $(Mask $sam)" $res }
            else { Warn "$(Mask $sam) does not hold 'Log on as a batch job' here" $res }
        } else {
            Warn "$(Mask $sam) does not hold 'Log on as a batch job' here" 'Grant it before enabling, or the tasks fail at launch with 0x80070569'
        }
    }
}
RptLine ''
RptLine '    A GPO can manage this right. If one does, the local grant above survives only until the'
RptLine '    next gpupdate and the tasks then start failing with 0x80070569 for no apparent reason.'
RptLine '    Check with:  gpresult /h C:\Migration\gp.html   and search it for "batch"'

# ================================================================== 5. apply
Step 'apply'
RptSub '5. changes'

# 5a. place the component trees out of staging, under their destination names
if ($stageOk) {
    RptLine "  placing $SourceEnv components from staging"
    foreach ($tt in $targetTrees) {
        if ($tt.Shared -or -not $tt.Src) { continue }
        if ($tt.Exists -and $tt.Files -and -not $Force) {
            RptLine ("    {0,-30} already here with {1} file(s) - left alone (-Force to overwrite)" -f (Mask $tt.Comp), $tt.Files)
            continue
        }
        RptLine ("    {0,-30} {1}  ->  {2}" -f (Mask $tt.Comp), (Mask $tt.Src), (Mask $tt.Dest))
        if (-not (Should-Do "copy $($tt.Comp) into $($tt.Dest)")) { continue }
        $out = & robocopy $tt.Src $tt.Dest /E /COPY:DAT /R:1 /W:1 /NFL /NDL /NJH /NJS 2>&1
        # robocopy exit codes are a bitmask, not a status: 0-7 are success, 8+ are real failures.
        if ($LASTEXITCODE -lt 8) {
            $tt.Exists = $true
            $tt.Files  = @(Get-ChildItem -LiteralPath $tt.Dest -Recurse -File -ErrorAction SilentlyContinue).Count
            Changed "placed $(Mask $tt.Comp) at $(Mask $tt.Dest) ($($tt.Files) file(s))"
        } else {
            Blocker "robocopy failed for $(Mask $tt.Comp) (exit $LASTEXITCODE)" (TrimTo ($out -join ' ') 90)
        }
    }
    $global:LASTEXITCODE = 0
    RptLine ''
    RptLine "    The staging folder is NOT deleted. Keep it until the $SourceEnv tasks have produced"
    RptLine '    output you have checked - it is the only untouched copy once the patches below run.'
    RptLine ''
}

foreach ($d in @($ScriptsRoot, $PromDir)) {
    if (Test-Path -LiteralPath $d) { RptLine "    exists: $d"; continue }
    if (Should-Do "create $d") { New-Item -ItemType Directory -Force -Path $d | Out-Null; Changed "created $d"; RptLine "    created $d" }
}
if (Test-Path -LiteralPath $PromDir) {
    foreach ($a in $checkAccts) {
        $sam = ($a -split '\\')[-1]
        if (-not $acctResolves[$a]) {
            RptLine ("    write access {0,-30}: skipped - the account does not exist, so there is nothing to grant to" -f (Mask $sam))
            continue
        }
        $has = $false
        try { $has = [bool](@((Get-Acl -LiteralPath $PromDir).Access | Where-Object {
                "$($_.IdentityReference)" -like "*$sam" -and "$($_.AccessControlType)" -eq 'Allow' -and "$($_.FileSystemRights)" -match 'Modify|FullControl|Write' }).Count) } catch {}
        if ($has) { RptLine ("    write access {0,-30}: yes" -f (Mask $sam)); continue }
        RptLine ("    write access {0,-30}: NO" -f (Mask $sam))
        if (Should-Do "grant Modify on $PromDir to $a") {
            $o = & icacls $PromDir /grant "$($a):(OI)(CI)M" 2>&1
            if ($LASTEXITCODE -eq 0) { Changed "granted Modify on $PromDir to $(Mask $a)" }
            else { Blocker "could not grant Modify on $PromDir to $(Mask $a)" (TrimTo ($o -join ' ') 80) }
        }
    }
}

# 5b. patch the COPIED tree. Two separate rewrites, both confined to the destination folders.
#
# Confined on purpose. Under the Suffixed layout $ScriptsRoot IS D:\Win\Ops, so recursing it would
# walk this host's OWN environment as well - and the .prom patch would rename the running SYS output
# files while the path patch re-pointed the SYS scripts at _STG. That is the single most destructive
# thing this script could do, so the file list is built from the resolved destination folders only.
$patchTrees = @($targetTrees | Where-Object { -not $_.Shared -and $_.Exists })
$patchFiles = @()
foreach ($tt in $patchTrees) {
    $patchFiles += @(Get-ChildItem -LiteralPath $tt.Dest -Recurse -Include *.ps1, *.psm1, *.bat, *.cmd, *.config, *.json, *.xml, *.ini -ErrorAction SilentlyContinue |
                     Where-Object { $_.Length -lt 5MB } |
                     # Logs and transcripts are HISTORY. Rewriting paths inside them changes the record
                     # of what the old server actually did - the evidence you would reach for when a
                     # migrated job misbehaves - and patches nothing that will ever execute.
                     Where-Object { $_.FullName -notmatch '(?i)\\Logs?\\' -and
                                    $_.Name -notmatch '(?i)^(PowerShell_transcript\.|log\.txt$|.*\.log$)' })
}
RptLine ''
RptKV '  patch scope' ("{0} file(s) across {1} destination folder(s)" -f $patchFiles.Count, $patchTrees.Count)
foreach ($tt in $patchTrees) { RptLine ("       {0}" -f (Mask $tt.Dest)) }
if (-not $patchTrees.Count) { RptLine '       (nothing to patch yet - copy the trees first, then re-run)' }
if ($stageOk -and -not $Apply -and @($targetTrees | Where-Object { -not $_.Shared -and $_.Src -and -not $_.Exists }).Count) {
    RptLine ''
    RptLine '    The two patch sections below have nothing to read yet: in a DRY RUN the trees are not'
    RptLine '    actually placed, so there is no copy to show you the edits for. -Apply does the whole'
    RptLine '    chain in order - place, patch, register - and prints every substitution as it goes.'
    RptLine '    Nothing is registered if a blocker is outstanding, so -Apply is still safe to run here.'
}

RptLine ''
RptLine "  5b-i. .prom filenames (adding '$PromSuffix')"
if ($SkipPromPatch) { RptLine '    skipped (-SkipPromPatch)' }
elseif (-not $patchFiles.Count) { RptLine '    skipped - the script trees are not here yet. Copy them, then re-run.' }
else {
    $patched = 0; $manualTotal = 0
    foreach ($f in $patchFiles) {
        $txt = ''
        try { $txt = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction Stop } catch { continue }
        if (-not $txt -or $txt -notmatch '\.prom\b') { continue }
        $res = Add-PromSuffix -Text $txt -Suffix $PromSuffix
        if ($res.Manual.Count) {
            $manualTotal += $res.Manual.Count
            RptLine ("    [MANUAL] {0}" -f (Mask $f.FullName))
            RptLine ("       {0} dynamically-built .prom name(s) - a script builds the filename at runtime," -f $res.Manual.Count)
            RptLine "       so it cannot be suffixed by text replacement. Edit these by hand."
            Warn "$(Mask $f.Name) builds its .prom filename dynamically" "Open it and add '$PromSuffix' to the name it constructs, or its output will collide with this host's own file"
        }
        if (-not $res.Changes.Count) { continue }
        RptLine ("    {0}" -f (Mask $f.FullName))
        foreach ($c in $res.Changes) { RptLine ("       {0}" -f $c) }
        if (Should-Do "patch $($f.Name)") {
            Backup-Once $f.FullName
            $res.Text | Set-Content -LiteralPath $f.FullName -Encoding utf8
            $patched++
        }
    }
    if ($Apply) { Changed "patched $patched file(s) to write *$PromSuffix.prom (each backed up as .bak)" }
    RptKV '  files needing manual edit' $manualTotal
    if (-not $patched -and -not $manualTotal -and $Apply) { RptLine '    nothing to patch (no literal .prom filenames found)' }
}

# 5b-ii. absolute paths inside the copied scripts
RptLine ''
RptLine ("  5b-ii. absolute paths inside the copied scripts ({0})" -f $(if ($Layout -eq 'Suffixed') { "<Component> -> <Component>$FolderSuffix" } else { "$SourceScriptsRoot -> $ScriptsRoot" }))
if ($SkipPathPatch) { RptLine '    skipped (-SkipPathPatch)' }
elseif (-not $patchFiles.Count) { RptLine '    skipped - the script trees are not here yet. Copy them, then re-run.' }
else {
    $pathPatched = 0
    foreach ($f in $patchFiles) {
        $txt = ''
        try { $txt = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction Stop } catch { continue }
        if (-not $txt -or $txt -notmatch [regex]::Escape($SourceScriptsRoot)) { continue }
        $script:PathHits.Clear()
        $new = Convert-EnvPath $txt
        if ($new -eq $txt) { continue }
        RptLine ("    {0}" -f (Mask $f.FullName))
        foreach ($h in ($script:PathHits | Sort-Object -Unique | Select-Object -First 8)) { RptLine ("       {0}" -f (Mask $h)) }
        if (Should-Do "re-point paths in $($f.Name)") {
            Backup-Once $f.FullName
            $new | Set-Content -LiteralPath $f.FullName -Encoding utf8
            $pathPatched++
        }
    }
    if ($Apply) { Changed "re-pointed absolute paths in $pathPatched file(s)" }
    if (-not $pathPatched -and $Apply) { RptLine '    nothing to re-point (no absolute paths into the source root)' }
    RptLine ''
    RptLine '    Not covered here, and worth one look by eye: a path built at runtime from a variable'
    RptLine '    ($root = "D:\Win\Ops"; Join-Path $root $name) survives this rewrite only if the literal'
    RptLine "    part still matches. Grep the copied tree for $SourceScriptsRoot afterwards:"
    RptLine ("        Select-String -Path '{0}\*' -Pattern '{1}' -Recurse -SimpleMatch | Select Path,LineNumber,Line" -f (Mask $ScriptsRoot), (Mask $SourceScriptsRoot))
}

# 5c. exporter config - the shared directory must be listed
RptLine ''
if (-not $ExporterConfig) {
    $svc = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -match 'exporter' }) | Select-Object -First 1
    if ($svc) {
        if ("$($svc.PathName)" -match '--config\.file[= ]\s*"([^"]+)"') { $ExporterConfig = $Matches[1] }
        elseif ("$($svc.PathName)" -match '--config\.file[= ]\s*([^\s"]+)') { $ExporterConfig = $Matches[1] }
    }
}
RptKV 'Exporter config' $(if ($ExporterConfig) { Mask $ExporterConfig } else { 'NOT FOUND' })
if ($ExporterConfig -and (Test-Path -LiteralPath $ExporterConfig)) {
    $cfg = Get-Content -LiteralPath $ExporterConfig -Raw
    if ($cfg -match [regex]::Escape($PromDir)) { RptLine "    $PromDir is already in the exporter's directories list - nothing to change" }
    else { Warn "$PromDir is not in the exporter's textfile directories" "Add it as a list item under collector.textfile.directories, then restart the exporter" }
} else { Warn 'no exporter config found' "The $SourceEnv .prom files would be written but never exposed" }

# 5d. register
RptLine ''
RptLine "  registering the $SourceEnv tasks as *$TaskSuffix into $TaskFolder (DISABLED)"
if ($Blockers.Count -and $Apply) {
    RptLine '    SKIPPED - fix the blockers above, then re-run with -Apply.'
} elseif ($incoming.Count) {
    $cred = $null
    if ($Apply) {
        $credAcct = $(if ($useAccount) { $useAccount } else { $incomingAccounts | Select-Object -First 1 })
        if (@($incoming | Where-Object { $_.LogonType -match 'Password' }).Count -and $credAcct) {
            $cred = Get-Credential -UserName $credAcct -Message "Password for $SourceEnv task account $credAcct" }
    }
    foreach ($i in $incoming) {
        $xml = $i.Raw
        if ($useAccount -and $i.UserId) { $xml = $xml -replace '<UserId>[^<]*</UserId>', "<UserId>$useAccount</UserId>" }
        # the URI carries the task's identity - rewrite it or Task Scheduler keeps the old name
        $xml = $xml -replace '<URI>[^<]*</URI>', "<URI>$TaskFolder$($i.NewName)</URI>"
        # re-point paths at this environment's own copy - same function that patched the scripts, so
        # the two can never drift apart. Shared folders (the textfile directory) are left alone.
        $script:PathHits.Clear()
        $xml = Convert-EnvPath $xml
        foreach ($h in ($script:PathHits | Sort-Object -Unique)) { RptLine ("      path: {0}" -f (Mask $h)) }
        if (-not (Should-Do "register $TaskFolder$($i.NewName) (disabled)")) { continue }
        try {
            $p = @{ TaskName = $i.NewName; TaskPath = $TaskFolder; Xml = $xml; Force = $true; ErrorAction = 'Stop' }
            if ($i.LogonType -match 'Password' -and $cred) { $p.User = $cred.UserName; $p.Password = $cred.GetNetworkCredential().Password }
            Register-ScheduledTask @p | Out-Null
            Disable-ScheduledTask -TaskName $i.NewName -TaskPath $TaskFolder -ErrorAction SilentlyContinue | Out-Null
            Changed "registered $TaskFolder$($i.NewName) (disabled)"
            RptLine ("    OK (disabled): {0}" -f (Mask "$TaskFolder$($i.NewName)"))
        } catch {
            Blocker "failed to register $(Mask $i.NewName)" (TrimTo $_.Exception.Message 90)
            RptLine ("    FAILED: {0} - {1}" -f (Mask $i.NewName), (TrimTo $_.Exception.Message 70))
        }
    }
}

# ================================================================== verdict
RptSub 'VERDICT'
if ($Blockers.Count -eq 0) {
    RptLine "  GO - nothing blocks co-hosting $SourceEnv here."
    if (-not $Apply) { RptLine '  This was a DRY RUN. Re-run with -Apply.' }
} else {
    RptLine ("  NO-GO - {0} blocker(s):" -f $Blockers.Count)
    $n = 0
    foreach ($b in $Blockers) { $n++; RptLine ("   {0,2}. {1}" -f $n, (Mask $b.P)); if ($b.F) { RptLine ("       fix: {0}" -f (Mask $b.F)) } }
}
if ($Warns.Count) {
    RptLine ''
    RptLine '  Warnings:'
    $n = 0
    foreach ($w in $Warns) { $n++; RptLine ("   {0,2}. {1}" -f $n, (Mask $w.P)); if ($w.F) { RptLine ("       {0}" -f (Mask $w.F)) } }
}
if ($Changes.Count) {
    RptLine ''
    RptLine '  Changed this run:'
    foreach ($c in $Changes) { RptLine "    + $(Mask $c)" }
}

RptSub 'order from here'
if (@($targetTrees | Where-Object { -not $_.Shared -and (-not $_.Exists -or -not $_.Files) }).Count) {
    RptLine "  1. Copy the $SourceEnv trees with the robocopy lines in section 3b, then re-run this DRY RUN."
    RptLine '     Nothing is patched or registered until the trees are actually on disk - the script cannot'
    RptLine '     re-point a path into a folder that does not exist, and will not pretend it has.'
} else {
    RptLine "  1. Trees are in place. Check section 2's NOT-imported list is right, then resolve the"
    RptLine '     accounts in section 4 - those are the only thing between here and -Apply.'
}
RptLine "  2. Hand-edit any file listed as [MANUAL] - those build their filename at runtime."
RptLine "  3. Batch-logon: -Apply now grants it. Check section 4 said 'granted' or 'already held', and"
RptLine '     check no GPO manages the right, or it comes back off at the next gpupdate.'
RptLine "  4. Enable ONE $SourceEnv task. Wait for its *$PromSuffix.prom to appear in $PromDir."
RptLine "  5. Re-run the duplicate-series check - this is the one that decides whether one exporter"
RptLine '     can serve both environments:'
RptLine "        .\Import-CrossEnvTasks.ps1 -CheckSeriesOnly"
RptLine "     Clean -> carry on enabling. Collisions -> the .prom CONTENT needs an Environment label,"
RptLine "     or $SourceEnv needs its own exporter on a second port."
RptLine "  6. Only then disable the same tasks on the old $SourceEnv server."
RptHead 'END OF REPORT'
RptLine '  Paste this whole report back to continue.'

$reportText = ($R -join "`r`n")
$reportText | Set-Content -LiteralPath $ReportPath -Encoding utf8
Write-Host $reportText
try { $reportText | Set-Clipboard; Write-Host "`nReport on the CLIPBOARD and saved to: $ReportPath" -ForegroundColor Cyan }
catch { Write-Host "`nReport saved to: $ReportPath" -ForegroundColor Cyan }
