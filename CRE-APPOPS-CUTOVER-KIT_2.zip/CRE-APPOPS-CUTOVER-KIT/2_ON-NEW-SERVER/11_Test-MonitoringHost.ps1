<#
.SYNOPSIS
  The runtime acceptance test. Watches the migrated tasks for a window, works out what any stuck
  process is actually blocked on, and checks the metrics really arrive. Read-only.

.DESCRIPTION
  Task STATE proves nothing. A feeder sampled ten seconds after launch looks identical to one wedged
  for an hour, and on a healthy APPMON host several feeders are long-running loops that log an event
  322 every five minutes for ever. So this judges three things instead:

    1. Did runs COMPLETE?  Task Scheduler events 100 / 102 / 201 are paired by InstanceId, which
       gives a real duration and exit code per run.
    2. Did OUTPUT appear?  The .prom directory is diffed across the window and against the baseline
       captured from the old server - that comparison is the actual acceptance criterion.
    3. If something IS stuck, WHY?  A process idle with no TCP socket is not necessarily off the
       network: SMB connections belong to the SYSTEM process and DNS is UDP, so neither shows under
       the script's own PID. Loaded modules give it away instead - credui means an invisible
       credential prompt in session 0, mpr/ntlanman means a blocked UNC, wbemprox means a WMI call.

  On an APPOPS host it also checks Prometheus target health and the Grafana API.

.PARAMETER CaptureFolder  Old-server capture, for the .prom baseline and the long-running verdict.
.PARAMETER Minutes        Watch window. Default 12, which covers two 5-minute trigger cycles.
.PARAMETER TraceOnly      Skip the watch; just diagnose whatever is stuck right now.

.EXAMPLE
  .\Test-MonitoringHost.ps1 -CaptureFolder C:\Migration\capture-SRVSYS1APPMON01-...
  .\Test-MonitoringHost.ps1 -TraceOnly
  .\Test-MonitoringHost.ps1 -PrometheusUrl http://localhost:9090 -GrafanaUrl http://localhost:9000
#>
[CmdletBinding()]
param(
    [string] $CaptureFolder,
    [int]    $Minutes = 12,
    [int]    $IntervalSeconds = 30,
    [string] $PromDir = 'D:\Win\Ops\WMITextfileExport',
    [string] $ScriptsRoot = 'D:\Win\Ops',
    [string] $ExporterUrl = 'http://localhost:9182/metrics',
    [string] $PrometheusUrl,
    [string] $GrafanaUrl,
    [string] $GrafanaApiKey,
    [switch] $TraceOnly,
    [switch] $Sanitize
)
$ErrorActionPreference = 'Continue'
$SuiteVersion = '1.0'
Import-Module (Join-Path $PSScriptRoot 'FOSMigrate.psm1') -Force -ErrorAction Stop
Assert-FosAdmin
New-FosReport -Sanitize:$Sanitize
$start = Get-Date
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
New-Item -ItemType Directory -Force -Path C:\Migration | Out-Null

$MO = $null
if ($CaptureFolder) {
    $mf = Join-Path $CaptureFolder 'manifest.json'
    if (Test-Path -LiteralPath $mf) {
        $MO = Import-FosManifest $mf
        if ($MO.exporter -and $MO.exporter.textfileDir -and -not $PSBoundParameters.ContainsKey('PromDir')) { $PromDir = "$($MO.exporter.textfileDir)" }
    }
}

# in scope = ours. Vendor updaters run as SYSTEM and are legitimately Running for long stretches;
# flagging an Edge updater as a hung task with a credential problem is pure noise.
$all = @(Get-ScheduledTask -ErrorAction SilentlyContinue | Where-Object { $_.TaskPath -notlike '\Microsoft*' })
$tasks = @($all | Where-Object {
    $act = ($_.Actions | ForEach-Object { "$($_.Execute) $($_.Arguments) $($_.WorkingDirectory)" }) -join ' '
    $u = "$($_.Principal.UserId)"
    ($act -like "*$ScriptsRoot*") -or ($u -notmatch '^(?:NT AUTHORITY\\)?(SYSTEM|LOCAL SERVICE|NETWORK SERVICE)$' -and "$($_.Principal.LogonType)" -ne 'ServiceAccount') })

if ($Sanitize) {
    Add-FosMask $env:COMPUTERNAME 'THIS-HOST'
    if ($MO) { Add-FosMask "$($MO.host)" 'OLD-HOST' }
    $i = 0
    foreach ($u in @($tasks | ForEach-Object { "$($_.Principal.UserId)" } | Sort-Object -Unique)) {
        $i++; Add-FosMask (ConvertTo-FosSam $u) "SVCACCT-$i"; Add-FosMask (("$u" -split '\\')[0]) 'DOM' } }

Write-Host ''
Write-Host ("  Test-MonitoringHost {0} on {1}" -f $SuiteVersion, $env:COMPUTERNAME) -ForegroundColor Cyan
if (-not $TraceOnly) { Write-Host ("  Watching {0} task(s) for {1} minutes. Leave this window open." -f $tasks.Count, $Minutes) -ForegroundColor Cyan }
Write-Host ''

$promBefore = @{}
if (Test-Path -LiteralPath $PromDir) {
    foreach ($f in Get-ChildItem -LiteralPath $PromDir -File -ErrorAction SilentlyContinue) { $promBefore[$f.Name] = $f.LastWriteTime } }

# ------------------------------------------------------------------ watch
$samples = 0
if (-not $TraceOnly) {
    $deadline = $start.AddMinutes($Minutes)
    while ((Get-Date) -lt $deadline) {
        $samples++
        $left = [int]($deadline - (Get-Date)).TotalSeconds
        Write-Host ("`r  sample {0}  {1}s remaining   " -f $samples, [Math]::Max(0, $left)) -NoNewline -ForegroundColor DarkGray
        Start-Sleep -Seconds ([Math]::Min($IntervalSeconds, [Math]::Max(1, $left)))
    }
    Write-Host ''
}

# ------------------------------------------------------------------ pair start/finish events
function Get-EvData { param($Event)
    $d = @{}
    try { $x = [xml]$Event.ToXml(); foreach ($n in $x.Event.EventData.Data) { $d["$($n.Name)"] = "$($n.'#text')" } } catch {}
    return $d }

Start-FosStep 'task scheduler events'
$runs = @{}; $refused = @{}
$evs = @(Invoke-FosTimeout {
    param($since)
    Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-TaskScheduler/Operational'; StartTime = [datetime]$since } -ErrorAction SilentlyContinue |
      Where-Object { $_.Id -in 100, 102, 111, 201, 322 } | Sort-Object TimeCreated |
      ForEach-Object { $x = $null; try { $x = [xml]$_.ToXml() } catch {}
        $d = @{}; if ($x) { foreach ($n in $x.Event.EventData.Data) { $d["$($n.Name)"] = "$($n.'#text')" } }
        [pscustomobject]@{ Id = $_.Id; Time = $_.TimeCreated; TaskName = $d['TaskName']; InstanceId = $d['InstanceId']; ResultCode = $d['ResultCode'] } }
} 120 @() 'task scheduler event query' -ArgumentList @($start.AddMinutes(-1)))
foreach ($e in @($evs)) {
    if ($e.Id -eq 322) { if ($e.TaskName) { $refused["$($e.TaskName)"] = 1 + [int]$refused["$($e.TaskName)"] }; continue }
    $iid = "$($e.InstanceId)"
    if (-not $iid) { continue }
    if (-not $runs.ContainsKey($iid)) { $runs[$iid] = [pscustomobject]@{ Task = "$($e.TaskName)"; Started = $null; Ended = $null; Result = $null; Terminated = $false } }
    switch ($e.Id) {
        100 { $runs[$iid].Started = $e.Time }
        102 { $runs[$iid].Ended = $e.Time }
        201 { $runs[$iid].Ended = $e.Time; $runs[$iid].Result = "$($e.ResultCode)" }
        111 { $runs[$iid].Terminated = $true }
    }
}

# ------------------------------------------------------------------ report
Add-FosHead 'MONITORING HOST ACCEPTANCE TEST'
Add-FosKV 'Generated' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Add-FosKV 'Script'    "Test-MonitoringHost $SuiteVersion"
Add-FosKV 'Server'    (Get-FosMask $env:COMPUTERNAME)
Add-FosKV 'Window'    $(if ($TraceOnly) { 'trace only - no watch' } else { "{0} -> {1} ({2} min, {3} samples)" -f $start.ToString('HH:mm:ss'), (Get-Date).ToString('HH:mm:ss'), $Minutes, $samples })
Add-FosKV 'Baseline from' $(if ($MO) { "$(Get-FosMask $MO.host) @ $($MO.capturedAt)" } else { '(none supplied)' })
Add-FosKV 'Tasks in scope' $tasks.Count

Add-FosSub 'verdict per task'
$stillRunning = @()
$rows = @()
foreach ($t in ($tasks | Sort-Object TaskName)) {
    $full = "$($t.TaskPath)$($t.TaskName)"
    $mine = @($runs.Values | Where-Object { $_.Task -eq $full })
    $done = @($mine | Where-Object { $_.Started -and $_.Ended })
    $open = @($mine | Where-Object { $_.Started -and -not $_.Ended })
    $cur  = Get-ScheduledTask -TaskPath $t.TaskPath -TaskName $t.TaskName -ErrorAction SilentlyContinue
    $verdict = 'NEVER STARTED'; $detail = 'no start event in the window'
    if ($done.Count) {
        $durs = @($done | ForEach-Object { [int](New-TimeSpan -Start $_.Started -End $_.Ended).TotalSeconds })
        $bad  = @($done | Where-Object { $_.Result -and $_.Result -ne '0' })
        $verdict = $(if ($bad.Count) { 'FAILED' } else { 'COMPLETES' })
        $detail = "duration {0}-{1}s" -f ($durs | Measure-Object -Minimum).Minimum, ($durs | Measure-Object -Maximum).Maximum
        if ($bad.Count) { $detail += "; result $($bad[0].Result)" }
    } elseif ($open.Count -or ($cur -and "$($cur.State)" -eq 'Running')) {
        $verdict = 'LONG-RUNNING'
        $since = $(if ($open.Count) { ($open | Sort-Object Started | Select-Object -First 1).Started } else { $start })
        $detail = "instance alive since $($since.ToString('HH:mm:ss'))"
        $stillRunning += $t
    }
    if ($refused["$full"]) { $detail += "; $($refused["$full"]) launch(es) refused (322)" }
    # what did the OLD server say about this task?
    $expected = ''
    if ($MO) {
        $ot = @($MO.tasks | Where-Object { "$($_.name)".ToLower() -eq $full.ToLower() }) | Select-Object -First 1
        if ($ot) { $expected = $(if ($ot.normallyLongRunning) { 'long-running there too' } else { 'completes there' }) }
        else { $expected = 'not on the old server' }
    }
    $rows += [pscustomobject]@{ Task = $full; Verdict = $verdict; Runs = $done.Count; OldServer = $expected; Detail = $detail }
}
Add-FosTable -Rows $rows -Columns ([ordered]@{ Task = 44; Verdict = 14; Runs = 5; OldServer = 22; Detail = 44 })

# a LONG-RUNNING task that is long-running on the old box too is fine; one that is not, is not
foreach ($r in $rows) {
    if ($r.Verdict -eq 'FAILED') { Add-FosFinding -Severity blocker -Area 'tasks' -Problem "$($r.Task) finished with a non-zero result ($($r.Detail))" -Fix 'Run the script by hand as the task account to see the error' }
    elseif ($r.Verdict -eq 'LONG-RUNNING' -and $r.OldServer -eq 'completes there') {
        Add-FosFinding -Severity blocker -Area 'tasks' -Problem "$($r.Task) is long-running here but COMPLETES on the old server" -Fix 'This one is genuinely stuck - see the trace section below' }
    elseif ($r.Verdict -eq 'NEVER STARTED') { Add-FosFinding -Severity warn -Area 'tasks' -Problem "$($r.Task) did not start during the window" -Fix 'Either it is disabled, or no trigger was due. Check the Triggers tab for a recurring trigger.' }
}

# ------------------------------------------------------------------ trace what is stuck
if ($stillRunning.Count) {
    Start-FosStep 'tracing running processes'
    Add-FosSub 'what the running tasks are actually doing'
    $Fingerprints = @(
        @{ Match = 'credui|wincredui|authui'; Verdict = 'CREDENTIAL PROMPT - CredUI is loaded. In session 0 that dialog is invisible and the process waits for ever.' }
        @{ Match = '^mpr\.|ntlanman|^davclnt'; Verdict = 'SMB / UNC - a blocked \\server\share open. It shows NO socket under this PID because the connection belongs to SYSTEM.' }
        @{ Match = '^wsmsvc|^wsmauto|^winrs'; Verdict = 'WinRM / remoting - it is trying to reach another machine.' }
        @{ Match = '^msdart|^adodb|^sqloledb|^msoledbsql|^sqlncli'; Verdict = 'SQL client - waiting on a database connection.' }
        @{ Match = '^wbemprox|^wbemcomn|^fastprox'; Verdict = 'WMI - a WMI/CIM call is in flight; a REMOTE one over DCOM can hang for minutes.' }
        @{ Match = '^dnsapi|^dnsrslvr'; Verdict = 'DNS resolver loaded - WEAK on its own (almost anything networked loads it). Only meaningful next to a UNC or -ComputerName.' }
    )
    $pids = @{}
    try { $sch = New-Object -ComObject Schedule.Service; $sch.Connect()
          foreach ($rt in $sch.GetRunningTasks(1)) { $pids[$rt.Path] = $rt.EnginePID } } catch {}
    foreach ($t in $stillRunning) {
        $full = "$($t.TaskPath)$($t.TaskName)"
        Add-FosLine ''
        Add-FosLine ("  [{0}]" -f (Get-FosMask $full))
        $epid = $pids[$full]
        if (-not $epid) { Add-FosLine '     no engine PID - the scheduler thinks it is running but there is no process (stale state)'
                          Add-FosFinding -Severity warn -Area 'tasks' -Problem "$full is marked Running with no process" -Fix 'Stop-ScheduledTask to clear it, then run it once by hand'; continue }
        $procs = @(@(Get-CimInstance Win32_Process -Filter "ProcessId=$epid" -ErrorAction SilentlyContinue) +
                   @(Get-CimInstance Win32_Process -Filter "ParentProcessId=$epid" -ErrorAction SilentlyContinue) |
                   Where-Object { $_ -and $_.Name -notmatch '^conhost' })
        foreach ($p in $procs) {
            $procId = [int]$p.ProcessId
            Add-FosLine ("     pid={0} {1}  up {2} min" -f $procId, $p.Name, [int](New-TimeSpan -Start $p.CreationDate -End (Get-Date)).TotalMinutes)
            if ($p.CommandLine) { Add-FosLine ("     cmd  : {0}" -f (Format-FosTrim (Get-FosMask $p.CommandLine) 96)) }
            # CPU burn over a short sample: a loop that is working ticks, a blocked process does not
            $c1 = (Get-Process -Id $procId -ErrorAction SilentlyContinue).CPU
            Start-Sleep -Milliseconds 1500
            $c2 = (Get-Process -Id $procId -ErrorAction SilentlyContinue).CPU
            $busy = $null
            if ($null -ne $c1 -and $null -ne $c2) {
                $burn = [math]::Round(($c2 - $c1), 3); $busy = ($burn -gt 0.02)
                Add-FosLine ("     cpu  : {0}s total, {1}s in 1.5s -> {2}" -f [math]::Round($c2, 1), $burn, $(if ($busy) { 'BUSY (working - probably a deliberate loop)' } else { 'IDLE (blocked on something)' })) }
            $mods = @()
            try { $mods = @((Get-Process -Id $procId -ErrorAction Stop).Modules | ForEach-Object { $_.ModuleName }) } catch { Add-FosLine '     mods : cannot read the module list' }
            $hit = $false
            foreach ($f in $Fingerprints) {
                $m = @($mods | Where-Object { $_ -match $f.Match })
                if ($m) { $hit = $true; Add-FosLine ("     >>>  {0}" -f (($m | Select-Object -First 3) -join ',')); Add-FosLine ("          {0}" -f $f.Verdict) } }
            if (-not $hit -and $mods.Count) { Add-FosLine '     >>>  none of the credential / SMB / WMI / SQL fingerprints are loaded' }
            $conns = @()
            try { $conns = @(Get-NetTCPConnection -OwningProcess $procId -ErrorAction Stop | Where-Object { $_.State -ne 'Listen' } | Select-Object -First 5) } catch {}
            foreach ($c in $conns) { Add-FosLine ("     sock : {0}:{1} {2}" -f $c.RemoteAddress, $c.RemotePort, $c.State) }
            if (-not $conns) { Add-FosLine '     sock : no TCP socket owned by this PID (SMB and DNS would not appear here - read the modules above)' }
            if ($busy -eq $false -and -not $hit) { Add-FosLine '     ==>  idle, no fingerprint: suspect a console read (Read-Host / pause / Console.ReadLine)' }
        }
        # the script's own log usually says where it stopped, faster than any of the above
        $sp = $null
        foreach ($a in $t.Actions) { if ("$($a.Arguments)" -match '(?i)-(?:file|f)\s+"?([^"]+\.ps1)"?') { $sp = $Matches[1] } }
        if ($sp) {
            $dir = Split-Path -Parent $sp
            $logs = @(Get-ChildItem -LiteralPath $dir -Recurse -Include *.log, *.txt -ErrorAction SilentlyContinue |
                      Where-Object { $_.LastWriteTime -gt (Get-Date).AddHours(-6) } | Sort-Object LastWriteTime -Descending | Select-Object -First 1)
            foreach ($l in $logs) {
                Add-FosLine ("     log  : {0} (last write {1})" -f (Get-FosMask $l.FullName), $l.LastWriteTime.ToString('HH:mm:ss'))
                foreach ($line in (Get-Content -LiteralPath $l.FullName -Tail 10 -ErrorAction SilentlyContinue)) {
                    Add-FosLine ("       | {0}" -f (Format-FosTrim (Get-FosMask $line) 92)) } }
        }
    }
}

# ------------------------------------------------------------------ the real acceptance test
Add-FosSub 'textfile output - THIS is the acceptance test'
if (-not (Test-Path -LiteralPath $PromDir)) {
    Add-FosLine "    $PromDir DOES NOT EXIST"
    Add-FosFinding -Severity blocker -Area 'output' -Problem "$PromDir does not exist" -Fix 'Repair-MonitoringHost.ps1 -Apply creates it and grants the task accounts Modify'
} else {
    $after = @(Get-ChildItem -LiteralPath $PromDir -File -ErrorAction SilentlyContinue)
    $changed = 0
    foreach ($f in $after) {
        $tag = $(if (-not $promBefore.ContainsKey($f.Name)) { 'NEW' } elseif ($f.LastWriteTime -gt $promBefore[$f.Name]) { 'UPDATED' } else { 'unchanged' })
        if ($tag -ne 'unchanged') { $changed++ }
        Add-FosLine ("    {0,-40} {1,9} bytes  {2}  {3}" -f $f.Name, $f.Length, $f.LastWriteTime.ToString('HH:mm:ss'), $tag) }
    if (-not $after.Count) { Add-FosLine '    (empty - no task has produced output)' }
    Add-FosLine ''
    Add-FosLine ("    {0} file(s) new or updated during the window" -f $changed)
    if ($MO -and $MO.exporter -and @($MO.exporter.promFiles).Count) {
        Add-FosLine ''
        Add-FosLine '    against the old server baseline:'
        foreach ($b in @($MO.exporter.promFiles)) {
            $here = @($after | Where-Object { $_.Name -eq $b.name }) | Select-Object -First 1
            if ($here) { Add-FosLine ("      [ok  ] {0,-38} old {1,8}b/~{2}min   here {3,8}b/{4}min" -f $b.name, $b.bytes, $b.ageMinutes, $here.Length, [int](New-TimeSpan -Start $here.LastWriteTime -End (Get-Date)).TotalMinutes) }
            else { Add-FosLine ("      [MISS] {0,-38} old {1,8}b, refreshed every ~{2} min" -f $b.name, $b.bytes, $b.ageMinutes)
                   Add-FosFinding -Severity blocker -Area 'output' -Problem "$($b.name) is not being produced here" -Fix 'Its feeder task has not run, or ran and could not write. Check the directory ACL for the task account before anything else.' } }
    }
}

Add-FosSub 'exporter scrape'
try {
    $body = (Invoke-WebRequest $ExporterUrl -UseBasicParsing -TimeoutSec 25).Content
    $lines = $body -split "`n"
    Add-FosKV 'Metric lines' $lines.Count
    $fam = @($lines | Where-Object { $_ -match '^# HELP (\S+)' } | ForEach-Object { ($_ -split ' ')[2] } | Sort-Object -Unique)
    Add-FosKV 'Metric families' $fam.Count
    $tf = @($lines | Where-Object { $_ -match '_textfile_mtime_seconds' -and $_ -notmatch '^#' })
    Add-FosKV 'Textfile files exposed' $tf.Count
    foreach ($l in ($tf | Select-Object -First 8)) { Add-FosLine ("    {0}" -f (Format-FosTrim $l 96)) }
    $err = @($lines | Where-Object { $_ -match '_textfile_scrape_error' -and $_ -notmatch '^#' })
    if ($err -match '\s1(\.0)?\s*$') { Add-FosFinding -Severity blocker -Area 'exporter' -Problem 'textfile_scrape_error = 1 - a .prom file in the directory does not parse' -Fix 'One malformed file suppresses the whole textfile collector. Test-PromFiles.ps1 finds it.' }
    if ($MO -and $MO.exporter -and @($MO.exporter.metricFamilies).Count) {
        $oldFam = @($MO.exporter.metricFamilies)
        $here = @{}; foreach ($f in $fam) { $here["$f"] = $true }
        $gone = @(); $renamed = 0
        foreach ($f in $oldFam) {
            if ($here.ContainsKey($f)) { continue }
            $alt = $null; if ($f -like 'wmi_*') { $alt = 'windows_' + $f.Substring(4) }
            if ($alt -and $here.ContainsKey($alt)) { $renamed++ } else { $gone += $f } }
        Add-FosKV 'Families renamed wmi_->windows_' $renamed
        Add-FosKV 'Families with no counterpart' $gone.Count
        if ($gone.Count) {
            foreach ($f in @($gone | Select-Object -First 25)) { Add-FosLine "      GONE $f" }
            Add-FosFinding -Severity warn -Area 'dashboards' -Problem "$($gone.Count) metric families the old exporter served have no counterpart here" -Fix 'Any dashboard panel or alert rule querying one of these is now blank. Search the dashboard JSON for each name.' }
    }
} catch { Add-FosFinding -Severity blocker -Area 'exporter' -Problem "nothing answered on $ExporterUrl" -Fix 'Repair-MonitoringHost.ps1 -Apply starts it and captures the binary''s own error if it will not' }

# ------------------------------------------------------------------ APPOPS extras
if ($PrometheusUrl) {
    Add-FosSub 'Prometheus'
    try {
        $t = (Invoke-WebRequest "$PrometheusUrl/api/v1/targets" -UseBasicParsing -TimeoutSec 30).Content | ConvertFrom-Json
        $tg = @($t.data.activeTargets)
        Add-FosKV 'Targets up'   @($tg | Where-Object { $_.health -eq 'up' }).Count
        Add-FosKV 'Targets down' @($tg | Where-Object { $_.health -ne 'up' }).Count
        foreach ($x in @($tg | Where-Object { $_.health -ne 'up' })) {
            Add-FosLine ("    DOWN {0,-34} {1}" -f (Get-FosMask $x.labels.instance), (Format-FosTrim $x.lastError 70)) }
        $down = @($tg | Where-Object { $_.health -ne 'up' })
        if ($down.Count) { Add-FosFinding -Severity blocker -Area 'prometheus' -Problem "$($down.Count) scrape target(s) are down" -Fix 'Usually the inbound 9182 rule, a stopped exporter, or a host still listed after decommissioning' }
        $me = @($tg | Where-Object { "$($_.labels.instance)" -match [regex]::Escape($env:COMPUTERNAME) })
        Add-FosKV 'This host in Prometheus' $(if ($me.Count) { "yes - $($me[0].health)" } else { 'NO - not a scrape target yet' })
        if (-not $me.Count) { Add-FosFinding -Severity blocker -Area 'prometheus' -Problem 'this host is not a Prometheus scrape target' -Fix "Add it to the file_sd JSON on the APPOPS server with the same Environment label as its neighbours, alongside the old entry - not instead of it" }
    } catch { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "could not reach $PrometheusUrl" }
}
if ($GrafanaUrl) {
    Add-FosSub 'Grafana'
    $h = @{}
    if ($GrafanaApiKey) { $h['Authorization'] = "Bearer $GrafanaApiKey" }
    foreach ($ep in @(@{ n = 'health'; u = '/api/health' }, @{ n = 'datasources'; u = '/api/datasources' }, @{ n = 'dashboards'; u = '/api/search?limit=5000' })) {
        try {
            $c = (Invoke-WebRequest ("$GrafanaUrl" + $ep.u) -Headers $h -UseBasicParsing -TimeoutSec 20).Content
            if ($ep.n -eq 'health') { Add-FosKV 'Health' (Format-FosTrim $c 90) }
            else { Add-FosKV $ep.n @($c | ConvertFrom-Json).Count }
        } catch { Add-FosFinding -Severity warn -Area 'grafana' -Problem "Grafana $($ep.n) endpoint did not answer" -Fix 'Check the URL and whether the API needs auth (-GrafanaApiKey)' }
    }
}

Add-FosFindingSummary
Add-FosSub 'how to read this'
Add-FosLine '  COMPLETES + files updating  -> done. Add the host to Prometheus if it is not there yet.'
Add-FosLine '  LONG-RUNNING + "long-running there too" + files updating  -> normal. That is how the old'
Add-FosLine '                                 server behaves. Judge it on output, never on task state.'
Add-FosLine '  LONG-RUNNING + cpu BUSY     -> working. Give it time, then check output again.'
Add-FosLine '  LONG-RUNNING + cpu IDLE + credui loaded  -> invisible credential prompt in session 0.'
Add-FosLine '                                 Check HOW the secret is stored first: ConvertTo-SecureString'
Add-FosLine '                                 -AsPlainText is portable and travels with the files, so'
Add-FosLine '                                 there is nothing to re-create - the value itself is wrong'
Add-FosLine '                                 or its config file did not come across.'
Add-FosLine '  LONG-RUNNING + cpu IDLE + mpr/ntlanman   -> blocked on a UNC path. Test it by hand.'
Add-FosLine '  NEVER STARTED               -> disabled, or no trigger was due in the window.'
Add-FosLine ''
Add-FosLine '  The definitive test is always two minutes of your time:'
Add-FosLine '    runas /user:<DOM>\<svcaccount> powershell.exe   then run the script and watch it.'
Add-FosHead 'END OF REPORT'
Add-FosLine '  Paste this whole report back to continue.'
$null = Write-FosReport -Path "C:\Migration\TEST-$env:COMPUTERNAME-$stamp.txt"
