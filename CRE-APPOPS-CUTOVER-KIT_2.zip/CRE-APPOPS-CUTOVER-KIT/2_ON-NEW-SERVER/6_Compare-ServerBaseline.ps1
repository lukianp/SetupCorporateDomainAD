<#
.SYNOPSIS
  Diffs two Invoke-ServerCapture manifests and answers one question: is everything running exactly
  where it was. Read-only. Prints a numbered remediation list with the command for each gap.

.DESCRIPTION
  Run the capture on the old server and on the new one, then point this at both manifests. It is
  deliberately one-directional: it reports what the OLD server had that the NEW one does not.
  Extra things on the new box are noted but never treated as faults - a 2025 build legitimately
  ships more than a 2012 one.

  What it will not let you miss:
    * a drive letter, a service, a service LOG-ON ACCOUNT, a start mode
    * a user right - the whole privilege table, not just the batch-logon one
    * a firewall rule, or a port that listened on the old box and has no rule on the new one
    * the service account's WinINET proxy, hosts-file overrides, machine environment variables
    * a scheduled task, or a task whose triggers came across differently
    * installed software and roles
    * METRIC FAMILIES that Prometheus can no longer see - the exporter upgrade renames wmi_* to
      windows_* and deletes some families outright, and every dashboard panel querying one of the
      deleted ones goes blank. This is the single most useful part of the comparison.

.EXAMPLE
  .\Compare-ServerBaseline.ps1 -Old C:\Migration\capture-SRVSYS1APPMON01-*\manifest.json `
                               -New C:\Migration\capture-VMSYSAPPMON01-*\manifest.json
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)] [string] $Old,
    [Parameter(Mandatory = $true)] [string] $New,
    [string] $OutputRoot = 'C:\Migration',
    [switch] $Sanitize
)
$ErrorActionPreference = 'Continue'
$SuiteVersion = '1.1'
Import-Module (Join-Path $PSScriptRoot 'FOSMigrate.psm1') -Force -ErrorAction Stop
New-FosReport -Sanitize:$Sanitize

function Resolve-One { param([string]$Pattern)
    $f = @(Get-ChildItem -Path $Pattern -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
    if (-not $f.Count) { throw "No manifest matched: $Pattern" }
    return $f[0].FullName }
$oldManifestPath = Resolve-One $Old
$newManifestPath = Resolve-One $New
$OldM = Import-FosManifest $oldManifestPath
$NewM = Import-FosManifest $newManifestPath

if ($Sanitize) {
    Add-FosMask "$($OldM.host)" 'OLD-HOST'; Add-FosMask "$($NewM.host)" 'NEW-HOST'
    Add-FosMask "$($OldM.system.domain)" 'DOM.LOCAL'
    $i = 0; foreach ($a in @($OldM.taskAccounts)) { $i++; Add-FosMask (ConvertTo-FosSam $a) "SVCACCT-$i" }
}

# ------------------------------------------------------------------ helpers
function Get-Missing {
    <# Items present in Old and absent from New, keyed by a projection. #>
    param([object[]]$OldSet, [object[]]$NewSet, [scriptblock]$Key)
    $newKeys = @{}
    foreach ($n in @($NewSet)) { $k = (& $Key $n); if ($null -ne $k) { $newKeys["$k"] = $n } }
    return @(@($OldSet) | Where-Object { $k = (& $Key $_); $null -ne $k -and -not $newKeys.ContainsKey("$k") })
}
function Get-Changed {
    <# Items in both, where a compared projection differs. Returns old/new pairs. #>
    param([object[]]$OldSet, [object[]]$NewSet, [scriptblock]$Key, [scriptblock]$Value)
    $newByKey = @{}
    foreach ($n in @($NewSet)) { $k = (& $Key $n); if ($null -ne $k) { $newByKey["$k"] = $n } }
    $out = @()
    foreach ($o in @($OldSet)) {
        $k = (& $Key $o)
        if ($null -eq $k -or -not $newByKey.ContainsKey("$k")) { continue }
        $ov = "$(& $Value $o)"; $nv = "$(& $Value $newByKey["$k"])"
        if ($ov -ne $nv) { $out += [pscustomobject]@{ Key = "$k"; Old = $ov; New = $nv } }
    }
    return $out
}
$script:Fix = New-Object System.Collections.ArrayList
function Add-Fix { param([string]$Severity, [string]$Area, [string]$What, [string]$Command = '')
    [void]$script:Fix.Add([pscustomobject]@{ Severity = $Severity; Area = $Area; What = $What; Command = $Command })
    Add-FosFinding -Severity $Severity -Area $Area -Problem $What -Fix $Command }

Add-FosHead 'SERVER BASELINE COMPARISON'
Add-FosKV 'Generated' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Add-FosKV 'OLD' ("{0}   captured {1}" -f (Get-FosMask $OldM.host), $OldM.capturedAt)
Add-FosKV 'NEW' ("{0}   captured {1}" -f (Get-FosMask $NewM.host), $NewM.capturedAt)
Add-FosKV 'OLD OS' "$($OldM.system.os) build $($OldM.system.build)"
Add-FosKV 'NEW OS' "$($NewM.system.os) build $($NewM.system.build)"
Add-FosKV 'Role'   "$($OldM.role) -> $($NewM.role)"

# ------------------------------------------------------------------ platform
Add-FosSub 'drive letters'
$oldLetters = @($OldM.volumes | ForEach-Object { "$($_.letter)".ToUpper() })
$newLetters = @($NewM.volumes | ForEach-Object { "$($_.letter)".ToUpper() })
foreach ($d in $oldLetters) {
    if ($newLetters -contains $d) { Add-FosLine ("    [ok  ] {0}" -f $d) }
    else { Add-FosLine ("    [MISS] {0}" -f $d)
           Add-Fix blocker 'storage' "drive $d exists on the old server and not on the new one" 'Every task action, service path and config file that references it is invalid until this volume exists with the same letter.' }
}
if ("$($OldM.system.timeZone)" -ne "$($NewM.system.timeZone)") {
    Add-Fix warn 'system' "time zone differs: $($OldM.system.timeZone) -> $($NewM.system.timeZone)" "Set-TimeZone -Id '$($OldM.system.timeZone)'  # timestamps in .prom files and log correlation depend on it" }
if ("$($OldM.system.executionPolicy)" -ne "$($NewM.system.executionPolicy)") {
    Add-FosKV 'Execution policy' "OLD $($OldM.system.executionPolicy)"
    Add-FosKV '' "NEW $($NewM.system.executionPolicy)"
    Add-Fix warn 'system' 'PowerShell execution policy differs' 'A stricter policy on the new box stops every .ps1 task action. Compare LocalMachine in particular.' }

# ------------------------------------------------------------------ network
Add-FosSub 'network and proxy'
$missHosts = @(Get-Missing $OldM.network.hostsEntries $NewM.network.hostsEntries { param($x) ($x -replace '\s+', ' ').ToLower() })
foreach ($h in $missHosts) { Add-Fix warn 'network' "hosts file entry not on the new server: $h" "Add it to $env:SystemRoot\System32\drivers\etc\hosts, or make DNS resolve it properly" }
$oldProx = @($OldM.network.userProxies); $newProx = @($NewM.network.userProxies)
if ($oldProx.Count -and -not $newProx.Count) {
    Add-Fix blocker 'network' "the old server had a WinINET proxy configured for $($oldProx.Count) profile(s) and the new one has none" 'Invoke-WebRequest inside a scheduled task uses the CALLING ACCOUNT profile proxy. Without it, outbound calls to D365/Azure hang rather than fail. Set it under the service account, or set a machine WinHTTP proxy.' }
foreach ($p in $oldProx) { Add-FosLine ("    OLD proxy  {0,-36} enabled={1} server={2}" -f (Get-FosMask $p.account), $p.enabled, $p.server) }
foreach ($p in $newProx) { Add-FosLine ("    NEW proxy  {0,-36} enabled={1} server={2}" -f (Get-FosMask $p.account), $p.enabled, $p.server) }
if ("$($OldM.network.winHttpProxy)" -ne "$($NewM.network.winHttpProxy)") {
    Add-FosLine '    WinHTTP proxy differs:'
    Add-FosLine ("      OLD: {0}" -f (Format-FosTrim $OldM.network.winHttpProxy 90))
    Add-FosLine ("      NEW: {0}" -f (Format-FosTrim $NewM.network.winHttpProxy 90))
    Add-Fix warn 'network' 'machine WinHTTP proxy differs' "netsh winhttp set proxy <server:port> `"<bypass-list>`"" }
foreach ($s in (Get-Missing $OldM.network.shares $NewM.network.shares { param($x) $x.name })) {
    Add-Fix warn 'network' "SMB share '$($s.name)' ($($s.path)) is not on the new server" "New-SmbShare -Name '$($s.name)' -Path '$($s.path)'" }

# ------------------------------------------------------------------ firewall and ports
Add-FosSub 'firewall rules and listening ports'
foreach ($r in (Get-Missing $OldM.firewall.rules $NewM.firewall.rules { param($x) "$($x.direction)|$($x.protocol)|$($x.localPort)|$($x.program)" })) {
    $cmd = "New-NetFirewallRule -DisplayName '$($r.name)' -Direction $($r.direction) -Action $($r.action)"
    if ($r.protocol) { $cmd += " -Protocol $($r.protocol)" }
    if ($r.localPort) { $cmd += " -LocalPort $($r.localPort)" }
    if ($r.program)   { $cmd += " -Program '$($r.program)'" }
    Add-Fix blocker 'firewall' "rule missing on the new server: $($r.name) ($($r.direction) $($r.protocol)/$($r.localPort))" $cmd }
$oldPorts = @($OldM.listeners | Where-Object { $_.address -notin '127.0.0.1', '::1' })
foreach ($l in $oldPorts) {
    $match = @($NewM.listeners | Where-Object { [int]$_.port -eq [int]$l.port })
    if (-not $match) { Add-Fix blocker 'ports' "port $($l.port) was listening on the old server ($($l.process)) and nothing listens on it now" 'Whatever provided it has not been installed, has not started, or is configured on a different port.' }
    elseif ("$($match[0].firewall)" -eq 'NO INBOUND RULE' -and "$($l.firewall)" -ne 'NO INBOUND RULE') {
        Add-Fix blocker 'firewall' "port $($l.port) listens on the new server but has no inbound rule (the old one had '$($l.firewall)')" "New-NetFirewallRule -DisplayName 'port $($l.port)' -Direction Inbound -Protocol TCP -LocalPort $($l.port) -Action Allow -Profile Domain" } }

# ------------------------------------------------------------------ user rights (the invisible one)
Add-FosSub 'user rights assignment'
$builtin = '^(BUILTIN|NT AUTHORITY|NT SERVICE|Everyone|CREATOR|APPLICATION PACKAGE|S-1-)'
$rightsChecked = 0
foreach ($right in @($OldM.security.userRights.PSObject.Properties.Name)) {
    $oldP = @($OldM.security.userRights.$right) | Where-Object { $_ -and $_ -notmatch $builtin }
    if (-not $oldP.Count) { continue }
    $rightsChecked++
    $newP = @($NewM.security.userRights.$right)
    foreach ($p in $oldP) {
        if (Test-FosInList $p $newP) { continue }
        $sev = $(if ($right -eq 'SeBatchLogonRight') { 'blocker' } else { 'warn' })
        Add-Fix $sev 'rights' "$(Get-FosMask $p) holds $right on the old server and not on the new one" "secpol.msc > User Rights Assignment, or: Repair-MonitoringHost.ps1 -Apply (it grants the batch-logon right for every task account)" } }
Add-FosKV 'Rights carrying non-builtin principals' $rightsChecked
if ($NewM.security.batchLogonGpoManaged -eq $true) {
    Add-Fix warn 'rights' 'a GPO manages "Log on as a batch job" on the NEW server' 'A local grant will be reverted at the next policy refresh - the tasks will work today and stop tomorrow. Get the accounts added to the GPO.' }

Add-FosSub 'security posture drift (expected on a new build - listed so nothing surprises you later)'
foreach ($k in 'lmCompatibilityLevel', 'restrictAnonymous', 'noLmHash') {
    $ov = "$($OldM.security.lsa.$k)"; $nv = "$($NewM.security.lsa.$k)"
    if ($ov -ne $nv) { Add-FosLine ("    LSA {0,-26} OLD={1,-6} NEW={2}" -f $k, $ov, $nv) } }
$oldTls = @($OldM.security.schannel | Where-Object { $_.enabled -eq 1 } | ForEach-Object { "$($_.protocol)/$($_.side)" })
$newTls = @($NewM.security.schannel | Where-Object { $_.enabled -eq 1 } | ForEach-Object { "$($_.protocol)/$($_.side)" })
foreach ($t in $oldTls) { if ($newTls -notcontains $t) {
    Add-Fix warn 'tls' "$t was explicitly enabled on the old server and is not on the new one" 'Server 2025 removes the old protocols. If anything the scripts talk to still requires TLS 1.0/1.1, it will fail with a handshake error - the fix is on the endpoint, not here.' } }
$oldCrypto = @($OldM.security.dotNetCrypto | Where-Object { $_.schUseStrongCrypto -eq 1 }).Count
$newCrypto = @($NewM.security.dotNetCrypto | Where-Object { $_.schUseStrongCrypto -eq 1 }).Count
if ($oldCrypto -and -not $newCrypto) {
    Add-Fix warn 'tls' '.NET SchUseStrongCrypto was set on the old server and is not on the new one' "Set it in both HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319 and the WOW6432Node copy, or .NET apps negotiate an old protocol and fail" }

# ------------------------------------------------------------------ services
Add-FosSub 'services'
foreach ($s in (Get-Missing $OldM.services $NewM.services { param($x) "$($x.name)".ToLower() })) {
    Add-Fix blocker 'services' "service '$($s.name)' ($($s.displayName)) is not installed on the new server" "Old binary path: $($s.pathName)" }
foreach ($c in (Get-Changed $OldM.services $NewM.services { param($x) "$($x.name)".ToLower() } { param($x) "$($x.startName)" })) {
    Add-Fix warn 'services' "service $($c.Key) runs as a different account: $(Get-FosMask $c.Old) -> $(Get-FosMask $c.New)" "sc.exe config $($c.Key) obj= `"$($c.Old)`" password= `"<password>`"" }
foreach ($c in (Get-Changed $OldM.services $NewM.services { param($x) "$($x.name)".ToLower() } { param($x) "$($x.startMode)" })) {
    Add-Fix warn 'services' "service $($c.Key) start mode: $($c.Old) -> $($c.New)" "Set-Service $($c.Key) -StartupType $($c.Old)" }
foreach ($c in (Get-Changed $OldM.services $NewM.services { param($x) "$($x.name)".ToLower() } { param($x) ($x.pathName -replace '\s+', ' ') })) {
    Add-FosLine ("    path differs: {0}" -f $c.Key)
    Add-FosLine ("      OLD {0}" -f (Get-FosMask (Format-FosTrim $c.Old 100)))
    Add-FosLine ("      NEW {0}" -f (Get-FosMask (Format-FosTrim $c.New 100))) }
$stopped = @($NewM.services | Where-Object { $_.startMode -eq 'Auto' -and $_.state -ne 'Running' })
foreach ($s in $stopped) { Add-Fix blocker 'services' "service '$($s.name)' is set to Auto on the new server but is $($s.state)" "Start-Service $($s.name)  # then check why it did not start on its own" }
# NSSM wrapped services: the registry definition is the real service. Capture 2.0 records it.
foreach ($os in @($OldM.services | Where-Object { $_.nssm })) {
    $ns = @($NewM.services | Where-Object { "$($_.name)".ToLower() -eq "$($os.name)".ToLower() }) | Select-Object -First 1
    if (-not $ns) { continue }
    if (-not $ns.nssm) { Add-Fix warn 'services' "service $($os.name) was NSSM wrapped on the old server and is not on the new one" 'Not wrong by itself. Confirm the new service definition carries the same flags, working directory and restart policy.'; continue }
    $oa = "$($os.nssm.appParameters)" -replace '\s+', ' '; $na = "$($ns.nssm.appParameters)" -replace '\s+', ' '
    if ($oa -ne $na) { Add-Fix warn 'services' "service $($os.name): NSSM AppParameters differ" "OLD: $oa`n         NEW: $na" }
    if ("$($os.nssm.appDirectory)".ToLower() -ne "$($ns.nssm.appDirectory)".ToLower()) { Add-Fix warn 'services' "service $($os.name): NSSM AppDirectory differs ($($os.nssm.appDirectory) -> $($ns.nssm.appDirectory))" 'Relative --config.file and data paths resolve against this directory.' }
    if ("$($os.nssm.appExitDefault)" -and "$($os.nssm.appExitDefault)" -ne "$($ns.nssm.appExitDefault)") { Add-Fix warn 'services' "service $($os.name): NSSM exit action $($os.nssm.appExitDefault) -> $($ns.nssm.appExitDefault)" "nssm set $($os.name) AppExit Default $($os.nssm.appExitDefault)" }
    foreach ($ev in @($os.nssm.environment)) { $k = ($ev -split '=', 2)[0]; if (-not (@($ns.nssm.environment) | Where-Object { $_ -like "$k=*" })) { Add-Fix warn 'services' "service $($os.name): NSSM environment variable $k set on the old server only" "nssm set $($os.name) AppEnvironmentExtra $k=<value>" } }
}
if ($OldM.network.goProxyEnv -and $NewM.network) {
    foreach ($pk in @($OldM.network.goProxyEnv.PSObject.Properties | ForEach-Object { $_.Name })) {
        if (-not ($NewM.network.goProxyEnv.PSObject.Properties | Where-Object { $_.Name -eq $pk })) { Add-Fix warn 'environment' "proxy variable $pk ($($OldM.network.goProxyEnv.$pk)) is set on the old server only" 'Grafana and Prometheus are Go programs: HTTP(S)_PROXY / NO_PROXY is the only proxy setting they read.' } } }
if ($OldM.azure -and $NewM.azure -and $OldM.azure.imdsReachable) {
    if (-not $NewM.azure.imdsReachable) { Add-Fix warn 'azure' 'the old VM reaches IMDS (169.254.169.254) and the new one does not' 'Managed identity auth (App Insights datasource) cannot work. Check NO_PROXY and any host firewall outbound rule.' }
    elseif ($OldM.azure.identityToken -eq 'obtained' -and $NewM.azure.identityToken -ne 'obtained') { Add-Fix warn 'azure' 'the old VM obtains a managed identity token and the new one does not' 'Attach the user assigned identity to the new VM (or enable a system assigned one and grant it the same RBAC).' }
    elseif ($OldM.azure.identityClientId -and $NewM.azure.identityClientId -and $OldM.azure.identityClientId -ne $NewM.azure.identityClientId) { Add-Fix warn 'azure' "default managed identity differs: $($OldM.azure.identityClientId) -> $($NewM.azure.identityClientId)" 'A datasource left on default identity now authenticates as a different principal. Either give it the same RBAC, or set azure.managed_identity_client_id in custom.ini to the shared user assigned identity.' }
}

# ------------------------------------------------------------------ tasks
if ($OldM.tasks) {
    Add-FosSub 'scheduled tasks'
    foreach ($t in (Get-Missing $OldM.tasks $NewM.tasks { param($x) "$($x.name)".ToLower() })) {
        Add-Fix blocker 'tasks' "task $(Get-FosMask $t.name) is not registered on the new server" "Register it from the captured XML (tasks\ folder next to the old manifest), disabled, then enable it once the accounts and paths are in place" }
    foreach ($c in (Get-Changed $OldM.tasks $NewM.tasks { param($x) "$($x.name)".ToLower() } { param($x) "$($x.account)" })) {
        Add-Fix warn 'tasks' "task $(Get-FosMask $c.Key) runs as a different account: $(Get-FosMask $c.Old) -> $(Get-FosMask $c.New)" '' }
    foreach ($c in (Get-Changed $OldM.tasks $NewM.tasks { param($x) "$($x.name)".ToLower() } { param($x) (@($x.triggers | ForEach-Object { "$($_.type):$($_.interval)" }) -join ',') })) {
        Add-Fix warn 'tasks' "task $(Get-FosMask $c.Key) has different triggers" "OLD [$($c.Old)] NEW [$($c.New)] - re-import the task XML rather than hand-editing" }
    # carry the old server's verdict forward: this is what stops a healthy long-running feeder being
    # misdiagnosed as hung on the new box
    $lr = @($OldM.tasks | Where-Object { $_.normallyLongRunning })
    Add-FosLine ''
    if ($lr.Count) {
        Add-FosLine '  Tasks that are long-running on the OLD (working) server - expect the same on the new one:'
        foreach ($t in $lr) { Add-FosLine ("    {0}  ({1}x event 322 in 24h there)" -f (Get-FosMask $t.name), $t.refusedLaunches24h) }
    } else { Add-FosLine '  No task is long-running on the old server, so anything stuck at Running on the new one is a fault.' }
}

# ------------------------------------------------------------------ software, features, env, certs
Add-FosSub 'installed software present on the old server only'
$missSw = @(Get-Missing $OldM.software $NewM.software { param($x) "$($x.name)".ToLower() })
Add-FosTable -Rows @($missSw | ForEach-Object { [pscustomobject]@{ Name = $_.name; Version = $_.version; Publisher = $_.publisher } }) -Columns ([ordered]@{ Name = 46; Version = 18; Publisher = 30 })
foreach ($s in $missSw) { Add-Fix warn 'software' "'$($s.name)' $($s.version) is installed on the old server only" 'Install it, or confirm with the app owner that it is not needed' }
foreach ($f in (Get-Missing @($OldM.features) @($NewM.features) { param($x) "$x" })) {
    Add-Fix warn 'features' "Windows feature '$f' is installed on the old server only" "Install-WindowsFeature $f" }
foreach ($v in (Get-Missing $OldM.environment.variables $NewM.environment.variables { param($x) "$($x.name)".ToUpper() })) {
    if ("$($v.name)" -match '^(Path|PATHEXT|TEMP|TMP|windir|ComSpec|NUMBER_OF_PROCESSORS|OS|PROCESSOR_|PSModulePath|USERNAME|DriverData)') { continue }
    Add-Fix warn 'environment' "machine environment variable $($v.name) is not set on the new server" "[Environment]::SetEnvironmentVariable('$($v.name)', '$($v.value)', 'Machine')" }
$oldPathEntries = @($OldM.environment.pathEntries | Where-Object { $_.exists } | ForEach-Object { "$($_.path)".TrimEnd('\').ToLower() })
$newPathEntries = @($NewM.environment.pathEntries | ForEach-Object { "$($_.path)".TrimEnd('\').ToLower() })
foreach ($p in $oldPathEntries) { if ($newPathEntries -notcontains $p) { Add-Fix warn 'environment' "PATH entry missing on the new server: $p" 'Add it to the machine PATH if something calls that tool by bare name' } }
foreach ($c in (Get-Missing $OldM.certificates $NewM.certificates { param($x) "$($x.subject)".ToLower() })) {
    Add-Fix warn 'certs' "certificate not on the new server: $(Format-FosTrim $c.subject 70)" "Export it from the old server with its private key and import into LocalMachine\My" }
if ($OldM.iis -and -not $NewM.iis) { Add-Fix blocker 'iis' 'the old server runs IIS and the new one does not' 'Install-WindowsFeature Web-Server -IncludeManagementTools, then recreate the sites and pools listed in the old capture' }
elseif ($OldM.iis -and $NewM.iis) {
    foreach ($s in (Get-Missing $OldM.iis.sites $NewM.iis.sites { param($x) "$($x.name)".ToLower() })) { Add-Fix blocker 'iis' "IIS site '$($s.name)' is missing on the new server" "Path was $($s.path), bindings $(@($s.bindings) -join ' ')" }
    foreach ($p in (Get-Missing $OldM.iis.pools $NewM.iis.pools { param($x) "$($x.name)".ToLower() })) { Add-Fix blocker 'iis' "IIS app pool '$($p.name)' is missing" "Identity was $($p.identityType) $($p.userName), runtime $($p.runtime)" }
    foreach ($c in (Get-Changed $OldM.iis.pools $NewM.iis.pools { param($x) "$($x.name)".ToLower() } { param($x) "$($x.userName)" })) {
        Add-Fix warn 'iis' "app pool $($c.Key) identity: $(Get-FosMask $c.Old) -> $(Get-FosMask $c.New)" '' } }

# ------------------------------------------------------------------ app trees
Add-FosSub 'application trees'
foreach ($ot in @($OldM.appTrees)) {
    $nt = @($NewM.appTrees | Where-Object { "$($_.root)".ToLower() -eq "$($ot.root)".ToLower() }) | Select-Object -First 1
    if (-not $nt) { Add-Fix blocker 'apptree' "$($ot.root) does not exist on the new server" "robocopy \\$($OldM.host)\$("$($ot.root)" -replace ':', '$') $($ot.root) /E /COPY:DAT /R:1 /W:1"; continue }
    Add-FosKV $ot.root ("OLD {0} files / {1}   NEW {2} files / {3}" -f $ot.fileCount, (Format-FosSize $ot.totalBytes), $nt.fileCount, (Format-FosSize $nt.totalBytes))
    $delta = [int]$ot.fileCount - [int]$nt.fileCount
    if ($delta -gt 0) { Add-Fix blocker 'apptree' "$delta file(s) fewer under $($ot.root) on the new server" "robocopy the tree again with /E - a partial copy is how a task finds its script but not its module" }
    foreach ($d in (Get-Missing @($ot.topLevel) @($nt.topLevel) { param($x) "$x".ToLower() })) {
        Add-Fix blocker 'apptree' "folder $($ot.root)\$d is missing on the new server" '' }
    if (@($ot.hashes).Count -and @($nt.hashes).Count) {
        $nh = @{}; foreach ($h in @($nt.hashes)) { $nh["$($h.path)".ToLower()] = $h.sha256 }
        $diff = @(@($ot.hashes) | Where-Object { $nh.ContainsKey("$($_.path)".ToLower()) -and $nh["$($_.path)".ToLower()] -ne $_.sha256 })
        if ($diff.Count) { Add-Fix warn 'apptree' "$($diff.Count) file(s) under $($ot.root) differ in content between the servers" 'Usually a config file that was edited on one side. Review each.' } }
}

# ------------------------------------------------------------------ exporter
if ($OldM.exporter -or $NewM.exporter) {
    Add-FosSub 'windows_exporter'
    Add-FosKV 'Version' ("OLD {0}   NEW {1}" -f $OldM.exporter.version, $NewM.exporter.version)
    Add-FosKV 'Collectors OLD' (@($OldM.exporter.collectors) -join ',')
    Add-FosKV 'Collectors NEW' (@($NewM.exporter.collectors) -join ',')
    foreach ($c in @($OldM.exporter.collectors)) {
        if (@($NewM.exporter.collectors) -notcontains $c) {
            if ($c -eq 'cs') { Add-FosLine "    collector 'cs' dropped - correct: it was removed from windows_exporter (metrics moved to cpu_info/memory)" }
            else { Add-Fix warn 'exporter' "collector '$c' was enabled on the old server and is not on the new one" "Add it to collectors.enabled unless it no longer exists in this exporter version" } } }
    if (@($NewM.exporter.collectors) -contains 'cs') {
        Add-Fix blocker 'exporter' "the NEW config still enables 'cs'" "'cs' does not exist in windows_exporter - the service will refuse to start. Replace it with cpu_info (and keep memory)." }
    if (@($OldM.exporter.collectors) -contains 'textfile' -and @($NewM.exporter.collectors) -notcontains 'textfile') {
        Add-Fix blocker 'exporter' 'the textfile collector is not enabled on the new server' 'Without it every feeder .prom file is written and never exposed' }
    Add-FosLine ''
    Add-FosLine '  .prom files the old server produces - the acceptance test for the new one:'
    foreach ($f in @($OldM.exporter.promFiles)) {
        $nf = @($NewM.exporter.promFiles | Where-Object { $_.name -eq $f.name }) | Select-Object -First 1
        if ($nf) { Add-FosLine ("    [ok  ] {0,-38} old {1,8}b/{2}min   new {3,8}b/{4}min" -f $f.name, $f.bytes, $f.ageMinutes, $nf.bytes, $nf.ageMinutes) }
        else { Add-FosLine ("    [MISS] {0,-38} old {1,8}b, refreshed every ~{2} min" -f $f.name, $f.bytes, $f.ageMinutes)
               Add-Fix blocker 'exporter' "$($f.name) is not being produced on the new server" 'The feeder task for it has not run, or ran and could not write. Check the textfile directory ACL for the task account first.' } }
    # ACL: the new directory is usually created by an admin, so the service accounts get read-only
    foreach ($a in @($OldM.taskAccounts)) {
        $sam = ConvertTo-FosSam $a
        $has = @($NewM.exporter.promAcl | Where-Object { "$($_.identity)" -like "*$sam" -and "$($_.type)" -eq 'Allow' -and "$($_.rights)" -match 'Modify|FullControl|Write' })
        if (-not $has) { Add-Fix blocker 'exporter' "$(Get-FosMask $sam) cannot write to the textfile directory on the new server" "icacls '$($NewM.exporter.textfileDir)' /grant '$($a):(OI)(CI)M'" } }
}

# ------------------------------------------------------------------ Grafana
if ($OldM.grafana -or $NewM.grafana) {
    Add-FosSub 'Grafana'
    Add-FosKV 'Version' ("OLD {0}   NEW {1}" -f $OldM.grafana.version, $NewM.grafana.version)
    Add-FosKV 'Port'    ("OLD configured {0} listening {1}   NEW configured {2} listening {3}" -f $OldM.grafana.configuredPort, (@($OldM.grafana.listeningPorts) -join ','), $NewM.grafana.configuredPort, (@($NewM.grafana.listeningPorts) -join ','))
    Add-FosKV 'Alerting' ("OLD {0}   NEW {1}" -f $OldM.grafana.alertingMode, $NewM.grafana.alertingMode)
    Add-FosKV 'Database' ("OLD {0}   NEW {1}" -f $OldM.grafana.database.type, $NewM.grafana.database.type)
    if ($OldM.grafana.edition -or $NewM.grafana.edition) {
        Add-FosKV 'Edition' ("OLD {0}   NEW {1}" -f $OldM.grafana.edition, $NewM.grafana.edition)
        if ("$($OldM.grafana.edition)" -match '(?i)enterprise' -and "$($NewM.grafana.edition)" -notmatch '(?i)enterprise') { Add-Fix blocker 'grafana' 'the old server runs Grafana Enterprise and the new one does not' 'Install the Enterprise build at the same version. Reports, data source permissions and other Enterprise features stop working otherwise.' }
        if ($OldM.grafana.licence -and $OldM.grafana.licence.exists) {
            if (-not ($NewM.grafana.licence -and $NewM.grafana.licence.exists)) { Add-Fix blocker 'grafana' 'the old server has an Enterprise licence file and the new one does not' "Copy $($OldM.grafana.licence.path) to the same path (or the enterprise.license_path in custom.ini) on the new server. The licence is validated against root_url, so root_url must match $($OldM.grafana.licence.url)." }
            elseif ("$($OldM.grafana.licence.url)" -ne "$($NewM.grafana.licence.url)") { Add-Fix warn 'grafana' "licence URL differs: $(Get-FosMask $OldM.grafana.licence.url) -> $(Get-FosMask $NewM.grafana.licence.url)" '' }
        }
    }
    if ($OldM.grafana.db -and $OldM.grafana.db.exists -and $NewM.grafana.db -and $NewM.grafana.db.exists) {
        Add-FosKV 'grafana.db' ("OLD {0} written {1}   NEW {2} written {3}" -f (Format-FosSize $OldM.grafana.db.bytes), $OldM.grafana.db.modified, (Format-FosSize $NewM.grafana.db.bytes), $NewM.grafana.db.modified)
        if ([double]$NewM.grafana.db.bytes -lt ([double]$OldM.grafana.db.bytes * 0.5)) { Add-Fix warn 'grafana' 'grafana.db on the new server is less than half the size of the old one' 'Route B not done yet, or the copy was taken from the wrong path. Content is in that file.' }
    }
    if ($OldM.grafana.settings -and $NewM.grafana.settings) {
        foreach ($sk in @($OldM.grafana.settings.PSObject.Properties | ForEach-Object { $_.Name })) {
            $ov2 = "$($OldM.grafana.settings.$sk)"; $nv2 = "$($NewM.grafana.settings.$sk)"
            if ($ov2 -ne $nv2 -and $sk -notmatch '^(server\.root_url|server\.domain|paths\.|database\.path|enterprise\.license_path|log\.)') { Add-Fix warn 'grafana' "custom.ini setting $sk differs: '$(Get-FosMask $ov2)' -> '$(Get-FosMask $nv2)'" 'Set it in custom.ini on the new server unless the change is deliberate.' } } }
    if (@($OldM.grafana.envOverrides).Count) { foreach ($eo in @($OldM.grafana.envOverrides)) { if (@($NewM.grafana.envOverrides) -notcontains $eo) { Add-Fix warn 'grafana' "override '$eo' is in force on the old server only" 'GF_ variables and cfg: flags beat custom.ini. Reproduce it or fold it into custom.ini.' } } }
    if ("$($OldM.grafana.configuredPort)" -ne "$($NewM.grafana.configuredPort)") {
        Add-Fix blocker 'grafana' "Grafana port changed: $($OldM.grafana.configuredPort) -> $($NewM.grafana.configuredPort)" "Every bookmark, every alert notification link and any reverse proxy points at the old one. Set http_port in custom.ini and restart." }
    if ("$($OldM.grafana.alertingMode)" -ne "$($NewM.grafana.alertingMode)") {
        Add-Fix blocker 'grafana' "alerting mode changed: $($OldM.grafana.alertingMode) -> $($NewM.grafana.alertingMode)" "Legacy alerts do not migrate themselves. If the old server ran legacy alerting, its dashboard-embedded alert rules must be re-created as unified rules before they will fire." }
    if ("$($OldM.grafana.rootUrl)" -ne "$($NewM.grafana.rootUrl)") {
        Add-Fix warn 'grafana' "root_url changed: $(Get-FosMask $OldM.grafana.rootUrl) -> $(Get-FosMask $NewM.grafana.rootUrl)" 'Alert notification links and share URLs are built from this.' }
    # config keys that matter, compared one by one
    $keysOfInterest = @('server.http_port', 'server.protocol', 'server.domain', 'server.root_url', 'database.type',
        'database.path', 'security.admin_user', 'users.allow_sign_up', 'auth.anonymous.enabled', 'auth.ldap.enabled',
        'unified_alerting.enabled', 'alerting.enabled', 'smtp.enabled', 'smtp.host', 'paths.data', 'paths.plugins', 'paths.provisioning')
    foreach ($k in $keysOfInterest) {
        $ov = "$($OldM.grafana.effective.$k)"; $nv = "$($NewM.grafana.effective.$k)"
        if ($ov -ne $nv) { Add-FosLine ("    {0,-32} OLD='{1}'  NEW='{2}'" -f $k, (Get-FosMask $ov), (Get-FosMask $nv)) } }
    foreach ($p in (Get-Missing @($OldM.grafana.plugins) @($NewM.grafana.plugins) { param($x) "$x".ToLower() })) {
        Add-Fix warn 'grafana' "plugin '$p' is installed on the old server only" "grafana-cli plugins install $p   # a panel using a missing plugin renders as an error box" }
    if ($OldM.grafana.api -and $NewM.grafana.api) {
        foreach ($d in (Get-Missing @($OldM.grafana.api.datasources) @($NewM.grafana.api.datasources) { param($x) "$($x.name)".ToLower() })) {
            Add-Fix blocker 'grafana' "datasource '$($d.name)' ($($d.type)) is missing on the new server" "Every dashboard bound to it shows 'datasource not found'. Recreate it with the SAME uid ($($d.uid)) or the dashboards will not bind." }
        foreach ($c in (Get-Changed @($OldM.grafana.api.datasources) @($NewM.grafana.api.datasources) { param($x) "$($x.name)".ToLower() } { param($x) "$($x.uid)" })) {
            Add-Fix blocker 'grafana' "datasource '$($c.Key)' has a different uid: $($c.Old) -> $($c.New)" 'Dashboards reference datasources by uid. Either restore the old uid or re-point every dashboard.' }
        Add-FosKV 'Dashboards' ("OLD {0}   NEW {1}" -f @($OldM.grafana.api.dashboards).Count, @($NewM.grafana.api.dashboards).Count)
        foreach ($d in (Get-Missing @($OldM.grafana.api.dashboards) @($NewM.grafana.api.dashboards) { param($x) "$($x.uid)" })) {
            Add-Fix warn 'grafana' "dashboard missing on the new server: '$($d.title)' (uid $($d.uid), folder $($d.folder))" '' }
        Add-FosKV 'Alert rules' ("OLD {0}   NEW {1}" -f @($OldM.grafana.api.alertRules).Count, @($NewM.grafana.api.alertRules).Count)
    }
}

# ------------------------------------------------------------------ Prometheus
if ($OldM.prometheus -or $NewM.prometheus) {
    Add-FosSub 'Prometheus'
    Add-FosKV 'Version'   ("OLD {0}   NEW {1}" -f $OldM.prometheus.version, $NewM.prometheus.version)
    Add-FosKV 'Retention' ("OLD {0}   NEW {1}" -f $OldM.prometheus.retention, $NewM.prometheus.retention)
    Add-FosKV 'TSDB size' ("OLD {0}   NEW {1}" -f (Format-FosSize $OldM.prometheus.tsdbBytes), (Format-FosSize $NewM.prometheus.tsdbBytes))
    if ("$($OldM.prometheus.retention)" -ne "$($NewM.prometheus.retention)") {
        Add-Fix warn 'prometheus' "retention differs: $($OldM.prometheus.retention) -> $($NewM.prometheus.retention)" 'A shorter retention silently truncates every long-range dashboard panel.' }
    if ($OldM.prometheus.flags -and $NewM.prometheus.flags) {
        foreach ($fk in @($OldM.prometheus.flags.PSObject.Properties | ForEach-Object { $_.Name })) {
            $ofv = "$($OldM.prometheus.flags.$fk)"; $nfv = "$($NewM.prometheus.flags.$fk)"
            if ($ofv -ne $nfv -and $fk -notmatch '^(storage\.tsdb\.path|config\.file)$') { Add-Fix warn 'prometheus' "flag --$fk differs: '$ofv' -> '$nfv'" 'Set it on the NSSM AppParameters of the new service unless the change is deliberate.' } } }
    if ("$($OldM.prometheus.listenAddress)" -and "$($OldM.prometheus.listenAddress)" -ne "$($NewM.prometheus.listenAddress)") { Add-Fix warn 'prometheus' "listen address differs: $($OldM.prometheus.listenAddress) -> $($NewM.prometheus.listenAddress)" 'Grafana datasources and the cutover gate use the port.' }
    if ($OldM.prometheus.alertmanagers -and @($OldM.prometheus.alertmanagers).Count -and -not @($NewM.prometheus.alertmanagers).Count) { Add-Fix warn 'prometheus' 'the old prometheus.yml has live alertmanager targets and the new one has none' '' }
    if ($OldM.prometheus.tsdb -and $NewM.prometheus.tsdb) { Add-FosKV 'Data on disk' ("OLD {0} days (oldest {1})   NEW {2} days (oldest {3})" -f $OldM.prometheus.tsdb.dataDays, $OldM.prometheus.tsdb.oldestSample, $NewM.prometheus.tsdb.dataDays, $NewM.prometheus.tsdb.oldestSample) }
    foreach ($j in (Get-Missing @($OldM.prometheus.scrapeJobs) @($NewM.prometheus.scrapeJobs) { param($x) "$x".ToLower() })) {
        Add-Fix blocker 'prometheus' "scrape job '$j' is not configured on the new server" 'Copy the job block from the old prometheus.yml' }
    foreach ($t in (Get-Missing @($OldM.prometheus.targets) @($NewM.prometheus.targets) { param($x) "$($x.target)".ToLower() })) {
        Add-Fix blocker 'prometheus' "scrape target $(Get-FosMask $t.target) is missing on the new server" "Add it to the file_sd JSON with the same labels: $(@($t.labels.PSObject.Properties | ForEach-Object { "$($_.Name)=$($_.Value)" }) -join ' ')" }
    foreach ($r in (Get-Missing @($OldM.prometheus.ruleFiles) @($NewM.prometheus.ruleFiles) { param($x) "$x".ToLower() })) {
        Add-Fix warn 'prometheus' "rule file '$r' is not referenced on the new server" '' }

    # THE ONE THAT MATTERS FOR THE DASHBOARDS
    $oldFam = @($OldM.prometheus.metricFamilies)
    $newFam = @($NewM.prometheus.metricFamilies)
    if ($oldFam.Count -and $newFam.Count) {
        Add-FosSub 'metric families - what the dashboards will lose'
        Add-FosKV 'OLD families' $oldFam.Count
        Add-FosKV 'NEW families' $newFam.Count
        $famSet = @{}; foreach ($f in $newFam) { $famSet["$f"] = $true }
        $gone = @(); $renamed = @()
        foreach ($f in $oldFam) {
            if ($famSet.ContainsKey($f)) { continue }
            $alt = $null
            if ($f -like 'wmi_*') { $alt = 'windows_' + $f.Substring(4) }
            if ($alt -and $famSet.ContainsKey($alt)) { $renamed += [pscustomobject]@{ Old = $f; New = $alt } }
            else { $gone += $f }
        }
        Add-FosKV 'Renamed wmi_ -> windows_' $renamed.Count
        Add-FosKV 'GONE with no counterpart' $gone.Count
        if ($renamed.Count) {
            Add-FosLine ''
            Add-FosLine '  Renamed - safe only if every dashboard query asks for both names:'
            foreach ($r in @($renamed | Select-Object -First 25)) { Add-FosLine ("    {0,-46} -> {1}" -f $r.Old, $r.New) }
            if ($renamed.Count -gt 25) { Add-FosLine ("    ... and $($renamed.Count - 25) more (full list in the manifest)") }
            Add-Fix warn 'dashboards' "$($renamed.Count) metric families were renamed wmi_* -> windows_*" 'The gold dashboards already query (wmi_x or windows_x). Anything NOT built from that library needs the same treatment or it goes blank.' }
        if ($gone.Count) {
            Add-FosLine ''
            Add-FosLine '  GONE - no windows_ counterpart exists. Any panel or alert querying these is now blank:'
            foreach ($f in @($gone | Select-Object -First 40)) { Add-FosLine "    $f" }
            if ($gone.Count -gt 40) { Add-FosLine ("    ... and $($gone.Count - 40) more") }
            Add-Fix blocker 'dashboards' "$($gone.Count) metric families exist on the old server and have no equivalent on the new one" 'Search the dashboard JSON and the alert rules for each name. Some were deliberately removed by the exporter (service_status, the cs_* family); those panels need rebuilding against the replacement metric.' }
    } elseif ($OldM.prometheus.metricFamilies -or $NewM.prometheus.metricFamilies) {
        Add-FosFinding -Severity info -Area 'prometheus' -Problem 'metric family lists were captured on only one side' -Fix 'Re-run the capture with -PrometheusUrl on both servers to get this comparison'
    }
}

# ------------------------------------------------------------------ verdict
Add-FosSub 'VERDICT'
$b = @($script:Fix | Where-Object { $_.Severity -eq 'blocker' })
$w = @($script:Fix | Where-Object { $_.Severity -eq 'warn' })
if (-not $b.Count) {
    Add-FosLine '  GO - nothing the old server had is missing on the new one.'
    if ($w.Count) { Add-FosLine "  ($($w.Count) warnings below - read them, none of them stop you.)" }
} else {
    Add-FosLine ("  NO-GO - {0} blocker(s) and {1} warning(s)." -f $b.Count, $w.Count)
}
Add-FosLine ''
Add-FosLine '  Numbered remediation list - the command is next to each item where there is one:'
$n = 0
foreach ($f in @($b + $w)) {
    $n++
    Add-FosLine ''
    Add-FosLine ("  {0,2}. [{1}] [{2}] {3}" -f $n, $f.Severity.ToUpper(), $f.Area, (Get-FosMask $f.What))
    if ($f.Command) { foreach ($l in ("$($f.Command)" -split "`n")) { Add-FosLine ("      {0}" -f (Get-FosMask $l.Trim())) } }
}
if (-not $n) { Add-FosLine '  (nothing to do)' }

Add-FosHead 'END OF COMPARISON'
Add-FosLine "  OLD manifest: $oldManifestPath"
Add-FosLine "  NEW manifest: $newManifestPath"
Add-FosLine '  Paste this whole report back to continue.'

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$null = Write-FosReport -Path (Join-Path $OutputRoot "COMPARE-$($OldM.host)-to-$($NewM.host)-$stamp.txt")
