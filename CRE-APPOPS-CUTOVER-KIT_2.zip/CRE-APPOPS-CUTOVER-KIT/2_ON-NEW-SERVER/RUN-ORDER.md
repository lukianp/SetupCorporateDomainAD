# ON THE NEW SERVER

Run from an ELEVATED PowerShell, in this folder, in this order.

Steps 6 through 12 are DRY RUN until you add `-Apply`. Read the report, then re-run with `-Apply`.

## Before step 5: build the box

Same drive letters, same paths. `D:\Win\Apps\`, `D:\Win\Ops\`. Do NOT reinstate SMB1 or PowerShell v2.
Install Grafana and Prometheus at the versions the old server's capture recorded.

| # | Run this | What it does | Gate |
|---|---|---|---|
| 5 | `.\5_Invoke-ServerCapture.ps1 -OldServer SRVCRE1APPOPS01 -GrafanaApiKey <token>` | Same baseline, this server. -OldServer flags every file and datasource that still names the old box | |
| 6 | `.\6_Compare-ServerBaseline.ps1 -Old <old manifest.json> -New <new manifest.json>` | Everything the old server had that this one does not, with the fix command per item | **must return GO** |
| 7 | `.\7_Repair-MonitoringHost.ps1 -Apply` | Installs and starts the exporter, creates the textfile directory, grants batch-logon and the directory ACL | |
| 8 | `.\8_Import-PrometheusConfig.ps1 -CaptureFolder C:\Migration\promcapture-... -AddRenameBridge` | Places prometheus.yml and every target and rule file | |
| | **then start Prometheus and write down the time** | The parallel run begins here | |
| 9 | `.\9_Import-GrafanaContent.ps1` | Dashboards, folders, datasources, alert rules | |
| 10 | `.\10_Import-CrossEnvTasks.ps1 ... -TaskSuffix '' -PromSuffix ''` | Registers the scheduled tasks, DISABLED, with paths re-pointed | |
| 11 | `.\11_Test-MonitoringHost.ps1 -CaptureFolder <old capture>` | Runtime acceptance: pairs task events for real durations, diffs `.prom` output against the old baseline | |
| 12 | `.\12_Test-PromFiles.ps1` | Validates this server's `.prom` output | |
| 13 | `.\13_Test-CutoverGate.ps1 -OldUrl http://SRVCRE1APPOPS01:9090 -NewUrl http://localhost:9090` | **THE GATE.** Targets, metric families and canary values, old against new | **must return GO before the DNS repoint** |

## Step 8 needs a hand edit

The script will NOT rewrite the YAML. PowerShell has no dependable YAML parser and text surgery on
YAML produces files that load and mean something different. It prints the `metric_relabel_configs`
block and tells you where it goes. Add it under each windows_exporter scrape job by hand, then let
Prometheus validate it by refusing to start:

```powershell
Restart-Service <prometheus service>
Start-Sleep 10
Invoke-WebRequest http://localhost:9090/-/healthy -UseBasicParsing
```

Without that block, every dashboard querying `wmi_*` goes blank.

## Step 10: copy the script trees first

```powershell
robocopy \\SRVCRE1APPOPS01\D$\Win\Ops D:\Win\_CRE-source /E /COPY:DAT /R:1 /W:1 /NFL /NDL
```

`/COPY:DAT`, never `/COPYALL` and never `/SEC`. Source ACLs bring across entries naming the old
server's local groups and that environment's SIDs. They arrive as unresolved SIDs and can lock the
service account out of its own folder.

Then, and note both suffixes are blank because this is a straight lift onto a host with no competing
task set:

```powershell
.\10_Import-CrossEnvTasks.ps1 -TasksFolder C:\Migration\capture-SRVCRE1APPOPS01-<stamp>\tasks `
    -SourceEnv CRE -TaskSuffix '' -PromSuffix '' `
    -ScriptsRoot 'D:\Win\Ops' -StagingRoot 'D:\Win\_CRE-source' `
    -SourceHost SRVCRE1APPOPS01
```

Everything registers DISABLED. Enable one task at a time.

## Judge tasks on output, never on state

Several feeders on this estate are long running loops by design. They sit at `Running` for ever and
log a Task Scheduler event 322 every five minutes while working correctly. A task at `Running` with
fresh `.prom` output is healthy. A task at `Running` with stale output is not. Step 11 carries the
old server's verdict forward so a healthy long runner is not misdiagnosed here.

## Step 13 is the only thing that decides the cutover

Run it during the parallel run, and AGAIN immediately before the DNS repoint. A firewall rule or a
target file can change between the decision and the window.

A target up on old and down on new is almost always the inbound 9182 rule on that host still naming
the old Prometheus IP. Fix the firewall, not the config.

Head series is EXPECTED to differ during a parallel run because the new TSDB is younger. The script
says so rather than failing you for it.

## Note on steps 8 and 13

`_Migrate-PrometheusConfig.ps1` is the engine for both. They are wrappers that call it with
`-Mode Import` and `-Mode Compare`. Do not delete it.
