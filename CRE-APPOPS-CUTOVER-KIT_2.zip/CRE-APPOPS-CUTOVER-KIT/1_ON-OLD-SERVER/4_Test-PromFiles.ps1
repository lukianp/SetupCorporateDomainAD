<#
.SYNOPSIS
    Validates .prom textfile-collector files against the Prometheus text exposition format, the way
    windows_exporter 0.31.x will read them - BEFORE the new exporter ever sees them.

.DESCRIPTION
    Read-only. Run it on the OLD server against the live textfile directory (or on any machine
    against a copy of the files). It reports, per file, exactly what the new exporter would object
    to, and WHY, so the fix can be made in the feeder script that writes the file.

    Why this exists: wmi_exporter 0.4.3 was forgiving. windows_exporter 0.31.x validates each file
    with the standard Prometheus text parser; a file with a problem is rejected WHOLE (that file's
    metrics vanish, windows_textfile_scrape_error goes to 1) - while every service still shows
    green. This script finds that before cutover instead of after.

    Checks (in the order the exporter would trip on them):
      1. Extension is .prom (anything else is silently ignored - not an error, just invisible)
      2. Encoding: no UTF-8/UTF-16 BOM  <-- THE classic Windows/PowerShell failure. Out-File writes
         a BOM by default (UTF-16 in Windows PowerShell 5.1!). A BOM makes the first line unparseable.
      3. Line endings: LF or CRLF both parse; a bare CR does not. Reported for information.
      4. Last line ends with a newline (documented hard requirement)
      5. Every non-blank, non-comment line parses as: name{labels} value [timestamp]
      6. Metric names match  [a-zA-Z_:][a-zA-Z0-9_:]*
      7. Label names match   [a-zA-Z_][a-zA-Z0-9_]*   and are not __reserved__
      8. Label values are double-quoted, with \ " and newline escaped
      9. Values parse as float / NaN / +Inf / -Inf; timestamps as int64 ms
     10. # TYPE lines: valid type; at most one per metric; before that metric's first sample
     11. # HELP lines: at most one per metric
     12. A metric's samples grouped together (WARNING only - reference parser tolerates interleaving)
     13. No duplicate metric+labelset within a file (undefined behaviour)
     14. Same metric name across two files -> flagged (allowed but usually a mistake)
     15. Staleness: file mtime older than -StaleDays (its producer may already be dead)

.PARAMETER Path
    Directory (default: D:\Win\Ops\WMITextfileExport) or a single .prom file.

.PARAMETER StaleDays
    Flag files not modified in this many days (default 7).

    Severity calibration was verified against the reference Go parser (promtool check metrics,
    Prometheus 3.5): every 'error' here is a real parse rejection there.

.EXAMPLE
    .\Test-PromFiles.ps1
    .\Test-PromFiles.ps1 -Path D:\Win\Ops\WMITextfileExport -Verbose
    .\Test-PromFiles.ps1 -Path C:\temp\copied-prom-files
#>
[CmdletBinding()]
param(
    [string]$Path,
    [int]$StaleDays = 7,
    [int]$LargeFileKB = 1024
)

$ErrorActionPreference = 'Continue'
$ScriptVersion = '1.1'

# ---- where does the exporter actually read from? Resolve it from the service definition when no
# -Path is given, so the check runs against the live directory and not an assumed one.
$resolvedFrom = 'parameter'
if (-not $Path) {
    $Path = 'D:\Win\Ops\WMITextfileExport'; $resolvedFrom = 'default (no exporter service found)'
    try {
        $esvc = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(?i)exporter' -or $_.PathName -match '(?i)(windows|wmi)_exporter' }) | Select-Object -First 1
        if ($esvc) {
            $cmd = "$($esvc.PathName)"
            if ($cmd -match '(?i)nssm') {
                $rk = "HKLM:\SYSTEM\CurrentControlSet\Services\$($esvc.Name)\Parameters"
                $rp = Get-ItemProperty -Path $rk -ErrorAction SilentlyContinue
                if ($rp -and $rp.Application) { $cmd = "`"$($rp.Application)`" $($rp.AppParameters)" }
            }
            $dirFromFlag = ''
            if ($cmd -match '--collector\.textfile\.director(?:y|ies)[= ]\s*"([^"]+)"|--collector\.textfile\.director(?:y|ies)[= ]\s*([^\s"]+)') { $dirFromFlag = "$($Matches[1])$($Matches[2])" }
            $cfgFile = ''
            if ($cmd -match '--config\.file[= ]\s*"([^"]+)"|--config\.file[= ]\s*([^\s"]+)') { $cfgFile = "$($Matches[1])$($Matches[2])" }
            if ($cfgFile -and (Test-Path -LiteralPath $cfgFile)) {
                $ct = Get-Content -LiteralPath $cfgFile -Raw
                if ($ct -match '(?ms)^[ \t]*directories:[ \t]*\r?\n(?:[ \t]*-[ \t]*(\S[^\r\n]*)\r?\n?)') { $dirFromFlag = $Matches[1].Trim().Trim('"', "'") }
                elseif ($ct -match '(?m)^[ \t]*directories:[ \t]*(\S[^\r\n]*)$') { $dirFromFlag = $Matches[1].Trim().Trim('"', "'") }
                elseif ($ct -match '(?m)^[ \t]*directory:[ \t]*(\S[^\r\n]*)$') { $dirFromFlag = $Matches[1].Trim().Trim('"', "'") }
            }
            if ($dirFromFlag) { $Path = ($dirFromFlag -split ',')[0].Trim(); $resolvedFrom = "exporter service '$($esvc.Name)'" }
            else { $resolvedFrom = "default (service '$($esvc.Name)' found but no textfile directory in its flags or config)" }
        }
    } catch {}
}
Write-Host "Test-PromFiles $ScriptVersion  path: $Path  (from $resolvedFrom)" -ForegroundColor Cyan
$nameRx  = '^[a-zA-Z_:][a-zA-Z0-9_:]*$'
$labelRx = '^[a-zA-Z_][a-zA-Z0-9_]*$'
$types   = @('counter','gauge','histogram','summary','untyped')

function New-Finding { param($File,$Line,$Sev,$Msg,$Fix)
    [pscustomobject]@{ File = $File; Line = $Line; Severity = $Sev; Problem = $Msg; Fix = $Fix } }

# ---- parse one sample line:  name{label="v",...} value [timestamp]
function Parse-SampleLine { param($LineText)
    $r = [ordered]@{ ok = $false; name = $null; labels = @{}; labelKey = ''; value = $null; ts = $null; err = $null }
    $t = $LineText.Trim()
    # metric name
    $m = [regex]::Match($t, '^([a-zA-Z_:][a-zA-Z0-9_:]*)\s*')
    if (-not $m.Success) { $r.err = 'metric name is missing or contains characters outside [a-zA-Z0-9_:]'; return $r }
    $r.name = $m.Groups[1].Value; $rest = $t.Substring($m.Length)
    # labels
    if ($rest.StartsWith('{')) {
        $close = -1; $inQ = $false; $esc = $false
        for ($i = 1; $i -lt $rest.Length; $i++) {
            $c = $rest[$i]
            if ($esc) { $esc = $false; continue }
            if ($c -eq '\') { $esc = $true; continue }
            if ($c -eq '"') { $inQ = -not $inQ; continue }
            if ($c -eq '}' -and -not $inQ) { $close = $i; break } }
        if ($close -lt 0) { $r.err = 'label block opened with { but never closed (or an unescaped " inside a label value)'; return $r }
        $inner = $rest.Substring(1, $close - 1).Trim()
        $rest = $rest.Substring($close + 1)
        if ($inner) {
            # split on commas outside quotes
            $parts = @(); $cur = ''; $inQ = $false; $esc = $false
            foreach ($ch in $inner.ToCharArray()) {
                if ($esc) { $cur += $ch; $esc = $false; continue }
                if ($ch -eq '\') { $cur += $ch; $esc = $true; continue }
                if ($ch -eq '"') { $inQ = -not $inQ }
                if ($ch -eq ',' -and -not $inQ) { $parts += $cur; $cur = ''; continue }
                $cur += $ch }
            if ($cur.Trim()) { $parts += $cur }
            foreach ($p in $parts) {
                $lm = [regex]::Match($p.Trim(), '^([^=\s]+)\s*=\s*"((?:[^"\\]|\\.)*)"$')
                if (-not $lm.Success) {
                    if ($p -match '=\s*[^"\s]') { $r.err = "label value not double-quoted: $($p.Trim())"; return $r }
                    $r.err = "malformed label pair: $($p.Trim())"; return $r }
                $ln = $lm.Groups[1].Value; $lv = $lm.Groups[2].Value
                if ($ln -notmatch $labelRx) { $r.err = "label name '$ln' contains invalid characters (allowed [a-zA-Z0-9_], not starting with a digit)"; return $r }
                if ($ln -like '__*') { $r.err = "label name '$ln' uses the reserved __ prefix"; return $r }
                if ($lv -match '(?<!\\)(?:\\\\)*"' ) { $r.err = "unescaped double-quote inside label value for '$ln'"; return $r }
                if ($lv -match '[\r\n]') { $r.err = "raw newline inside label value for '$ln' (must be \n escaped)"; return $r }
                if ($r.labels.ContainsKey($ln)) { $r.err = "label '$ln' appears twice"; return $r }
                $r.labels[$ln] = $lv } } }
    # value [timestamp]
    $vt = $rest.Trim() -split '\s+'
    if (-not $vt[0]) { $r.err = 'no value after the metric name/labels'; return $r }
    $v = $vt[0]
    if ($v -notin @('NaN','+Inf','-Inf','Inf')) {
        $d = 0.0
        if (-not [double]::TryParse($v, [Globalization.NumberStyles]::Float, [Globalization.CultureInfo]::InvariantCulture, [ref]$d)) {
            $hint = ''
            if ($v -match ',') { $hint = ' - looks like a locale decimal comma; the format requires a dot' }
            if ($v -match '^[0-9\.]+[A-Za-z%]+$') { $hint = ' - units/percent signs are not allowed in the value' }
            $r.err = "value '$v' is not a valid float$hint"; return $r } }
    $r.value = $v
    if ($vt.Count -ge 2) {
        $l = 0L
        if (-not [long]::TryParse($vt[1], [ref]$l)) { $r.err = "timestamp '$($vt[1])' is not an int64 (milliseconds since epoch)"; return $r }
        if ($vt[1].Length -le 10 -and $l -gt 0) { $r.err = "timestamp '$($vt[1])' looks like SECONDS; the format requires MILLISECONDS"; return $r }
        $r.ts = $l }
    if ($vt.Count -gt 2) { $r.err = "unexpected trailing tokens after value/timestamp: $($vt[2..($vt.Count-1)] -join ' ')"; return $r }
    $r.labelKey = (($r.labels.Keys | Sort-Object | ForEach-Object { "$_=$($r.labels[$_])" }) -join ',')
    $r.ok = $true
    return $r }

# ---- collect files
$files = @()
if (Test-Path -LiteralPath $Path -PathType Leaf) { $files = @(Get-Item -LiteralPath $Path) }
elseif (Test-Path -LiteralPath $Path -PathType Container) {
    $files = @(Get-ChildItem -LiteralPath $Path -File | Where-Object { $_.Extension -in @('.prom','.txt','.metrics','') -or $_.Name -like '*.prom*' }) }
else { Write-Error "Path not found: $Path"; exit 2 }

$findings = New-Object System.Collections.ArrayList
$metricOwners = @{}   # metric name -> list of files (cross-file duplicate check)
$summary = @()
$fileMetrics = @{}    # file -> distinct metric names, so the reviewer sees what each file feeds

# ---- the directory itself: size, count, who can write. The exporter reads every file on every
# scrape, so an 80 MB relic from 2019 costs CPU each 15 seconds and is served as if current.
if (Test-Path -LiteralPath $Path -PathType Container) {
    $allFiles = @(Get-ChildItem -LiteralPath $Path -File -ErrorAction SilentlyContinue)
    $totalKB = [math]::Round((($allFiles | Measure-Object -Property Length -Sum).Sum) / 1KB, 0)
    Write-Host ("  directory: {0} file(s), {1} KB total" -f $allFiles.Count, $totalKB)
    foreach ($bf in @($allFiles | Where-Object { $_.Length -gt ($LargeFileKB * 1KB) })) {
        [void]$findings.Add((New-Finding $bf.Name 0 'warning' "file is $([math]::Round($bf.Length / 1MB, 1)) MB - the exporter parses it in full on EVERY scrape; a file this size is either a log written to the wrong folder or a producer that never truncates" 'find the producer; a textfile should be a few KB of current values, not history'))
    }
    if ($allFiles.Count -gt 50) { [void]$findings.Add((New-Finding $Path 0 'warning' "$($allFiles.Count) files in the textfile directory" 'each is parsed every scrape; retire dead producers')) }
    try {
        $acl = Get-Acl -LiteralPath $Path
        $writers = @($acl.Access | Where-Object { $_.AccessControlType -eq 'Allow' -and "$($_.FileSystemRights)" -match 'Write|Modify|FullControl' } | ForEach-Object { "$($_.IdentityReference)" } | Sort-Object -Unique)
        Write-Host ("  can write here: {0}" -f ($writers -join ', '))
        Write-Host '  (every task account that produces a .prom file must be in that list, and the exporter service account must be able to read)'
    } catch {}
}

foreach ($f in $files) {
    $rel = $f.Name
    $status = 'OK'
    $metricsInFile = 0
    # 1. extension
    if ($f.Extension -ne '.prom') {
        [void]$findings.Add((New-Finding $rel 0 'ignored' "extension is '$($f.Extension)' - windows_exporter reads ONLY *.prom; this file is invisible to it (no error, just missing)" 'rename to .prom, or confirm it is intentionally not exported'))
        $status = 'IGNORED'
        $summary += [pscustomobject]@{ File = $rel; Status = $status; Metrics = 0; SizeKB = [math]::Round($f.Length/1KB,1); Modified = $f.LastWriteTime; StaleDays = [int]((Get-Date) - $f.LastWriteTime).TotalDays }
        continue }
    # 15. staleness
    $stale = [int]((Get-Date) - $f.LastWriteTime).TotalDays
    if ($stale -gt $StaleDays) {
        [void]$findings.Add((New-Finding $rel 0 'warning' "last written $stale days ago - the task that produces this file may already be broken; the new exporter will serve stale numbers as if current" 'fix or retire the producer before migrating; do not carry a dead file')) }
    # 2. BOM
    $bytes = [IO.File]::ReadAllBytes($f.FullName)
    if ($bytes.Length -ge 3 -and $bytes[0] -eq 0xEF -and $bytes[1] -eq 0xBB -and $bytes[2] -eq 0xBF) {
        [void]$findings.Add((New-Finding $rel 1 'error' 'file starts with a UTF-8 BOM (EF BB BF) - the first line will fail to parse and the WHOLE FILE is rejected' 'in the writing script use [IO.File]::WriteAllText($p,$s,(New-Object Text.UTF8Encoding($false))) or Out-File -Encoding utf8NoBOM (PS7) / -Encoding ascii (PS5.1)'))
        $status = 'FAIL' }
    elseif ($bytes.Length -ge 2 -and (($bytes[0] -eq 0xFF -and $bytes[1] -eq 0xFE) -or ($bytes[0] -eq 0xFE -and $bytes[1] -eq 0xFF))) {
        [void]$findings.Add((New-Finding $rel 1 'error' 'file is UTF-16 (FF FE / FE FF BOM) - this is what Windows PowerShell 5.1 Out-File writes BY DEFAULT; the exporter cannot parse it at all' 'in the writing script use Out-File -Encoding ascii, or [IO.File]::WriteAllText with UTF8Encoding($false)'))
        $status = 'FAIL'
        $summary += [pscustomobject]@{ File = $rel; Status = $status; Metrics = 0; SizeKB = [math]::Round($f.Length/1KB,1); Modified = $f.LastWriteTime; StaleDays = $stale }
        continue }
    $text = [Text.Encoding]::UTF8.GetString($bytes)
    if ($text.Length -and $text[0] -eq [char]0xFEFF) { $text = $text.Substring(1) }
    # 3. line endings
    $crlf = ([regex]::Matches($text, "`r`n")).Count; $bareCr = ([regex]::Matches($text, "`r(?!`n)")).Count
    if ($bareCr) { [void]$findings.Add((New-Finding $rel 0 'error' "$bareCr bare CR line ending(s) (old-Mac style) - not a line separator to the parser" 'write with `n or `r`n')); $status = 'FAIL' }
    # 4. trailing newline
    if ($text.Length -and -not $text.EndsWith("`n")) {
        [void]$findings.Add((New-Finding $rel 0 'error' 'last line does not end with a newline - documented hard requirement of the textfile collector' 'append "`n" after the last metric line in the writing script'))
        $status = 'FAIL' }
    if (-not $text.Trim()) {
        [void]$findings.Add((New-Finding $rel 0 'warning' 'file is empty - harmless, but its producer wrote nothing' 'check the producer'))
        $summary += [pscustomobject]@{ File = $rel; Status = 'EMPTY'; Metrics = 0; SizeKB = 0; Modified = $f.LastWriteTime; StaleDays = $stale }
        continue }
    # 5-13. line by line
    $lines = $text -split "`r?`n"
    $typeSeen = @{}; $helpSeen = @{}; $firstSample = @{}; $lastMetric = $null; $closedMetrics = @{}; $seenSeries = @{}; $interleaveNoted = $false
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $ln = $lines[$i]; $n = $i + 1
        if (-not $ln.Trim()) { continue }
        if ($ln.TrimStart().StartsWith('#')) {
            $c = $ln.Trim()
            if ($c -match '^#\s*TYPE\s+(\S+)\s+(\S+)\s*$') {
                $mn = $Matches[1]; $ty = $Matches[2].ToLower()
                if ($mn -notmatch $nameRx) { [void]$findings.Add((New-Finding $rel $n 'error' "# TYPE names an invalid metric '$mn'" 'fix the name')); $status = 'FAIL' }
                if ($ty -notin $types) { [void]$findings.Add((New-Finding $rel $n 'error' "# TYPE '$ty' is not one of counter|gauge|histogram|summary|untyped" 'use gauge for point-in-time values, counter for monotonic totals')); $status = 'FAIL' }
                if ($typeSeen.ContainsKey($mn)) { [void]$findings.Add((New-Finding $rel $n 'error' "second # TYPE line for '$mn' (only one allowed)" 'emit TYPE once per metric')); $status = 'FAIL' }
                if ($firstSample.ContainsKey($mn)) { [void]$findings.Add((New-Finding $rel $n 'error' "# TYPE for '$mn' appears AFTER its first sample (line $($firstSample[$mn])) - TYPE must come first" 'move HELP/TYPE above the samples')); $status = 'FAIL' }
                $typeSeen[$mn] = $ty; continue }
            if ($c -match '^#\s*HELP\s+(\S+)\s*(.*)$') {
                $mn = $Matches[1]
                if ($helpSeen.ContainsKey($mn)) { [void]$findings.Add((New-Finding $rel $n 'error' "second # HELP line for '$mn' (only one allowed)" 'emit HELP once per metric')); $status = 'FAIL' }
                $helpSeen[$mn] = $true; continue }
            if ($c -match '^#\s*(TYPE|HELP)\b') { [void]$findings.Add((New-Finding $rel $n 'error' "malformed $($Matches[1]) line: $c" 'format is: # TYPE <name> <type>  /  # HELP <name> <text>')); $status = 'FAIL' }
            continue }   # plain comment
        $p = Parse-SampleLine $ln
        if (-not $p.ok) {
            $shown = $ln.Trim(); if ($shown.Length -gt 120) { $shown = $shown.Substring(0, 120) + "... ($($ln.Length) chars)" }
            [void]$findings.Add((New-Finding $rel $n 'error' "$($p.err)  |  $shown" 'fix the writing script; the whole file is rejected while this line is present'))
            $status = 'FAIL'; continue }
        $metricsInFile++
        if (-not $fileMetrics.ContainsKey($rel)) { $fileMetrics[$rel] = New-Object System.Collections.ArrayList }
        if ($fileMetrics[$rel] -notcontains $p.name) { [void]$fileMetrics[$rel].Add($p.name) }
        if (-not $firstSample.ContainsKey($p.name)) { $firstSample[$p.name] = $n }
        # 12. grouping
        if ($lastMetric -and $lastMetric -ne $p.name) { $closedMetrics[$lastMetric] = $true }
        # Interleaving violates the spec text but the reference Go parser (the one windows_exporter
        # uses - verified with promtool check metrics) tolerates it: it re-attaches samples to the
        # existing metric family. So: warning, not rejection. Report once per file, not per line.
        if ($closedMetrics.ContainsKey($p.name) -and $lastMetric -ne $p.name -and -not $interleaveNoted) {
            [void]$findings.Add((New-Finding $rel $n 'warning' "samples for '$($p.name)' (and possibly others) are interleaved with other metrics - spec says one contiguous group per metric; the parser windows_exporter uses tolerates it, so the file is NOT rejected. Only becomes an error if a # TYPE line follows a sample." 'optional tidy-up: emit each metric''s lines together'))
            $interleaveNoted = $true }
        $lastMetric = $p.name
        # 13. duplicate series
        $sk = "$($p.name)|$($p.labelKey)"
        if ($seenSeries.ContainsKey($sk)) { [void]$findings.Add((New-Finding $rel $n 'error' "duplicate series: $($p.name){$($p.labelKey)} already at line $($seenSeries[$sk]) - the text parser accepts it but windows_exporter's textfile collector runs its own duplicate check and rejects the file" 'deduplicate, or add a distinguishing label')); $status = 'FAIL' }
        else { $seenSeries[$sk] = $n }
        # 14. cross-file registry
        if (-not $metricOwners.ContainsKey($p.name)) { $metricOwners[$p.name] = New-Object System.Collections.ArrayList }
        if ($metricOwners[$p.name] -notcontains $rel) { [void]$metricOwners[$p.name].Add($rel) }
        # advisory: TYPE missing
        if (-not $typeSeen.ContainsKey($p.name) -and $firstSample[$p.name] -eq $n) {
            [void]$findings.Add((New-Finding $rel $n 'info' "no # TYPE for '$($p.name)' - accepted (untyped) but Grafana/PromQL rate() etc. behave better with an explicit type" 'add "# TYPE <name> gauge|counter" above the samples')) }
    }
    if ($crlf -and $status -eq 'OK') { [void]$findings.Add((New-Finding $rel 0 'info' "uses CRLF line endings ($crlf) - parses fine; LF is conventional" 'no action needed')) }
    $summary += [pscustomobject]@{ File = $rel; Status = $status; Metrics = $metricsInFile; SizeKB = [math]::Round($f.Length/1KB,1); Modified = $f.LastWriteTime; StaleDays = $stale }
}
# 14. cross-file duplicates
foreach ($mn in $metricOwners.Keys) {
    if ($metricOwners[$mn].Count -gt 1) {
        [void]$findings.Add((New-Finding ($metricOwners[$mn] -join ' + ') 0 'warning' "metric '$mn' is written by more than one file - allowed, but the series must not collide (same labels in two files = undefined)" 'confirm the two producers emit distinct label sets, or consolidate')) }
}

# ---- report
""
"Textfile-collector readiness for windows_exporter 0.31.x  -  $Path"
"=" * 78
$summary | Format-Table File, Status, Metrics, SizeKB, StaleDays, Modified -AutoSize | Out-String -Width 200 | Write-Host
"What each file feeds (distinct metric families, first 6):"
foreach ($fk in ($fileMetrics.Keys | Sort-Object)) { "  {0,-40} {1,4} families: {2}{3}" -f $fk, $fileMetrics[$fk].Count, (@($fileMetrics[$fk] | Select-Object -First 6) -join ', '), $(if ($fileMetrics[$fk].Count -gt 6) { ' ...' }) }
"" 
$errs = @($findings | Where-Object Severity -eq 'error'); $warns = @($findings | Where-Object Severity -eq 'warning'); $ign = @($findings | Where-Object Severity -eq 'ignored')
if ($findings.Count) {
    "Findings ($($errs.Count) error, $($warns.Count) warning, $(@($findings | Where-Object Severity -eq 'info').Count) info):"
    $findings | Sort-Object @{e={ @{error=0;ignored=1;warning=2;info=3}[$_.Severity] }}, File, Line |
        Format-Table Severity, File, Line, Problem, Fix -Wrap -AutoSize | Out-String -Width 220 | Write-Host }
$failFiles = @($summary | Where-Object Status -eq 'FAIL')
if ($failFiles.Count) {
    Write-Host "RESULT: $($failFiles.Count) file(s) would be REJECTED WHOLE by windows_exporter 0.31.x - their metrics vanish from dashboards while every service shows green. Fix the producer scripts before cutover." -ForegroundColor Red
    exit 1 }
elseif ($ign.Count) { Write-Host "RESULT: no parse errors, but $($ign.Count) file(s) have the wrong extension and will be silently ignored." -ForegroundColor Yellow; exit 0 }
else { Write-Host "RESULT: every .prom file parses cleanly - safe for windows_exporter 0.31.x." -ForegroundColor Green; exit 0 }
