<#
.SYNOPSIS
  Captures everything about a Windows server that a migration has to reproduce, and writes it as a
  machine-readable manifest plus one pasteable text report. Read-only.

.DESCRIPTION
  Run it on the OLD server, run it again on the NEW one, then feed both manifests to
  Compare-ServerBaseline.ps1. That pair answers the only question that matters on a lift:
  "is everything running exactly where it was".

  The point of the capture is the stuff nobody wrote down - the local state a server accumulates
  over ten years and that a fresh build has never heard of:

    * user rights assignments (all of them, not just the one you already know about)
    * LSA / SMB / Schannel / .NET TLS posture - a 2012 box trusts protocols a 2025 box has removed
    * the WinINET proxy of the SERVICE ACCOUNT, not just WinHTTP - scripts using Invoke-WebRequest
      read the calling user's proxy, and a missing one is an outbound call that hangs, not fails
    * firewall rules somebody added by hand, and whether anything is listening without one
    * service log-on accounts, recovery actions and delayed start
    * scheduled tasks with their XML, their accounts, and - importantly - whether a task is
      NORMALLY long-running on this server, so the new box is not misdiagnosed
    * installed software with the Windows noise filtered out
    * the app trees themselves: config files, hardcoded hostnames, UNC paths, credential handling

  Role add-ons detect themselves:
    APPMON  windows_exporter / wmi_exporter: service, version, config, textfile directory and its
            ACL, the .prom files and their freshness, and a live scrape.
    APPOPS  Grafana: effective config from defaults.ini + custom.ini, the port it is ACTUALLY
            listening on versus the one configured, database, plugins, provisioning, and - via the
            API when credentials are supplied - dashboards, datasources and alert rules.
            Prometheus: config, scrape jobs, every file_sd target with its labels, retention, TSDB
            size, target health, and the full list of metric family names. That last one is what
            tells you which metrics the dashboards will lose when the exporter is upgraded.

  v2.0 additions, all driven by what the first SRVCRE1APPOPS01 run missed:
    * domain role check first: a box with AD DS installed is not a monitoring server until proven
    * NSSM services read from the registry (binary, flags, working directory, stdout/stderr logs,
      environment, restart policy); v1.0 reported the NSSM banner as the Grafana version
    * Grafana: edition (OSS or Enterprise), licence file decoded for licensed URL and expiry,
      custom.ini captured verbatim with secrets masked, grafana.db size and last write (Route B
      viability), plugins with versions, auth and SMTP and Azure settings, image renderer
    * Prometheus: effective flags from the API, version from prometheus_build_info, TSDB block
      range (oldest sample on disk), WAL size, every DOWN target classified as placeholder / DNS /
      refused / timeout, alertmanager and remote_write presence
    * who depends on this box: established connections to the Grafana and Prometheus ports with
      reverse DNS, so the consumer list is evidence rather than memory
    * Azure: IMDS reachability with the proxy bypassed, VM identity, and whether a managed identity
      token can be obtained and which client id answered
    * proxy as Go programs see it: HTTP_PROXY / HTTPS_PROXY / NO_PROXY from machine environment and
      from the NSSM service environment, not just WinHTTP
    * certificates with their bindings (HTTP.sys, IIS, Grafana cert_file)
    * scheduled tasks: batch logon right three state check per account, personal account flag
    * Octopus Tentacle presence and what it deployed here
    * service and NSSM event log errors for the last 7 days
    * -GrafanaUrl and -PrometheusUrl auto detected from the listening ports when not supplied

.PARAMETER Role         Auto (default), Appmon, Appops, Generic. Auto detects by installed services.
.PARAMETER AppRoots     Application directories to inventory. Default D:\Win\Ops, D:\Win\Apps.
.PARAMETER OldServer    When capturing the NEW box, the old hostname, so references to it are flagged.
.PARAMETER GrafanaUrl   e.g. http://localhost:9091. Auto detected from the listener when omitted.
.PARAMETER GrafanaApiKey / -GrafanaCredential   Either one authenticates the API calls. Without
                        them only /api/health (no auth) is read.
.PARAMETER PrometheusUrl  e.g. http://localhost:9090. Auto detected from the listener when omitted.
.PARAMETER Deep         Hash every file in the app trees (slow, but proves a copy was faithful).
.PARAMETER Sanitize     Mask host, domain, account names and SIDs in the TEXT report (never the manifest).

.EXAMPLE
  .\Invoke-ServerCapture.ps1
  .\Invoke-ServerCapture.ps1 -Role Appops -GrafanaUrl http://localhost:9091 -PrometheusUrl http://localhost:9090
  .\Invoke-ServerCapture.ps1 -OldServer SRVSYS1APPMON01 -Sanitize
#>
[CmdletBinding()]
param(
    [ValidateSet('Auto', 'Appmon', 'Appops', 'Generic')] [string] $Role = 'Auto',
    [string]   $OutputRoot = 'C:\Migration',
    [string[]] $AppRoots   = @('D:\Win\Ops', 'D:\Win\Apps'),
    [string]   $OldServer,
    [string]   $GrafanaUrl,
    [string]   $GrafanaApiKey,
    [pscredential] $GrafanaCredential,
    [string]   $PrometheusUrl,
    [switch]   $Deep,
    [switch]   $SkipTasks,
    [switch]   $Sanitize
)
$ErrorActionPreference = 'Continue'
$SuiteVersion = '2.0'

Import-Module (Join-Path $PSScriptRoot 'FOSMigrate.psm1') -Force -ErrorAction Stop
Assert-FosAdmin
New-FosReport -Sanitize:$Sanitize
foreach ($fn in 'Get-FosNssmParameters', 'Resolve-FosServiceCommand', 'Invoke-FosWebDirect', 'Get-FosFlag', 'Test-FosHoldsRight') {
    if (-not (Get-Command $fn -ErrorAction SilentlyContinue)) { throw "FOSMigrate.psm1 beside this script is too old: it lacks $fn. Use the psm1 shipped with capture $SuiteVersion." }
}

function Resolve-ServiceCommand { param([string]$Name, [string]$PathName) return (Resolve-FosServiceCommand -Name $Name -PathName $PathName) }

function Invoke-Section {
    <# One failed section must not cost the whole capture. The report is still written, with a
       finding that names the section and the error. #>
    param([string]$Name, [scriptblock]$Block)
    try { & $Block }
    catch {
        $msg = "$($_.Exception.Message)"
        $where = ''
        try { $where = " (line $($_.InvocationInfo.ScriptLineNumber))" } catch {}
        Add-FosFinding -Severity warn -Area 'collection' -Problem "section '$Name' failed$where and is incomplete: $(Format-FosTrim $msg 160)"
    }
}

function Get-DirSize {
    param([string]$Dir, [int]$TimeoutSec = 180)
    if (-not $Dir -or -not (Test-Path -LiteralPath $Dir)) { return 0 }
    $v = Invoke-FosTimeout ([scriptblock]::Create("(Get-ChildItem -LiteralPath '$Dir' -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum")) $TimeoutSec 0 "size of $Dir"
    if ($null -eq $v) { return 0 }
    return [double]$v
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$out   = Join-Path $OutputRoot "capture-$env:COMPUTERNAME-$stamp"
New-Item -ItemType Directory -Force -Path $out, (Join-Path $out 'tasks'), (Join-Path $out 'config') | Out-Null

Write-Host ''
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ("  Invoke-ServerCapture {0}   HOST: {1}" -f $SuiteVersion, $env:COMPUTERNAME) -ForegroundColor Cyan
Write-Host '  =========================================================' -ForegroundColor Cyan

$M = [ordered]@{ suiteVersion = $SuiteVersion; capturedAt = (Get-Date).ToString('s'); host = $env:COMPUTERNAME }

# ================================================================= 1. system
Start-FosStep 'system'
$os = Get-CimInstance Win32_OperatingSystem
$cs = Get-CimInstance Win32_ComputerSystem
$bios = Get-CimInstance Win32_BIOS -ErrorAction SilentlyContinue
$M.system = [ordered]@{
    host = $env:COMPUTERNAME; domain = "$($cs.Domain)"; partOfDomain = [bool]$cs.PartOfDomain
    os = "$($os.Caption)"; version = "$($os.Version)"; build = "$($os.BuildNumber)"
    installDate = $(if ($os.InstallDate) { ([datetime]$os.InstallDate).ToString('s') } else { '' })
    lastBoot = $(if ($os.LastBootUpTime) { ([datetime]$os.LastBootUpTime).ToString('s') } else { '' })
    timeZone = (Get-TimeZone -ErrorAction SilentlyContinue).Id
    manufacturer = "$($cs.Manufacturer)"; model = "$($cs.Model)"; serial = "$($bios.SerialNumber)"
    logicalCpus = $cs.NumberOfLogicalProcessors; memoryGB = [math]::Round($cs.TotalPhysicalMemory / 1GB, 1)
    powershell = $PSVersionTable.PSVersion.ToString()
    dotNetRelease = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full' -ErrorAction SilentlyContinue).Release
    executionPolicy = @(Get-ExecutionPolicy -List | ForEach-Object { "$($_.Scope)=$($_.ExecutionPolicy)" }) -join '; '
    pendingReboot = [bool]((Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired') -or
                           (Test-Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\PendingFileRenameOperations'))
    uptimeDays = $(if ($os.LastBootUpTime) { [math]::Round((New-TimeSpan -Start ([datetime]$os.LastBootUpTime) -End (Get-Date)).TotalDays, 1) } else { $null })
}
# Domain role FIRST. 0/1 standalone or member workstation, 2/3 standalone or member server,
# 4 backup DC, 5 primary DC. The first CRE run found AD-Domain-Services installed on the APPOPS box.
# A DC is not migrated with this suite; a box with the feature installed but a member role is.
$roleNames = @{ 0 = 'standalone workstation'; 1 = 'member workstation'; 2 = 'standalone server'; 3 = 'member server'; 4 = 'backup domain controller'; 5 = 'primary domain controller' }
$M.system.domainRole = [int]$cs.DomainRole
$M.system.domainRoleName = "$($roleNames[[int]$cs.DomainRole])"
$M.system.isDomainController = ([int]$cs.DomainRole -ge 4)
$M.system.adDsInstalled = $false
try { $ntds = Get-Service NTDS -ErrorAction SilentlyContinue; if ($ntds) { $M.system.adDsInstalled = $true; $M.system.ntdsState = "$($ntds.Status)" } } catch {}
try { $adf = Get-WindowsFeature AD-Domain-Services -ErrorAction SilentlyContinue; if ($adf -and $adf.Installed) { $M.system.adDsInstalled = $true } } catch {}
if ($M.system.isDomainController) {
    Add-FosFinding -Severity blocker -Area 'system' -Problem "this host is a $($M.system.domainRoleName) (DomainRole=$($M.system.domainRole))" -Fix 'Stop. A domain controller is not migrated with this suite. Confirm with the AD team what this box is before any monitoring work continues.'
} elseif ($M.system.adDsInstalled) {
    Add-FosFinding -Severity warn -Area 'system' -Problem "AD-Domain-Services is installed but DomainRole=$($M.system.domainRole) ($($M.system.domainRoleName)): the feature is present and unused" -Fix 'Do not install it on the replacement. Record it on the change as a difference that is intentional.'
}
if ($M.system.pendingReboot) { Add-FosFinding -Severity info -Area 'system' -Problem 'a reboot is pending on this host' -Fix 'Nothing to do for the capture. Note it: a reboot before decommission may change service state.' }
# OU membership: a server in the wrong OU gets the wrong GPOs, which is how a working local grant
# quietly disappears three hours after the cutover.
$M.system.distinguishedName = Invoke-FosTimeout {
    try { ([adsisearcher]"(&(objectCategory=computer)(name=$env:COMPUTERNAME))").FindOne().Properties['distinguishedname'][0] } catch { '' }
} 45 '' 'AD computer lookup'

if ($Sanitize) {
    Add-FosMask $env:COMPUTERNAME 'THIS-HOST'
    if ($OldServer) { Add-FosMask $OldServer 'OLD-HOST' }
    if ($cs.Domain) { Add-FosMask "$($cs.Domain)" 'DOM.LOCAL'; Add-FosMask (("$($cs.Domain)" -split '\.')[0]) 'DOM' }
}

# ================================================================= 2. storage
Start-FosStep 'storage'
$M.volumes = @(Get-CimInstance Win32_Volume -ErrorAction SilentlyContinue |
    Where-Object { $_.DriveLetter } | ForEach-Object {
        [ordered]@{ letter = $_.DriveLetter; label = "$($_.Label)"; fs = "$($_.FileSystem)"
                    capacityGB = [math]::Round($_.Capacity / 1GB, 1); freeGB = [math]::Round($_.FreeSpace / 1GB, 1)
                    blockSize = $_.BlockSize } })

# ================================================================= 3. network
Start-FosStep 'network'
$M.network = [ordered]@{ adapters = @(); dnsServers = @(); hostsEntries = @(); winHttpProxy = ''; userProxies = @(); shares = @() }
$M.network.adapters = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=TRUE' -ErrorAction SilentlyContinue |
    ForEach-Object {
        [ordered]@{ description = "$($_.Description)"; ip = @($_.IPAddress); mask = @($_.IPSubnet)
                    gateway = @($_.DefaultIPGateway); dns = @($_.DNSServerSearchOrder)
                    dhcp = [bool]$_.DHCPEnabled; suffix = "$($_.DNSDomain)" } })
$M.network.dnsServers = @($M.network.adapters | ForEach-Object { $_.dns } | Where-Object { $_ } | Sort-Object -Unique)
# hosts file: a hardcoded override here is invisible everywhere else and does not migrate
$hosts = "$env:SystemRoot\System32\drivers\etc\hosts"
if (Test-Path $hosts) {
    $M.network.hostsEntries = @(Get-Content $hosts -ErrorAction SilentlyContinue |
        Where-Object { $_ -match '^\s*[0-9a-fA-F]' -and $_ -notmatch '^\s*#' } | ForEach-Object { $_.Trim() })
}
$M.network.winHttpProxy = (Invoke-FosTimeout { (& netsh winhttp show proxy 2>&1 | Out-String).Trim() } 30 '' 'netsh winhttp')
# WinINET proxy per user hive. Invoke-WebRequest uses the CALLING USER's setting, so the service
# account's profile is the one that matters - and it is the one a rebuild never reproduces.
foreach ($h in @(Get-ChildItem 'Registry::HKEY_USERS' -ErrorAction SilentlyContinue | Where-Object { $_.Name -notmatch '_Classes$' })) {
    $k = "Registry::$($h.Name)\Software\Microsoft\Windows\CurrentVersion\Internet Settings"
    $p = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
    if ($p -and ($p.ProxyEnable -or $p.ProxyServer -or $p.AutoConfigURL)) {
        $sid = ($h.Name -split '\\')[-1]
        $who = Resolve-FosPrincipal $sid
        $M.network.userProxies += [ordered]@{ sid = $sid; account = $who; enabled = [int]$p.ProxyEnable
                                              server = "$($p.ProxyServer)"; autoConfig = "$($p.AutoConfigURL)"; bypass = "$($p.ProxyOverride)" }
    }
}
$M.network.shares = @(Get-CimInstance Win32_Share -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -notmatch '^\w\$$|^(ADMIN|IPC)\$$' } |
    ForEach-Object { [ordered]@{ name = $_.Name; path = "$($_.Path)"; description = "$($_.Description)" } })
# WinHTTP bypass list, parsed, and the proxy the way GO PROGRAMS see it. Grafana and Prometheus
# are Go binaries: they ignore WinHTTP and WinINET entirely and read HTTP_PROXY / HTTPS_PROXY /
# NO_PROXY from their own environment. On an Azure VM a Grafana datasource using a managed identity
# calls 169.254.169.254; with HTTPS_PROXY set and no NO_PROXY entry for it, that call goes to the
# corporate proxy and the datasource fails with a message that does not mention the proxy.
$M.network.winHttpProxyServer = ''; $M.network.winHttpBypass = @()
if ($M.network.winHttpProxy -match '(?im)^\s*Proxy Server\(s\)\s*:\s*(.+)$') { $M.network.winHttpProxyServer = $Matches[1].Trim() }
if ($M.network.winHttpProxy -match '(?im)^\s*Bypass List\s*:\s*(.+)$') { $M.network.winHttpBypass = @($Matches[1].Trim() -split '\s*;\s*' | Where-Object { $_ -and $_ -ne '(none)' }) }
$M.network.goProxyEnv = [ordered]@{}
foreach ($n in 'HTTP_PROXY', 'HTTPS_PROXY', 'NO_PROXY', 'http_proxy', 'https_proxy', 'no_proxy') {
    $v = [Environment]::GetEnvironmentVariable($n, 'Machine')
    if ($v) { $M.network.goProxyEnv[$n] = "$v" }
}
$M.network.ipAddresses = @($M.network.adapters | ForEach-Object { @($_.ip) } | Where-Object { $_ -and $_ -notmatch ':' } | Sort-Object -Unique)

# ================================================================= 3b. Azure
Start-FosStep 'Azure instance metadata and managed identity'
$M.azure = [ordered]@{ imdsReachable = $false; vmName = ''; resourceGroup = ''; subscriptionId = ''; vmId = ''; location = ''; vmSize = ''
                       identityToken = 'not attempted'; identityClientId = ''; identityError = ''; imdsError = '' }
Invoke-Section 'azure' {
    $hdr = @{ Metadata = 'true' }
    $im = Invoke-FosWebDirect 'http://169.254.169.254/metadata/instance/compute?api-version=2021-02-01' -Headers $hdr -TimeoutSec 5
    if ($im.ok -and $im.body) {
        $M.azure.imdsReachable = $true
        try {
            $j = $im.body | ConvertFrom-Json
            $M.azure.vmName = "$($j.name)"; $M.azure.resourceGroup = "$($j.resourceGroupName)"; $M.azure.subscriptionId = "$($j.subscriptionId)"
            $M.azure.vmId = "$($j.vmId)"; $M.azure.location = "$($j.location)"; $M.azure.vmSize = "$($j.vmSize)"
            $M.azure.resourceId = "$($j.resourceId)"
        } catch {}
        # A token request answers with the identity that IMDS picks by default: the system assigned
        # identity if there is one, otherwise the single user assigned identity, otherwise an error.
        # client_id in the answer tells you WHICH identity a datasource left on defaults is using.
        $tk = Invoke-FosWebDirect 'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fmanagement.azure.com%2F' -Headers $hdr -TimeoutSec 8
        if ($tk.ok -and $tk.body) {
            try { $tj = $tk.body | ConvertFrom-Json; $M.azure.identityToken = 'obtained'; $M.azure.identityClientId = "$($tj.client_id)"; $M.azure.identityResource = "$($tj.resource)" } catch { $M.azure.identityToken = 'obtained (unparsed)' }
        } else {
            $M.azure.identityToken = 'refused'
            $M.azure.identityError = Format-FosTrim "$($tk.status) $($tk.error) $($tk.body)" 200
        }
        if ($Sanitize) { if ($M.azure.vmName) { Add-FosMask $M.azure.vmName 'AZ-VM' }; if ($M.azure.subscriptionId) { Add-FosMask $M.azure.subscriptionId 'AZ-SUB' }; if ($M.azure.resourceGroup) { Add-FosMask $M.azure.resourceGroup 'AZ-RG' } }
    } else {
        $M.azure.imdsError = Format-FosTrim $im.error 120
    }
    if ($M.azure.imdsReachable) {
        $noProxy = "$($M.network.goProxyEnv['NO_PROXY'])$($M.network.goProxyEnv['no_proxy'])"
        $hasProxy = [bool]("$($M.network.goProxyEnv['HTTPS_PROXY'])$($M.network.goProxyEnv['https_proxy'])$($M.network.goProxyEnv['HTTP_PROXY'])$($M.network.goProxyEnv['http_proxy'])")
        if ($hasProxy -and $noProxy -notmatch '169\.254\.169\.254') {
            Add-FosFinding -Severity warn -Area 'azure' -Problem 'a machine level HTTP(S)_PROXY is set and NO_PROXY does not include 169.254.169.254' -Fix 'Any Go program (Grafana) doing managed identity auth will send the IMDS call to the proxy. Add 169.254.169.254 to NO_PROXY on the replacement.'
        }
        if ($M.azure.identityToken -eq 'refused') {
            Add-FosFinding -Severity info -Area 'azure' -Problem 'IMDS answers but no managed identity token was issued' -Fix 'Either the VM has no managed identity, or only user assigned identities are attached and the request must name a client_id. Check the VM identity blade.'
        }
    }
}

# ================================================================= 4. firewall + listeners
Start-FosStep 'firewall and listening ports'
$M.firewall = [ordered]@{ profiles = @(); rules = @() }
try {
    $M.firewall.profiles = @(Get-NetFirewallProfile -ErrorAction Stop | ForEach-Object {
        [ordered]@{ name = "$($_.Name)"; enabled = [bool]$_.Enabled; inboundAction = "$($_.DefaultInboundAction)"
                    outboundAction = "$($_.DefaultOutboundAction)"; logBlocked = "$($_.LogBlocked)" } })
} catch {}
# Only rules somebody added: grouped rules are Windows' own. Enabled+Allow+Inbound is what a scrape
# actually depends on.
$M.firewall.rules = @(Invoke-FosTimeout {
    $pf = @{}
    Get-NetFirewallPortFilter -ErrorAction SilentlyContinue | ForEach-Object { $pf[$_.InstanceID] = $_ }
    $af = @{}
    Get-NetFirewallApplicationFilter -ErrorAction SilentlyContinue | ForEach-Object { $af[$_.InstanceID] = $_ }
    Get-NetFirewallRule -ErrorAction SilentlyContinue |
      Where-Object { $_.Enabled -eq 'True' -and -not $_.Group } |
      ForEach-Object {
        $p = $pf[$_.InstanceID]; $a = $af[$_.InstanceID]
        [ordered]@{ name = "$($_.DisplayName)"; direction = "$($_.Direction)"; action = "$($_.Action)"
                    profile = "$($_.Profile)"; protocol = "$($p.Protocol)"; localPort = @($p.LocalPort) -join ','
                    remotePort = @($p.RemotePort) -join ','; program = "$($a.Program)" }
      }
} 120 @() 'firewall rule enumeration')

$M.listeners = @()
try {
    $procById = @{}
    Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | ForEach-Object { $procById[[int]$_.ProcessId] = $_ }
    $svcByPid = @{}
    Get-CimInstance Win32_Service -Filter 'ProcessId<>0' -ErrorAction SilentlyContinue | ForEach-Object {
        if (-not $svcByPid.ContainsKey([int]$_.ProcessId)) { $svcByPid[[int]$_.ProcessId] = @() }
        $svcByPid[[int]$_.ProcessId] += $_.Name }
    $M.listeners = @(Get-NetTCPConnection -State Listen -ErrorAction SilentlyContinue |
        Sort-Object LocalPort -Unique | ForEach-Object {
            $pr = $procById[[int]$_.OwningProcess]
            [ordered]@{ port = [int]$_.LocalPort; address = "$($_.LocalAddress)"; pid = [int]$_.OwningProcess
                        process = "$($pr.Name)"; path = "$($pr.ExecutablePath)"
                        services = @($svcByPid[[int]$_.OwningProcess]) -join ',' } })
} catch {}
# A port that listens with no inbound rule works locally and fails the moment something scrapes it.
foreach ($l in $M.listeners) {
    if ($l.address -in '127.0.0.1', '::1') { continue }
    if ($l.port -in 135, 139, 445, 3389, 5985, 5986, 47001) { continue }
    $has = @($M.firewall.rules | Where-Object { $_.direction -eq 'Inbound' -and $_.action -eq 'Allow' -and ($_.localPort -split ',') -contains "$($l.port)" })
    if (-not $has) { $l.firewall = 'NO INBOUND RULE' } else { $l.firewall = $has[0].name }
}
# Who is connected right now. The consumers of Grafana and Prometheus are the people and systems
# that break on cutover day; this is the only place that list exists as evidence.
Start-FosStep 'established connections to application ports'
$M.consumers = @()
Invoke-Section 'consumers' {
    $appPorts = @($M.listeners | Where-Object { $_.address -notin '127.0.0.1', '::1' -and $_.port -notin 135, 139, 445, 3389, 5985, 5986, 47001 } | ForEach-Object { [int]$_.port })
    if ($appPorts.Count) {
        $est = @(Get-FosEstablishedByPort -Ports $appPorts)
        $allRemote = @($est | ForEach-Object { @($_.remoteAddresses) } | Sort-Object -Unique)
        $rdns = Resolve-FosReverseDns -Addresses $allRemote -TimeoutSec 25
        foreach ($e in $est) {
            $e.remoteHosts = @($e.remoteAddresses | ForEach-Object { $h = "$($rdns[$_])"; if ($h) { "$_ ($h)" } else { $_ } })
            $l = @($M.listeners | Where-Object { $_.port -eq $e.port }) | Select-Object -First 1
            $e.process = $(if ($l) { $l.process } else { '' })
            $M.consumers += $e
        }
    }
}

# ================================================================= 5. security posture
Start-FosStep 'security posture'
$M.security = [ordered]@{}
$M.security.userRights = Get-FosAllUserRights
$lsa = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Lsa' -ErrorAction SilentlyContinue
$M.security.lsa = [ordered]@{ lmCompatibilityLevel = $lsa.LmCompatibilityLevel; restrictAnonymous = $lsa.RestrictAnonymous
                              noLmHash = $lsa.NoLMHash; restrictRemoteSam = "$($lsa.RestrictRemoteSam)" }
$uac = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System' -ErrorAction SilentlyContinue
$M.security.uac = [ordered]@{ enableLUA = $uac.EnableLUA; consentPromptBehaviorAdmin = $uac.ConsentPromptBehaviorAdmin
                              localAccountTokenFilterPolicy = $uac.LocalAccountTokenFilterPolicy }
try { $smb = Get-SmbServerConfiguration -ErrorAction Stop
      $M.security.smb = [ordered]@{ requireSigning = [bool]$smb.RequireSecuritySignature; enableSMB1 = [bool]$smb.EnableSMB1Protocol
                                    enableSMB2 = [bool]$smb.EnableSMB2Protocol } } catch {}
# Schannel: a 2012 box may still be negotiating TLS 1.0. 2025 will not, and anything that depended
# on it (an old D365 endpoint, an internal appliance) stops working with a confusing error.
$M.security.schannel = @()
foreach ($proto in 'SSL 2.0', 'SSL 3.0', 'TLS 1.0', 'TLS 1.1', 'TLS 1.2', 'TLS 1.3') {
    foreach ($side in 'Client', 'Server') {
        $k = "HKLM:\SYSTEM\CurrentControlSet\Control\SecurityProviders\SCHANNEL\Protocols\$proto\$side"
        $v = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
        if ($v) { $M.security.schannel += [ordered]@{ protocol = $proto; side = $side; enabled = $v.Enabled; disabledByDefault = $v.DisabledByDefault } }
    }
}
$M.security.dotNetCrypto = @()
foreach ($k in 'HKLM:\SOFTWARE\Microsoft\.NETFramework\v4.0.30319', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\.NETFramework\v4.0.30319') {
    $v = Get-ItemProperty -Path $k -ErrorAction SilentlyContinue
    if ($v) { $M.security.dotNetCrypto += [ordered]@{ key = $k; schUseStrongCrypto = $v.SchUseStrongCrypto; systemDefaultTlsVersions = $v.SystemDefaultTlsVersions } }
}
$M.security.batchLogonGpoManaged = Test-FosRightIsGpoManaged

# ================================================================= 6. accounts
Start-FosStep 'local accounts and groups'
$M.accounts = [ordered]@{ localUsers = @(); localGroups = @() }
try {
    $M.accounts.localUsers = @(Get-LocalUser -ErrorAction Stop | ForEach-Object {
        [ordered]@{ name = $_.Name; enabled = [bool]$_.Enabled; lastLogon = $(if ($_.LastLogon) { $_.LastLogon.ToString('s') } else { '' })
                    passwordNeverExpires = [bool]$_.PasswordNeverExpires; description = "$($_.Description)" } })
    $M.accounts.localGroups = @(Get-LocalGroup -ErrorAction Stop | ForEach-Object {
        $g = $_.Name
        $mem = @()
        try { $mem = @(Get-LocalGroupMember -Group $g -ErrorAction Stop | ForEach-Object { "$($_.Name)" }) } catch {}
        [ordered]@{ name = $g; members = $mem } } | Where-Object { $_.members.Count })
} catch {
    Add-FosFinding -Severity info -Area 'accounts' -Problem 'Get-LocalUser/Group unavailable (2012 without the cmdlets) - using net localgroup would be needed'
}

# ================================================================= 7. services
Start-FosStep 'services'
$M.services = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
    Where-Object { -not (Test-FosIsJunkService -Name $_.Name -PathName $_.PathName) } |
    ForEach-Object {
        $rec = ''
        try { $rec = ((& sc.exe qfailure $_.Name 2>&1 | Out-String) -replace '\s+', ' ').Trim() } catch {}
        $delayed = $null
        try { $delayed = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\$($_.Name)" -ErrorAction SilentlyContinue).DelayedAutostart } catch {}
        $nssm = $null
        if ("$($_.PathName)" -match '(?i)nssm') { $nssm = Get-FosNssmParameters -Name $_.Name }
        $eff = Resolve-ServiceCommand -Name $_.Name -PathName $_.PathName
        $exe = Get-FosExeFromCommand $eff
        [ordered]@{ name = $_.Name; displayName = "$($_.DisplayName)"; state = "$($_.State)"; startMode = "$($_.StartMode)"
                    startName = "$($_.StartName)"; pathName = "$($_.PathName)"; description = "$($_.Description)"
                    delayedAutoStart = [bool]$delayed; processId = [int]$_.ProcessId
                    recovery = (Format-FosTrim $rec 220)
                    effectiveCommand = $eff; exe = $exe; exeExists = $(if ($exe) { [bool](Test-Path -LiteralPath $exe) } else { $null })
                    exeVersion = $(if ($exe -and (Test-Path -LiteralPath $exe)) { "$((Get-Item -LiteralPath $exe -ErrorAction SilentlyContinue).VersionInfo.FileVersion)" } else { '' })
                    nssm = $nssm } } | Sort-Object { $_.name })
foreach ($s in @($M.services | Where-Object { $_.nssm })) {
    if ($s.exeExists -eq $false) { Add-FosFinding -Severity blocker -Area 'services' -Problem "service $($s.name) is NSSM wrapped and its Application '$($s.exe)' does not exist" -Fix 'The service cannot start. Either it is dead cruft or the binary was moved.' }
    foreach ($ev in @($s.nssm.environment)) {
        if ($ev -match '(?i)^(HTTPS?_PROXY|NO_PROXY)=') { $M.network.goProxyEnv["$($s.name):$(($ev -split '=', 2)[0])"] = ($ev -split '=', 2)[1] }
    }
    if ($s.nssm.appStdout -or $s.nssm.appStderr) {
        foreach ($lp in @($s.nssm.appStdout, $s.nssm.appStderr) | Where-Object { $_ } | Sort-Object -Unique) {
            if (Test-Path -LiteralPath $lp) {
                $li = Get-Item -LiteralPath $lp -ErrorAction SilentlyContinue
                if ($li -and $li.Length -gt 500MB -and -not $s.nssm.appRotateFiles) { Add-FosFinding -Severity warn -Area 'services' -Problem "NSSM log for $($s.name) is $(Format-FosSize $li.Length) with no rotation: $lp" -Fix 'Set AppRotateFiles=1 and AppRotateBytes on the replacement.' }
            }
        }
    }
}

# ================================================================= 8. scheduled tasks
if (-not $SkipTasks) {
    Start-FosStep 'scheduled tasks'
    $ev322 = @{}
    foreach ($t in @(Invoke-FosTimeout {
            Get-WinEvent -FilterHashtable @{ LogName = 'Microsoft-Windows-TaskScheduler/Operational'; Id = 322; StartTime = (Get-Date).AddDays(-1) } -MaxEvents 3000 -ErrorAction SilentlyContinue |
              ForEach-Object { try { $x = [xml]$_.ToXml(); ($x.Event.EventData.Data | Where-Object { $_.Name -eq 'TaskName' }).'#text' } catch {} }
        } 120 @() 'event 322 query')) { if ($t) { $ev322["$t"] = 1 + [int]$ev322["$t"] } }

    $M.tasks = @()
    foreach ($t in @(Get-ScheduledTask -ErrorAction SilentlyContinue |
                     Where-Object { $_.TaskPath -notlike '\Microsoft*' -and $_.TaskName -notmatch '^(MicrosoftEdgeUpdate|GoogleUpdate|OneDrive|Optimize Start Menu|CreateExplorerShell|User_Feed)' })) {
        $full = "$($t.TaskPath)$($t.TaskName)"
        $i = $null; try { $i = $t | Get-ScheduledTaskInfo } catch {}
        $safe = ($full.Trim('\') -replace '[\\/:*?"<>|]', '_')
        try { Export-ScheduledTask -TaskName $t.TaskName -TaskPath $t.TaskPath | Set-Content -LiteralPath (Join-Path $out "tasks\$safe.xml") -Encoding utf8 } catch {}
        $acts = @()
        foreach ($a in $t.Actions) {
            $exe = "$($a.Execute)"; $ar = "$($a.Arguments)"; $wd = "$($a.WorkingDirectory)"
            $sp = $null
            if ($ar -match '(?i)-(?:file|f)\s+"?([^"]+\.ps1)"?') { $sp = $Matches[1] }
            elseif ($exe -match '(?i)\.exe"?$') { $sp = ($exe -replace '"', '') }
            $acts += [ordered]@{ execute = $exe; arguments = $ar; workingDirectory = $wd; scriptPath = $sp
                                 placeholder = [bool]("$exe $ar $wd" -match '#\{')
                                 scriptExists = $(if ($sp) { [bool](Test-Path -LiteralPath $sp) } else { $null }) }
        }
        $trg = @()
        foreach ($x in @($t.Triggers)) {
            $trg += [ordered]@{ type = ($x.CimClass.CimClassName -replace '^MSFT_Task', '' -replace 'Trigger$', '')
                                enabled = $x.Enabled; start = "$($x.StartBoundary)"; end = "$($x.EndBoundary)"
                                interval = $(if ($x.Repetition) { "$($x.Repetition.Interval)" } else { '' }) }
        }
        $lastRun = $null
        if ($i -and $i.LastRunTime) { try { if (([datetime]$i.LastRunTime).Year -ge 2000) { $lastRun = ([datetime]$i.LastRunTime).ToString('s') } } catch {} }
        $acct = "$($t.Principal.UserId)"
        $sam = ConvertTo-FosSam $acct
        # a personal account: not a well known principal, not svc*/sa*/s-* style, looks like a person
        $personal = [bool]($acct -and $acct -notmatch '^(?:NT AUTHORITY\\|BUILTIN\\)?(SYSTEM|LOCAL SERVICE|NETWORK SERVICE|Administrators|Users)$' -and $sam -notmatch '(?i)^(svc|sa[_-]|s-|srv|service|app|gmsa|msa)' -and $sam -notmatch '\$$')
        $M.tasks += [ordered]@{
            name = $full; account = $acct; logonType = "$($t.Principal.LogonType)"
            runLevel = "$($t.Principal.RunLevel)"; enabled = [bool]$t.Settings.Enabled; state = "$($t.State)"
            multipleInstances = "$($t.Settings.MultipleInstances)"
            executionTimeLimit = "$($t.Settings.ExecutionTimeLimit)"
            author = "$($t.Author)"; description = (Format-FosTrim "$($t.Description)" 160); taskDate = "$($t.Date)"
            lastRun = $lastRun; lastResult = $(if ($i) { '0x{0:X8}' -f ([int64]$i.LastTaskResult -band 4294967295L) } else { '' })
            nextRun = $(if ($i -and $i.NextRunTime) { ([datetime]$i.NextRunTime).ToString('s') } else { '' })
            missedRuns = $(if ($i) { [int]$i.NumberOfMissedRuns } else { 0 })
            actions = $acts; triggers = $trg
            normallyLongRunning = ($t.State -eq 'Running'); refusedLaunches24h = [int]$ev322["$full"]
            hasRecurringTrigger = [bool](@($trg | Where-Object { $_.interval -or $_.type -match 'Daily|Weekly|Monthly|Time' }).Count)
            personalAccount = $personal
            batchLogon = ''
        }
    }
    $M.taskAccounts = @($M.tasks | ForEach-Object { $_.account } |
        Where-Object { $_ -and $_ -notmatch '^(?:NT AUTHORITY\\)?(SYSTEM|LOCAL SERVICE|NETWORK SERVICE)$' } | Sort-Object -Unique)
    # batch logon right per account, three state. Password logon tasks need it; S4U and
    # InteractiveToken tasks do not, so it is only a finding where it matters.
    $rightByAcct = @{}
    foreach ($a in $M.taskAccounts) { $rightByAcct[$a] = Test-FosHoldsRight -Account $a -Right 'SeBatchLogonRight' }
    foreach ($t in $M.tasks) {
        if ($rightByAcct.ContainsKey($t.account)) { $t.batchLogon = $rightByAcct[$t.account] }
        if ($t.logonType -eq 'Password' -and $t.batchLogon -eq 'NO') { Add-FosFinding -Severity warn -Area 'tasks' -Problem "task $($t.name) runs as $($t.account) with Password logon and that account does not hold SeBatchLogonRight" -Fix 'It fails with 0x80070569 on launch. Either it is already dead here, or the right is held through a group this capture could not expand.' }
    }
    $pers = @($M.tasks | Where-Object { $_.personalAccount })
    if ($pers.Count) { Add-FosFinding -Severity warn -Area 'tasks' -Problem "$($pers.Count) task(s) run under what looks like a personal account: $(($pers | ForEach-Object { ConvertTo-FosSam $_.account } | Sort-Object -Unique) -join ', ')" -Fix 'Register entries, not migration items, unless a service account is named before cutover. A personal account dies with the person.' }
    $ph = @($M.tasks | Where-Object { @($_.actions | Where-Object { $_.placeholder }).Count })
    if ($ph.Count) { Add-FosFinding -Severity warn -Area 'tasks' -Problem "$($ph.Count) task(s) carry an unsubstituted Octopus #{...} variable in the action" -Fix 'They have never worked. Register entries.' }
    $miss = @($M.tasks | Where-Object { @($_.actions | Where-Object { $_.scriptExists -eq $false }).Count })
    if ($miss.Count) { Add-FosFinding -Severity warn -Area 'tasks' -Problem "$($miss.Count) task(s) point at a script or exe that does not exist on this host" -Fix 'Confirm before migrating: the task is dead here, so it must not be counted as working on the replacement.' }
    if ($Sanitize) { $n = 0; foreach ($a in $M.taskAccounts) { $n++; Add-FosMask (ConvertTo-FosSam $a) "SVCACCT-$n" } }
}

# ================================================================= 9. software, features, certs
Start-FosStep 'installed software'
$M.software = @(Get-FosInstalledSoftware | ForEach-Object { [ordered]@{ name = $_.Name; version = $_.Version; publisher = $_.Publisher; arch = $_.Arch; location = $_.Location } })
$M.features = @(Invoke-FosTimeout {
    try { Get-WindowsFeature -ErrorAction Stop | Where-Object Installed | ForEach-Object { $_.Name } } catch { @() }
} 120 @() 'Get-WindowsFeature')
$M.psModules = @(Get-Module -ListAvailable -ErrorAction SilentlyContinue |
    Where-Object { $_.ModuleBase -notmatch [regex]::Escape("$env:SystemRoot\system32\WindowsPowerShell") } |
    ForEach-Object { [ordered]@{ name = $_.Name; version = "$($_.Version)"; path = $_.ModuleBase } } | Sort-Object { $_.name } -Unique)
$M.certificates = @(Get-ChildItem Cert:\LocalMachine\My -ErrorAction SilentlyContinue | ForEach-Object {
    $eku = @()
    try { $eku = @($_.EnhancedKeyUsageList | ForEach-Object { "$($_.FriendlyName)" } | Where-Object { $_ }) } catch {}
    [ordered]@{ subject = "$($_.Subject)"; issuer = "$($_.Issuer)"; thumbprint = $_.Thumbprint; friendlyName = "$($_.FriendlyName)"
                notBefore = $_.NotBefore.ToString('s'); notAfter = $_.NotAfter.ToString('s'); daysLeft = [int]($_.NotAfter - (Get-Date)).TotalDays
                hasPrivateKey = [bool]$_.HasPrivateKey; dnsNames = @($_.DnsNameList | ForEach-Object { "$_" }); eku = $eku
                selfSigned = ($_.Subject -eq $_.Issuer); boundTo = @() } })
# Where each certificate is USED. A private key that nothing binds is baggage; one that HTTP.sys
# or IIS or Grafana binds is a dependency the replacement must reproduce.
Invoke-Section 'certificate bindings' {
    $ssl = Invoke-FosTimeout { (& netsh http show sslcert 2>&1 | Out-String) } 30 '' 'netsh http show sslcert'
    if ($ssl) {
        $cur = ''
        foreach ($l in ($ssl -split "`r?`n")) {
            if ($l -match '(?i)^\s*(IP:port|Hostname:port)\s*:\s*(\S+)') { $cur = $Matches[2]; continue }
            if ($l -match '(?i)^\s*Certificate Hash\s*:\s*([0-9a-f]+)') {
                $tp = $Matches[1].ToUpper()
                foreach ($c in @($M.certificates | Where-Object { $_.thumbprint -eq $tp })) { $c.boundTo += "http.sys $cur" }
            }
        }
    }
}
foreach ($c in $M.certificates) {
    if ($c.daysLeft -lt 0) { Add-FosFinding -Severity warn -Area 'certs' -Problem "certificate expired $($c.notAfter): $(Format-FosTrim $c.subject 60)" }
    elseif ($c.daysLeft -lt 45) { Add-FosFinding -Severity warn -Area 'certs' -Problem "certificate expires in $($c.daysLeft) days: $(Format-FosTrim $c.subject 60)" }
}
$unbound = @($M.certificates | Where-Object { $_.hasPrivateKey -and -not $_.selfSigned -and -not $_.boundTo.Count -and $_.daysLeft -gt 0 })
if ($unbound.Count) { Add-FosFinding -Severity info -Area 'certs' -Problem "$($unbound.Count) certificate(s) with a private key are not bound to HTTP.sys or IIS: $(($unbound | ForEach-Object { Format-FosTrim $_.subject 40 }) -join '; ')" -Fix 'Something may still use them from application config (Grafana cert_file, a script, a client cert). Find the consumer before deciding whether to export them; if nothing needs them, do not carry them.' }

# ================================================================= 10. environment
Start-FosStep 'environment, PATH, autoruns, ODBC'
$machineEnv = [Environment]::GetEnvironmentVariables('Machine')
$M.environment = [ordered]@{ variables = @(); pathEntries = @(); runKeys = @(); odbc = @() }
foreach ($k in $machineEnv.Keys) { $M.environment.variables += [ordered]@{ name = "$k"; value = "$($machineEnv[$k])" } }
foreach ($p in (("$($machineEnv['Path'])") -split ';' | Where-Object { $_ })) {
    $M.environment.pathEntries += [ordered]@{ path = $p.Trim(); exists = [bool](Test-Path -LiteralPath $p.Trim() -ErrorAction SilentlyContinue) }
}
foreach ($rk in 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run', 'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Run') {
    $v = Get-ItemProperty -Path $rk -ErrorAction SilentlyContinue
    if ($v) { foreach ($n in ($v.PSObject.Properties | Where-Object { $_.Name -notmatch '^PS' })) {
        $M.environment.runKeys += [ordered]@{ key = $rk; name = $n.Name; value = "$($n.Value)" } } }
}
try { $M.environment.odbc = @(Get-OdbcDsn -ErrorAction Stop | ForEach-Object {
        [ordered]@{ name = $_.Name; type = "$($_.DsnType)"; driver = "$($_.DriverName)"; server = "$($_.Attribute.Server)" } }) } catch {}

# ================================================================= 11. IIS
Start-FosStep 'IIS'
$M.iis = $null
if (Get-Service W3SVC -ErrorAction SilentlyContinue) {
    $M.iis = [ordered]@{ sites = @(); pools = @() }
    try {
        Import-Module WebAdministration -ErrorAction Stop
        $M.iis.sites = @(Get-Website -ErrorAction SilentlyContinue | ForEach-Object {
            [ordered]@{ name = $_.Name; state = "$($_.State)"; path = "$($_.PhysicalPath)"
                        bindings = @($_.Bindings.Collection | ForEach-Object { "$($_.protocol)/$($_.bindingInformation)" })
                        appPool = "$($_.applicationPool)" } })
        $M.iis.pools = @(Get-ChildItem IIS:\AppPools -ErrorAction SilentlyContinue | ForEach-Object {
            [ordered]@{ name = $_.Name; state = "$($_.State)"; runtime = "$($_.managedRuntimeVersion)"
                        pipeline = "$($_.managedPipelineMode)"; identityType = "$($_.processModel.identityType)"
                        userName = "$($_.processModel.userName)" } })
    } catch { Add-FosFinding -Severity info -Area 'iis' -Problem "IIS present but WebAdministration failed: $(Format-FosTrim $_.Exception.Message 70)" }
    # an https binding on a site means the http.sys binding above belongs to that site
    foreach ($s in @($M.iis.sites)) { foreach ($b in @($s.bindings)) { if ($b -match '^https/(.+)$') {
        $bi = $Matches[1]
        foreach ($c in @($M.certificates | Where-Object { @($_.boundTo | Where-Object { $_ -match 'http\.sys' }).Count })) {
            $port = ($bi -split ':')[1]
            if ($port -and @($c.boundTo | Where-Object { $_ -match ":$port$" }).Count -and $c.boundTo -notcontains "iis $($s.name)") { $c.boundTo += "iis $($s.name)" } } } } }
}

# ================================================================= 11b. Octopus
# Octopus pushed wmi_exporter to every scrape target in 2018. What it deployed HERE, and whether a
# Tentacle is still listening, decides whether a future Octopus deploy can overwrite the new host.
Start-FosStep 'Octopus Tentacle'
$M.octopus = $null
Invoke-Section 'octopus' {
    $tsvc = @($M.services | Where-Object { $_.name -match '(?i)octopus|tentacle' -or $_.pathName -match '(?i)tentacle' })
    $roots = @('C:\Octopus', 'D:\Octopus', "$env:ProgramData\Octopus") | Where-Object { Test-Path -LiteralPath $_ }
    if ($tsvc.Count -or $roots.Count) {
        $o = [ordered]@{ services = @($tsvc | ForEach-Object { "$($_.name) [$($_.state)] $($_.startName)" }); roots = @($roots); configFiles = @(); applications = @(); tentacleVersion = '' }
        foreach ($r in $roots) {
            foreach ($cf in @(Get-ChildItem -LiteralPath $r -Filter '*.config' -File -ErrorAction SilentlyContinue)) {
                $txt = ''
                try { $txt = Get-Content -LiteralPath $cf.FullName -Raw -ErrorAction Stop } catch {}
                $rec = [ordered]@{ path = $cf.FullName; serverUrl = ''; communicationStyle = ''; port = '' }
                if ($txt -match '(?i)Tentacle\.Communication\.TrustedOctopusServers[^\]]*"Thumbprint"') { $rec.hasTrustedServers = $true }
                if ($txt -match '(?i)Tentacle\.Services\.PortNumber["\s:]+(\d+)') { $rec.port = $Matches[1] }
                if ($txt -match '(?i)Tentacle\.Communication\.TentacleCommunicationStyle["\s:]+([A-Za-z]+)') { $rec.communicationStyle = $Matches[1] }
                if ($txt -match '(?i)"(https?://[^"]+)"') { $rec.serverUrl = $Matches[1] }
                $o.configFiles += $rec
            }
            $app = Join-Path $r 'Applications'
            if (Test-Path -LiteralPath $app) {
                foreach ($envDir in @(Get-ChildItem -LiteralPath $app -Directory -ErrorAction SilentlyContinue)) {
                    foreach ($pkg in @(Get-ChildItem -LiteralPath $envDir.FullName -Directory -ErrorAction SilentlyContinue)) {
                        $vers = @(Get-ChildItem -LiteralPath $pkg.FullName -Directory -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending)
                        $o.applications += [ordered]@{ environment = $envDir.Name; package = $pkg.Name; deployments = $vers.Count
                                                       latest = $(if ($vers.Count) { $vers[0].Name } else { '' })
                                                       lastDeployed = $(if ($vers.Count) { $vers[0].LastWriteTime.ToString('s') } else { '' }) }
                    }
                }
            }
        }
        $texe = @($tsvc | ForEach-Object { $_.exe } | Where-Object { $_ -and (Test-Path -LiteralPath $_) }) | Select-Object -First 1
        if ($texe) { $o.tentacleVersion = "$((Get-Item -LiteralPath $texe).VersionInfo.ProductVersion)" }
        $M.octopus = $o
        $listening = @($tsvc | Where-Object { $_.state -eq 'Running' })
        if ($listening.Count) { Add-FosFinding -Severity warn -Area 'octopus' -Problem "an Octopus Tentacle is running on this host ($($listening[0].name))" -Fix 'A deploy from the 2018 exporter project can still land here. Before the replacement goes live, confirm in Octopus that neither the old nor the new host is in that project target role, or the new windows_exporter gets overwritten by wmi_exporter 0.4.3.' }
        $expPkg = @($o.applications | Where-Object { $_.package -match '(?i)exporter|prometheus|grafana' })
        foreach ($p in $expPkg) { Add-FosFinding -Severity info -Area 'octopus' -Problem "Octopus deployed package '$($p.package)' here (env $($p.environment), latest $($p.latest), $($p.lastDeployed))" }
    }
}

# ================================================================= 12. application trees
Start-FosStep 'application trees'
$M.appTrees = @()
foreach ($root in $AppRoots) {
    if (-not (Test-Path -LiteralPath $root)) { continue }
    $files = @(Invoke-FosTimeout ([scriptblock]::Create("Get-ChildItem -LiteralPath '$root' -Recurse -File -ErrorAction SilentlyContinue | Select-Object FullName, Length, LastWriteTime")) 240 @() "scan of $root")
    $tree = [ordered]@{ root = $root; fileCount = @($files).Count
                        totalBytes = (@($files) | Measure-Object -Property Length -Sum).Sum
                        newest = (@($files) | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
                        topLevel = @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue | ForEach-Object { $_.Name })
                        configFiles = @(); hardcoded = @(); credentialHandling = @(); uncPaths = @(); urls = @(); hashes = @() }
    # Vendored web assets are not the application's configuration. Grafana ships megabytes of
    # minified JS and package-lock.json under public\ and plugins-bundled\; scanning them reported
    # regex fragments as UNC paths and the npm registry as a dependency.
    $vendorNoise = '(?i)\\(node_modules|public|plugins-bundled|\.github|Grafanabackup)\\'
    foreach ($f in @($files | Where-Object { $_.FullName -match '\.(ps1|psm1|config|json|xml|ini|yml|yaml|bat|cmd)$' -and $_.Length -lt 5MB -and $_.FullName -notmatch $vendorNoise })) {
        $txt = ''
        try { $txt = Get-Content -LiteralPath $f.FullName -Raw -ErrorAction Stop } catch { continue }
        if (-not $txt) { continue }
        if ($f.FullName -match '\.(config|json|xml|ini|yml|yaml)$') {
            $tree.configFiles += [ordered]@{ path = $f.FullName; bytes = $f.Length; modified = $f.LastWriteTime.ToString('s')
                                             looksLikeCredentials = [bool]($txt -match '(?i)(password|pwd|secret|apikey|api_key|connectionstring)\s*[:=]') }
        }
        $tells = @()
        foreach ($pat in 'Get-Credential', 'Read-Host', 'Import-Clixml', 'ConvertTo-SecureString', 'ConvertFrom-SecureString') {
            if ($txt -match "(?i)$pat") { $tells += $pat } }
        # -AsPlainText means the secret is NOT machine-bound: it travels with the files and there is
        # nothing to re-create on the target. Getting this backwards cost us a day on CRE.
        if ($txt -match '(?i)ConvertTo-SecureString[^\r\n]*-AsPlainText') { $tells += 'AsPlainText (portable, NOT DPAPI)' }
        if ($tells.Count) { $tree.credentialHandling += [ordered]@{ path = $f.FullName; tells = @($tells | Sort-Object -Unique) } }
        foreach ($u in @([regex]::Matches($txt, '\\\\[A-Za-z0-9_.-]+\\[^\s"'',;)]*') | ForEach-Object { $_.Value })) { $tree.uncPaths += $u }
        foreach ($u in @([regex]::Matches($txt, 'https?://[A-Za-z0-9_.:-]+[^\s"'',;)]*') | ForEach-Object { $_.Value })) { $tree.urls += $u }
        if ($OldServer -and $txt -match [regex]::Escape($OldServer)) { $tree.hardcoded += $f.FullName }
        elseif ($env:COMPUTERNAME -and $txt -match [regex]::Escape($env:COMPUTERNAME)) { $tree.hardcoded += "$($f.FullName) (references THIS host by name)" }
    }
    $tree.uncPaths = @($tree.uncPaths | Sort-Object -Unique)
    $tree.urls     = @($tree.urls | Sort-Object -Unique)
    if ($Deep) {
        $tree.hashes = @($files | ForEach-Object {
            try { [ordered]@{ path = $_.FullName; sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256 -ErrorAction Stop).Hash } } catch {} })
    }
    $M.appTrees += $tree
}

# ================================================================= 13. role detection + add-ons
$svcNames = @($M.services | ForEach-Object { "$($_.name) $($_.displayName) $($_.pathName)" }) -join ' '
if ($Role -eq 'Auto') {
    if ($svcNames -match '(?i)grafana|prometheus') { $Role = 'Appops' }
    elseif ($svcNames -match '(?i)exporter') { $Role = 'Appmon' }
    else { $Role = 'Generic' }
}
$M.role = $Role
Write-Host ("  role detected: {0}" -f $Role) -ForegroundColor Cyan


if ($Role -eq 'Appmon' -or $svcNames -match '(?i)exporter') {
    Start-FosStep 'exporter (APPMON role)'
    $esvc = @($M.services | Where-Object { $_.name -match '(?i)exporter' }) | Select-Object -First 1
    $e = [ordered]@{ service = $null; exe = $null; version = ''; configFile = $null; configText = $null
                     collectors = @(); textfileDir = $null; promFiles = @(); promAcl = @(); metricsLines = 0; metricFamilies = @() }
    if ($esvc) {
        $e.service = $esvc.name
        $bin = Resolve-ServiceCommand -Name $esvc.name -PathName $esvc.pathName
        if ($bin -match '^"([^"]+\.exe)"') { $e.exe = $Matches[1] } elseif ($bin -match '^(\S+\.exe)') { $e.exe = $Matches[1] }
        if ($bin -match '--config\.file[= ]\s*"([^"]+)"') { $e.configFile = $Matches[1] }
        elseif ($bin -match '--config\.file[= ]\s*([^\s"]+)') { $e.configFile = $Matches[1] }
        if ($e.exe -and (Test-Path -LiteralPath $e.exe)) {
            $v = (& $e.exe --version 2>&1 | Out-String)     # writes to stderr; that is not an error
            if ($v -match '(?i)(windows_exporter|wmi_exporter),?\s*version\s*([0-9.]+)') { $e.version = "$($Matches[1]) $($Matches[2])" }
            else { $e.version = Format-FosTrim $v 80 }
        }
        if ($e.configFile -and (Test-Path -LiteralPath $e.configFile)) {
            $e.configText = Get-Content -LiteralPath $e.configFile -Raw
            if ($e.configText -match '(?m)^\s*enabled:\s*(.+)$') { $e.collectors = @($Matches[1] -split ',' | ForEach-Object { $_.Trim() } | Where-Object { $_ }) }
            # anchor to the directories: key - matching the first "- item" anywhere in the YAML would
            # happily return a rule file or an alertmanager target instead
            if ($e.configText -match '(?ms)^[ \t]*directories:[ \t]*\r?\n(?:[ \t]*-[ \t]*(\S[^\r\n]*)\r?\n?)') { $e.textfileDir = $Matches[1].Trim() }
            elseif ($e.configText -match '(?m)^[ \t]*directories:[ \t]*(\S[^\r\n]*)$') {
                $e.textfileDir = $Matches[1].Trim()
                Add-FosFinding -Severity blocker -Area 'exporter' -Problem "config has 'directories:' as a scalar" -Fix 'windows_exporter 0.31 types it as []string - it must be a YAML list or the service will not start'
            }
        }
    }
    if (-not $e.textfileDir) { $e.textfileDir = 'D:\Win\Ops\WMITextfileExport' }
    if (Test-Path -LiteralPath $e.textfileDir) {
        $e.promFiles = @(Get-ChildItem -LiteralPath $e.textfileDir -File -ErrorAction SilentlyContinue | ForEach-Object {
            [ordered]@{ name = $_.Name; bytes = $_.Length; modified = $_.LastWriteTime.ToString('s')
                        ageMinutes = [int](New-TimeSpan -Start $_.LastWriteTime -End (Get-Date)).TotalMinutes } })
        try { $e.promAcl = @((Get-Acl -LiteralPath $e.textfileDir).Access | ForEach-Object {
                [ordered]@{ identity = "$($_.IdentityReference)"; rights = "$($_.FileSystemRights)"; type = "$($_.AccessControlType)" } }) } catch {}
    }
    $body = Invoke-FosWeb 'http://localhost:9182/metrics' -TimeoutSec 25
    if ($body) {
        $lines = $body -split "`n"
        $e.metricsLines = $lines.Count
        $e.metricFamilies = @($lines | Where-Object { $_ -match '^# HELP (\S+)' } | ForEach-Object { ($_ -split ' ')[2] } | Sort-Object -Unique)
        $scrapeErr = @($lines | Where-Object { $_ -match 'textfile_scrape_error' -and $_ -notmatch '^#' })
        $e.textfileScrapeError = @($scrapeErr) -join '; '
        if ($e.textfileScrapeError -match '\s1(\.0)?\s*$') { Add-FosFinding -Severity warn -Area 'exporter' -Problem 'textfile_scrape_error = 1: a .prom file fails to parse' -Fix 'Run Test-PromFiles.ps1 against the textfile directory' }
    } else { Add-FosFinding -Severity warn -Area 'exporter' -Problem 'nothing answered on http://localhost:9182/metrics' }
    if ($e.collectors -contains 'cs') { Add-FosFinding -Severity blocker -Area 'exporter' -Problem "config enables the 'cs' collector" -Fix "'cs' was removed from windows_exporter (metrics moved to cpu_info/memory) - the service will not start on the new build" }
    $M.exporter = $e
}

if ($Role -eq 'Appops' -or $svcNames -match '(?i)grafana|prometheus') {
    Start-FosStep 'Grafana (APPOPS role)'
    $gsvc = @($M.services | Where-Object { $_.name -match '(?i)grafana' -or $_.displayName -match '(?i)grafana' -or $_.effectiveCommand -match '(?i)grafana' }) | Select-Object -First 1
    $g = [ordered]@{ service = $null; exe = $null; home = $null; version = ''; edition = 'unknown'; editionEvidence = @(); configPaths = @(); effective = @{}
                     configuredPort = ''; listeningPorts = @(); database = @{}; plugins = @(); provisioning = @(); provisionedDatasources = @()
                     alertingMode = ''; api = $null; command = ''; appDirectory = ''; envOverrides = @(); customIniRedacted = ''
                     licence = $null; db = $null; log = $null; settings = [ordered]@{} }
    Invoke-Section 'grafana' {
        if ($gsvc) {
            $g.service = $gsvc.name
            $g.command = "$($gsvc.effectiveCommand)"
            $g.appDirectory = "$($gsvc.nssm.appDirectory)"
            $bin = $g.command
            $g.exe = Get-FosExeFromCommand $bin
            foreach ($fl in '--homepath', '-homepath') { $v = Get-FosFlag $bin $fl; if ($v) { $g.home = $v; break } }
            $cfgFlag = ''
            foreach ($fl in '--config', '-config') { $v = Get-FosFlag $bin $fl; if ($v) { $cfgFlag = $v; break } }
            # cfg:section.key=value overrides on the command line beat every ini file
            foreach ($mm in [regex]::Matches($bin, 'cfg:([A-Za-z0-9_.]+)=("[^"]*"|\S+)')) { $g.envOverrides += "cmdline $($mm.Groups[1].Value)=$($mm.Groups[2].Value)" }
            # Grafana resolves homepath as: flag, else the working directory if it holds conf\defaults.ini,
            # else one level up from it. The working directory of an NSSM service is AppDirectory.
            if (-not $g.home) {
                $cands = @()
                if ($g.appDirectory) { $cands += $g.appDirectory; $cands += (Split-Path -Parent $g.appDirectory) }
                if ($g.exe) { $cands += (Split-Path -Parent $g.exe); $cands += (Split-Path -Parent (Split-Path -Parent $g.exe)) }
                foreach ($c in @($cands | Where-Object { $_ })) { if (Test-Path -LiteralPath (Join-Path $c 'conf\defaults.ini')) { $g.home = $c; break } }
                if (-not $g.home -and $g.exe) { $g.home = Split-Path -Parent (Split-Path -Parent $g.exe) }
            }
            if ($g.exe -and (Test-Path -LiteralPath $g.exe)) {
                $vi = (Get-Item -LiteralPath $g.exe).VersionInfo
                $g.exeProductName = "$($vi.ProductName)"; $g.exeFileVersion = "$($vi.FileVersion)"
                $v = ''
                try { $v = (& $g.exe -v 2>&1 | Out-String) } catch {}
                if ($v -notmatch 'Version\s+[0-9.]+') { try { $v = (& $g.exe --version 2>&1 | Out-String) } catch {} }
                if ($v -notmatch 'Version\s+[0-9.]+' -and $g.exe -match '(?i)grafana\.exe$') { try { $v = (& $g.exe server -v 2>&1 | Out-String) } catch {} }
                if ($v -match 'Version\s+([0-9][0-9.]*)') { $g.version = $Matches[1] } elseif ($v) { $g.version = Format-FosTrim $v 60 }
                if ($v -match '(?i)commit:\s*([0-9a-f]+)') { $g.commit = $Matches[1] }
                if ($v -match '(?i)enterprise') { $g.editionEvidence += 'binary -v output says enterprise' }
                if ($vi.ProductName -match '(?i)enterprise') { $g.editionEvidence += "exe ProductName '$($vi.ProductName)'" }
            }
            # GF_ environment overrides: machine level and NSSM service level. If any exist, the ini
            # on disk is not the whole configuration.
            foreach ($k in ([Environment]::GetEnvironmentVariables('Machine')).Keys) { if ("$k" -like 'GF_*') { $g.envOverrides += "machine $k" } }
            foreach ($ev in @($gsvc.nssm.environment)) { if ($ev -match '^(GF_[A-Z0-9_]+)=') { $g.envOverrides += "nssm $($Matches[1])" } }
            if ($g.home) {
                $defaults = Join-Path $g.home 'conf\defaults.ini'
                $custom   = $(if ($cfgFlag) { $cfgFlag } else { Join-Path $g.home 'conf\custom.ini' })
                if ($cfgFlag -and -not [IO.Path]::IsPathRooted($cfgFlag) -and $g.appDirectory) { $custom = Join-Path $g.appDirectory $cfgFlag }
                $g.configPaths = @(@{ path = $defaults; exists = [bool](Test-Path -LiteralPath $defaults) }, @{ path = $custom; exists = [bool](Test-Path -LiteralPath $custom); fromFlag = [bool]$cfgFlag })
                $g.effective = Get-FosIniEffective @($defaults, $custom)
                if (Test-Path -LiteralPath $custom) {
                    $raw = Get-Content -LiteralPath $custom -Raw -ErrorAction SilentlyContinue
                    $g.customIniRedacted = Get-FosRedactedText $raw
                    $g.customIniRedacted | Set-Content -LiteralPath (Join-Path $out 'config\grafana-custom.ini') -Encoding utf8
                    $g.customIniLines = @($raw -split "`n").Count
                    $g.customIniSections = @([regex]::Matches($raw, '(?m)^\s*\[([^\]]+)\]') | ForEach-Object { $_.Groups[1].Value })
                    $g.customIniModified = (Get-Item -LiteralPath $custom).LastWriteTime.ToString('s')
                } else {
                    Add-FosFinding -Severity warn -Area 'grafana' -Problem "no custom.ini at ${custom}: Grafana is running on defaults.ini plus whatever GF_ variables or cfg: flags say" -Fix 'This is what a fresh install looks like. Confirm it is intentional and not a lost config.'
                }
                $e = $g.effective
                $g.configuredPort = "$($e['server.http_port'])"
                $g.database = [ordered]@{ type = "$($e['database.type'])"; path = "$($e['database.path'])"; host = "$($e['database.host'])"; name = "$($e['database.name'])"; user = "$($e['database.user'])" }
                $g.rootUrl = "$($e['server.root_url'])"
                $g.protocol = "$($e['server.protocol'])"
                $g.unifiedAlerting = "$($e['unified_alerting.enabled'])"
                $g.legacyAlerting  = "$($e['alerting.enabled'])"
                $g.alertingMode = $(if ("$($e['unified_alerting.enabled'])" -match '(?i)true') { 'unified' } elseif ("$($e['alerting.enabled'])" -match '(?i)true') { 'legacy' } else { 'unclear' })
                # the settings that decide what the replacement has to reproduce
                foreach ($key in 'server.http_addr', 'server.http_port', 'server.domain', 'server.root_url', 'server.serve_from_sub_path', 'server.protocol', 'server.cert_file', 'server.cert_key', 'server.enforce_domain',
                                 'database.type', 'database.path', 'database.host', 'database.name', 'database.wal',
                                 'paths.data', 'paths.logs', 'paths.plugins', 'paths.provisioning',
                                 'security.admin_user', 'security.disable_initial_admin_creation', 'security.cookie_secure', 'security.allow_embedding',
                                 'users.allow_sign_up', 'users.auto_assign_org_role', 'users.viewers_can_edit',
                                 'auth.disable_login_form', 'auth.oauth_auto_login', 'auth.anonymous.enabled', 'auth.anonymous.org_role', 'auth.basic.enabled',
                                 'auth.ldap.enabled', 'auth.ldap.config_file', 'auth.ldap.allow_sign_up', 'auth.proxy.enabled', 'auth.proxy.header_name',
                                 'auth.azuread.enabled', 'auth.azuread.auth_url', 'auth.azuread.allowed_groups', 'auth.generic_oauth.enabled', 'auth.generic_oauth.name', 'auth.generic_oauth.auth_url',
                                 'auth.github.enabled', 'auth.google.enabled', 'auth.okta.enabled', 'auth.saml.enabled',
                                 'smtp.enabled', 'smtp.host', 'smtp.from_address', 'smtp.from_name', 'smtp.user', 'smtp.skip_verify',
                                 'alerting.enabled', 'alerting.execute_alerts', 'unified_alerting.enabled', 'unified_alerting.ha_peers',
                                 'azure.cloud', 'azure.managed_identity_enabled', 'azure.managed_identity_client_id', 'azure.workload_identity_enabled', 'azure.user_identity_enabled',
                                 'enterprise.license_path', 'enterprise.license_validation_type', 'enterprise.auto_assign_org_id',
                                 'rendering.server_url', 'rendering.callback_url', 'plugin.grafana-image-renderer.rendering_mode',
                                 'plugins.allow_loading_unsigned_plugins', 'plugins.plugin_admin_enabled',
                                 'log.mode', 'log.level', 'log.file.max_days', 'analytics.reporting_enabled', 'analytics.check_for_updates',
                                 'snapshots.external_enabled', 'dashboards.versions_to_keep', 'dashboards.min_refresh_interval', 'feature_toggles.enable', 'date_formats.default_timezone') {
                    if ($e.Contains($key)) { $g.settings[$key] = "$($e[$key])" }
                }
                foreach ($sub in 'data', 'logs', 'plugins', 'provisioning') { $p = "$($e["paths.$sub"])"; if ($p) { $g["path_$sub"] = $p } }
                $dataDir = "$($e['paths.data'])"; if (-not $dataDir) { $dataDir = Join-Path $g.home 'data' }
                if (-not [IO.Path]::IsPathRooted($dataDir) -and $g.home) { $dataDir = Join-Path $g.home $dataDir }
                $g.dataDir = $dataDir
                # edition and licence
                if ($g.editionEvidence.Count) { $g.edition = 'Enterprise' }
                $swEnt = @($M.software | Where-Object { $_.name -match '(?i)grafana' })
                foreach ($s in $swEnt) { if ($s.name -match '(?i)enterprise') { $g.edition = 'Enterprise'; $g.editionEvidence += "installed software '$($s.name)' $($s.version)" } }
                $licPath = "$($e['enterprise.license_path'])"
                if (-not $licPath) { $licPath = Join-Path $dataDir 'license.jwt' }
                $g.licence = [ordered]@{ path = $licPath; exists = [bool](Test-Path -LiteralPath $licPath) }
                if ($g.licence.exists) {
                    $g.edition = 'Enterprise'; $g.editionEvidence += "licence file present at $licPath"
                    $tok = ''
                    try { $tok = (Get-Content -LiteralPath $licPath -Raw -ErrorAction Stop).Trim() } catch {}
                    $pl = ConvertFrom-FosJwtPayload $tok
                    if ($pl) {
                        foreach ($k in 'lid', 'url', 'slug', 'prod', 'iat', 'nbf', 'exp', 'included_users', 'included_admins', 'included_viewers', 'lic_exp_warn_days', 'tok_exp_warn_days', 'sub', 'trial', 'usage_billing', 'details_url', 'account') {
                            if ($null -ne $pl.$k) {
                                $val = $pl.$k
                                if ($k -in 'iat', 'nbf', 'exp' -and "$val" -match '^\d+$') { $val = ([DateTimeOffset]::FromUnixTimeSeconds([long]$val)).UtcDateTime.ToString('s') + 'Z' }
                                $g.licence[$k] = $(if ($val -is [array]) { @($val | ForEach-Object { "$_" }) -join ',' } else { "$val" })
                            }
                        }
                        if ($pl.exp) { try { $g.licence.daysLeft = [int](([DateTimeOffset]::FromUnixTimeSeconds([long]$pl.exp)).UtcDateTime - (Get-Date).ToUniversalTime()).TotalDays } catch {} }
                    } else { $g.licence.decodeError = 'payload could not be decoded' }
                }
                if ($g.edition -eq 'unknown' -and $g.exe -and (Test-Path -LiteralPath $g.exe)) {
                    # the binary itself: an Enterprise build embeds the licensing package name
                    try {
                        $fstream = [IO.File]::OpenRead($g.exe); $buf = New-Object byte[] (4MB); $hit = $false; $chunks = 0
                        while (-not $hit -and $chunks -lt 64 -and ($n = $fstream.Read($buf, 0, $buf.Length)) -gt 0) { $chunks++; $s = [Text.Encoding]::ASCII.GetString($buf, 0, $n); if ($s -match 'grafana-enterprise|pkg/extensions/licensing') { $hit = $true } }
                        $fstream.Close()
                        if ($hit) { $g.edition = 'Enterprise'; $g.editionEvidence += 'enterprise strings inside the binary' } else { $g.edition = 'OSS (no enterprise strings in the first 256 MB of the binary)' }
                    } catch {}
                }
                # grafana.db: the whole content store. Its size, and whether it is being written to
                # right now, decides how Route B (stop, copy, start) is scheduled with the developer.
                if (-not $g.database.type -or $g.database.type -match '(?i)sqlite') {
                    $dbPath = "$($g.database.path)"; if (-not $dbPath) { $dbPath = Join-Path $dataDir 'grafana.db' }
                    if (-not [IO.Path]::IsPathRooted($dbPath)) { $dbPath = Join-Path $dataDir $dbPath }
                    $g.db = [ordered]@{ path = $dbPath; exists = [bool](Test-Path -LiteralPath $dbPath) }
                    if ($g.db.exists) {
                        $dbi = Get-Item -LiteralPath $dbPath
                        $g.db.bytes = $dbi.Length; $g.db.modified = $dbi.LastWriteTime.ToString('s')
                        $g.db.minutesSinceWrite = [int](New-TimeSpan -Start $dbi.LastWriteTime -End (Get-Date)).TotalMinutes
                        $g.db.walPresent = [bool](Test-Path -LiteralPath "$dbPath-wal"); $g.db.shmPresent = [bool](Test-Path -LiteralPath "$dbPath-shm")
                        $g.db.journalPresent = [bool](Test-Path -LiteralPath "$dbPath-journal")
                        if ($g.db.walPresent) { $g.db.walBytes = (Get-Item -LiteralPath "$dbPath-wal").Length }
                    } else { Add-FosFinding -Severity warn -Area 'grafana' -Problem "sqlite database not found at $dbPath" -Fix 'Either database.path in custom.ini points elsewhere, or paths.data is not what this capture resolved. Find the live grafana.db before planning Route B.' }
                } else {
                    $g.db = [ordered]@{ path = ''; exists = $false; external = "$($g.database.type) on $($g.database.host)/$($g.database.name)" }
                    Add-FosFinding -Severity info -Area 'grafana' -Problem "Grafana uses an external $($g.database.type) database at $($g.database.host)" -Fix 'Route B does not apply. The new Grafana points at the same database and the content moves with it; confirm the DB firewall allows the new host.'
                }
                # plugins with versions
                $plugDir = "$($e['paths.plugins'])"; if (-not $plugDir) { $plugDir = Join-Path $dataDir 'plugins' }
                if (-not [IO.Path]::IsPathRooted($plugDir) -and $g.home) { $plugDir = Join-Path $g.home $plugDir }
                $g.pluginsDir = $plugDir
                if (Test-Path -LiteralPath $plugDir) {
                    $g.plugins = @(Get-ChildItem -LiteralPath $plugDir -Directory -ErrorAction SilentlyContinue | ForEach-Object {
                        $pj = Join-Path $_.FullName 'plugin.json'; if (-not (Test-Path -LiteralPath $pj)) { $pj = Join-Path $_.FullName 'dist\plugin.json' }
                        $pv = ''; $pt = ''; $plugId = $_.Name
                        if (Test-Path -LiteralPath $pj) { try { $pjo = Get-Content -LiteralPath $pj -Raw | ConvertFrom-Json; $pv = "$($pjo.info.version)"; $pt = "$($pjo.type)"; if ($pjo.id) { $plugId = "$($pjo.id)" } } catch {} }
                        "$plugId $pv $pt".Trim() })
                }
                $provDir = "$($e['paths.provisioning'])"; if (-not $provDir) { $provDir = Join-Path $g.home 'conf\provisioning' }
                if (-not [IO.Path]::IsPathRooted($provDir) -and $g.home) { $provDir = Join-Path $g.home $provDir }
                if (Test-Path -LiteralPath $provDir) {
                    $g.provisioning = @(Get-ChildItem -LiteralPath $provDir -Recurse -File -ErrorAction SilentlyContinue | ForEach-Object { [ordered]@{ path = $_.FullName; bytes = $_.Length; modified = $_.LastWriteTime.ToString('s') } })
                    foreach ($pf in @(Get-ChildItem -LiteralPath (Join-Path $provDir 'datasources') -Filter '*.y*ml' -File -ErrorAction SilentlyContinue)) {
                        $ptxt = ''; try { $ptxt = Get-Content -LiteralPath $pf.FullName -Raw } catch {}
                        foreach ($mm in [regex]::Matches($ptxt, '(?m)^\s*-\s*name:\s*(.+)$')) { $g.provisionedDatasources += "$($mm.Groups[1].Value.Trim()) [$($pf.Name)]" }
                        if ($ptxt) { (Get-FosRedactedText $ptxt) | Set-Content -LiteralPath (Join-Path $out "config\grafana-provisioning-$($pf.Name)") -Encoding utf8 }
                    }
                }
                $ldap = "$($e['auth.ldap.config_file'])"
                if ("$($e['auth.ldap.enabled'])" -match '(?i)true' -and $ldap) {
                    if (-not [IO.Path]::IsPathRooted($ldap) -and $g.home) { $ldap = Join-Path $g.home $ldap }
                    $g.ldapConfig = [ordered]@{ path = $ldap; exists = [bool](Test-Path -LiteralPath $ldap) }
                    if ($g.ldapConfig.exists) { (Get-FosRedactedText (Get-Content -LiteralPath $ldap -Raw)) | Set-Content -LiteralPath (Join-Path $out 'config\grafana-ldap.toml') -Encoding utf8 }
                }
                # the log: is Grafana healthy, and what does it complain about
                $logDir = "$($e['paths.logs'])"; if (-not $logDir) { $logDir = Join-Path $dataDir 'log' }
                if (-not [IO.Path]::IsPathRooted($logDir) -and $g.home) { $logDir = Join-Path $g.home $logDir }
                $logFile = Join-Path $logDir 'grafana.log'
                $g.log = [ordered]@{ path = $logFile; exists = [bool](Test-Path -LiteralPath $logFile); errors24h = 0; lastErrors = @() }
                if ($g.log.exists) {
                    $li = Get-Item -LiteralPath $logFile
                    $g.log.bytes = $li.Length; $g.log.modified = $li.LastWriteTime.ToString('s')
                    $tail = @(Get-Content -LiteralPath $logFile -Tail 4000 -ErrorAction SilentlyContinue)
                    $errs = @($tail | Where-Object { $_ -match '(?:level|lvl)=(error|eror|crit)' })
                    $since = (Get-Date).AddDays(-1)
                    $g.log.errors24h = @($errs | Where-Object {
                        $recent = $false
                        if ($_ -match '^t=(\S+)') {
                            $ts = $Matches[1] -replace '([+-]\d{2})(\d{2})$', '$1:$2'     # +0000 to +00:00 for .NET
                            $dt = [datetime]::MinValue
                            if ([datetime]::TryParse($ts, [Globalization.CultureInfo]::InvariantCulture, [Globalization.DateTimeStyles]::AdjustToUniversal, [ref]$dt)) { $recent = ($dt -ge $since.ToUniversalTime()) }
                        }
                        $recent }).Count
                    $g.log.lastErrors = @($errs | Select-Object -Last 8 | ForEach-Object { Format-FosTrim ($_ -replace '^t=\S+\s*', '') 170 })
                    if ($g.log.errors24h -gt 50) { Add-FosFinding -Severity warn -Area 'grafana' -Problem "grafana.log has $($g.log.errors24h) error lines in the last 24h" -Fix 'Read the last errors in the report. Errors that exist before the move must not be blamed on it.' }
                }
                if ($g.envOverrides.Count) { Add-FosFinding -Severity warn -Area 'grafana' -Problem "$($g.envOverrides.Count) GF_ / cfg: override(s) are in force: $(($g.envOverrides | Select-Object -First 6) -join ', ')" -Fix 'custom.ini is not the whole configuration. Reproduce these on the replacement or fold them into custom.ini.' }
                if ("$($e['auth.anonymous.enabled'])" -match '(?i)true') { Add-FosFinding -Severity info -Area 'grafana' -Problem "anonymous access is enabled (org role $($e['auth.anonymous.org_role']))" }
                if ("$($e['smtp.enabled'])" -match '(?i)true') { Add-FosFinding -Severity info -Area 'grafana' -Problem "SMTP is enabled via $($e['smtp.host']) from $($e['smtp.from_address'])" -Fix 'The mail relay must accept the new host IP.' }
                if ("$($e['server.protocol'])" -match '(?i)https') { Add-FosFinding -Severity info -Area 'grafana' -Problem "Grafana serves HTTPS itself with cert_file $($e['server.cert_file'])" -Fix 'That certificate and key must be present on the replacement at the same path, or the path changed in custom.ini.' }
                if ($g.licence -and $g.licence.exists) {
                    if ($g.licence.url -and $g.rootUrl -and ("$($g.licence.url)".TrimEnd('/') -ne "$($g.rootUrl)".TrimEnd('/'))) { Add-FosFinding -Severity warn -Area 'grafana' -Problem "licence is issued for $($g.licence.url) but root_url is $($g.rootUrl)" -Fix 'Grafana Enterprise validates the licence against root_url. Either they already differ and the licence is not being honoured, or root_url is set elsewhere.' }
                    if ($g.licence.url) { Add-FosFinding -Severity warn -Area 'grafana' -Problem "Grafana Enterprise licence is bound to URL $($g.licence.url)$(if ($g.licence.exp) { ", expires $($g.licence.exp)" })" -Fix 'The replacement must serve the same root_url (DNS alias), or Grafana Labs must reissue the licence for the new URL before cutover. Without a valid licence Enterprise runs with OSS features only.' }
                    if ($null -ne $g.licence.daysLeft -and $g.licence.daysLeft -lt 90) { Add-FosFinding -Severity warn -Area 'grafana' -Problem "Grafana Enterprise licence expires in $($g.licence.daysLeft) days" }
                } elseif ($g.edition -eq 'Enterprise') {
                    Add-FosFinding -Severity info -Area 'grafana' -Problem 'Enterprise build with no licence file found' -Fix 'It runs as OSS. Confirm no Enterprise feature (reports, data source permissions, SAML) is in use.'
                }
                if ($g.db -and $g.db.exists -and $g.db.minutesSinceWrite -lt 60) { Add-FosFinding -Severity info -Area 'grafana' -Problem "grafana.db was written $($g.db.minutesSinceWrite) minutes ago: someone is editing" -Fix 'For Route B stop Grafana before copying grafana.db (and -wal/-shm). Agree the minute with the developer.' }
            }
        }
        $g.listeningPorts = @($M.listeners | Where-Object { $_.process -match '(?i)grafana' -or ($gsvc -and $_.services -match "(^|,)$([regex]::Escape($gsvc.name))(,|$)") } | ForEach-Object { $_.port } | Sort-Object -Unique)
        if ($g.configuredPort -and $g.listeningPorts.Count -and ($g.listeningPorts -notcontains [int]$g.configuredPort)) {
            Add-FosFinding -Severity blocker -Area 'grafana' -Problem "Grafana is listening on $($g.listeningPorts -join ',') but config says $($g.configuredPort)" -Fix 'The running config is not the one you are reading. Check for a second homepath, a --config flag, a GF_SERVER_HTTP_PORT variable, or a custom.ini that is not being loaded.'
        }
        # API. /api/health needs no auth and gives version, commit and (Enterprise) enterpriseCommit.
        if (-not $GrafanaUrl -and $g.listeningPorts.Count) {
            $scheme = $(if ($g.protocol -match '(?i)https') { 'https' } else { 'http' })
            $GrafanaUrl = "${scheme}://localhost:$($g.listeningPorts[0])"
            $g.apiUrlAutoDetected = $GrafanaUrl
        }
        if ($GrafanaUrl) {
            $api = [ordered]@{ url = $GrafanaUrl }
            $hres = Invoke-FosWebDirect "$GrafanaUrl/api/health" -TimeoutSec 15
            if ($hres.ok -and $hres.body) {
                try {
                    $hj = $hres.body | ConvertFrom-Json
                    $api.health = [ordered]@{ database = "$($hj.database)"; version = "$($hj.version)"; commit = "$($hj.commit)"; enterpriseCommit = "$($hj.enterpriseCommit)" }
                    if (-not $g.version -or $g.version -notmatch '^[0-9]') { $g.version = "$($hj.version)" }
                    if ($hj.enterpriseCommit) { $g.edition = 'Enterprise'; $g.editionEvidence += '/api/health reports enterpriseCommit' }
                } catch { $api.health = Format-FosTrim $hres.body 80 }
            } else { Add-FosFinding -Severity warn -Area 'grafana' -Problem "Grafana API at $GrafanaUrl/api/health did not answer ($(Format-FosTrim $hres.error 80))" -Fix 'Check the URL and protocol. If Grafana serves HTTPS with a private certificate, pass -GrafanaUrl with http on the loopback port instead.' }
            $h = @{}
            if ($GrafanaApiKey) { $h['Authorization'] = "Bearer $GrafanaApiKey" }
            elseif ($GrafanaCredential) { $pair = "$($GrafanaCredential.UserName):$($GrafanaCredential.GetNetworkCredential().Password)"; $h['Authorization'] = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pair)) }
            if ($h.Count) {
                $fs = Invoke-FosWebDirect "$GrafanaUrl/api/frontend/settings" -Headers $h -TimeoutSec 20
                if ($fs.ok) { try { $fj = $fs.body | ConvertFrom-Json
                        $api.buildInfo = [ordered]@{ version = "$($fj.buildInfo.version)"; edition = "$($fj.buildInfo.edition)"; commit = "$($fj.buildInfo.commit)"; hideVersion = [bool]$fj.buildInfo.hideVersion }
                        if ($fj.buildInfo.edition) { $g.edition = "$($fj.buildInfo.edition)"; $g.editionEvidence += "/api/frontend/settings edition=$($fj.buildInfo.edition)" }
                        if ($fj.licenseInfo) { $api.licenseInfo = [ordered]@{ expiry = "$($fj.licenseInfo.expiry)"; stateInfo = "$($fj.licenseInfo.stateInfo)"; licenseUrl = "$($fj.licenseInfo.licenseUrl)"; slug = "$($fj.licenseInfo.slug)"; enabledFeatures = @($fj.licenseInfo.enabledFeatures.PSObject.Properties | Where-Object { $_.Value } | ForEach-Object { $_.Name }) } }
                        if ($fj.azure) { $api.azure = [ordered]@{ cloud = "$($fj.azure.cloud)"; managedIdentityEnabled = [bool]$fj.azure.managedIdentityEnabled; workloadIdentityEnabled = [bool]$fj.azure.workloadIdentityEnabled; userIdentityEnabled = [bool]$fj.azure.userIdentityEnabled } }
                        $api.unifiedAlertingEnabled = [bool]$fj.unifiedAlertingEnabled; $api.alertingEnabled = [bool]$fj.alertingEnabled; $api.angularSupportEnabled = [bool]$fj.angularSupportEnabled
                        $api.ldapEnabled = [bool]$fj.ldapEnabled; $api.authProxyEnabled = [bool]$fj.authProxyEnabled; $api.anonymousEnabled = [bool]$fj.anonymousEnabled
                    } catch {} }
                $ds = Invoke-FosWebDirect "$GrafanaUrl/api/datasources" -Headers $h -TimeoutSec 20
                if ($ds.ok) { try {
                    $api.datasources = @($ds.body | ConvertFrom-Json | ForEach-Object {
                        $jd = $_.jsonData
                        $rec = [ordered]@{ name = $_.name; type = $_.type; url = "$($_.url)"; uid = "$($_.uid)"; id = $_.id; isDefault = [bool]$_.isDefault; access = "$($_.access)"; basicAuth = [bool]$_.basicAuth; readOnly = [bool]$_.readOnly }
                        if ($jd) { foreach ($k in 'httpMethod', 'timeInterval', 'tlsSkipVerify', 'authType', 'azureAuthType', 'cloudName', 'subscriptionId', 'tenantId', 'clientId', 'azureCredentials', 'oauthPassThru', 'manageAlerts', 'prometheusType', 'prometheusVersion', 'logAnalyticsDefaultWorkspace', 'azureLogAnalyticsSameAs') {
                            if ($null -ne $jd.$k) { $v = $jd.$k; if ($v -is [pscustomobject]) { $v = ($v | ConvertTo-Json -Compress -Depth 4) }; $rec[$k] = "$v" } } }
                        $hc = Invoke-FosWebDirect "$GrafanaUrl/api/datasources/uid/$($_.uid)/health" -Headers $h -TimeoutSec 25
                        if ($hc.ok -or $hc.body) { try { $hcj = $hc.body | ConvertFrom-Json; $rec.health = "$($hcj.status)"; $rec.healthMessage = Format-FosTrim "$($hcj.message)" 140 } catch { $rec.health = "http $($hc.status)" } }
                        else { $rec.health = "no answer ($($hc.status))" }
                        $rec })
                    foreach ($d in @($api.datasources)) {
                        if ($d.type -match '(?i)azure-monitor') {
                            $mode = "$($d.azureAuthType)$($d.authType)"; if ($d.azureCredentials -match '"authType"\s*:\s*"([^"]+)"') { $mode = $Matches[1] }
                            if ($mode -match '(?i)msi|managed') { Add-FosFinding -Severity warn -Area 'grafana' -Problem "datasource '$($d.name)' authenticates with the VM managed identity (health: $($d.health))" -Fix 'A system assigned identity is bound to THIS VM resource and does not move. Create a user assigned identity with the same RBAC, attach it to both VMs, set azure.managed_identity_client_id in custom.ini on the replacement, and add 169.254.169.254 to NO_PROXY.' }
                            elseif ($mode -match '(?i)clientsecret') { Add-FosFinding -Severity info -Area 'grafana' -Problem "datasource '$($d.name)' uses an app registration client secret (portable)" -Fix 'The secret is in grafana.db secure_json_data, encrypted with security.secret_key. Route B keeps it; Route A needs it re-entered.' }
                        }
                        if ($d.health -and $d.health -notmatch '(?i)^ok$') { Add-FosFinding -Severity warn -Area 'grafana' -Problem "datasource '$($d.name)' ($($d.type)) health is '$($d.health)': $($d.healthMessage)" -Fix 'Already failing before the move. Record it so the replacement is not blamed.' }
                        if (($env:COMPUTERNAME -and $d.url -match [regex]::Escape($env:COMPUTERNAME)) -or ($OldServer -and $d.url -match [regex]::Escape($OldServer))) { Add-FosFinding -Severity warn -Area 'grafana' -Problem "datasource '$($d.name)' points at this host by name: $($d.url)" -Fix 'Repoint to localhost or to the DNS alias on the replacement.' }
                    }
                } catch {} }
                $srch = Invoke-FosWebDirect "$GrafanaUrl/api/search?type=dash-db&limit=5000" -Headers $h -TimeoutSec 30
                if ($srch.ok) { try { $api.dashboards = @($srch.body | ConvertFrom-Json | ForEach-Object { [ordered]@{ uid = $_.uid; title = $_.title; folder = "$($_.folderTitle)" } }) } catch {} }
                $fold = Invoke-FosWebDirect "$GrafanaUrl/api/folders?limit=1000" -Headers $h -TimeoutSec 20
                if ($fold.ok) { try { $api.folders = @($fold.body | ConvertFrom-Json | ForEach-Object { "$($_.title)" }) } catch {} }
                $rules = Invoke-FosWebDirect "$GrafanaUrl/api/v1/provisioning/alert-rules" -Headers $h -TimeoutSec 20
                if ($rules.ok) { try { $api.alertRules = @($rules.body | ConvertFrom-Json | ForEach-Object { [ordered]@{ uid = $_.uid; title = $_.title; folderUID = $_.folderUID } }) } catch {} }
                $chan = Invoke-FosWebDirect "$GrafanaUrl/api/alert-notifications" -Headers $h -TimeoutSec 20
                if ($chan.ok) { try { $api.legacyChannels = @($chan.body | ConvertFrom-Json | ForEach-Object { "$($_.name) [$($_.type)]" }) } catch {} }
                $cps = Invoke-FosWebDirect "$GrafanaUrl/api/v1/provisioning/contact-points" -Headers $h -TimeoutSec 20
                if ($cps.ok) { try { $api.contactPoints = @($cps.body | ConvertFrom-Json | ForEach-Object { "$($_.name) [$($_.type)]" }) } catch {} }
                $plg = Invoke-FosWebDirect "$GrafanaUrl/api/plugins?embedded=0" -Headers $h -TimeoutSec 20
                if ($plg.ok) { try { $api.plugins = @($plg.body | ConvertFrom-Json | Where-Object { $_.signature -ne 'internal' } | ForEach-Object { "$($_.id) $($_.info.version) $($_.type)$(if ($_.angularDetected) { ' ANGULAR' })" }) } catch {} }
                $st = Invoke-FosWebDirect "$GrafanaUrl/api/admin/stats" -Headers $h -TimeoutSec 20
                if ($st.ok) { try { $sj = $st.body | ConvertFrom-Json; $api.stats = [ordered]@{ users = $sj.users; orgs = $sj.orgs; dashboards = $sj.dashboards; datasources = $sj.datasources; alerts = $sj.alerts; activeUsers = $sj.activeUsers; snapshots = $sj.snapshots; playlists = $sj.playlists; stars = $sj.stars } } catch {} }
                $usr = Invoke-FosWebDirect "$GrafanaUrl/api/org/users?perpage=1000" -Headers $h -TimeoutSec 20
                if ($usr.ok) { try { $uj = @($usr.body | ConvertFrom-Json); $api.orgUserCount = $uj.Count; $api.orgAdmins = @($uj | Where-Object { $_.role -eq 'Admin' } | ForEach-Object { "$($_.login)" }); $api.recentlySeen = @($uj | Where-Object { "$($_.lastSeenAtAge)" -match '^(<\s*)?\d+\s*(m|h|d|minute|hour|day)s?$' } | ForEach-Object { "$($_.login) ($($_.lastSeenAtAge))" }) } catch {} }
                $sa = Invoke-FosWebDirect "$GrafanaUrl/api/serviceaccounts/search?perpage=500" -Headers $h -TimeoutSec 20
                if ($sa.ok) { try { $saj = $sa.body | ConvertFrom-Json; $api.serviceAccounts = @($saj.serviceAccounts | ForEach-Object { "$($_.name) [$($_.role)] tokens=$($_.tokens)$(if ($_.isDisabled) { ' DISABLED' })" }) } catch {} }
                $lic = Invoke-FosWebDirect "$GrafanaUrl/api/licensing/token" -Headers $h -TimeoutSec 20
                if ($lic.ok) { try { $lj = $lic.body | ConvertFrom-Json; $api.licensingToken = [ordered]@{ url = "$($lj.url)"; slug = "$($lj.slug)"; exp = $(if ($lj.exp) { ([DateTimeOffset]::FromUnixTimeSeconds([long]$lj.exp)).UtcDateTime.ToString('s') } else { '' }); includedUsers = "$($lj.included_users)"; status = "$($lj.status)"; trial = [bool]$lj.trial } } catch {} }
            } else {
                $api.note = 'no -GrafanaApiKey / -GrafanaCredential supplied: only /api/health read. Datasources, licence status and consumers by login are in the Export-GrafanaContent output instead.'
            }
            $g.api = $api
        }
    }
    $M.grafana = $g
    if ($Sanitize -and $g.rootUrl) { try { Add-FosMask ([uri]$g.rootUrl).Host 'GRAFANA-ALIAS' } catch {} }

    Start-FosStep 'Prometheus (APPOPS role)'
    $psvc = @($M.services | Where-Object { $_.name -match '(?i)prometheus' -or $_.displayName -match '(?i)prometheus' -or $_.effectiveCommand -match '(?i)prometheus' }) | Select-Object -First 1
    $pr = [ordered]@{ service = $null; exe = $null; version = ''; goVersion = ''; configFile = $null; configText = $null; configRedacted = ''
                      scrapeJobs = @(); targetFiles = @(); targets = @(); retention = ''; retentionSize = ''; tsdbPath = ''; tsdbBytes = 0
                      ruleFiles = @(); api = $null; metricFamilies = @(); command = ''; appDirectory = ''; flags = [ordered]@{}; effectiveFlags = $null
                      listenAddress = ''; externalUrl = ''; tsdb = $null; global = [ordered]@{}; alertmanagers = @(); remoteWrite = 0; remoteRead = 0
                      staticTargets = @(); downByClass = [ordered]@{} }
    Invoke-Section 'prometheus' {
        if ($psvc) {
            $pr.service = $psvc.name
            $pr.command = "$($psvc.effectiveCommand)"
            $pr.appDirectory = "$($psvc.nssm.appDirectory)"
            $bin = $pr.command
            $pr.exe = Get-FosExeFromCommand $bin
            foreach ($fl in 'config.file', 'storage.tsdb.path', 'storage.tsdb.retention', 'storage.tsdb.retention.time', 'storage.tsdb.retention.size', 'web.listen-address', 'web.external-url', 'web.route-prefix',
                             'web.enable-lifecycle', 'web.enable-admin-api', 'storage.tsdb.no-lockfile', 'storage.tsdb.wal-compression', 'log.level', 'log.format', 'query.timeout', 'query.max-samples', 'web.read-timeout', 'web.max-connections',
                             'storage.remote.flush-deadline', 'alertmanager.notification-queue-capacity', 'rules.alert.for-outage-tolerance', 'web.page-title', 'web.console.templates', 'web.console.libraries') {
                $v = Get-FosFlag $bin "--$fl"
                if ($v) { $pr.flags[$fl] = $v }
                elseif ($bin -match "(?:^|\s)--$([regex]::Escape($fl))(?:\s|$)") { $pr.flags[$fl] = 'true' }
            }
            $pr.configFile = "$($pr.flags['config.file'])"
            $pr.tsdbPath   = "$($pr.flags['storage.tsdb.path'])"
            $pr.retention  = "$($pr.flags['storage.tsdb.retention.time'])"; if (-not $pr.retention) { $pr.retention = "$($pr.flags['storage.tsdb.retention'])" }
            $pr.retentionSize = "$($pr.flags['storage.tsdb.retention.size'])"
            $pr.listenAddress = "$($pr.flags['web.listen-address'])"
            $pr.externalUrl = "$($pr.flags['web.external-url'])"
            # relative paths resolve against the process working directory: NSSM AppDirectory, else the exe folder
            $base = $(if ($pr.appDirectory) { $pr.appDirectory } elseif ($pr.exe) { Split-Path -Parent $pr.exe } else { '' })
            if ($pr.configFile -and -not [IO.Path]::IsPathRooted($pr.configFile) -and $base) { $pr.configFile = Join-Path $base $pr.configFile }
            if (-not $pr.configFile -and $base) { $pr.configFile = Join-Path $base 'prometheus.yml' }
            if ($pr.tsdbPath -and -not [IO.Path]::IsPathRooted($pr.tsdbPath) -and $base) { $pr.tsdbPath = Join-Path $base $pr.tsdbPath }
            if (-not $pr.tsdbPath -and $base) { $pr.tsdbPath = Join-Path $base 'data' }
            if ($pr.exe -and (Test-Path -LiteralPath $pr.exe)) {
                $vi = (Get-Item -LiteralPath $pr.exe).VersionInfo
                $pr.exeFileVersion = "$($vi.FileVersion)"
                $v = ''
                try { $v = (& $pr.exe --version 2>&1 | Out-String) } catch {}
                if ($v -match 'prometheus, version ([0-9][0-9.]*)') { $pr.version = $Matches[1] } elseif ($v) { $pr.version = Format-FosTrim $v 60 }
                if ($v -match 'go version:\s*(\S+)') { $pr.goVersion = $Matches[1] }
                if ($v -match 'build date:\s*(\S+)') { $pr.buildDate = $Matches[1] }
            }
        }
        # auto detect the API URL from the listen address or the listener table
        if (-not $PrometheusUrl) {
            $port = ''
            if ($pr.listenAddress -match ':(\d+)$') { $port = $Matches[1] }
            if (-not $port) { $l = @($M.listeners | Where-Object { $_.process -match '(?i)prometheus' -or ($psvc -and $_.services -match "(^|,)$([regex]::Escape($psvc.name))(,|$)") }) | Select-Object -First 1; if ($l) { $port = "$($l.port)" } }
            if ($port) { $PrometheusUrl = "http://localhost:$port"; $pr.apiUrlAutoDetected = $PrometheusUrl }
        }
        if ($pr.configFile -and (Test-Path -LiteralPath $pr.configFile)) {
            $pr.configText = Get-Content -LiteralPath $pr.configFile -Raw
            $pr.configRedacted = Get-FosRedactedText $pr.configText
            $pr.configRedacted | Set-Content -LiteralPath (Join-Path $out 'config\prometheus.yml') -Encoding utf8
            $pr.configModified = (Get-Item -LiteralPath $pr.configFile).LastWriteTime.ToString('s')
            # comments stripped for structural questions, so a commented out alertmanager is not counted
            $live = (($pr.configText -split "`r?`n") | Where-Object { $_ -notmatch '^\s*#' }) -join "`n"
            foreach ($rx in [regex]::Matches($live, '(?m)^\s*-\s*job_name:\s*[''"]?([^''"\r\n#]+)')) { $pr.scrapeJobs += $rx.Groups[1].Value.Trim() }
            # two spellings: "- files: ['a.json']" inline, or "files:" then "- a.json" on the next line. [ \t] not \s
            # after "files:", or the match runs onto the next line and returns "- a.json" as the file name.
            foreach ($rx in [regex]::Matches($live, '(?m)^[ \t]*-?[ \t]*(?:files:[ \t]*)?\[?[ \t]*[''"]?([^''"\r\n\]#\s-][^''"\r\n\]#]*\.json)')) { $pr.targetFiles += $rx.Groups[1].Value.Trim() }
            foreach ($rx in [regex]::Matches($live, '(?m)files:[ \t]*\[([^\]]+)\]')) { foreach ($cand in ($rx.Groups[1].Value -split ',')) { $c2 = $cand.Trim().Trim('"', "'"); if ($c2 -match '\.json$') { $pr.targetFiles += $c2 } } }
            $pr.targetFiles = @($pr.targetFiles | Sort-Object -Unique)
            foreach ($rx in [regex]::Matches($live, '(?m)^\s*-\s*[''"]?([^''"\r\n#]*\.(?:yml|yaml|rules))[''"]?\s*$')) { $pr.ruleFiles += $rx.Groups[1].Value.Trim() }
            if ($live -match '(?m)^\s*scrape_interval:\s*(\S+)') { $pr.global['scrape_interval'] = $Matches[1] }
            if ($live -match '(?m)^\s*evaluation_interval:\s*(\S+)') { $pr.global['evaluation_interval'] = $Matches[1] }
            if ($live -match '(?m)^\s*scrape_timeout:\s*(\S+)') { $pr.global['scrape_timeout'] = $Matches[1] }
            if ($live -match '(?ms)^alerting:.*?alertmanagers:') {
                foreach ($rx in [regex]::Matches($live, '(?m)^\s*-\s*targets:\s*\[([^\]]*)\]')) { foreach ($tt in ($rx.Groups[1].Value -split ',')) { if ($tt.Trim() -match '9093') { $pr.alertmanagers += $tt.Trim().Trim('"', "'") } } }
                if ($live -match '(?ms)alertmanagers:.*?targets:\s*\r?\n\s*-\s*[''"]?([^\s''"]+:9093)') { $pr.alertmanagers += $Matches[1] }
                $pr.alertmanagers = @($pr.alertmanagers | Sort-Object -Unique)
            }
            $pr.remoteWrite = @([regex]::Matches($live, '(?m)^\s*remote_write:')).Count
            $pr.remoteRead  = @([regex]::Matches($live, '(?m)^\s*remote_read:')).Count
            $pr.hasRenameBridge = [bool]($live -match 'metric_relabel_configs')
            $pr.hasRelabel = [bool]($live -match '(?m)^\s*relabel_configs:')
            $pr.hasBasicAuth = [bool]($live -match '(?m)^\s*basic_auth:')
            $pr.hasTls = [bool]($live -match '(?m)^\s*tls_config:|scheme:\s*https')
            foreach ($rx in [regex]::Matches($live, '(?ms)static_configs:\s*\r?\n\s*-\s*targets:\s*\[([^\]]*)\]')) { foreach ($tt in ($rx.Groups[1].Value -split ',')) { $t2 = $tt.Trim().Trim('"', "'"); if ($t2) { $pr.staticTargets += $t2 } } }
            if ($env:COMPUTERNAME -and $pr.configText -match [regex]::Escape($env:COMPUTERNAME)) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem 'prometheus.yml names this host' -Fix 'Decide per entry on the replacement: a self scrape becomes localhost; a scrape OF this host stays until decommission.' }
            if ($pr.remoteWrite) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "prometheus.yml has $($pr.remoteWrite) remote_write block(s)" -Fix 'Two instances writing the same series to one remote during the parallel run will double count or conflict. Disable remote_write on the new instance until cutover.' }
            if ($pr.alertmanagers.Count) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "prometheus.yml sends alerts to $($pr.alertmanagers -join ', ')" -Fix 'Two instances alerting to one Alertmanager during the parallel run deduplicate by labels, so this is usually fine. Confirm the Alertmanager firewall allows the new host.' }
            if (-not $pr.hasRenameBridge -and $pr.scrapeJobs.Count) { Add-FosFinding -Severity info -Area 'prometheus' -Problem 'no metric_relabel_configs in prometheus.yml' -Fix 'The wmi_ to windows_ bridge has to be added on the replacement by hand. Import mode prints the block.' }
        } else {
            Add-FosFinding -Severity blocker -Area 'prometheus' -Problem "prometheus.yml not found$(if ($pr.configFile) { " at $($pr.configFile)" })" -Fix 'Read the service command above and locate the config by hand.'
        }
        $base2 = $(if ($pr.configFile) { Split-Path -Parent $pr.configFile } else { '' })
        foreach ($tf in @($pr.targetFiles | Sort-Object -Unique)) {
            $path = $tf
            if (-not [IO.Path]::IsPathRooted($path) -and $base2) { $path = Join-Path $base2 $tf }
            $hits = @(Get-ChildItem -Path $path -ErrorAction SilentlyContinue)
            if (-not $hits.Count) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "file_sd path $tf matches no file" -Fix 'A glob that matches nothing today, or a broken reference. Either way the replacement inherits it.'; continue }
            foreach ($file in $hits) {
                try {
                    $j = Get-Content -LiteralPath $file.FullName -Raw | ConvertFrom-Json
                    Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $out "config\targets-$($file.Name)") -Force -ErrorAction SilentlyContinue
                    foreach ($grp in @($j)) {
                        foreach ($t in @($grp.targets)) {
                            $lbl = [ordered]@{}
                            if ($grp.labels) { foreach ($p2 in $grp.labels.PSObject.Properties) { $lbl[$p2.Name] = "$($p2.Value)" } }
                            $pr.targets += [ordered]@{ file = $file.Name; target = "$t"; labels = $lbl; modified = $file.LastWriteTime.ToString('s') }
                        }
                    }
                } catch { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "target file $($file.Name) is not valid JSON" -Fix 'Prometheus ignores the whole file. Fix it before it is copied.' }
            }
        }
        foreach ($rf in @($pr.ruleFiles)) {
            $rp = $rf; if (-not [IO.Path]::IsPathRooted($rp) -and $base2) { $rp = Join-Path $base2 $rf }
            foreach ($file in @(Get-ChildItem -Path $rp -ErrorAction SilentlyContinue)) { Copy-Item -LiteralPath $file.FullName -Destination (Join-Path $out "config\rules-$($file.Name)") -Force -ErrorAction SilentlyContinue }
        }
        # TSDB on disk: size, block count, and the oldest and newest sample. The oldest sample tells
        # you what the retention actually is, whatever the flag says.
        if ($pr.tsdbPath -and (Test-Path -LiteralPath $pr.tsdbPath)) {
            $pr.tsdbBytes = Get-DirSize $pr.tsdbPath 240
            $t = [ordered]@{ path = $pr.tsdbPath; blocks = 0; oldestSample = ''; newestSample = ''; walBytes = 0; headBytes = 0; lockFile = [bool](Test-Path -LiteralPath (Join-Path $pr.tsdbPath 'lock')) }
            $minT = $null; $maxT = $null
            foreach ($bd in @(Get-ChildItem -LiteralPath $pr.tsdbPath -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^[0-9A-Z]{26}$' })) {
                $t.blocks++
                $mp = Join-Path $bd.FullName 'meta.json'
                if (Test-Path -LiteralPath $mp) { try { $mj = Get-Content -LiteralPath $mp -Raw | ConvertFrom-Json
                        if ($null -eq $minT -or [long]$mj.minTime -lt $minT) { $minT = [long]$mj.minTime }
                        if ($null -eq $maxT -or [long]$mj.maxTime -gt $maxT) { $maxT = [long]$mj.maxTime } } catch {} }
            }
            if ($null -ne $minT) { $t.oldestSample = ([DateTimeOffset]::FromUnixTimeMilliseconds($minT)).UtcDateTime.ToString('s') + 'Z'; $t.dataDays = [math]::Round(((Get-Date).ToUniversalTime() - ([DateTimeOffset]::FromUnixTimeMilliseconds($minT)).UtcDateTime).TotalDays, 1) }
            if ($null -ne $maxT) { $t.newestSample = ([DateTimeOffset]::FromUnixTimeMilliseconds($maxT)).UtcDateTime.ToString('s') + 'Z' }
            $t.walBytes = Get-DirSize (Join-Path $pr.tsdbPath 'wal') 60
            $t.headBytes = Get-DirSize (Join-Path $pr.tsdbPath 'chunks_head') 60
            $pr.tsdb = $t
        } elseif ($pr.tsdbPath) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "TSDB path $($pr.tsdbPath) does not exist" -Fix 'The flag or the working directory resolution is wrong. Find the data folder by hand; its size sets the disk on the replacement.' }
        if ($PrometheusUrl) {
            $api = [ordered]@{ url = $PrometheusUrl }
            $fres = Invoke-FosWebDirect "$PrometheusUrl/api/v1/status/flags" -TimeoutSec 20
            if ($fres.ok) { try { $fj = ($fres.body | ConvertFrom-Json).data; $api.flags = [ordered]@{}
                    foreach ($k in 'config.file', 'storage.tsdb.path', 'storage.tsdb.retention', 'storage.tsdb.retention.time', 'storage.tsdb.retention.size', 'web.listen-address', 'web.external-url', 'web.enable-lifecycle', 'web.enable-admin-api', 'storage.tsdb.min-block-duration', 'storage.tsdb.max-block-duration', 'query.max-samples', 'query.timeout') {
                        if ($null -ne $fj.$k -and "$($fj.$k)" -ne '') { $api.flags[$k] = "$($fj.$k)" } }
                    $pr.effectiveFlags = $api.flags
                    # the API is authoritative over the command line parse
                    $er = "$($api.flags['storage.tsdb.retention.time'])"; if (-not $er -or $er -eq '0s') { $er = "$($api.flags['storage.tsdb.retention'])" }
                    if ($er -and $er -ne '0s') { $pr.retention = $er }
                    $wd = $(if ($pr.appDirectory) { $pr.appDirectory } elseif ($pr.exe) { Split-Path -Parent $pr.exe } else { '' })
                    foreach ($pair in @(@{ f = 'storage.tsdb.path'; k = 'tsdbPathEffective' }, @{ f = 'config.file'; k = 'configFileEffective' })) {
                        $pv = "$($api.flags[$pair.f])"
                        if ($pv) { if (-not [IO.Path]::IsPathRooted($pv) -and $wd) { $pv = Join-Path $wd $pv }; $pr[$pair.k] = $pv }
                    }
                } catch {} }
            $bq = Invoke-FosWebDirect ("$PrometheusUrl/api/v1/query?query=" + [uri]::EscapeDataString('prometheus_build_info')) -TimeoutSec 20
            if ($bq.ok) { try { $bj = ($bq.body | ConvertFrom-Json).data.result; if (@($bj).Count) { $m0 = @($bj)[0].metric; if ($m0.version) { $pr.version = "$($m0.version)" }; if ($m0.goversion) { $pr.goVersion = "$($m0.goversion)" }; $api.buildInfo = "$($m0.version) go $($m0.goversion) $($m0.revision)" } } catch {} }
            $bi = Invoke-FosWebDirect "$PrometheusUrl/api/v1/status/buildinfo" -TimeoutSec 15
            if ($bi.ok) { try { $bij = ($bi.body | ConvertFrom-Json).data; if ($bij.version -and -not $pr.version) { $pr.version = "$($bij.version)" } } catch {} }
            $rt = Invoke-FosWebDirect "$PrometheusUrl/api/v1/status/runtimeinfo" -TimeoutSec 15
            if ($rt.ok) { try { $rj = ($rt.body | ConvertFrom-Json).data; $api.runtime = [ordered]@{ startTime = (ConvertTo-FosStamp $rj.startTime); reloadConfigSuccess = "$($rj.reloadConfigSuccess)"; lastConfigTime = (ConvertTo-FosStamp $rj.lastConfigTime); storageRetention = "$($rj.storageRetention)"; goroutines = "$($rj.goroutineCount)" }; if ($rj.storageRetention) { $pr.retention = "$($rj.storageRetention)" } } catch {} }
            $t = Invoke-FosWebDirect "$PrometheusUrl/api/v1/targets" -TimeoutSec 30
            if ($t.ok) { try {
                $j = $t.body | ConvertFrom-Json
                $api.targets = @($j.data.activeTargets | ForEach-Object {
                    $inst = "$($_.labels.instance)"; $le = "$($_.lastError)"
                    $cls = 'up'
                    if ($_.health -ne 'up') {
                        if ($inst -match '(?i)SERVERURL|:PORT$|#\{|<|>|example|placeholder') { $cls = 'PLACEHOLDER' }
                        elseif ($le -match '(?i)no such host|name resolution|could not resolve|lookup .* no such') { $cls = 'DNS' }
                        elseif ($le -match '(?i)connection refused|actively refused|forcibly closed') { $cls = 'REFUSED' }
                        elseif ($le -match '(?i)timeout|deadline exceeded|i/o timeout') { $cls = 'TIMEOUT' }
                        elseif ($le -match '(?i)certificate|tls|x509') { $cls = 'TLS' }
                        elseif ($le -match '(?i)401|403|unauthori') { $cls = 'AUTH' }
                        elseif ($le -match '(?i)404|server returned HTTP status') { $cls = 'HTTP' }
                        elseif ($le -match '(?i)sample limit|label|parse|invalid|expected') { $cls = 'PARSE' }
                        else { $cls = 'OTHER' }
                    }
                    [ordered]@{ job = "$($_.labels.job)"; instance = $inst; health = "$($_.health)"; lastError = $le; lastScrape = (ConvertTo-FosStamp $_.lastScrape); scrapeUrl = "$($_.scrapeUrl)"; class = $cls
                                hostName = $(if ($inst -match '^\[?([^\]:]+)\]?(?::\d+)?$') { $Matches[1] } else { $inst }) } })
                $down = @($api.targets | Where-Object { $_.health -ne 'up' })
                $upT  = @($api.targets | Where-Object { $_.health -eq 'up' })
                foreach ($grp in ($down | Group-Object { $_.class })) { $pr.downByClass[$grp.Name] = $grp.Count }
                # the fleet: every host whose inbound 9182 rule must admit the NEW Prometheus IP
                @($upT | ForEach-Object { "$($_.job),$($_.instance),$($_.scrapeUrl)" }) | Set-Content -LiteralPath (Join-Path $out 'config\scrape-targets-up.csv') -Encoding utf8
                @($down | ForEach-Object { "$($_.job),$($_.instance),$($_.class),$($_.lastError -replace ',', ';')" }) | Set-Content -LiteralPath (Join-Path $out 'config\scrape-targets-down.csv') -Encoding utf8
                # DNS and TCP truth for the down ones, so the register entry says WHY, not just DOWN
                $probe = @($down | Where-Object { $_.class -in 'DNS', 'REFUSED', 'TIMEOUT', 'OTHER' } | ForEach-Object { $_.instance } | Sort-Object -Unique | Select-Object -First 60)
                if ($probe.Count) {
                    $pres = Invoke-FosTimeout {
                        param($list)
                        $o = @{}
                        foreach ($i in $list) {
                            $hn = $i; $pt = 0
                            if ($i -match '^\[?([^\]:]+)\]?:(\d+)$') { $hn = $Matches[1]; $pt = [int]$Matches[2] }
                            $r = @{ dns = ''; tcp = '' }
                            try { $ips = [System.Net.Dns]::GetHostAddresses($hn); $r.dns = (@($ips | ForEach-Object { $_.IPAddressToString }) -join ' ') } catch { $r.dns = 'NXDOMAIN' }
                            if ($r.dns -ne 'NXDOMAIN' -and $pt) {
                                try { $c = New-Object System.Net.Sockets.TcpClient; $ar = $c.BeginConnect($hn, $pt, $null, $null)
                                      if ($ar.AsyncWaitHandle.WaitOne(3000)) { try { $c.EndConnect($ar); $r.tcp = 'open' } catch { $r.tcp = 'refused' } } else { $r.tcp = 'timeout' }
                                      $c.Close() } catch { $r.tcp = 'refused' }
                            }
                            $o[$i] = $r
                        }
                        $o
                    } 150 @{} 'down target DNS and TCP probe' -ArgumentList (,@($probe))
                    if ($pres) { foreach ($d in $down) { if ($pres.ContainsKey($d.instance)) { $d.dns = "$($pres[$d.instance].dns)"; $d.tcp = "$($pres[$d.instance].tcp)" } } }
                }
                if ($down.Count) {
                    $cls = ($pr.downByClass.Keys | ForEach-Object { "$_=$($pr.downByClass[$_])" }) -join ', '
                    Add-FosFinding -Severity warn -Area 'prometheus' -Problem "$($down.Count) of $(@($api.targets).Count) scrape targets are DOWN ($cls)" -Fix 'PLACEHOLDER and DNS entries are cruft to remove from the target files. REFUSED on a live host is a stopped exporter or a firewall. Decide each before the cutover gate runs, or it compares against a broken baseline.'
                    $selfDown = @($down | Where-Object { ($env:COMPUTERNAME -and $_.instance -match [regex]::Escape($env:COMPUTERNAME)) -or $_.instance -match '(?i)^(localhost|127\.0\.0\.1)' })
                    if ($selfDown.Count) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "this host's own scrape target is down: $($selfDown[0].instance) ($($selfDown[0].lastError))" }
                }
                $noJob = @($api.targets | Where-Object { -not $_.job })
                if ($noJob.Count) { Add-FosFinding -Severity info -Area 'prometheus' -Problem "$($noJob.Count) target(s) have no job label" }
            } catch {} }
            $n = Invoke-FosWebDirect "$PrometheusUrl/api/v1/label/__name__/values" -TimeoutSec 90
            if ($n.ok) { try {
                $all = @(($n.body | ConvertFrom-Json).data)
                $pr.metricFamilies = @($all)
                $api.metricFamilyCount = $all.Count
                $api.wmiFamilies = @($all | Where-Object { $_ -like 'wmi_*' }).Count
                $api.windowsFamilies = @($all | Where-Object { $_ -like 'windows_*' }).Count
                $api.textfileFamilies = @($all | Where-Object { $_ -notlike 'wmi_*' -and $_ -notlike 'windows_*' -and $_ -notlike 'prometheus_*' -and $_ -notlike 'go_*' -and $_ -notlike 'process_*' -and $_ -notlike 'net_conntrack_*' -and $_ -notlike 'scrape_*' -and $_ -ne 'up' }).Count
                @($all | Sort-Object) | Set-Content -LiteralPath (Join-Path $out 'config\metric-names.txt') -Encoding utf8
            } catch {} }
            foreach ($cq in @(@{ k = 'headSeries'; q = 'prometheus_tsdb_head_series' }, @{ k = 'targetsUp'; q = 'count(up == 1)' }, @{ k = 'targetsDown'; q = 'count(up == 0)' }, @{ k = 'jobs'; q = 'count(count by (job) (up))' }, @{ k = 'textfileScrapeErrors'; q = 'sum({__name__=~"(wmi|windows)_textfile_scrape_error"})' }, @{ k = 'samplesPerSecond'; q = 'rate(prometheus_tsdb_head_samples_appended_total[5m])' }, @{ k = 'oldestSampleAgeDays'; q = '(time() - prometheus_tsdb_lowest_timestamp_seconds) / 86400' }, @{ k = 'oldestSampleAgeDaysLegacy'; q = '(time() - prometheus_tsdb_lowest_timestamp / 1000) / 86400' })) {
                $qr = Invoke-FosWebDirect ("$PrometheusUrl/api/v1/query?query=" + [uri]::EscapeDataString($cq.q)) -TimeoutSec 30
                if ($qr.ok) { try { $res = @(($qr.body | ConvertFrom-Json).data.result); if ($res.Count -eq 1) { $api[$cq.k] = [math]::Round([double]$res[0].value[1], 2) } } catch {} }
            }
            $r = Invoke-FosWebDirect "$PrometheusUrl/api/v1/rules" -TimeoutSec 20
            if ($r.ok) { try { $api.ruleGroups = @(($r.body | ConvertFrom-Json).data.groups | ForEach-Object { [ordered]@{ name = $_.name; file = $_.file; rules = @($_.rules).Count } }) } catch {} }
            $am = Invoke-FosWebDirect "$PrometheusUrl/api/v1/alertmanagers" -TimeoutSec 15
            if ($am.ok) { try { $amj = ($am.body | ConvertFrom-Json).data; $api.alertmanagersActive = @($amj.activeAlertmanagers | ForEach-Object { "$($_.url)" }); $api.alertmanagersDropped = @($amj.droppedAlertmanagers | ForEach-Object { "$($_.url)" }) } catch {} }
            $al = Invoke-FosWebDirect "$PrometheusUrl/api/v1/alerts" -TimeoutSec 15
            if ($al.ok) { try { $alj = ($al.body | ConvertFrom-Json).data; $api.firingAlerts = @($alj.alerts | Where-Object { $_.state -eq 'firing' } | ForEach-Object { "$($_.labels.alertname)" }) } catch {} }
            if (-not $fres.ok -and -not $t.ok) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem "Prometheus API at $PrometheusUrl did not answer" -Fix 'Prometheus must be running for the target and metric baselines. If it listens on another port pass -PrometheusUrl.' }
            $pr.api = $api
        } else { Add-FosFinding -Severity warn -Area 'prometheus' -Problem 'Prometheus API URL could not be determined (no --web.listen-address flag and no listener found)' -Fix 'Pass -PrometheusUrl http://localhost:<port>.' }
        if (-not $pr.retention) { Add-FosFinding -Severity warn -Area 'prometheus' -Problem 'no retention flag on the service and none reported by the API: Prometheus default applies (15d on 2.x)' -Fix 'The parallel run must be at least the retention window. Confirm from the TSDB oldest sample below.' }
        if ($pr.tsdb -and $pr.tsdb.dataDays) {
            $retDays = 0
            if ($pr.retention -match '^(\d+)d$') { $retDays = [int]$Matches[1] } elseif ($pr.retention -match '^(\d+)h$') { $retDays = [int]$Matches[1] / 24 } elseif (-not $pr.retention) { $retDays = 15 }
            if ($retDays -and $pr.tsdb.dataDays -lt ($retDays * 0.8)) { Add-FosFinding -Severity info -Area 'prometheus' -Problem "TSDB holds $($pr.tsdb.dataDays) days of data against a $retDays day retention" -Fix 'Either the instance was rebuilt recently or data was lost. Neither is a migration problem, but the parallel run needs the full retention window regardless.' }
        }
    }
    $M.prometheus = $pr

    # 9091 is the Pushgateway default port. On this estate Grafana uses it, which is not a push path.
    $pg = @($M.listeners | Where-Object { $_.port -eq 9091 -and $_.process -notmatch '(?i)grafana' })
    if ($pg) {
        $M.pushgateway = $pg
        Add-FosFinding -Severity info -Area 'prometheus' -Problem "something other than Grafana is listening on 9091 ($($pg[0].process)): that is the Pushgateway default port" -Fix 'Confirm whether this is a Pushgateway (push model). It changes the firewall direction.'
    }
}

# ================================================================= 14. event log
Start-FosStep 'service and NSSM events, last 7 days'
$M.events = [ordered]@{ scm = @(); nssm = @(); application = @() }
Invoke-Section 'events' {
    $names = @($M.services | ForEach-Object { $_.name } | Where-Object { $_ })
    $since = (Get-Date).AddDays(-7)
    $scm = Invoke-FosTimeout {
        param($s)
        Get-WinEvent -FilterHashtable @{ LogName = 'System'; ProviderName = 'Service Control Manager'; StartTime = $s; Level = 1, 2, 3 } -MaxEvents 400 -ErrorAction SilentlyContinue |
            ForEach-Object { [pscustomobject]@{ time = $_.TimeCreated.ToString('s'); id = $_.Id; level = $_.LevelDisplayName; message = ($_.Message -replace '\s+', ' ') } }
    } 60 @() 'SCM events' -ArgumentList $since
    $M.events.scm = @($scm | Where-Object { $m1 = $_.message; @($names | Where-Object { $m1 -match [regex]::Escape($_) }).Count } | Select-Object -First 40 | ForEach-Object { [ordered]@{ time = $_.time; id = $_.id; level = $_.level; message = (Format-FosTrim $_.message 180) } })
    $ns = Invoke-FosTimeout {
        param($s)
        Get-WinEvent -FilterHashtable @{ LogName = 'Application'; ProviderName = 'nssm'; StartTime = $s } -MaxEvents 300 -ErrorAction SilentlyContinue |
            ForEach-Object { [pscustomobject]@{ time = $_.TimeCreated.ToString('s'); id = $_.Id; level = $_.LevelDisplayName; message = ($_.Message -replace '\s+', ' ') } }
    } 60 @() 'nssm events' -ArgumentList $since
    $M.events.nssm = @($ns | Select-Object -First 40 | ForEach-Object { [ordered]@{ time = $_.time; id = $_.id; level = $_.level; message = (Format-FosTrim $_.message 180) } })
    $restarts = @($ns | Where-Object { $_.message -match '(?i)restart|exited|died|killed' })
    if ($restarts.Count -gt 5) { Add-FosFinding -Severity warn -Area 'services' -Problem "NSSM logged $($restarts.Count) service exit or restart events in 7 days" -Fix 'A service that restarts on the old box will restart on the new one. Read the nssm events in the report.' }
}

# ================================================================= report
Start-FosStep 'writing report'
Add-FosHead "SERVER CAPTURE - $(Get-FosMask $env:COMPUTERNAME)"
Add-FosKV 'Generated'    (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
Add-FosKV 'Suite'        "Invoke-ServerCapture $SuiteVersion"
Add-FosKV 'Role'         $Role
Add-FosKV 'Host'         (Get-FosMask $M.system.host)
Add-FosKV 'Domain'       (Get-FosMask $M.system.domain)
Add-FosKV 'OU'           (Get-FosMask (Format-FosTrim $M.system.distinguishedName 90))
Add-FosKV 'OS'           "$($M.system.os) ($($M.system.version) build $($M.system.build))"
Add-FosKV 'Installed'    $M.system.installDate
Add-FosKV 'Last boot'    $M.system.lastBoot
Add-FosKV 'CPU / RAM'    "$($M.system.logicalCpus) logical / $($M.system.memoryGB) GB"
Add-FosKV 'PowerShell'   $M.system.powershell
Add-FosKV '.NET release' $M.system.dotNetRelease
Add-FosKV 'Exec policy'  $M.system.executionPolicy
Add-FosKV 'Time zone'    $M.system.timeZone
Add-FosKV 'Pending reboot' $M.system.pendingReboot
Add-FosKV 'Uptime days'  $M.system.uptimeDays
Add-FosKV 'Domain role'  ("{0} ({1})" -f $M.system.domainRole, $M.system.domainRoleName)
Add-FosKV 'AD DS installed' $M.system.adDsInstalled
Add-FosKV 'Capture folder' $out

Add-FosSub 'Azure'
Add-FosKV 'IMDS reachable' $M.azure.imdsReachable
if ($M.azure.imdsReachable) {
    Add-FosKV 'VM name'        (Get-FosMask $M.azure.vmName)
    Add-FosKV 'Resource group' (Get-FosMask $M.azure.resourceGroup)
    Add-FosKV 'Subscription'   (Get-FosMask $M.azure.subscriptionId)
    Add-FosKV 'Location / size' "$($M.azure.location) / $($M.azure.vmSize)"
    Add-FosKV 'MI token'       $M.azure.identityToken
    if ($M.azure.identityClientId) { Add-FosKV 'MI client id'    $M.azure.identityClientId }
    if ($M.azure.identityError)    { Add-FosKV 'MI error'        $M.azure.identityError }
    Add-FosLine '  The client id above is the identity a Grafana datasource on default settings uses.'
    Add-FosLine '  A system assigned identity is bound to this VM resource and does not move with a copy.'
} else { Add-FosKV 'IMDS error' $M.azure.imdsError; Add-FosLine '  (not an Azure VM, or 169.254.169.254 is blocked: a managed identity cannot work from here)' }

Add-FosSub 'volumes'
Add-FosTable -Rows @($M.volumes | ForEach-Object { [pscustomobject]@{ Drive = $_.letter; Label = $_.label; FS = $_.fs; SizeGB = $_.capacityGB; FreeGB = $_.freeGB } }) -Columns ([ordered]@{ Drive = 7; Label = 20; FS = 6; SizeGB = 9; FreeGB = 9 })

Add-FosSub 'network'
foreach ($a in $M.network.adapters) { Add-FosKV (Format-FosTrim $a.description 26) ("{0}  gw={1}  dns={2}  dhcp={3}" -f (@($a.ip) -join ','), (@($a.gateway) -join ','), (@($a.dns) -join ','), $a.dhcp) }
Add-FosLine ''
Add-FosLine '  WinHTTP proxy (machine-wide, used by services):'
foreach ($l in @("$($M.network.winHttpProxy)" -split "`n")) { if ($l.Trim()) { Add-FosLine "    $($l.Trim())" } }
Add-FosLine ''
Add-FosLine '  WinINET proxy per user profile - THIS is what Invoke-WebRequest in a task uses:'
if (-not $M.network.userProxies.Count) { Add-FosLine '    (none set on any loaded profile)' }
foreach ($p in $M.network.userProxies) { Add-FosLine ("    {0,-40} enabled={1} server={2} pac={3}" -f (Get-FosMask $p.account), $p.enabled, $p.server, $p.autoConfig) }
Add-FosLine ''
Add-FosLine '  Proxy as GO programs see it (Grafana, Prometheus, exporters read only these):'
if (-not $M.network.goProxyEnv.Count) { Add-FosLine '    (no HTTP_PROXY / HTTPS_PROXY / NO_PROXY set at machine level or on any NSSM service)' }
foreach ($k in $M.network.goProxyEnv.Keys) { Add-FosLine ("    {0,-32} {1}" -f $k, (Get-FosMask $M.network.goProxyEnv[$k])) }
if ($M.network.winHttpBypass.Count) { Add-FosLine ("  WinHTTP bypass list: {0}" -f ($M.network.winHttpBypass -join '; ')) }
Add-FosLine ("  This host's IPv4 addresses (the fleet's inbound rules are scoped to these): {0}" -f (Get-FosMask ($M.network.ipAddresses -join ', ')))
if ($M.network.hostsEntries.Count) {
    Add-FosLine ''
    Add-FosLine '  hosts file overrides (these do NOT migrate and are invisible in DNS):'
    foreach ($h in $M.network.hostsEntries) { Add-FosLine "    $(Get-FosMask $h)" }
}
if ($M.network.shares.Count) {
    Add-FosLine ''
    Add-FosLine '  SMB shares:'
    foreach ($s in $M.network.shares) { Add-FosLine ("    {0,-20} {1}" -f $s.name, (Get-FosMask $s.path)) }
}

Add-FosSub 'firewall profiles'
Add-FosTable -Rows @($M.firewall.profiles | ForEach-Object { [pscustomobject]@{ Profile = $_.name; Enabled = $_.enabled; Inbound = $_.inboundAction; Outbound = $_.outboundAction } }) -Columns ([ordered]@{ Profile = 12; Enabled = 9; Inbound = 10; Outbound = 10 })
Add-FosSub 'firewall rules added by hand (enabled, not part of a Windows group)'
Add-FosTable -Rows @($M.firewall.rules | ForEach-Object { [pscustomobject]@{ Rule = $_.name; Dir = $_.direction; Action = $_.action; Proto = $_.protocol; Port = $_.localPort } }) -Columns ([ordered]@{ Rule = 44; Dir = 9; Action = 7; Proto = 6; Port = 14 })

Add-FosSub 'listening ports (and whether a rule lets anything in)'
Add-FosTable -Rows @($M.listeners | Where-Object { $_.address -notin '127.0.0.1', '::1' } | ForEach-Object { [pscustomobject]@{ Port = $_.port; Process = $_.process; Service = $_.services; Firewall = $_.firewall } }) -Columns ([ordered]@{ Port = 7; Process = 24; Service = 22; Firewall = 20 })

Add-FosSub 'WHO IS CONNECTED RIGHT NOW (the consumers that break on cutover day)'
if (-not $M.consumers.Count) { Add-FosLine '  (no established connections to any application port at capture time)' }
foreach ($c in $M.consumers) {
    Add-FosLine ("  port {0,-6} {1,-20} {2} connection(s) from:" -f $c.port, $c.process, $c.connections)
    foreach ($r in @($c.remoteHosts)) { Add-FosLine ("      {0}" -f (Get-FosMask $r)) }
}
Add-FosLine '  Run the capture at a busy time of day as well; a quiet-hours list is not the consumer list.'

Add-FosSub 'user rights assignment (the part nobody documents)'
foreach ($k in $M.security.userRights.Keys) {
    $v = @($M.security.userRights[$k])
    if (-not $v.Count) { continue }
    Add-FosLine ("  {0,-34} {1}" -f $k, (Get-FosMask (Format-FosTrim ($v -join ', ') 120)))
}
Add-FosSub 'security posture'
Add-FosKV 'LmCompatibilityLevel' $M.security.lsa.lmCompatibilityLevel
Add-FosKV 'RestrictAnonymous'    $M.security.lsa.restrictAnonymous
Add-FosKV 'EnableLUA'            $M.security.uac.enableLUA
if ($M.security.smb) { Add-FosKV 'SMB signing required' $M.security.smb.requireSigning; Add-FosKV 'SMB1 enabled' $M.security.smb.enableSMB1 }
Add-FosKV 'Batch-logon GPO-managed' $M.security.batchLogonGpoManaged
if ($M.security.schannel.Count) {
    Add-FosLine ''
    Add-FosLine '  Schannel protocol overrides (absent = Windows default for this build):'
    foreach ($s in $M.security.schannel) { Add-FosLine ("    {0,-10} {1,-7} Enabled={2} DisabledByDefault={3}" -f $s.protocol, $s.side, $s.enabled, $s.disabledByDefault) }
}
foreach ($d in $M.security.dotNetCrypto) { Add-FosLine ("  .NET {0,-46} SchUseStrongCrypto={1} SystemDefaultTlsVersions={2}" -f ($d.key -replace '.*\\(WOW6432Node\\)?Microsoft', '$1Microsoft'), $d.schUseStrongCrypto, $d.systemDefaultTlsVersions) }

Add-FosSub 'services (Windows components filtered out by binary path)'
Add-FosTable -Rows @($M.services | ForEach-Object { [pscustomobject]@{ Name = $_.name; State = $_.state; Start = $_.startMode; Account = $_.startName; Path = $_.pathName } }) -Columns ([ordered]@{ Name = 26; State = 9; Start = 9; Account = 22; Path = 46 })
$nssmSvcs = @($M.services | Where-Object { $_.nssm })
if ($nssmSvcs.Count) {
    Add-FosLine ''
    Add-FosLine '  NSSM wrapped services, as the registry defines them (this is what the replacement must reproduce):'
    foreach ($s in $nssmSvcs) {
        Add-FosLine ("    {0}" -f $s.name)
        Add-FosLine ("      Application : {0}  exists={1}  fileVersion={2}" -f (Get-FosMask $s.nssm.application), $s.exeExists, $s.exeVersion)
        Add-FosLine ("      Parameters  : {0}" -f (Get-FosMask $s.nssm.appParameters))
        Add-FosLine ("      Directory   : {0}" -f (Get-FosMask $s.nssm.appDirectory))
        if ($s.nssm.appStdout -or $s.nssm.appStderr) { Add-FosLine ("      Stdout/err  : {0} | {1}  rotate={2}" -f (Get-FosMask $s.nssm.appStdout), (Get-FosMask $s.nssm.appStderr), $s.nssm.appRotateFiles) }
        if ($s.nssm.appExitDefault) { Add-FosLine ("      On exit     : {0}  restartDelay={1}" -f $s.nssm.appExitDefault, $s.nssm.appRestartDelay) }
        foreach ($ev in @($s.nssm.environment)) { Add-FosLine ("      Env         : {0}" -f (Get-FosMask (Get-FosRedactedText $ev))) }
    }
}

if ($M.tasks) {
    Add-FosSub 'scheduled tasks'
    Add-FosTable -Rows @($M.tasks | ForEach-Object {
        $n = @()
        if (@($_.actions | Where-Object { $_.placeholder }).Count) { $n += 'PLACEHOLDER' }
        if (@($_.actions | Where-Object { $_.scriptExists -eq $false }).Count) { $n += 'SCRIPT MISSING' }
        if (-not $_.hasRecurringTrigger) { $n += 'no recurring trigger' }
        if ($_.normallyLongRunning) { $n += "long-running ($($_.refusedLaunches24h)x322)" }
        if (-not $_.lastRun) { $n += 'never run' }
        if ($_.personalAccount) { $n += 'PERSONAL ACCT' }
        if ($_.logonType -eq 'Password' -and $_.batchLogon -eq 'NO') { $n += 'no batch logon' }
        [pscustomobject]@{ Task = $_.name; Account = (ConvertTo-FosSam $_.account); Logon = $_.logonType; Batch = $_.batchLogon; State = $_.state; Result = $_.lastResult; LastRun = $(if ($_.lastRun) { "$($_.lastRun)".Substring(0, 10) } else { '' }); Notes = ($n -join '; ') } }) `
        -Columns ([ordered]@{ Task = 38; Account = 24; Logon = 9; Batch = 7; State = 9; Result = 11; LastRun = 10; Notes = 36 })
    Add-FosLine ''
    Add-FosLine '  actions:'
    foreach ($t in $M.tasks) {
        foreach ($a in $t.actions) { Add-FosLine ("    {0,-40} {1} {2}" -f (Get-FosMask (Format-FosTrim $t.name 40)), (Get-FosMask $a.execute), (Get-FosMask (Format-FosTrim $a.arguments 110))) }
    }
    Add-FosLine '  Batch = does the account hold SeBatchLogonRight (YES / NO / UNKNOWN when held via a group this box cannot expand).'

    Add-FosSub 'IS LONG-RUNNING NORMAL ON THIS SERVER?'
    $lr = @($M.tasks | Where-Object { $_.normallyLongRunning })
    if ($lr.Count) {
        Add-FosLine '  Yes - these are sitting at Running right now on a server that works:'
        foreach ($t in $lr) { Add-FosLine ("    {0}  ({1} refused launches in 24h)" -f (Get-FosMask $t.name), $t.refusedLaunches24h) }
        Add-FosLine ''
        Add-FosLine '  So on the replacement, Running + a stream of event 322 is EXPECTED, not a hang.'
        Add-FosLine '  Judge those tasks on their .prom output and on CPU burn, never on task state.'
    } else {
        Add-FosLine '  No - every task here starts and finishes.'
        Add-FosLine '  So on the replacement, any task stuck at Running for more than a few minutes IS a fault.'
    }
}

Add-FosSub 'installed software (Windows updates and redistributables filtered)'
Add-FosTable -Rows @($M.software | ForEach-Object { [pscustomobject]@{ Name = $_.name; Version = $_.version; Publisher = $_.publisher; Arch = $_.arch } }) -Columns ([ordered]@{ Name = 46; Version = 18; Publisher = 30; Arch = 5 })
if ($M.features.Count) { Add-FosSub 'installed roles and features'; Add-FosLine ("  " + (@($M.features) -join ', ')) }

Add-FosSub 'machine PATH entries'
foreach ($p in $M.environment.pathEntries) { Add-FosLine ("    [{0}] {1}" -f $(if ($p.exists) { 'ok  ' } else { 'MISS' }), (Get-FosMask $p.path)) }
$missPath = @($M.environment.pathEntries | Where-Object { -not $_.exists })
if ($missPath.Count) { Add-FosFinding -Severity info -Area 'environment' -Problem "$($missPath.Count) PATH entries do not exist - harmless here, but they tell you what used to be installed" }

if ($M.certificates.Count) {
    Add-FosSub 'certificates in LocalMachine\My'
    Add-FosTable -Rows @($M.certificates | ForEach-Object { [pscustomobject]@{ Subject = $_.subject; Expires = "$($_.notAfter)".Substring(0, 10); Days = $_.daysLeft; Key = $_.hasPrivateKey; Self = $_.selfSigned; BoundTo = $(if ($_.boundTo.Count) { $_.boundTo -join '; ' } else { '(nothing found)' }) } }) -Columns ([ordered]@{ Subject = 44; Expires = 11; Days = 6; Key = 5; Self = 5; BoundTo = 34 })
    Add-FosLine '  BoundTo is HTTP.sys and IIS only. A key used by Grafana cert_file or by a script is not detected here.'
}
if ($M.octopus) {
    Add-FosSub 'Octopus Tentacle'
    Add-FosKV 'Services'  (@($M.octopus.services) -join '; ')
    Add-FosKV 'Version'   $M.octopus.tentacleVersion
    foreach ($cf in @($M.octopus.configFiles)) { Add-FosKV 'Config' ("{0}  style={1} port={2}" -f (Get-FosMask $cf.path), $cf.communicationStyle, $cf.port) }
    if (@($M.octopus.applications).Count) {
        Add-FosLine '  packages Octopus deployed here (Applications folder):'
        Add-FosTable -Rows @($M.octopus.applications | ForEach-Object { [pscustomobject]@{ Environment = $_.environment; Package = $_.package; Deploys = $_.deployments; Latest = $_.latest; LastDeployed = $_.lastDeployed } }) -Columns ([ordered]@{ Environment = 16; Package = 36; Deploys = 7; Latest = 16; LastDeployed = 20 })
    }
}
if ($M.events -and ($M.events.scm.Count -or $M.events.nssm.Count)) {
    Add-FosSub 'service events, last 7 days (SCM warnings and errors naming these services; all nssm events)'
    foreach ($ev in @($M.events.scm | Select-Object -First 15)) { Add-FosLine ("  {0} SCM  {1,-7} {2}" -f $ev.time, $ev.level, (Get-FosMask $ev.message)) }
    foreach ($ev in @($M.events.nssm | Select-Object -First 15)) { Add-FosLine ("  {0} nssm {1,-7} {2}" -f $ev.time, $ev.level, (Get-FosMask $ev.message)) }
}
if ($M.iis) {
    Add-FosSub 'IIS sites'
    Add-FosTable -Rows @($M.iis.sites | ForEach-Object { [pscustomobject]@{ Site = $_.name; State = $_.state; Pool = $_.appPool; Bindings = (@($_.bindings) -join ' '); Path = $_.path } }) -Columns ([ordered]@{ Site = 24; State = 9; Pool = 20; Bindings = 30; Path = 34 })
    Add-FosSub 'IIS application pools'
    Add-FosTable -Rows @($M.iis.pools | ForEach-Object { [pscustomobject]@{ Pool = $_.name; State = $_.state; Runtime = $_.runtime; Identity = $(if ($_.userName) { $_.userName } else { $_.identityType }) } }) -Columns ([ordered]@{ Pool = 26; State = 9; Runtime = 10; Identity = 30 })
}

foreach ($tree in $M.appTrees) {
    Add-FosSub "application tree: $($tree.root)"
    Add-FosKV 'Files'        $tree.fileCount
    Add-FosKV 'Total size'   (Format-FosSize $tree.totalBytes)
    Add-FosKV 'Newest file'  $tree.newest
    Add-FosKV 'Top level'    (@($tree.topLevel) -join ', ')
    if ($tree.credentialHandling.Count) {
        Add-FosLine ''
        Add-FosLine '  credential handling found in the scripts:'
        foreach ($c in $tree.credentialHandling) { Add-FosLine ("    {0}`n      {1}" -f (Get-FosMask $c.path), (@($c.tells) -join ', ')) }
    }
    if ($tree.uncPaths.Count) {
        Add-FosLine ''
        Add-FosLine '  UNC paths referenced (each must be reachable from the new server):'
        foreach ($u in $tree.uncPaths) { Add-FosLine "    $(Get-FosMask $u)" }
    }
    if ($tree.urls.Count) {
        Add-FosLine ''
        Add-FosLine '  URLs referenced (proxy and TLS both matter to these):'
        foreach ($u in @($tree.urls | Select-Object -First 40)) { Add-FosLine "    $(Get-FosMask $u)" }
    }
    if ($tree.hardcoded.Count) {
        Add-FosLine ''
        Add-FosLine '  files that hardcode a server name:'
        foreach ($f in $tree.hardcoded) { Add-FosLine "    $(Get-FosMask $f)" }
        Add-FosFinding -Severity warn -Area 'apptree' -Problem "$($tree.hardcoded.Count) file(s) under $($tree.root) hardcode a server name" -Fix 'Re-point them before the task runs on the new host'
    }
    $credCfg = @($tree.configFiles | Where-Object { $_.looksLikeCredentials })
    if ($credCfg.Count) {
        Add-FosLine ''
        Add-FosLine '  config files that appear to contain credentials (values NOT captured):'
        foreach ($c in $credCfg) { Add-FosLine "    $(Get-FosMask $c.path)" }
        Add-FosFinding -Severity warn -Area 'apptree' -Problem "$($credCfg.Count) config file(s) appear to hold credentials in clear text" -Fix 'They travel with the file copy, so nothing needs re-creating - but note it in the change record, and confirm each environment keeps its OWN copy'
    }
}

if ($M.exporter) {
    Add-FosSub 'windows_exporter'
    Add-FosKV 'Service'      $M.exporter.service
    Add-FosKV 'Exe'          (Get-FosMask $M.exporter.exe)
    Add-FosKV 'Version'      $M.exporter.version
    Add-FosKV 'Config'       (Get-FosMask $M.exporter.configFile)
    Add-FosKV 'Collectors'   (@($M.exporter.collectors) -join ',')
    Add-FosKV 'Textfile dir' (Get-FosMask $M.exporter.textfileDir)
    Add-FosKV 'Metric lines' $M.exporter.metricsLines
    Add-FosKV 'Metric families' @($M.exporter.metricFamilies).Count
    Add-FosLine ''
    Add-FosLine '  .prom output - this is the acceptance test for the replacement:'
    if (-not $M.exporter.promFiles.Count) { Add-FosLine '    (none)' }
    foreach ($f in $M.exporter.promFiles) { Add-FosLine ("    {0,-40} {1,9} bytes  written {2} min ago" -f $f.name, $f.bytes, $f.ageMinutes) }
    if ($M.exporter.configText) {
        Add-FosLine ''
        Add-FosLine '  config.yaml verbatim:'
        foreach ($l in ($M.exporter.configText -split "`r?`n")) { Add-FosLine "    $l" }
    }
}

if ($M.grafana) {
    $gr = $M.grafana
    Add-FosSub 'Grafana'
    Add-FosKV 'Service'        $gr.service
    Add-FosKV 'Command'        (Get-FosMask $gr.command)
    Add-FosKV 'Working dir'    (Get-FosMask $gr.appDirectory)
    Add-FosKV 'Version'        ("{0}{1}" -f $gr.version, $(if ($gr.commit) { " (commit $($gr.commit))" }))
    Add-FosKV 'Edition'        ("{0}  evidence: {1}" -f $gr.edition, $(if ($gr.editionEvidence.Count) { $gr.editionEvidence -join '; ' } else { 'none' }))
    Add-FosKV 'Home path'      (Get-FosMask $gr.home)
    Add-FosKV 'Data path'      (Get-FosMask $gr.dataDir)
    Add-FosKV 'Configured port' $gr.configuredPort
    Add-FosKV 'Listening on'   (@($gr.listeningPorts) -join ',')
    Add-FosKV 'Root URL'       (Get-FosMask $gr.rootUrl)
    Add-FosKV 'Protocol'       $gr.protocol
    Add-FosKV 'Database'       "$($gr.database.type) $($gr.database.path)$($gr.database.host)"
    Add-FosKV 'Alerting mode'  "$($gr.alertingMode)  (unified=$($gr.unifiedAlerting) legacy=$($gr.legacyAlerting))"
    foreach ($c in $gr.configPaths) { Add-FosKV 'Config file' ("{0}  exists={1}{2}" -f (Get-FosMask $c.path), $c.exists, $(if ($c.fromFlag) { ' (from --config flag)' })) }
    if ($gr.customIniModified) { Add-FosKV 'custom.ini modified' $gr.customIniModified }
    if ($gr.envOverrides.Count) { Add-FosKV 'Overrides in force' ($gr.envOverrides -join '; ') }
    if ($gr.licence) {
        Add-FosLine ''
        Add-FosLine '  Enterprise licence:'
        Add-FosKV '  file'        ("{0}  exists={1}" -f (Get-FosMask $gr.licence.path), $gr.licence.exists)
        if ($gr.licence.exists) {
            foreach ($k in 'url', 'slug', 'prod', 'exp', 'daysLeft', 'included_users', 'included_admins', 'included_viewers', 'lid', 'trial', 'decodeError') { if ($null -ne $gr.licence[$k] -and "$($gr.licence[$k])" -ne '') { Add-FosKV "  $k" (Get-FosMask $gr.licence[$k]) } }
            Add-FosLine '  The licence is validated against root_url. Same alias on the replacement, or a reissued licence.'
        }
    }
    if ($gr.db) {
        Add-FosLine ''
        Add-FosLine '  grafana.db (Route B copies this file; every dashboard, user, datasource secret and version is in it):'
        if ($gr.db.exists) {
            Add-FosKV '  path'     (Get-FosMask $gr.db.path)
            Add-FosKV '  size'     (Format-FosSize $gr.db.bytes)
            Add-FosKV '  last write' ("{0}  ({1} min ago)" -f $gr.db.modified, $gr.db.minutesSinceWrite)
            Add-FosKV '  wal / shm / journal' ("{0} / {1} / {2}{3}" -f $gr.db.walPresent, $gr.db.shmPresent, $gr.db.journalPresent, $(if ($gr.db.walBytes) { "  wal=$(Format-FosSize $gr.db.walBytes)" }))
            Add-FosLine '  Copy it with Grafana STOPPED, including the -wal and -shm files if present. A copy taken while running is inconsistent.'
        } elseif ($gr.db.external) { Add-FosKV '  external' $gr.db.external } else { Add-FosKV '  path' ("{0}  NOT FOUND" -f (Get-FosMask $gr.db.path)) }
    }
    if ($gr.settings.Count) {
        Add-FosLine ''
        Add-FosLine '  effective settings that the replacement must reproduce (defaults.ini + custom.ini):'
        foreach ($k in $gr.settings.Keys) { Add-FosLine ("    {0,-46} {1}" -f $k, (Get-FosMask (Format-FosTrim $gr.settings[$k] 100))) }
    }
    Add-FosLine ''
    Add-FosKV 'Plugins dir'    (Get-FosMask $gr.pluginsDir)
    Add-FosKV 'Plugins'        $(if ($gr.plugins.Count) { $gr.plugins -join '; ' } else { '(none installed outside core)' })
    if ($gr.provisioning.Count) {
        Add-FosLine ''
        Add-FosLine '  provisioning files:'
        foreach ($p in $gr.provisioning) { Add-FosLine ("    {0}  {1} bytes  {2}" -f (Get-FosMask $p.path), $p.bytes, $p.modified) }
        if ($gr.provisionedDatasources.Count) { Add-FosKV '  provisioned datasources' ($gr.provisionedDatasources -join '; ') }
    }
    if ($gr.ldapConfig) { Add-FosKV 'LDAP config' ("{0}  exists={1}" -f (Get-FosMask $gr.ldapConfig.path), $gr.ldapConfig.exists) }
    if ($gr.log) {
        Add-FosLine ''
        Add-FosKV 'Log file'     ("{0}  exists={1}{2}" -f (Get-FosMask $gr.log.path), $gr.log.exists, $(if ($gr.log.exists) { "  $(Format-FosSize $gr.log.bytes)  last write $($gr.log.modified)" }))
        if ($gr.log.exists) {
            Add-FosKV 'Errors last 24h' $gr.log.errors24h
            foreach ($le in @($gr.log.lastErrors)) { Add-FosLine ("    {0}" -f (Get-FosMask $le)) }
        }
    }
    if ($gr.api) {
        $a = $gr.api
        Add-FosLine ''
        Add-FosKV 'API URL'        ("{0}{1}" -f $a.url, $(if ($gr.apiUrlAutoDetected) { ' (auto detected from the listener)' }))
        if ($a.health -is [System.Collections.IDictionary]) { Add-FosKV 'API health' ("db={0} version={1} commit={2}{3}" -f $a.health.database, $a.health.version, $a.health.commit, $(if ($a.health.enterpriseCommit) { " enterpriseCommit=$($a.health.enterpriseCommit)" })) }
        elseif ($a.health) { Add-FosKV 'API health' $a.health }
        if ($a.note) { Add-FosLine ("  {0}" -f $a.note) }
        if ($a.buildInfo) { Add-FosKV 'API buildInfo' ("version={0} edition={1}" -f $a.buildInfo.version, $a.buildInfo.edition) }
        if ($a.licenseInfo) { Add-FosKV 'API licence' ("state={0} expiry={1} url={2} features={3}" -f $a.licenseInfo.stateInfo, $a.licenseInfo.expiry, (Get-FosMask $a.licenseInfo.licenseUrl), (@($a.licenseInfo.enabledFeatures) -join ',')) }
        if ($a.licensingToken) { Add-FosKV 'API licensing token' ("status={0} url={1} exp={2} users={3}" -f $a.licensingToken.status, (Get-FosMask $a.licensingToken.url), $a.licensingToken.exp, $a.licensingToken.includedUsers) }
        if ($a.azure) { Add-FosKV 'API azure' ("cloud={0} managedIdentity={1} workloadIdentity={2} userIdentity={3}" -f $a.azure.cloud, $a.azure.managedIdentityEnabled, $a.azure.workloadIdentityEnabled, $a.azure.userIdentityEnabled) }
        if ($a.datasources) {
            Add-FosKV 'API datasources' @($a.datasources).Count
            foreach ($d in @($a.datasources)) {
                $extra = @()
                foreach ($k in 'authType', 'azureAuthType', 'cloudName', 'clientId', 'subscriptionId', 'httpMethod', 'tlsSkipVerify', 'prometheusType') { if ($d[$k]) { $extra += "$k=$($d[$k])" } }
                if ($d.azureCredentials) { $extra += "azureCredentials=$(Format-FosTrim $d.azureCredentials 90)" }
                Add-FosLine ("    {0,-26} {1,-32} {2}" -f (Format-FosTrim $d.name 26), (Format-FosTrim $d.type 32), (Get-FosMask $d.url))
                Add-FosLine ("      health={0} {1}{2}{3}" -f $d.health, (Get-FosMask (Format-FosTrim $d.healthMessage 90)), $(if ($d.isDefault) { '  DEFAULT' }), $(if ($d.readOnly) { '  provisioned/readOnly' }))
                if ($extra.Count) { Add-FosLine ("      {0}" -f (Get-FosMask ($extra -join '  '))) }
            }
        }
        if ($null -ne $a.dashboards) { Add-FosKV 'API dashboards' @($a.dashboards).Count }
        if ($a.folders) { Add-FosKV 'API folders' (@($a.folders) -join '; ') }
        if ($null -ne $a.alertRules) { Add-FosKV 'API alert rules' @($a.alertRules).Count }
        if ($a.legacyChannels) { Add-FosKV 'API legacy channels' (@($a.legacyChannels) -join '; ') }
        if ($a.contactPoints) { Add-FosKV 'API contact points' (@($a.contactPoints) -join '; ') }
        if ($a.plugins) { Add-FosKV 'API plugins' (@($a.plugins) -join '; ') }
        if ($a.stats) { Add-FosKV 'API stats' ("users={0} activeUsers={1} dashboards={2} datasources={3} alerts={4} snapshots={5}" -f $a.stats.users, $a.stats.activeUsers, $a.stats.dashboards, $a.stats.datasources, $a.stats.alerts, $a.stats.snapshots) }
        if ($null -ne $a.orgUserCount) { Add-FosKV 'API org users' ("{0}  admins: {1}" -f $a.orgUserCount, (Get-FosMask (@($a.orgAdmins) -join ', '))) }
        if ($a.recentlySeen) { Add-FosKV 'Seen in last month' (Get-FosMask (@($a.recentlySeen) -join '; ')) }
        if ($a.serviceAccounts) { Add-FosKV 'API service accounts' (@($a.serviceAccounts) -join '; ') }
    }
    if ($gr.customIniRedacted) {
        Add-FosLine ''
        Add-FosLine '  custom.ini verbatim (secret values masked):'
        foreach ($l in ($gr.customIniRedacted -split "`r?`n")) { Add-FosLine ("    {0}" -f (Get-FosMask $l)) }
    }
}

if ($M.prometheus) {
    $pm = $M.prometheus
    Add-FosSub 'Prometheus'
    Add-FosKV 'Service'     $pm.service
    Add-FosKV 'Command'     (Get-FosMask $pm.command)
    Add-FosKV 'Working dir' (Get-FosMask $pm.appDirectory)
    Add-FosKV 'Version'     ("{0}{1}{2}" -f $pm.version, $(if ($pm.goVersion) { " (go $($pm.goVersion))" }), $(if ($pm.buildDate) { " built $($pm.buildDate)" }))
    Add-FosKV 'Config'      ("{0}{1}" -f (Get-FosMask $pm.configFile), $(if ($pm.configModified) { "  modified $($pm.configModified)" }))
    if ($pm.configFileEffective -and $pm.configFileEffective -ne $pm.configFile) { Add-FosKV 'Config (per API flags)' (Get-FosMask $pm.configFileEffective) }
    Add-FosKV 'Listen'      $(if ($pm.listenAddress) { $pm.listenAddress } else { '(default :9090)' })
    if ($pm.externalUrl) { Add-FosKV 'External URL' (Get-FosMask $pm.externalUrl) }
    Add-FosKV 'Retention'   $(if ($pm.retention) { $pm.retention } else { 'NOT SET: default 15d' })
    if ($pm.retentionSize) { Add-FosKV 'Retention size' $pm.retentionSize }
    Add-FosKV 'TSDB path'   ("{0}{1}" -f (Get-FosMask $pm.tsdbPath), $(if ($pm.tsdbPathEffective -and $pm.tsdbPathEffective -ne $pm.tsdbPath) { "  (API says $($pm.tsdbPathEffective))" }))
    Add-FosKV 'TSDB size'   (Format-FosSize $pm.tsdbBytes)
    if ($pm.tsdb) {
        Add-FosKV '  blocks'  $pm.tsdb.blocks
        Add-FosKV '  oldest sample' ("{0}{1}" -f $pm.tsdb.oldestSample, $(if ($pm.tsdb.dataDays) { "  ($($pm.tsdb.dataDays) days of data on disk)" }))
        Add-FosKV '  newest sample' $pm.tsdb.newestSample
        Add-FosKV '  wal / head' ("{0} / {1}" -f (Format-FosSize $pm.tsdb.walBytes), (Format-FosSize $pm.tsdb.headBytes))
    }
    if ($pm.flags.Count) { Add-FosLine ''; Add-FosLine '  flags on the command line:'; foreach ($k in $pm.flags.Keys) { Add-FosLine ("    --{0,-36} {1}" -f $k, (Get-FosMask $pm.flags[$k])) } }
    if ($pm.effectiveFlags) { Add-FosLine '  flags as the running process reports them (API):'; foreach ($k in $pm.effectiveFlags.Keys) { Add-FosLine ("    --{0,-36} {1}" -f $k, (Get-FosMask $pm.effectiveFlags[$k])) } }
    Add-FosLine ''
    Add-FosKV 'Global'      (($pm.global.Keys | ForEach-Object { "$_=$($pm.global[$_])" }) -join '  ')
    Add-FosKV 'Scrape jobs' (@($pm.scrapeJobs) -join ', ')
    Add-FosKV 'Static targets' $(if ($pm.staticTargets.Count) { (Get-FosMask ($pm.staticTargets -join ', ')) } else { '(none)' })
    Add-FosKV 'file_sd files' (@($pm.targetFiles) -join ', ')
    Add-FosKV 'Rule files'  $(if ($pm.ruleFiles.Count) { $pm.ruleFiles -join ', ' } else { '(none)' })
    Add-FosKV 'Alertmanagers' $(if ($pm.alertmanagers.Count) { Get-FosMask ($pm.alertmanagers -join ', ') } else { '(none active in config)' })
    Add-FosKV 'remote_write / read' ("{0} / {1}" -f $pm.remoteWrite, $pm.remoteRead)
    Add-FosKV 'Rename bridge present' $pm.hasRenameBridge
    Add-FosKV 'relabel / basic_auth / tls' ("{0} / {1} / {2}" -f $pm.hasRelabel, $pm.hasBasicAuth, $pm.hasTls)
    Add-FosLine ''
    Add-FosLine '  scrape targets from the file_sd JSON (this is the list the new host must join):'
    Add-FosTable -Rows @($pm.targets | ForEach-Object {
        $row = $_          # inside the inner loop $_ becomes the KEY, so hold the target here
        $lbl = @($row.labels.Keys | ForEach-Object { "$_=$($row.labels[$_])" }) -join ' '
        [pscustomobject]@{ Target = $row.target; File = $row.file; Labels = $lbl } }) `
        -Columns ([ordered]@{ Target = 34; File = 22; Labels = 60 })
    if ($pm.api) {
        $a = $pm.api
        Add-FosLine ''
        Add-FosKV 'API URL'      ("{0}{1}" -f $a.url, $(if ($pm.apiUrlAutoDetected) { ' (auto detected)' }))
        if ($a.runtime) { Add-FosKV 'Started'      $a.runtime.startTime; Add-FosKV 'Config reload ok' ("{0} at {1}" -f $a.runtime.reloadConfigSuccess, $a.runtime.lastConfigTime) }
        Add-FosKV 'Targets up'   @($a.targets | Where-Object { $_.health -eq 'up' }).Count
        Add-FosKV 'Targets down' @($a.targets | Where-Object { $_.health -ne 'up' }).Count
        if ($pm.downByClass.Count) { Add-FosKV '  down by class' (($pm.downByClass.Keys | ForEach-Object { "$_=$($pm.downByClass[$_])" }) -join ', ') }
        Add-FosLine ''
        Add-FosLine '  by job:'
        foreach ($grp in @($a.targets | Group-Object { $_.job } | Sort-Object Name)) { Add-FosLine ("    {0,-36} {1,3} up / {2,3} total" -f (Get-FosMask $grp.Name), @($grp.Group | Where-Object { $_.health -eq 'up' }).Count, $grp.Count) }
        $downT = @($a.targets | Where-Object { $_.health -ne 'up' })
        if ($downT.Count) {
            Add-FosLine ''
            Add-FosLine '  DOWN (pre-existing; class tells you what to do with each):'
            Add-FosTable -Rows @($downT | ForEach-Object { [pscustomobject]@{ Class = $_.class; Job = $_.job; Instance = $_.instance; DNS = "$($_.dns)"; TCP = "$($_.tcp)"; Error = $_.lastError } }) -Columns ([ordered]@{ Class = 11; Job = 16; Instance = 36; DNS = 16; TCP = 8; Error = 60 })
            Add-FosLine '  PLACEHOLDER/DNS: delete from the target file. REFUSED with TCP refused: exporter stopped on a live host. TIMEOUT: firewall.'
        }
        Add-FosLine ''
        Add-FosKV 'Metric families' $a.metricFamilyCount
        Add-FosKV '  wmi_* families'     $a.wmiFamilies
        Add-FosKV '  windows_* families' $a.windowsFamilies
        Add-FosKV '  other (textfile, app) families' $a.textfileFamilies
        foreach ($k in 'headSeries', 'samplesPerSecond', 'jobs', 'targetsUp', 'targetsDown', 'textfileScrapeErrors', 'oldestSampleAgeDays', 'oldestSampleAgeDaysLegacy') { if ($null -ne $a[$k]) { Add-FosKV "  $k" $a[$k] } }
        if ($a.ruleGroups) { Add-FosKV 'Rule groups' ((@($a.ruleGroups) | ForEach-Object { "$($_.name) ($($_.rules))" }) -join '; ') }
        if ($a.alertmanagersActive) { Add-FosKV 'Alertmanagers active' (Get-FosMask (@($a.alertmanagersActive) -join ', ')) }
        if ($a.alertmanagersDropped) { Add-FosKV 'Alertmanagers dropped' (Get-FosMask (@($a.alertmanagersDropped) -join ', ')) }
        if ($a.firingAlerts) { Add-FosKV 'Firing alerts' (@($a.firingAlerts) -join ', ') }
        Add-FosLine ''
        Add-FosLine '  The metric family list is in the manifest and in config\metric-names.txt. Compare-ServerBaseline'
        Add-FosLine '  and the cutover gate use it to say exactly which families the dashboards lose.'
        Add-FosLine '  config\scrape-targets-up.csv is the fleet whose inbound exporter rule must admit the NEW Prometheus IP.'
    }
    if ($pm.configRedacted) {
        Add-FosLine ''
        Add-FosLine '  prometheus.yml verbatim (secret values masked):'
        foreach ($l in ($pm.configRedacted -split "`r?`n")) { Add-FosLine ("    {0}" -f (Get-FosMask $l)) }
    }
}

Add-FosFindingSummary
Add-FosSub 'capture folder contents'
foreach ($f in @(Get-ChildItem -LiteralPath $out -Recurse -File -ErrorAction SilentlyContinue | Sort-Object FullName)) { Add-FosLine ("    {0,-60} {1,9} bytes" -f $f.FullName.Substring($out.Length + 1), $f.Length) }
Add-FosSub 'next'
Add-FosLine '  1. Run this same script on the replacement server.'
Add-FosLine '  2. Compare-ServerBaseline.ps1 -Old <old manifest.json> -New <new manifest.json>'
Add-FosLine '  3. Work the NO-GO list, then Repair-MonitoringHost.ps1 -Apply.'
Add-FosLine '  4. Test-MonitoringHost.ps1 for the runtime acceptance test.'
Add-FosHead 'END OF CAPTURE'
Add-FosLine '  Paste this whole report back to continue. The manifest holds the machine-readable detail.'
Add-FosLine ("  Sections that failed or timed out: {0}" -f $(if (@(Get-FosFindings 'info' | Where-Object { $_.Area -eq 'collection' }).Count + @(Get-FosFindings 'warn' | Where-Object { $_.Area -eq 'collection' }).Count) { 'see FINDINGS [collection]' } else { 'none' }))

Save-FosManifest $M (Join-Path $out 'manifest.json')
$null = Write-FosReport -Path (Join-Path $out 'CAPTURE-REPORT.txt')
Write-Host ("Manifest: {0}" -f (Join-Path $out 'manifest.json')) -ForegroundColor Cyan
Write-Host ("Copy the whole folder {0} to the replacement server." -f $out) -ForegroundColor Cyan
