# ON THE OLD SERVER: SRVCRE1APPOPS01

Everything here is READ ONLY. Nothing in this folder changes the old server.

Run from an ELEVATED PowerShell, in this folder, in this order.

| # | Run this | What it does | Output |
|---|---|---|---|
| 1 | `.\1_Invoke-ServerCapture.ps1 -GrafanaApiKey <token>` | Full server baseline. v2.0: domain role, NSSM service definitions, Grafana edition and licence, custom.ini, grafana.db, Prometheus flags and TSDB, down targets classified, who is connected, Azure identity, proxy as Go sees it, certificate bindings, Octopus, service events | `C:\Migration\capture-SRVCRE1APPOPS01-<stamp>\` |
| 2 | `.\2_Export-PrometheusConfig.ps1` | prometheus.yml, every target and rule file, a safety copy of the config tree, live target health with each DOWN target classified and probed, and the metric family baseline | `C:\Migration\promcapture-SRVCRE1APPOPS01-<stamp>\` |
| 3 | `.\3_Export-GrafanaContent.ps1 -Url http://localhost:9091 -Token <token> -OutputPath C:\Migration\grafana-export` | Dashboards, folders, datasources with auth mode and live health, alert rules, licence, every panel query evaluated. Ends with a SUMMARY block on screen | `C:\Migration\grafana-export\` |
| 4 | `.\4_Test-PromFiles.ps1` | Validates the textfile `.prom` files as the NEW exporter will read them. Finds the directory from the exporter service itself | report only |

## What to paste back

- Step 1: the whole `CAPTURE-REPORT.txt` (it is on the clipboard when the script ends).
- Step 2: the whole `PROMCFG-Export-*.txt` report.
- Step 3: the `GRAFANA EXPORT SUMMARY` block (also in `SUMMARY.txt` and on the clipboard). `ANALYSIS.md` is no longer needed separately; the summary carries the findings, API failures, missing metrics and empty panels.
- Step 4: the console output.

Nothing else has to leave the server. The zip stays inside.

## The token

Steps 1 and 3 read the Grafana API. Without a token step 1 still runs, but its Grafana section is
limited to `/api/health` and the licence, edition and datasource health come from step 3 only.

Create it once: Grafana, Administration, Service accounts, Add service account, role Admin, Add
token. Use the same token for both steps. Delete the service account after the cutover.

## URLs are detected

Step 1 finds the Grafana and Prometheus ports from the listening sockets. Pass `-GrafanaUrl` or
`-PrometheusUrl` only if it reports the wrong port.

## Then

Copy all three `C:\Migration\` output folders to the new server.

## If step 1 says BLOCKER on the domain role

Stop. The box is a domain controller. Nothing in this kit applies until the AD team has said what
the server is.

## Why step 4 runs here and not only on the new box

wmi_exporter 0.4.3 tolerates malformed `.prom` files. The current windows_exporter does not: it
rejects the file whole and sets `windows_textfile_scrape_error` to 1, while every service still
shows green. Finding that here means fixing the feeder script once, before it becomes a cutover
night problem.

## Note on step 2

`_Migrate-PrometheusConfig.ps1` is the engine. Step 2 is a wrapper that calls it with
`-Mode Export`. Do not run the engine directly and do not delete it.

Step 2 needs Prometheus RUNNING to capture the target list and metric baseline. If it is stopped,
start it first or the acceptance baseline is empty and step 13 on the new server has nothing to
compare against.
