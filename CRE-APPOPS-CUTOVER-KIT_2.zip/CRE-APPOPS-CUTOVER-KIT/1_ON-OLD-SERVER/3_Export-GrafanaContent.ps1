<#
.SYNOPSIS
    Exports EVERYTHING that defines a Grafana instance - dashboards and all the things around them -
    into a folder that can be (a) analysed, (b) re-imported elsewhere, and (c) optionally
    de-identified so it can leave the company perimeter.

.DESCRIPTION
    Read-only against Grafana (GET requests only). Run it against each Grafana in turn, from any
    machine that can reach the API. Needs a service-account token with the Admin role (Viewer
    cannot read notification channels, users, or permissions).

    What it captures (Grafana 9.x - 11.x API):
      dashboards\<folder>\<slug>__<uid>.json   every dashboard, full JSON, import-ready
      dashboards-index.csv                     one row per dashboard: folder, tags, panels, panel
                                               types, datasources used, variables, embedded legacy
                                               alerts, Angular panels, hard-coded hosts, version,
                                               last updated / by whom, provisioned?
      folders.json                             folder tree + folder permissions
      permissions.json                         per-dashboard permissions
      datasources.json                         datasource definitions (Grafana never returns
                                               secrets on this endpoint)
      library-panels.json                      shared library panels
      playlists.json, preferences.json, home-dashboard.json
      alerting\legacy-notification-channels.json   (secrets redacted, addresses kept)
      alerting\legacy-alerts.json                  legacy alerts + live state
      alerting\unified-rules.json                  unified alert rules (ruler API, if any)
      alerting\contact-points.json, policies.json, mute-timings.json, templates.json
      plugins.json                             installed plugins, versions, Angular flag, signature
      users.json / teams.json / service-accounts.json   (with -IncludeUsers)
      instance.json                            version, settings, org, health
      ANALYSIS.md                              human summary + the "make it better" findings:
                                               Angular panels, hard-coded hostnames, datasource
                                               referenced by name, duplicate titles, orphaned
                                               datasource refs, unused datasources, alerting map
      manifest.json                            what was captured, counts, any endpoint failures

    -Sanitize adds  share\  : the same bundle with hostnames, FQDNs, domains, IPs, emails,
    DOMAIN\accounts and URL hosts replaced by stable tokens (HOST-1, DOMAIN-1, IP-1, EMAIL-1...),
    leak-checked, zipped. The token map stays OUTSIDE share\ in sanitize-map.csv. Dashboard
    structure, panel types, PromQL shape and app names are all preserved so the content can be
    reasoned about; only identifiers are replaced. Pass -SanitizeMap from a previous run so the
    same host keeps the same token across all four Grafanas.

    v1.1 adds the WORLD the dashboards run against, read-only through Grafana's datasource proxy
    (the same path a dashboard uses to render), for every Prometheus datasource:
      prometheus\<ds>\metric-names.json          every metric name the TSDB knows
      prometheus\<ds>\metadata.json              metric HELP/TYPE
      prometheus\<ds>\labels.json, label-<job|instance|env...>-values.json
      prometheus\<ds>\targets.json               scrape targets + health (what is being monitored)
      prometheus\<ds>\series-count-by-metric.json  cardinality per metric
      prometheus\<ds>\buildinfo.json, flags.json, config.yml (secrets redacted)
    and evaluates EVERY panel query and EVERY query variable once (instant, cheap) so
      queries.csv     one row per query: dashboard, panel, expr, datasource, and whether it
                      returns data TODAY (rows / empty / error / unresolved variable) - this is
                      the "what is already broken in prod" list
      variables.csv   each dashboard variable, its query, and the values it resolves to
      versions.json   per-dashboard change history (who edited what, when)
      alert-annotations.json  recent legacy alert state changes (is alerting actually firing?)
    -HostTokenStyle RoleAware (default) makes sanitised host tokens keep environment + role +
    ordinal (srvfoswebiis18 -> HOST-prd-webiis-18, srvcre1appmon01 -> HOST-cre1-appmon-01) so
    the cross-environment naming pattern is visible without the real names. Opaque -> HOST-n.

.EXAMPLE
    .\Export-GrafanaContent.ps1 -Url http://localhost:9091 -Credential (Get-Credential admin) -OutputPath C:\GrafanaExport\PROD -Sanitize
    .\Export-GrafanaContent.ps1 -Url http://localhost:9091 -Token glsa_xxx -OutputPath C:\GrafanaExport\PROD -Sanitize
    .\Export-GrafanaContent.ps1 -Url http://srvcre1appops01:9091 -Token glsa_yyy -OutputPath C:\GrafanaExport\CRE -Sanitize -SanitizeMap C:\GrafanaExport\PROD\sanitize-map.csv
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)][string]$Url,
    [string]$Token,
    [pscredential]$Credential,
    [string]$OutputPath,
    [string]$Label,
    [switch]$IncludeUsers,
    [switch]$Sanitize,
    [string]$SanitizeMap,
    [string[]]$ExtraHosts = @(),
    [string[]]$ExtraDomains = @(),
    [switch]$SkipZip,
    [switch]$SkipQueryEval,
    [int]$MaxQueryEvals = 3000,
    [ValidateSet('RoleAware','Opaque')][string]$HostTokenStyle = 'RoleAware'
)

$ScriptVersion = '1.2.0'
$ErrorActionPreference = 'Continue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch {}
try { [Net.ServicePointManager]::ServerCertificateValidationCallback = { $true } } catch {}
$Url = $Url.TrimEnd('/')
# auth: a service-account token (Bearer) OR a Grafana user (basic auth, e.g. admin after a CLI
# reset). Either works for every endpoint used here as long as the identity is org Admin.
if (-not $Token -and -not $Credential) { $Credential = Get-Credential -Message "Grafana login for $Url (e.g. admin) - or re-run with -Token" }
$H = @{ Accept = 'application/json' }
if ($Token) { $H['Authorization'] = "Bearer $Token" }
else { $pair = "$($Credential.UserName):$($Credential.GetNetworkCredential().Password)"
       $H['Authorization'] = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($pair)) }
$Script:Failures = New-Object System.Collections.ArrayList
$Script:Findings = New-Object System.Collections.ArrayList

function G { param($Path, [switch]$Quiet)
    try {
        $r = Invoke-RestMethod -Uri "$Url$Path" -Headers $H -Method Get -TimeoutSec 60 -ErrorAction Stop
        # PS 5.1 unrolls JSON arrays onto the pipeline; PS 7 hands them back as ONE object.
        # Normalise: always emit array elements individually so @(G ...) is a real list on both.
        if ($null -ne $r -and $r -is [System.Collections.IList] -and $r -isnot [string]) { foreach ($i in $r) { $i }; return }
        return $r }
    catch {
        $code = $null; try { $code = [int]$_.Exception.Response.StatusCode } catch {}
        if (-not $Quiet -or $code -notin @(404, 400)) { [void]$Script:Failures.Add([pscustomobject]@{ endpoint = $Path; status = $code; error = "$($_.Exception.Message)" }) }
        return $null } }
function J { param($Obj, $File)
    $txt = if ($null -eq $Obj) { 'null' } else { ConvertTo-Json -InputObject $Obj -Depth 60 }
    $txt | Out-File -LiteralPath $File -Encoding UTF8 }
function Slug { param($s) $x = ("$s" -replace '[^\w\-\. ]', '_' -replace '\s+', '-').Trim('-_'); if (-not $x) { $x = 'untitled' }; if ($x.Length -gt 80) { $x = $x.Substring(0, 80) }; $x }
function Add-Finding { param($Sev, $Area, $Msg) [void]$Script:Findings.Add([pscustomobject]@{ severity = $Sev; area = $Area; finding = $Msg }) }
function StampFull { param($v) if ($v -is [datetime]) { return $v.ToUniversalTime().ToString('s') + 'Z' } return "$v" }
function Stamp { param($v) if ($v -is [datetime]) { return $v.ToUniversalTime().ToString('yyyy-MM-dd') } $t = "$v"; if ($t.Length -ge 10) { return $t.Substring(0, 10) } return $t }

# ---- connect
$health = G '/api/health'
if (-not $health) { Write-Error "Cannot reach $Url/api/health - check URL/port (these Grafanas run on 9091, not 3000)"; exit 2 }
$settings = G '/api/frontend/settings'
$org = G '/api/org'
if (-not $org) { Write-Error "Login rejected by $Url (/api/org returned nothing) - needs an Admin-role token, or -Credential for an admin user"; exit 3 }
$ver = "$($health.version)"; if (-not $ver -and $settings) { $ver = "$($settings.buildInfo.version)" }
if (-not $Label) { try { $Label = ([uri]$Url).Host } catch { $Label = 'grafana' } }
if (-not $OutputPath) { $OutputPath = Join-Path (Get-Location).Path ("GrafanaExport-" + (Slug $Label)) }
foreach ($d in @('', 'dashboards', 'alerting')) { $p = Join-Path $OutputPath $d; if (-not (Test-Path -LiteralPath $p)) { $null = New-Item -ItemType Directory -Path $p -Force } }
Write-Host "Exporting $Url  (Grafana $ver, org '$($org.name)')  ->  $OutputPath" -ForegroundColor Cyan

$edition = "$(if ($settings) { $settings.buildInfo.edition })"; if (-not $edition -and $health.enterpriseCommit) { $edition = 'Enterprise (enterpriseCommit in /api/health)' }
$licInfo = $(if ($settings -and $settings.licenseInfo) { [ordered]@{ stateInfo = "$($settings.licenseInfo.stateInfo)"; expiry = "$($settings.licenseInfo.expiry)"; licenseUrl = "$($settings.licenseInfo.licenseUrl)"; slug = "$($settings.licenseInfo.slug)"
        enabledFeatures = @($settings.licenseInfo.enabledFeatures.PSObject.Properties | Where-Object { $_.Value } | ForEach-Object { $_.Name }) } })
$licTok = G '/api/licensing/token' -Quiet
$azureSettings = $(if ($settings -and $settings.azure) { [ordered]@{ cloud = "$($settings.azure.cloud)"; managedIdentityEnabled = [bool]$settings.azure.managedIdentityEnabled; workloadIdentityEnabled = [bool]$settings.azure.workloadIdentityEnabled; userIdentityEnabled = [bool]$settings.azure.userIdentityEnabled } })
$adminStats = G '/api/admin/stats' -Quiet
Write-Host "  edition: $(if ($edition) { $edition } else { 'OSS (no edition reported)' })$(if ($licInfo) { "  licence: $($licInfo.stateInfo) $($licInfo.licenseUrl)" })"
J ([ordered]@{ url = $Url; label = $Label; version = $ver; edition = $edition; org = $org; health = $health; licenseInfo = $licInfo
    licensingToken = $(if ($licTok) { [ordered]@{ url = "$($licTok.url)"; slug = "$($licTok.slug)"; exp = "$($licTok.exp)"; includedUsers = "$($licTok.included_users)"; status = "$($licTok.status)"; trial = [bool]$licTok.trial } })
    azure = $azureSettings; adminStats = $adminStats
    generatedAt = (Get-Date -Format 's'); tool = "Export-GrafanaContent $ScriptVersion"
    settings = $(if ($settings) { [ordered]@{ buildInfo = $settings.buildInfo; angularSupportEnabled = $settings.angularSupportEnabled
        unifiedAlertingEnabled = $settings.unifiedAlertingEnabled; alertingEnabled = $settings.alertingEnabled
        defaultDatasource = $settings.defaultDatasource; authProxyEnabled = $settings.authProxyEnabled; anonymousEnabled = $settings.anonymousEnabled
        ldapEnabled = $settings.ldapEnabled; featureToggles = $settings.featureToggles } }) }) (Join-Path $OutputPath 'instance.json')

# ---- datasources
$dss = @(G '/api/datasources')
J $dss (Join-Path $OutputPath 'datasources.json')
$dsByUid = @{}; $dsByName = @{}
foreach ($d in $dss) { if ($d.uid) { $dsByUid["$($d.uid)"] = $d }; if ($d.name) { $dsByName["$($d.name)"] = $d } }
Write-Host "  datasources: $($dss.Count)"
# per datasource: how it authenticates and whether it works TODAY. The Azure Monitor datasource in
# CRE uses the VM's managed identity, which is bound to the old VM resource and does not migrate.
$dsHealth = New-Object System.Collections.ArrayList
foreach ($d in $dss) {
    $jd = $d.jsonData
    $rec = [ordered]@{ name = "$($d.name)"; uid = "$($d.uid)"; type = "$($d.type)"; url = "$($d.url)"; access = "$($d.access)"; isDefault = [bool]$d.isDefault; readOnly = [bool]$d.readOnly; basicAuth = [bool]$d.basicAuth
                       withCredentials = [bool]$d.withCredentials; secureFields = @($(if ($d.secureJsonFields) { $d.secureJsonFields.PSObject.Properties | Where-Object { $_.Value } | ForEach-Object { $_.Name } })) }
    if ($jd) { foreach ($k in 'httpMethod', 'timeInterval', 'tlsSkipVerify', 'tlsAuth', 'tlsAuthWithCACert', 'authType', 'azureAuthType', 'cloudName', 'subscriptionId', 'tenantId', 'clientId', 'azureCredentials', 'oauthPassThru', 'manageAlerts', 'prometheusType', 'prometheusVersion', 'logAnalyticsDefaultWorkspace', 'azureLogAnalyticsSameAs', 'sigV4Auth', 'serverName', 'database', 'authenticationType', 'connectionTimeout') {
        if ($null -ne $jd.$k) { $v = $jd.$k; if ($v -is [pscustomobject]) { $v = ($v | ConvertTo-Json -Compress -Depth 4) }; $rec[$k] = "$v" } } }
    $authMode = "$($rec['azureAuthType'])$($rec['authType'])"; if ($rec['azureCredentials'] -match '"authType"\s*:\s*"([^"]+)"') { $authMode = $Matches[1] }
    if ($authMode) { $rec.authMode = $authMode }
    $hc = $null
    try { $hc = Invoke-RestMethod -Uri "$Url/api/datasources/uid/$($d.uid)/health" -Headers $H -Method Get -TimeoutSec 40 -ErrorAction Stop; $rec.health = "$($hc.status)"; $rec.healthMessage = "$($hc.message)" }
    catch { $msg = "$($_.Exception.Message)"; try { $bd = $_.ErrorDetails.Message; if ($bd) { $bj = $bd | ConvertFrom-Json; if ($bj.message) { $msg = "$($bj.message)" }; if ($bj.status) { $rec.health = "$($bj.status)" } } } catch {}; if (-not $rec.health) { $rec.health = 'ERROR' }; $rec.healthMessage = ($msg -replace '[\r\n]+', ' ') }
    [void]$dsHealth.Add([pscustomobject]$rec)
    Write-Host ("    {0,-26} {1,-34} health={2} {3}" -f $d.name, $d.type, $rec.health, $(if ($authMode) { "auth=$authMode" }))
    if ($d.type -match '(?i)azure-monitor' -and $authMode -match '(?i)msi|managed') { Add-Finding 'serious' 'portability' "Datasource '$($d.name)' authenticates with the VM's MANAGED IDENTITY (health today: $($rec.health)). A system assigned identity is bound to this VM resource and does not move with the content. Before cutover: create a user assigned identity with the same RBAC on the App Insights / Log Analytics resources, attach it to both VMs, set azure.managed_identity_client_id in custom.ini on the replacement, add 169.254.169.254 to NO_PROXY there." }
    if ($rec.health -and $rec.health -notmatch '(?i)^ok$') { Add-Finding 'warning' 'integrity' "Datasource '$($d.name)' ($($d.type)) health check FAILS today: $($rec.healthMessage). Pre-existing; record it so the replacement is not blamed." }
    if ($rec.secureFields.Count -and $d.type -notmatch '(?i)azure') { Add-Finding 'info' 'portability' "Datasource '$($d.name)' holds secret fields ($($rec.secureFields -join ',')). Route A (JSON import) cannot carry them; they are re-entered by hand. Route B (grafana.db copy) keeps them, encrypted with security.secret_key, which must be identical on the replacement." }
}
J @($dsHealth) (Join-Path $OutputPath 'datasources-health.json')

# ---- folders (nested-folder aware via search)
$folders = @(G '/api/search?type=dash-folder&limit=5000')
$folderPerms = @{}
foreach ($f in $folders) { $fp = G "/api/folders/$($f.uid)/permissions" -Quiet; if ($fp) { $folderPerms["$($f.uid)"] = $fp } }
J ([ordered]@{ folders = $folders; permissions = $folderPerms }) (Join-Path $OutputPath 'folders.json')
Write-Host "  folders: $($folders.Count)"

# ---- dashboards (paged)
$search = New-Object System.Collections.ArrayList
$page = 1
do { $batch = @(G "/api/search?type=dash-db&limit=1000&page=$page"); foreach ($b in $batch) { [void]$search.Add($b) }; $page++ } while ($batch.Count -eq 1000 -and $page -lt 50)
Write-Host "  dashboards: $($search.Count)"

$AngularCore = @('graph', 'singlestat', 'table-old', 'grafana-worldmap-panel')
$AngularCommunity = @('grafana-piechart-panel', 'grafana-worldmap-panel', 'natel-discrete-panel', 'vonage-status-panel', 'briangann-gauge-panel', 'michaeldmoore-annunciator-panel', 'flant-statusmap-panel', 'digrich-bubblechart-panel', 'agenty-flowcharting-panel', 'savantly-heatmap-panel', 'grafana-singlestat-panel', 'natel-plotly-panel', 'petrslavotinek-carpetplot-panel', 'mtanda-histogram-panel', 'jdbranham-diagram-panel', 'btplc-status-dot-panel', 'btplc-trend-box-panel', 'natel-influx-admin-panel', 'grafana-clock-panel-old', 'yesoreyeram-boomtable-panel', 'ryantxu-ajax-panel', 'blackmirror1-singlestat-math-panel', 'novalabs-annotations-panel', 'zuburqan-parity-report-panel', 'farski-blendstat-panel', 'snuids-radar-panel', 'snuids-trafficlights-panel', 'bessler-pictureit-panel', 'aidanmountford-html-panel', 'scadavis-synoptic-panel', 'natel-usgs-datasource', 'grafana-simple-json-datasource')
$hostRx = '(?i)\b((?:srv|vmprd|dc\d|dc)[a-z0-9\-]{3,}|[a-z0-9\-]+\.(?:fos[a-z]*|[a-z0-9\-]+)\.org\.uk)\b'
$ipRx = '\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b'

function Walk-Panels { param($Panels, $Bag)
    foreach ($p in @($Panels)) {
        if (-not $p) { continue }
        [void]$Bag.panels.Add($p)
        if ($p.panels) { Walk-Panels $p.panels $Bag } } }

$index = New-Object System.Collections.ArrayList
$dashPerms = @{}
$allDsRefs = @{}
$titleSeen = @{}
$panelTypeCensus = @{}
$exportedDash = 0
foreach ($s in $search) {
    $full = G "/api/dashboards/uid/$($s.uid)"
    if (-not $full -or -not $full.dashboard) { continue }
    $exportedDash++
    $d = $full.dashboard; $m = $full.meta
    $folderTitle = "$(if ($m.folderTitle) { $m.folderTitle } else { 'General' })"
    $fdir = Join-Path (Join-Path $OutputPath 'dashboards') (Slug $folderTitle)
    if (-not (Test-Path -LiteralPath $fdir)) { $null = New-Item -ItemType Directory -Path $fdir -Force }
    # import-ready file: dashboard JSON with id nulled + meta needed to re-home it
    $d.id = $null
    J ([ordered]@{ dashboard = $d; folderUid = "$($m.folderUid)"; folderTitle = $folderTitle; overwrite = $true
        meta = [ordered]@{ uid = "$($d.uid)"; version = $m.version; updated = (StampFull $m.updated); updatedBy = "$($m.updatedBy)"
            created = (StampFull $m.created); createdBy = "$($m.createdBy)"; provisioned = [bool]$m.provisioned; url = "$($m.url)" } }) `
        (Join-Path $fdir ("$(Slug $d.title)__$($d.uid).json"))
    $pp = G "/api/dashboards/uid/$($s.uid)/permissions" -Quiet
    if ($pp) { $dashPerms["$($d.uid)"] = @($pp | Select-Object role, teamId, team, userId, userLogin, permissionName) }
    # analysis
    $bag = @{ panels = New-Object System.Collections.ArrayList }
    Walk-Panels $d.panels $bag
    $types = @{}; $dsRefs = @{}; $hardHosts = @{}; $angCore = @(); $angComm = @(); $panelAlerts = @(); $dsByNameRefs = 0; $legacyMetricRefs = 0
    foreach ($p in $bag.panels) {
        $t = "$($p.type)"; if ($t) { $types[$t] = [int]$types[$t] + 1; $panelTypeCensus[$t] = [int]$panelTypeCensus[$t] + 1 }
        if ($AngularCore -contains $t) { $angCore += "$($p.title)" }
        if ($AngularCommunity -contains $t) { $angComm += "$($p.title) [$t]" }
        if ($p.alert) { $panelAlerts += [ordered]@{ panel = "$($p.title)"; alert = "$($p.alert.name)"; frequency = "$($p.alert.frequency)"
            notifications = @(@($p.alert.notifications) | ForEach-Object { "$(if ($_.uid) { $_.uid } else { $_.id })" }) } }
        $pds = $p.datasource
        $refs = @($pds) + @(@($p.targets) | ForEach-Object { $_.datasource })
        foreach ($r in $refs) {
            if ($null -eq $r) { continue }
            if ($r -is [string]) { if ($r) { $dsRefs["name:$r"] = 1; $dsByNameRefs++ } }
            elseif ($r.uid) { $dsRefs["uid:$($r.uid)"] = 1 }
            elseif ($r.name) { $dsRefs["name:$($r.name)"] = 1; $dsByNameRefs++ } }
        $blob = ($p | ConvertTo-Json -Depth 30 -Compress)
        foreach ($mt in [regex]::Matches($blob, $hostRx)) { $hardHosts[$mt.Value.ToLower()] = 1 }
        foreach ($mt in [regex]::Matches($blob, $ipRx)) { $hardHosts[$mt.Value] = 1 }
        if ($blob -match '\bwmi_[a-z_]+') { $legacyMetricRefs++ } }
    foreach ($k in $dsRefs.Keys) { $allDsRefs[$k] = 1 }
    $vars = @(@($d.templating.list) | ForEach-Object { "$($_.name)[$($_.type)]" })
    $usesVars = [bool](@($d.templating.list | Where-Object { $_.type -eq 'query' }).Count)
    $tk = "$($d.title)".ToLower(); $titleSeen[$tk] = [int]$titleSeen[$tk] + 1
    [void]$index.Add([pscustomobject]@{
        Uid = "$($d.uid)"; Title = "$($d.title)"; Folder = $folderTitle; Tags = (@($d.tags) -join ';')
        Panels = $bag.panels.Count; PanelTypes = (($types.Keys | Sort-Object | ForEach-Object { "$_ x$($types[$_])" }) -join '; ')
        AngularCorePanels = $angCore.Count; AngularCommunityPanels = $angComm.Count; AngularCommunityDetail = ($angComm -join '; ')
        Datasources = (($dsRefs.Keys | Sort-Object | ForEach-Object {
            if ($_ -like 'uid:*') { $u = $_.Substring(4)
                if ($u -match '^\$\{?([A-Za-z0-9_]+)\}?$') {   # datasource VARIABLE (${DS_PROMETHEUS}) - resolved at view time, never "missing"
                    $vn = $Matches[1]; $dv = @($d.templating.list | Where-Object { $_.type -eq 'datasource' -and $_.name -eq $vn }) | Select-Object -First 1
                    "variable:`$$vn($(if ($dv) { $dv.query } else { '?' }))" }
                elseif ($dsByUid[$u]) { "$($dsByUid[$u].name)($($dsByUid[$u].type))" } else { "MISSING-UID:$u" } }
            else { $n = $_.Substring(5); if ($dsByName[$n]) { "$n(by-name)" } else { "MISSING-NAME:$n" } } }) -join '; ')
        DatasourceByNameRefs = $dsByNameRefs; Variables = ($vars -join '; '); UsesQueryVariables = $usesVars
        HardcodedHosts = (($hardHosts.Keys | Sort-Object) -join '; '); HardcodedHostCount = $hardHosts.Count
        LegacyWmiMetricPanels = $legacyMetricRefs
        EmbeddedLegacyAlerts = $panelAlerts.Count; EmbeddedAlertDetail = (@($panelAlerts | ForEach-Object { "$($_.alert) -> $(@($_.notifications) -join ',')" }) -join '; ')
        Refresh = "$($d.refresh)"; TimeFrom = "$($d.time.from)"; SchemaVersion = "$($d.schemaVersion)"
        Version = $m.version; Updated = (StampFull $m.updated); UpdatedBy = "$($m.updatedBy)"; Created = (StampFull $m.created); Provisioned = [bool]$m.provisioned
        Url = "$($m.url)" })
}
$index | Export-Csv -LiteralPath (Join-Path $OutputPath 'dashboards-index.csv') -NoTypeInformation -Encoding UTF8
J $dashPerms (Join-Path $OutputPath 'permissions.json')

# ---- the rest of the content
$lib = G '/api/library-elements?perPage=500'; J $(if ($lib) { $lib.result } else { @() }) (Join-Path $OutputPath 'library-panels.json')
J @(G '/api/playlists' -Quiet) (Join-Path $OutputPath 'playlists.json')
J (G '/api/org/preferences' -Quiet) (Join-Path $OutputPath 'preferences.json')
J (G '/api/dashboards/home' -Quiet) (Join-Path $OutputPath 'home-dashboard.json')
$plugins = @(G '/api/plugins?embedded=0')
J @($plugins | Select-Object id, name, type, category, enabled, hasUpdate, signature, signatureType,
    @{n='version';e={ $_.info.version }}, @{n='angularDetected';e={ [bool]$_.angularDetected }}) (Join-Path $OutputPath 'plugins.json')
$snaps = @(G '/api/dashboard/snapshots' -Quiet); J $snaps (Join-Path $OutputPath 'snapshots-list.json')

# ---- alerting (both generations)
$alertDir = Join-Path $OutputPath 'alerting'
$legacyChans = @(G '/api/alert-notifications' -Quiet)
$chansOut = @($legacyChans | ForEach-Object {
    $st = [ordered]@{}
    if ($_.settings) { foreach ($sp in $_.settings.PSObject.Properties) {
        if ($sp.Name -match '(?i)password|token|secret|apikey|basicauth|bottoken') { $st[$sp.Name] = '***REDACTED***' } else { $st[$sp.Name] = $sp.Value } } }
    [pscustomobject]@{ id = $_.id; uid = $_.uid; name = $_.name; type = $_.type; isDefault = $_.isDefault; sendReminder = $_.sendReminder; frequency = $_.frequency; settings = $st } })
J $chansOut (Join-Path $alertDir 'legacy-notification-channels.json')
$legacyAlerts = @(G '/api/alerts?limit=5000' -Quiet)
J @($legacyAlerts | Select-Object id, name, state, newStateDate, dashboardUid, dashboardSlug, panelId, url) (Join-Path $alertDir 'legacy-alerts.json')
$ruler = G '/api/ruler/grafana/api/v1/rules' -Quiet; J $ruler (Join-Path $alertDir 'unified-rules.json')
J @(G '/api/v1/provisioning/contact-points' -Quiet) (Join-Path $alertDir 'contact-points.json')
J (G '/api/v1/provisioning/policies' -Quiet) (Join-Path $alertDir 'policies.json')
J @(G '/api/v1/provisioning/mute-timings' -Quiet) (Join-Path $alertDir 'mute-timings.json')
J @(G '/api/v1/provisioning/templates' -Quiet) (Join-Path $alertDir 'templates.json')
$unifiedRuleCount = 0; if ($ruler) { foreach ($fp in $ruler.PSObject.Properties) { foreach ($grp in @($fp.Value)) { $unifiedRuleCount += @($grp.rules).Count } } }
Write-Host "  alerting: $($legacyChans.Count) legacy channel(s), $($legacyAlerts.Count) legacy alert(s), $unifiedRuleCount unified rule(s)"

# ============================================================ the world the dashboards run against
# Everything below goes through Grafana's datasource proxy: GET /api/datasources/proxy/uid/<uid>/...
# is exactly what the browser does when a panel renders. Read-only, instant queries only, capped.
function PX { param($DsUid, $Path, [switch]$Quiet)
    $r = G "/api/datasources/proxy/uid/$DsUid$Path" -Quiet:$Quiet
    if ($null -eq $r) { $r = G "/api/datasources/proxy/$($dsByUid[$DsUid].id)$Path" -Quiet:$Quiet }   # older Grafana: id-based proxy
    return $r }
function PQ { param($DsUid, $Query)   # instant query -> @{ ok; rows; error; ms }
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $r = Invoke-RestMethod -Uri "$Url/api/datasources/proxy/uid/$DsUid/api/v1/query?query=$([uri]::EscapeDataString($Query))&timeout=15s" -Headers $H -Method Get -TimeoutSec 30 -ErrorAction Stop
        $sw.Stop()
        if ($r.status -eq 'success') { return @{ ok = $true; rows = @($r.data.result).Count; error = $null; ms = $sw.ElapsedMilliseconds; type = "$($r.data.resultType)" } }
        return @{ ok = $false; rows = 0; error = "$($r.error)"; ms = $sw.ElapsedMilliseconds }
    } catch { $sw.Stop()
        $msg = "$($_.Exception.Message)"
        try { $body = $_.ErrorDetails.Message; if ($body) { $j = $body | ConvertFrom-Json; if ($j.error) { $msg = "$($j.error)" } } } catch {}
        return @{ ok = $false; rows = 0; error = ($msg -replace '[\r\n]+', ' '); ms = $sw.ElapsedMilliseconds } } }
function Redact-Yaml { param($Text) if (-not $Text) { return $Text }
    ($Text -split "`n" | ForEach-Object { if ($_ -match '(?i)^(\s*)(password|secret|bearer_token|credentials|api_key|client_secret|basic_auth_password|token)\s*:') { "$($Matches[1])$($Matches[2]): ***REDACTED***" } else { $_ } }) -join "`n" }

$promDir = Join-Path $OutputPath 'prometheus'
$promDs = @($dss | Where-Object { "$($_.type)" -eq 'prometheus' })
$dsWorld = @{}     # uid -> @{ metrics=@{}; instances=@(); jobs=@() }
foreach ($pd in $promDs) {
    $dd = Join-Path $promDir (Slug $pd.name); if (-not (Test-Path -LiteralPath $dd)) { $null = New-Item -ItemType Directory -Path $dd -Force }
    $u = "$($pd.uid)"
    Write-Host "  prometheus '$($pd.name)' ($($pd.url)):" -NoNewline
    $probe = PQ $u 'vector(1)'
    if (-not $probe.ok) {
        Write-Host " UNREACHABLE through the Grafana proxy ($($probe.error))" -ForegroundColor Yellow
        Add-Finding 'serious' 'integrity' "Datasource '$($pd.name)' ($($pd.url)) is not reachable through Grafana ($($probe.error)) - every panel bound to it is blank today; either the backend is gone (cruft) or the URL is wrong. Its metric catalogue could not be captured."
        $dsWorld[$u] = @{ metrics = @{}; instances = @(); jobs = @(); version = 'unreachable'; targetsUp = $null; targetsTotal = $null; unreachable = $true }
        continue }
    $names = PX $u '/api/v1/label/__name__/values' -Quiet
    $metricNames = @($(if ($names -and $names.data) { $names.data } else { @() }))
    J $metricNames (Join-Path $dd 'metric-names.json')
    $labels = PX $u '/api/v1/labels' -Quiet;   J $(if ($labels) { $labels.data } else { @() }) (Join-Path $dd 'labels.json')
    $labelVals = @{}
    foreach ($ln in @('job','instance','env','environment','host','hostname','server','role','service')) {
        $lv = PX $u "/api/v1/label/$ln/values" -Quiet
        if ($lv -and $lv.data -and @($lv.data).Count) { $labelVals[$ln] = @($lv.data); J @($lv.data) (Join-Path $dd "label-$ln-values.json") } }
    $tg = PX $u '/api/v1/targets' -Quiet
    if ($tg -and $tg.data) { J @($tg.data.activeTargets | Select-Object scrapeUrl, health, lastError, lastScrape, scrapeInterval, @{n='labels';e={ $_.labels }}) (Join-Path $dd 'targets.json') }
    $md = PX $u '/api/v1/metadata' -Quiet; if ($md -and $md.data) { J $md.data (Join-Path $dd 'metadata.json') }
    $bi = PX $u '/api/v1/status/buildinfo' -Quiet; if ($bi) { J $bi.data (Join-Path $dd 'buildinfo.json') }
    $fl = PX $u '/api/v1/status/flags' -Quiet; if ($fl) { J $fl.data (Join-Path $dd 'flags.json') }
    $cfg = PX $u '/api/v1/status/config' -Quiet; if ($cfg -and $cfg.data.yaml) { (Redact-Yaml $cfg.data.yaml) | Out-File -LiteralPath (Join-Path $dd 'config.yml') -Encoding UTF8 }
    $cnt = PQ $u 'count by (__name__) ({__name__=~".+"})'
    if ($cnt.ok) { try { $raw = Invoke-RestMethod -Uri "$Url/api/datasources/proxy/uid/$u/api/v1/query?query=$([uri]::EscapeDataString('count by (__name__) ({__name__=~".+"})'))" -Headers $H -TimeoutSec 60
            J @($raw.data.result | ForEach-Object { [pscustomobject]@{ metric = "$($_.metric.__name__)"; series = [int]$_.value[1] } } | Sort-Object series -Descending) (Join-Path $dd 'series-count-by-metric.json') } catch {} }
    # NOT $ver: that is the Grafana version and this loop used to overwrite it, so ANALYSIS.md
    # reported the Prometheus version as Grafana's
    $pver = $(if ($bi -and $bi.data) { "$($bi.data.version)" } else { 'pre-2.14 (no buildinfo)' })
    $dsWorld[$u] = @{ metrics = @{}; instances = @($labelVals['instance'] | Where-Object { $_ }); jobs = @($labelVals['job'] | Where-Object { $_ }); version = $pver
        targetsUp = $(if ($tg) { @($tg.data.activeTargets | Where-Object { $_.health -eq 'up' }).Count }); targetsTotal = $(if ($tg) { @($tg.data.activeTargets).Count }) }
    foreach ($mn in $metricNames) { $dsWorld[$u].metrics["$mn"] = 1 }
    Write-Host " $($metricNames.Count) metrics, $(@($labelVals['instance'] | Where-Object { $_ }).Count) instances, $(@($labelVals['job'] | Where-Object { $_ }).Count) jobs, Prometheus $pver" }
$defaultDs = @($dss | Where-Object { $_.isDefault } | Select-Object -First 1)
if (-not $defaultDs -and $promDs.Count) { $defaultDs = @($promDs[0]) }

# ---- resolve which datasource a panel/target means (uid, name, null=default, mixed)
function Resolve-Ds { param($Ref, $Fallback)
    if ($null -eq $Ref -or "$Ref" -eq '') { return $Fallback }
    if ($Ref -is [string]) { if ($Ref -eq '-- Mixed --' -or $Ref -eq '-- Grafana --') { return $null }; if ($dsByName[$Ref]) { return "$($dsByName[$Ref].uid)" }; return $null }
    if ($Ref.uid) { if ("$($Ref.uid)" -match '^\$\{?(.+?)\}?$') { return $Fallback }; return "$($Ref.uid)" }
    if ($Ref.name -and $dsByName["$($Ref.name)"]) { return "$($dsByName["$($Ref.name)"].uid)" }
    return $Fallback }

# ---- variables: evaluate every query variable so its real values are known
$varRows = New-Object System.Collections.ArrayList
$dashVarValues = @{}    # dashUid -> @{ varName -> @(values) }
$evalCount = 0
function Eval-LabelValues { param($DsUid, $Q)
    # label_values(label) | label_values(metric{sel}, label) | query_result(expr) | metrics(rx) | label_names()
    $q = "$Q".Trim()
    if ($q -match '^label_values\(\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)$') {
        $r = PX $DsUid "/api/v1/label/$($Matches[1])/values" -Quiet; if ($r -and $r.data) { return @($r.data) }; return @() }
    if ($q -match '^label_values\((.+),\s*([A-Za-z_][A-Za-z0-9_]*)\s*\)$') {
        $sel = $Matches[1].Trim(); $lab = $Matches[2]
        $r = PX $DsUid "/api/v1/label/$lab/values?match[]=$([uri]::EscapeDataString($sel))" -Quiet
        if ($r -and $r.data) { return @($r.data) }
        $r = PX $DsUid "/api/v1/series?match[]=$([uri]::EscapeDataString($sel))" -Quiet   # pre-2.24 fallback
        if ($r -and $r.data) { return @(@($r.data | ForEach-Object { "$($_.$lab)" } | Where-Object { $_ } | Select-Object -Unique)) }
        return @() }
    if ($q -match '^label_names\(\)$') { $r = PX $DsUid '/api/v1/labels' -Quiet; if ($r) { return @($r.data) }; return @() }
    if ($q -match '^metrics\((.+)\)$') { $rx = $Matches[1]; return @($dsWorld[$DsUid].metrics.Keys | Where-Object { $_ -match $rx } | Select-Object -First 200) }
    if ($q -match '^query_result\((.+)\)$') { $expr = $Matches[1]
        try { $r = Invoke-RestMethod -Uri "$Url/api/datasources/proxy/uid/$DsUid/api/v1/query?query=$([uri]::EscapeDataString($expr))" -Headers $H -TimeoutSec 30
              return @($r.data.result | ForEach-Object { $m = $_.metric; $lbl = (($m.PSObject.Properties | ForEach-Object { "$($_.Name)=`"$($_.Value)`"" }) -join ','); "$($m.__name__){$lbl} $($_.value[1])" } | Select-Object -First 200) } catch { return @() } }
    return $null }   # unknown form

foreach ($s in $search) {
    $f = Join-Path (Join-Path (Join-Path $OutputPath 'dashboards') (Slug $(if ($s.folderTitle) { $s.folderTitle } else { 'General' }))) ("$(Slug $s.title)__$($s.uid).json")
    if (-not (Test-Path -LiteralPath $f)) { continue }
    $d = (Get-Content -LiteralPath $f -Raw | ConvertFrom-Json).dashboard
    $vals = @{}
    foreach ($v in @($d.templating.list)) {
        if (-not $v -or -not $v.name) { continue }
        $vt = "$($v.type)"; $q = $(if ($v.query -is [string]) { $v.query } elseif ($v.query.query) { "$($v.query.query)" } else { "$($v.query)" })
        $vd = Resolve-Ds $v.datasource $(if ($defaultDs) { "$($defaultDs.uid)" })
        $resolved = $null; $status = ''
        switch ($vt) {
            'query'      { if ($vd -and $dsWorld.ContainsKey($vd)) { $resolved = Eval-LabelValues $vd $q; $status = $(if ($null -eq $resolved) { 'unsupported-query-form' } elseif (@($resolved).Count) { 'ok' } else { 'EMPTY' }) } else { $status = 'no-prometheus-datasource' } }
            'custom'     { $resolved = @(@("$q" -split '\s*,\s*') | ForEach-Object { ($_ -split ':')[-1].Trim() } | Where-Object { $_ }); $status = 'static' }
            'constant'   { $resolved = @("$q"); $status = 'static' }
            'textbox'    { $resolved = @("$q"); $status = 'static' }
            'interval'   { $resolved = @(@("$q" -split '\s*,\s*') | Where-Object { $_ }); $status = 'static' }
            'datasource' { $resolved = @($dss | Where-Object { "$($_.type)" -eq "$($v.query)" } | ForEach-Object { $_.name }); $status = 'datasource' }
            default      { $status = "type:$vt" } }
        if ($null -eq $resolved) { $resolved = @() }
        $vals["$($v.name)"] = @($resolved)
        [void]$varRows.Add([pscustomobject]@{ Dashboard = "$($d.title)"; DashUid = "$($d.uid)"; Variable = "$($v.name)"; Type = $vt; Query = $q
            Datasource = $(if ($vd -and $dsByUid[$vd]) { $dsByUid[$vd].name }); Status = $status; ValueCount = @($resolved).Count
            SampleValues = (@($resolved | Select-Object -First 12) -join ' | '); Current = "$(if ($v.current) { $v.current.text })"; IncludeAll = [bool]$v.includeAll; Multi = [bool]$v.multi }) }
    $dashVarValues["$($d.uid)"] = $vals }
$varRows | Export-Csv -LiteralPath (Join-Path $OutputPath 'variables.csv') -NoTypeInformation -Encoding UTF8

# ---- every panel query: extract + evaluate once
$qRows = New-Object System.Collections.ArrayList
function Sub-Vars { param($Expr, $Vals)
    $e = "$Expr"
    $e = $e -replace '\$__rate_interval|\$\{__rate_interval\}', '5m' -replace '\$__interval|\$\{__interval\}', '1m' -replace '\$__range|\$\{__range\}', '1h' -replace '\$__auto', '5m'
    $e = $e -replace '\$\{__from\}|\$__from', '0' -replace '\$\{__to\}|\$__to', '0'
    # any label matcher against a variable -> match anything (we want to know if the metric has data at all)
    $e = [regex]::Replace($e, '(=~|!~|=|!=)\s*"[^"]*\$[^"]*"', '=~".+"')
    $e = [regex]::Replace($e, "(=~|!~|=|!=)\s*'[^']*\$[^']*'", '=~".+"')   # single-quoted matchers ('$Instance.*') are valid PromQL too
    foreach ($k in $Vals.Keys) {
        $vv = @($Vals[$k]); $rep = $(if ($vv.Count) { "$($vv[0])" } else { $null })
        if ($null -eq $rep -or $rep -eq '') { continue }
        $e = [regex]::Replace($e, '\$\{' + [regex]::Escape($k) + '(:[a-z]+)?\}|\$' + [regex]::Escape($k) + '\b|\[\[' + [regex]::Escape($k) + '(:[a-z]+)?\]\]', $rep) }
    return $e }
$panelIdx = 0
foreach ($s in $search) {
    $f = Join-Path (Join-Path (Join-Path $OutputPath 'dashboards') (Slug $(if ($s.folderTitle) { $s.folderTitle } else { 'General' }))) ("$(Slug $s.title)__$($s.uid).json")
    if (-not (Test-Path -LiteralPath $f)) { continue }
    $d = (Get-Content -LiteralPath $f -Raw | ConvertFrom-Json).dashboard
    $vals = $dashVarValues["$($d.uid)"]; if (-not $vals) { $vals = @{} }
    $bag = @{ panels = New-Object System.Collections.ArrayList }; Walk-Panels $d.panels $bag
    foreach ($pnl in $bag.panels) {
        if ("$($pnl.type)" -eq 'row') { continue }
        $pds = Resolve-Ds $pnl.datasource $(if ($defaultDs) { "$($defaultDs.uid)" })
        foreach ($t in @($pnl.targets)) {
            if (-not $t) { continue }
            $tds = Resolve-Ds $t.datasource $pds
            $expr = "$($t.expr)"
            $isProm = [bool]($tds -and $dsWorld.ContainsKey($tds))
            $status = ''; $rows = $null; $err = $null; $ms = $null; $missing = ''
            if (-not $expr) { $status = $(if ($t.rawSql -or $t.query) { 'non-promql' } else { 'no-expr' }) }
            elseif ($t.hide) { $status = 'hidden' }
            elseif (-not $isProm) { $status = 'no-prometheus-datasource' }
            elseif ($dsWorld[$tds].unreachable) { $status = 'datasource-unreachable' }
            else {
                # metric names referenced vs metrics that exist
                $refd = @([regex]::Matches($expr, '\b([a-zA-Z_:][a-zA-Z0-9_:]*)\s*(\{|\[|$|\)|\s)') | ForEach-Object { $_.Groups[1].Value } |
                    Where-Object { $_ -notmatch '^(sum|avg|min|max|count|rate|irate|increase|by|without|on|ignoring|group_left|group_right|and|or|unless|topk|bottomk|histogram_quantile|label_replace|label_join|abs|ceil|floor|round|time|vector|scalar|clamp_max|clamp_min|delta|deriv|predict_linear|changes|resets|sort|sort_desc|absent|absent_over_time|avg_over_time|max_over_time|min_over_time|sum_over_time|count_over_time|quantile_over_time|stddev_over_time|stdvar_over_time|last_over_time|present_over_time|offset|bool|inf|nan|holt_winters|double_exponential_smoothing|day_of_week|day_of_month|hour|minute|month|year|timestamp|exp|ln|log2|log10|sqrt|sgn|quantile|count_values|stddev|stdvar|group|e|s|m|h|d|w|y|ms)$' } | Select-Object -Unique)
                $miss = @($refd | Where-Object { -not $dsWorld[$tds].metrics.ContainsKey($_) -and $_ -notmatch '^\$' })
                $missing = ($miss -join ';')
                if ($SkipQueryEval -or $evalCount -ge $MaxQueryEvals) { $status = 'not-evaluated' }
                else {
                    $sub = Sub-Vars $expr $vals
                    if ($sub -match '\$[A-Za-z_{\[]') { $status = 'unresolved-variable' }
                    else { $evalCount++; $r = PQ $tds $sub; $ms = $r.ms
                        if ($r.ok) { $rows = $r.rows; $status = $(if ($r.rows -gt 0) { 'ok' } else { 'EMPTY' }) } else { $status = 'ERROR'; $err = $r.error } } } }
            [void]$qRows.Add([pscustomobject]@{ Dashboard = "$($d.title)"; DashUid = "$($d.uid)"; Folder = "$(if ($s.folderTitle) { $s.folderTitle } else { 'General' })"
                Panel = "$($pnl.title)"; PanelId = $pnl.id; PanelType = "$($pnl.type)"; RefId = "$($t.refId)"
                Datasource = $(if ($tds -and $dsByUid[$tds]) { $dsByUid[$tds].name } else { "$($t.datasource)$($pnl.datasource)" })
                Expr = $expr; Legend = "$($t.legendFormat)"; Instant = [bool]$t.instant; Format = "$($t.format)"
                Unit = "$($pnl.fieldConfig.defaults.unit)"; UsesVars = [bool]($expr -match '\$|\[\[')
                MetricsReferenced = ($refd -join ';'); MetricsMissingInTsdb = $missing
                LiveStatus = $status; LiveRows = $rows; LiveError = $err; LiveMs = $ms
                HardcodedHosts = (@([regex]::Matches($expr, $hostRx) | ForEach-Object { $_.Value.ToLower() } | Select-Object -Unique) -join ';') }) } } }
$qRows | Export-Csv -LiteralPath (Join-Path $OutputPath 'queries.csv') -NoTypeInformation -Encoding UTF8
$qEval = @($qRows | Where-Object { $_.LiveStatus -in @('ok','EMPTY','ERROR') })
$qEmpty = @($qRows | Where-Object { $_.LiveStatus -eq 'EMPTY' }); $qErr = @($qRows | Where-Object { $_.LiveStatus -eq 'ERROR' })
$qMissing = @($qRows | Where-Object { $_.MetricsMissingInTsdb })
Write-Host "  queries: $($qRows.Count) extracted, $($qEval.Count) evaluated live -> $(@($qRows | Where-Object { $_.LiveStatus -eq 'ok' }).Count) return data, $($qEmpty.Count) EMPTY, $($qErr.Count) ERROR; $($qMissing.Count) reference metrics absent from the TSDB"
if ($qEmpty.Count) { Add-Finding 'serious' 'broken' "$($qEmpty.Count) panel quer(ies) return NO DATA right now (empty result on an instant query): $((@($qEmpty | Select-Object -First 15 | ForEach-Object { "$($_.Dashboard) / $($_.Panel)" }) -join '; '))$(if ($qEmpty.Count -gt 15) { ' ...' }) - full list in queries.csv (LiveStatus=EMPTY)" }
if ($qErr.Count) { Add-Finding 'serious' 'broken' "$($qErr.Count) panel quer(ies) ERROR against Prometheus (bad PromQL, unknown function on this Prometheus version, or unresolvable): $((@($qErr | Select-Object -First 10 | ForEach-Object { "$($_.Dashboard) / $($_.Panel): $($_.LiveError)" }) -join '; '))" }
if ($qMissing.Count) { Add-Finding 'serious' 'broken' "$($qMissing.Count) quer(ies) reference metric names that DO NOT EXIST in the datasource's TSDB (renamed/retired exporter metric, dead producer, or typo): $((@($qMissing | Select-Object -ExpandProperty MetricsMissingInTsdb -Unique | Select-Object -First 20) -join '; '))" }
$vEmpty = @($varRows | Where-Object { $_.Status -eq 'EMPTY' })
if ($vEmpty.Count) { Add-Finding 'warning' 'broken' "$($vEmpty.Count) dashboard variable(s) resolve to NO values (their dropdowns are empty, panels depending on them show nothing): $((@($vEmpty | ForEach-Object { "$($_.Dashboard)/`$$($_.Variable)" }) -join '; '))" }
foreach ($u in $dsWorld.Keys) { $w = $dsWorld[$u]; if ($null -ne $w.targetsTotal -and $w.targetsTotal -gt 0 -and $w.targetsUp -lt $w.targetsTotal) {
    Add-Finding 'warning' 'monitoring' "Datasource '$($dsByUid[$u].name)': $($w.targetsUp) of $($w.targetsTotal) scrape targets are UP - the down ones are the cruft-register list (prometheus\<ds>\targets.json)" } }

# ---- dashboard version history + recent alert activity
$verHist = @{}
foreach ($s in $search) { $vh = G "/api/dashboards/uid/$($s.uid)/versions?limit=30" -Quiet
    if ($vh) { $verHist["$($s.uid)"] = @(@($(if ($vh.versions) { $vh.versions } else { $vh })) | Select-Object version, created, createdBy, message) } }
J $verHist (Join-Path $OutputPath 'versions.json')
$annos = @(G '/api/annotations?type=alert&limit=1000' -Quiet)
J @($annos | Select-Object id, alertId, alertName, dashboardUID, panelId, newState, prevState, time, text) (Join-Path $OutputPath 'alert-annotations.json')
if ($annos.Count) { $recent = @($annos | Where-Object { $_.time -and ([DateTimeOffset]::FromUnixTimeMilliseconds([long]$_.time).UtcDateTime) -gt (Get-Date).AddDays(-30) })
    $recentTxt = ''
    if ($recent.Count) { $recentTxt = ' (recent: ' + ((@($recent | Select-Object -First 5 | ForEach-Object { "$($_.alertName) -> $($_.newState)" })) -join '; ') + ')' }
    Add-Finding 'info' 'alerting' "$($annos.Count) legacy alert state change(s) on record, $($recent.Count) in the last 30 days - alerting IS live on this instance$recentTxt" }
$libConn = @{}
foreach ($le in @($(if ($lib) { $lib.result }))) { $c = G "/api/library-elements/$($le.uid)/connections" -Quiet; if ($c) { $libConn["$($le.uid)"] = @($(if ($c.result) { $c.result } else { $c })) } }
J $libConn (Join-Path $OutputPath 'library-panel-connections.json')

# ---- users/teams (opt-in; identifiers)
if ($IncludeUsers) {
    J @(G '/api/org/users?perpage=1000' -Quiet | Select-Object userId, login, email, name, role, lastSeenAtAge, isDisabled) (Join-Path $OutputPath 'users.json')
    $teams = G '/api/teams/search?perpage=1000' -Quiet; J $(if ($teams) { $teams.teams } else { @() }) (Join-Path $OutputPath 'teams.json')
    $sas = G '/api/serviceaccounts/search?perpage=500' -Quiet; J $(if ($sas) { $sas.serviceAccounts | Select-Object id, name, login, role, isDisabled, tokens } else { @() }) (Join-Path $OutputPath 'service-accounts.json') }

# ---- analysis findings
$angCoreDash = @($index | Where-Object { $_.AngularCorePanels -gt 0 }); $angCommDash = @($index | Where-Object { $_.AngularCommunityPanels -gt 0 })
$hardDash = @($index | Where-Object { $_.HardcodedHostCount -gt 0 }); $noVarDash = @($index | Where-Object { -not $_.UsesQueryVariables -and $_.Panels -gt 1 })
$byNameDash = @($index | Where-Object { $_.DatasourceByNameRefs -gt 0 }); $missingDs = @($index | Where-Object { $_.Datasources -match 'MISSING-' })
$dupTitles = @($titleSeen.Keys | Where-Object { $titleSeen[$_] -gt 1 })
$usedDsUids = @($allDsRefs.Keys | Where-Object { $_ -like 'uid:*' } | ForEach-Object { $_.Substring(4) })
$usedDsNames = @($allDsRefs.Keys | Where-Object { $_ -like 'name:*' } | ForEach-Object { $_.Substring(5) })
$unusedDs = @($dss | Where-Object { $usedDsUids -notcontains "$($_.uid)" -and $usedDsNames -notcontains "$($_.name)" -and -not $_.isDefault })
$stale = @($index | Where-Object { $_.Updated -and ([datetime]$_.Updated) -lt (Get-Date).AddYears(-2) })
$wmiDash = @($index | Where-Object { $_.LegacyWmiMetricPanels -gt 0 })
if ($angCommDash.Count) { Add-Finding 'critical' 'upgrade' "$($angCommDash.Count) dashboard(s) use COMMUNITY Angular panels (hard blockers for Grafana 12+; must be replaced): $(($angCommDash | ForEach-Object { $_.Title }) -join '; ')" }
if ($angCoreDash.Count) { Add-Finding 'warning' 'upgrade' "$($angCoreDash.Count) dashboard(s) use legacy CORE Angular panels (graph/singlestat/table-old - auto-migrate on upgrade, verify visually): $(($angCoreDash | ForEach-Object { $_.Title }) -join '; ')" }
if ($hardDash.Count) { Add-Finding 'serious' 'portability' "$($hardDash.Count) dashboard(s) hard-code hostnames/IPs in queries or text - they break on every server rename and cannot be promoted between environments unchanged: $(($hardDash | ForEach-Object { "$($_.Title) [$($_.HardcodedHostCount)]" }) -join '; ')" }
if ($noVarDash.Count) { Add-Finding 'warning' 'portability' "$($noVarDash.Count) multi-panel dashboard(s) use no query variables (no `$instance/`$job selectors) - each is pinned to fixed targets: $(($noVarDash | ForEach-Object { $_.Title }) -join '; ')" }
if ($byNameDash.Count) { Add-Finding 'warning' 'portability' "$($byNameDash.Count) dashboard(s) reference datasources by NAME (pre-8.x style) - fragile across environments; modern dashboards use a `${DS} datasource variable: $(($byNameDash | ForEach-Object { $_.Title }) -join '; ')" }
if ($missingDs.Count) { Add-Finding 'serious' 'integrity' "$($missingDs.Count) dashboard(s) reference a datasource that does NOT exist on this Grafana (panels show 'datasource not found'): $(($missingDs | ForEach-Object { $_.Title }) -join '; ')" }
if ($dupTitles.Count) { Add-Finding 'info' 'hygiene' "$($dupTitles.Count) duplicate dashboard title(s) across folders: $($dupTitles -join '; ')" }
if ($unusedDs.Count) { Add-Finding 'info' 'hygiene' "$($unusedDs.Count) datasource(s) referenced by no dashboard: $(($unusedDs | ForEach-Object { "$($_.name)($($_.type))" }) -join '; ')" }
if ($stale.Count) { Add-Finding 'info' 'hygiene' "$($stale.Count) dashboard(s) not edited in 2+ years - candidates for the cruft register: $(($stale | ForEach-Object { $_.Title }) -join '; ')" }
if ($wmiDash.Count) { Add-Finding 'info' 'migration' "$($wmiDash.Count) dashboard(s) query wmi_* metrics - these depend on the metric_relabel rename bridge after the exporter upgrade, and are the rename backlog for the upgrade tranche" }
$embedded = @($index | Where-Object { $_.EmbeddedLegacyAlerts -gt 0 })
if ($legacyChans.Count -or $legacyAlerts.Count -or $embedded.Count) {
    Add-Finding 'serious' 'alerting' "LEGACY alerting in use: $($legacyChans.Count) notification channel(s), $($legacyAlerts.Count) legacy alert(s), $([int](@($embedded | Measure-Object -Property EmbeddedLegacyAlerts -Sum)).Sum) panel-embedded alert definition(s) across $($embedded.Count) dashboard(s). Legacy alerting is REMOVED in Grafana 11 - migrate to unified alerting on 10.4 before any upgrade." }
elseif ($unifiedRuleCount -eq 0) { Add-Finding 'warning' 'alerting' 'No alerting of either generation found via API - either this instance genuinely does not alert, or the token lacks the Admin role.' }
$noPerm = @($index | Where-Object { -not $dashPerms.ContainsKey($_.Uid) })
$recentEdits = @($index | Where-Object { $ok = $false; if ($_.Updated) { $du = [datetime]::MinValue; if ([datetime]::TryParse("$($_.Updated)", [ref]$du)) { $ok = ($du -gt (Get-Date).AddDays(-14)) } }; $ok } | Sort-Object Updated -Descending)
if ($recentEdits.Count) { Add-Finding 'info' 'migration' "$($recentEdits.Count) dashboard(s) edited in the last 14 days (someone is actively working here; re-export or copy grafana.db immediately before the import, not days before): $((@($recentEdits | Select-Object -First 12 | ForEach-Object { "$($_.Title) ($(Stamp $_.Updated) by $($_.UpdatedBy))" })) -join '; ')" }
if ($Script:Failures.Count) { Add-Finding 'warning' 'export' "$($Script:Failures.Count) API endpoint(s) failed: $((@($Script:Failures | ForEach-Object { "$($_.endpoint) [$($_.status)]" }) | Select-Object -First 8) -join '; ') - content from those is missing from this bundle" }

# ---- ANALYSIS.md
$md = New-Object System.Collections.ArrayList
[void]$md.Add("# Grafana content export - $Label"); [void]$md.Add('')
[void]$md.Add("$Url  |  Grafana **$ver**  |  org **$($org.name)**  |  exported $(Get-Date -Format 's')  |  Export-GrafanaContent $ScriptVersion"); [void]$md.Add('')
[void]$md.Add("| Item | Count |"); [void]$md.Add("|---|---|")
[void]$md.Add("| Dashboards | $exportedDash |"); [void]$md.Add("| Folders | $($folders.Count) |"); [void]$md.Add("| Datasources | $($dss.Count) |")
[void]$md.Add("| Library panels | $(@($(if ($lib) { $lib.result })).Count) |"); [void]$md.Add("| Plugins (non-core) | $(@($plugins | Where-Object { $_.signature -ne 'internal' }).Count) |")
[void]$md.Add("| Legacy notification channels | $($legacyChans.Count) |"); [void]$md.Add("| Legacy alerts | $($legacyAlerts.Count) |"); [void]$md.Add("| Unified alert rules | $unifiedRuleCount |"); [void]$md.Add('')
[void]$md.Add('## Findings'); [void]$md.Add('')
foreach ($f in ($Script:Findings | Sort-Object { @{critical=0;serious=1;warning=2;info=3}[$_.severity] })) { [void]$md.Add("- **$($f.severity)** ($($f.area)): $($f.finding)") }
if (-not $Script:Findings.Count) { [void]$md.Add('- nothing flagged') }
[void]$md.Add(''); [void]$md.Add('## Panel type census (whole instance)'); [void]$md.Add('')
foreach ($k in ($panelTypeCensus.Keys | Sort-Object { -$panelTypeCensus[$_] })) { $tag = ''; if ($AngularCore -contains $k) { $tag = ' _(legacy core Angular)_' }; if ($AngularCommunity -contains $k) { $tag = ' **(community Angular - blocker)**' }; [void]$md.Add("- $k x$($panelTypeCensus[$k])$tag") }
[void]$md.Add(''); [void]$md.Add('## Datasources'); [void]$md.Add('')
foreach ($d in $dss) { $used = ($usedDsUids -contains "$($d.uid)") -or ($usedDsNames -contains "$($d.name)"); [void]$md.Add("- **$($d.name)** ($($d.type)) -> $($d.url)$(if ($d.isDefault) { ' [default]' })$(if (-not $used) { ' - not referenced by any dashboard' })") }
[void]$md.Add(''); [void]$md.Add('## Dashboards by folder'); [void]$md.Add('')
foreach ($grp in ($index | Group-Object Folder | Sort-Object Name)) {
    [void]$md.Add("### $($grp.Name) ($($grp.Count))")
    foreach ($r in ($grp.Group | Sort-Object Title)) {
        $flags = @(); if ($r.AngularCommunityPanels) { $flags += 'ANGULAR-COMMUNITY' }; if ($r.AngularCorePanels) { $flags += 'angular-core' }
        if ($r.HardcodedHostCount) { $flags += "hardcoded-hosts:$($r.HardcodedHostCount)" }; if ($r.EmbeddedLegacyAlerts) { $flags += "alerts:$($r.EmbeddedLegacyAlerts)" }
        if (-not $r.UsesQueryVariables) { $flags += 'no-vars' }; if ($r.Datasources -match 'MISSING') { $flags += 'MISSING-DS' }
        [void]$md.Add("- $($r.Title) - $($r.Panels) panel(s), v$($r.Version), updated $(Stamp $r.Updated) by $($r.UpdatedBy)$(if ($flags.Count) { "  [$($flags -join ', ')]" })") }
    [void]$md.Add('') }
if ($legacyChans.Count) {
    [void]$md.Add('## Legacy notification channels (who gets told)'); [void]$md.Add('')
    foreach ($c in $chansOut) { $dest = "$($c.settings.addresses)$($c.settings.url)$($c.settings.recipient)"; [void]$md.Add("- **$($c.name)** [$($c.type)]$(if ($c.isDefault) { ' DEFAULT' }) -> $dest") }
    [void]$md.Add('') }
if ($embedded.Count) {
    [void]$md.Add('## Panel-embedded legacy alerts -> channel'); [void]$md.Add('')
    foreach ($r in $embedded) { [void]$md.Add("- $($r.Title): $($r.EmbeddedAlertDetail)") }
    [void]$md.Add('') }
($md -join "`r`n") | Out-File -LiteralPath (Join-Path $OutputPath 'ANALYSIS.md') -Encoding UTF8

J ([ordered]@{ tool = "Export-GrafanaContent $ScriptVersion"; url = $Url; label = $Label; grafanaVersion = $ver; generatedAt = (Get-Date -Format 's')
    counts = [ordered]@{ dashboards = $exportedDash; folders = $folders.Count; datasources = $dss.Count; legacyChannels = $legacyChans.Count
        legacyAlerts = $legacyAlerts.Count; unifiedRules = $unifiedRuleCount; libraryPanels = @($(if ($lib) { $lib.result })).Count; plugins = $plugins.Count }
    findings = @($Script:Findings); apiFailures = @($Script:Failures) }) (Join-Path $OutputPath 'manifest.json')

Write-Host ("  findings: " + (($Script:Findings | Group-Object severity | ForEach-Object { "$($_.Count) $($_.Name)" }) -join ', '))
if ($Script:Failures.Count) { Write-Host "  API failures: $($Script:Failures.Count) (manifest.json)" -ForegroundColor Yellow }

# ============================================================ sanitised share bundle
if ($Sanitize) {
    Write-Host "  sanitising for share..." -ForegroundColor Cyan
    $map = [ordered]@{}; $counters = @{}
    if ($SanitizeMap -and (Test-Path -LiteralPath $SanitizeMap)) {
        foreach ($row in (Import-Csv -LiteralPath $SanitizeMap)) { $map[$row.Original.ToLower()] = $row.Token
            if ($row.Token -match '^([A-Z]+)-(\d+)$') { $k = $Matches[1]; $n = [int]$Matches[2]; if ($n -gt [int]$counters[$k]) { $counters[$k] = $n } } } }
    $usedTokens = @{}; foreach ($v in $map.Values) { $usedTokens["$v"] = 1 }
    function Tok { param($Kind, $Orig)
        $key = $Orig.ToLower(); if ($map.Contains($key)) { return $map[$key] }
        if ($Kind -eq 'HOST' -and $HostTokenStyle -eq 'RoleAware') {
            # keep environment + role + ordinal, drop the real prefix and the company acronym:
            #   srvfoswebiis18 -> HOST-prd-webiis-18   srvcre1appmon01 -> HOST-cre1-appmon-01   dc1foswebiis18 -> HOST-dc1prd-webiis-18
            if ($key -match '^(?<pfx>srv|vmprd|vm|dc\d)(?<env>fos|cre1|cre2|cre|sys1|sys|stg1|stg|trn|oat1|oat|prd|prod|uat|dev|tst|txt|hst)?(?<role>[a-z]+?)(?<n>\d{1,3})?$') {
                $env = "$($Matches['env'])"; if ($env -eq 'fos') { $env = 'prd' }; if (-not $env) { $env = 'x' }
                $pfx = "$($Matches['pfx'])"; if ($pfx -match '^dc\d$') { $env = "$pfx$env" } elseif ($pfx -eq 'vmprd') { $env = "vm$env" }
                $role = "$($Matches['role'])"; if (-not $role) { $role = 'host' }
                $n = "$($Matches['n'])"; if (-not $n) { $n = '00' }
                $t = "HOST-$env-$role-$n"; $i = 2; while ($usedTokens.ContainsKey($t)) { $t = "HOST-$env-$role-$n" + "b$i"; $i++ }
                $usedTokens[$t] = 1; $map[$key] = $t; return $t } }
        $counters[$Kind] = [int]$counters[$Kind] + 1; $t = "$Kind-$($counters[$Kind])"; $usedTokens[$t] = 1; $map[$key] = $t; return $t }
    # discover identifiers across the whole bundle text first (so tokens are stable within the run)
    $allText = (Get-ChildItem -LiteralPath $OutputPath -Recurse -Include *.json, *.csv, *.md -File | Where-Object { $_.FullName -notlike "*\share\*" -and $_.FullName -notlike "*/share/*" } | ForEach-Object { Get-Content -LiteralPath $_.FullName -Raw }) -join "`n"
    $emailRx = '[\w\.\-\+]+@[\w\.\-]+\.[A-Za-z]{2,}'
    $domainRx = '(?i)\b((?:[a-z0-9\-]+\.)+(?:org\.uk|co\.uk|gov\.uk|com|net|local|internal))\b'
    $winAcctRx = '(?i)\b([A-Z][A-Z0-9\-]{1,15})\\([A-Za-z0-9\.\-_\$]+)'
    # public vocabulary that must never become a token
    $publicDomains = '(?i)^(.*\.)?(grafana\.(com|net)|prometheus\.io|github\.com|githubusercontent\.com|microsoft\.com|office\.com|azure\.com|windows\.net|w3\.org|schema\.org|example\.(com|org|net)|email\.com|localhost|iana\.org)$'
    $genericUsers = @('admin','administrator','anonymous','grafana','root','api','service','system','guest','user','test')
    $orgHosts = @{}
    foreach ($m in [regex]::Matches($allText, $emailRx)) { $null = Tok 'EMAIL' $m.Value }
    foreach ($m in [regex]::Matches($allText, $winAcctRx)) { $null = Tok 'DOMAIN' $m.Groups[1].Value; $null = Tok 'ACCT' $m.Groups[2].Value }
    # SaaS tenant hostnames: the domain is public but the leftmost label names the company
    $tenantRx = '(?i)^(?<tenant>[a-z0-9\-]+)\.(?<sfx>webhook\.office\.com|slack\.com|atlassian\.net|pagerduty\.com|opsgenie\.com|sharepoint\.com|service-now\.com|servicenow\.com|zendesk\.com|hornbill\.com|onmicrosoft\.com|azurewebsites\.net|blob\.core\.windows\.net|okta\.com|splunkcloud\.com|datadoghq\.com|freshservice\.com)$'
    foreach ($m in [regex]::Matches($allText, $domainRx)) { $fq = $m.Groups[1].Value.ToLower()
        if ($fq -match $tenantRx) { $null = Tok 'TENANT' $Matches['tenant']; continue }
        if ($fq -match $publicDomains) { continue }
        # host.domain split that respects two-label public suffixes: fos.org.uk is a DOMAIN,
        # srvx.fos.org.uk is HOST srvx + DOMAIN fos.org.uk
        $parts = $fq -split '\.'
        $suffixLabels = $(if ($fq -match '\.(org|co|gov|ac|me|ltd|plc|nhs|sch|net)\.uk$') { 2 } else { 1 })
        if ($parts.Count -gt ($suffixLabels + 1)) { $null = Tok 'HOST' $parts[0]; $null = Tok 'DOMAIN' ($parts[1..($parts.Count-1)] -join '.') }
        else { $null = Tok 'DOMAIN' $fq } }
    foreach ($m in [regex]::Matches($allText, $hostRx)) { $v = $m.Value.ToLower(); if ($v -notmatch '\.') { $null = Tok 'HOST' $v } }
    foreach ($m in [regex]::Matches($allText, $ipRx)) { if ($m.Value -notmatch '^(127\.|0\.0\.0\.0)') { $null = Tok 'IP' $m.Value } }
    foreach ($xh in $ExtraHosts) { if ($xh) { $null = Tok 'HOST' $xh } }
    foreach ($dm in $ExtraDomains) { if ($dm) { $null = Tok 'DOMAIN' $dm } }
    # user identifiers from the export itself
    if ($IncludeUsers) { $uj = Join-Path $OutputPath 'users.json'; if (Test-Path $uj) { foreach ($u in @(Get-Content $uj -Raw | ConvertFrom-Json)) {
        foreach ($cand in @($u.login, $u.name)) { if ($cand -and "$cand".ToLower() -notin $genericUsers -and "$cand".Length -ge 3) { $null = Tok 'USER' "$cand" } } } } }
    foreach ($r in $index) { foreach ($who in @($r.UpdatedBy, $r.CreatedBy)) { if ($who -and "$who".ToLower() -notin $genericUsers -and "$who".Length -ge 3) { $null = Tok 'USER' "$who" } } }
    # never tokenise a value that is itself public vocabulary or a bare public suffix
    foreach ($k in @($map.Keys)) { if ($k -match $publicDomains -or $k -match '^(org|co|gov|ac)\.uk$' -or $k -in $genericUsers) { $map.Remove($k) } }
    # substitution: longest originals first so 'srvcre1appmon01.foscre.org.uk' beats 'srvcre1appmon01'
    $ordered = @($map.Keys | Sort-Object { -$_.Length })
    function San { param($Text)
        if (-not $Text) { return $Text }
        # word-boundary aware: 'fos' must not rewrite the inside of 'infos'; boundaries exclude
        # letters/digits/underscore so host:port, host.domain, "host" and DOMAIN\acct all still match
        foreach ($k in $ordered) { $Text = [regex]::Replace($Text, '(?<![A-Za-z0-9_])' + [regex]::Escape($k) + '(?![A-Za-z0-9_])', $map[$k], 'IgnoreCase') }
        return $Text }
    $shareDir = Join-Path $OutputPath 'share'
    if (Test-Path -LiteralPath $shareDir) { Remove-Item -LiteralPath $shareDir -Recurse -Force }
    $null = New-Item -ItemType Directory -Path $shareDir -Force
    foreach ($f in (Get-ChildItem -LiteralPath $OutputPath -Recurse -Include *.json, *.csv, *.md -File | Where-Object { $_.FullName -notlike "*\share\*" -and $_.FullName -notlike "*/share/*" -and $_.Name -ne 'sanitize-map.csv' })) {
        if ($f.Name -in @('users.json','teams.json','service-accounts.json','permissions.json')) { continue }   # identity records stay inside regardless
        $rel = $f.FullName.Substring($OutputPath.Length).TrimStart('\','/')
        $dest = Join-Path $shareDir (San $rel)
        $dd = Split-Path $dest -Parent; if (-not (Test-Path -LiteralPath $dd)) { $null = New-Item -ItemType Directory -Path $dd -Force }
        (San (Get-Content -LiteralPath $f.FullName -Raw)) | Out-File -LiteralPath $dest -Encoding UTF8 }
    # leak check
    $leaks = New-Object System.Collections.ArrayList
    foreach ($f in (Get-ChildItem -LiteralPath $shareDir -Recurse -File)) {
        $t = Get-Content -LiteralPath $f.FullName -Raw
        if (-not $t) { continue }
        foreach ($m in [regex]::Matches($t, $emailRx)) { [void]$leaks.Add("$($f.Name): email $($m.Value)") }
        foreach ($m in [regex]::Matches($t, $ipRx)) { if ($m.Value -notmatch '^(127\.|0\.0\.0\.0|\d+\.\d+\.\d+\.0$)') { [void]$leaks.Add("$($f.Name): ip $($m.Value)") } }
        foreach ($m in [regex]::Matches($t, '(?i)\b(srv|vmprd)[a-z0-9\-]{4,}')) { [void]$leaks.Add("$($f.Name): host $($m.Value)") }
        foreach ($m in [regex]::Matches($t, $domainRx)) {
            if ($m.Value -match $tenantRx -and $Matches['tenant'] -notmatch '^(TENANT|HOST)-\d+$') { [void]$leaks.Add("$($f.Name): saas-tenant $($m.Value)"); continue }
            if ($m.Value -notmatch $publicDomains) { [void]$leaks.Add("$($f.Name): domain $($m.Value)") } } }
    ($leaks | Select-Object -Unique) | Out-File -LiteralPath (Join-Path $shareDir 'LEAKCHECK.txt') -Encoding UTF8
    if (-not $leaks.Count) { 'CLEAN - no hostnames, IPs, emails or org domains detected in share\' | Out-File -LiteralPath (Join-Path $shareDir 'LEAKCHECK.txt') -Encoding UTF8 }
    @($map.Keys | ForEach-Object { [pscustomobject]@{ Original = $_; Token = $map[$_] } }) | Export-Csv -LiteralPath (Join-Path $OutputPath 'sanitize-map.csv') -NoTypeInformation -Encoding UTF8
    if (-not $SkipZip) { $zip = Join-Path $OutputPath "share-$(Slug $Label).zip"; if (Test-Path $zip) { Remove-Item $zip -Force }
        Compress-Archive -Path (Join-Path $shareDir '*') -DestinationPath $zip -Force }
    Write-Host "  share bundle: $(@($map.Keys).Count) identifier(s) tokenised; leak check: $(if ($leaks.Count) { "$($leaks.Count) POSSIBLE LEAK(S) - review LEAKCHECK.txt" } else { 'CLEAN' })" -ForegroundColor $(if ($leaks.Count) { 'Yellow' } else { 'Green' })
    Write-Host "  SEND: $(if (-not $SkipZip) { $zip } else { $shareDir })    KEEP INSIDE: $(Join-Path $OutputPath 'sanitize-map.csv')" }

# ============================================================ pasteable summary
# Everything a reviewer needs from this export, on the console, so nothing has to leave the box.
$L = New-Object System.Collections.ArrayList
function PL { param($t = '') [void]$L.Add($t) }
PL ''; PL ('=' * 78); PL "  GRAFANA EXPORT SUMMARY - $Label  (paste this block back)"; PL ('=' * 78)
PL ("  {0,-26}: {1}" -f 'URL', $Url); PL ("  {0,-26}: {1}" -f 'Version / edition', "$ver / $(if ($edition) { $edition } else { 'OSS' })")
if ($licInfo) { PL ("  {0,-26}: {1}" -f 'Licence', "$($licInfo.stateInfo) url=$($licInfo.licenseUrl) expiry=$($licInfo.expiry) features=$($licInfo.enabledFeatures -join ',')") }
if ($licTok) { PL ("  {0,-26}: {1}" -f 'Licence token', "url=$($licTok.url) exp=$(if ($licTok.exp) { ([DateTimeOffset]::FromUnixTimeSeconds([long]$licTok.exp)).UtcDateTime.ToString('s') }) users=$($licTok.included_users) status=$($licTok.status)") }
if ($azureSettings) { PL ("  {0,-26}: {1}" -f 'Azure settings', "cloud=$($azureSettings.cloud) managedIdentity=$($azureSettings.managedIdentityEnabled) workloadIdentity=$($azureSettings.workloadIdentityEnabled) userIdentity=$($azureSettings.userIdentityEnabled)") }
if ($adminStats) { PL ("  {0,-26}: {1}" -f 'Admin stats', "users=$($adminStats.users) activeUsers=$($adminStats.activeUsers) dashboards=$($adminStats.dashboards) datasources=$($adminStats.datasources) alerts=$($adminStats.alerts) snapshots=$($adminStats.snapshots)") }
PL ("  {0,-26}: {1}" -f 'Alerting', "unified=$($settings.unifiedAlertingEnabled) legacy=$($settings.alertingEnabled) legacyChannels=$($legacyChans.Count) legacyAlerts=$($legacyAlerts.Count) unifiedRules=$unifiedRuleCount")
PL ("  {0,-26}: {1}" -f 'Content', "dashboards=$exportedDash folders=$($folders.Count) libraryPanels=$(@($(if ($lib) { $lib.result })).Count) plugins(non-core)=$(@($plugins | Where-Object { $_.signature -ne 'internal' }).Count)")
PL ("  {0,-26}: {1}" -f 'Queries', "$($qRows.Count) extracted, $($qEval.Count) evaluated, $(@($qRows | Where-Object { $_.LiveStatus -eq 'ok' }).Count) ok, $($qEmpty.Count) EMPTY, $($qErr.Count) ERROR, $($qMissing.Count) reference absent metrics")
PL ''; PL '  datasources (name | type | url | auth | health):'
foreach ($dh in $dsHealth) { PL ("    {0,-24} {1,-32} {2}" -f $dh.name, $dh.type, $dh.url); PL ("      auth={0} default={1} secure=[{2}] health={3} {4}" -f $(if ($dh.authMode) { $dh.authMode } else { $(if ($dh.basicAuth) { 'basic' } else { 'none' }) }), $dh.isDefault, ($dh.secureFields -join ','), $dh.health, $(if ($dh.healthMessage) { $dh.healthMessage.Substring(0, [Math]::Min(110, $dh.healthMessage.Length)) })) }
$nonCore = @($plugins | Where-Object { $_.signature -ne 'internal' })
if ($nonCore.Count) { PL ''; PL '  non-core plugins:'; foreach ($pl in $nonCore) { PL ("    {0,-44} {1,-10} {2,-12} {3}{4}" -f $pl.id, $pl.info.version, $pl.type, $pl.signature, $(if ($pl.angularDetected) { '  ANGULAR' })) } }
PL ''; PL '  findings:'
foreach ($f in ($Script:Findings | Sort-Object { @{critical=0;serious=1;warning=2;info=3}[$_.severity] })) { PL ("    [{0}] ({1}) {2}" -f $f.severity.ToUpper(), $f.area, $f.finding) }
if ($Script:Failures.Count) { PL ''; PL '  API failures (endpoint, status, error):'; foreach ($fl in $Script:Failures) { PL ("    {0,-56} {1,-5} {2}" -f $fl.endpoint, $fl.status, ($fl.error -replace '[\r\n]+', ' ')) } }
if ($qMissing.Count) {
    PL ''; PL '  metrics referenced by dashboards that do not exist in the TSDB (count of queries):'
    $mc = @{}; foreach ($q in $qMissing) { foreach ($m in ($q.MetricsMissingInTsdb -split ';')) { if ($m) { $mc[$m] = [int]$mc[$m] + 1 } } }
    foreach ($k in ($mc.Keys | Sort-Object { -$mc[$_] } | Select-Object -First 30)) { PL ("    {0,4}  {1}{2}" -f $mc[$k], $k, $(if ($k -like 'wmi_*') { '   (rename bridge candidate)' })) }
}
if ($qEmpty.Count) {
    PL ''; PL '  panels returning no data today, by dashboard:'
    foreach ($g in ($qEmpty | Group-Object Dashboard | Sort-Object Count -Descending | Select-Object -First 20)) { PL ("    {0,4}  {1}" -f $g.Count, $g.Name) }
}
if ($qErr.Count) { PL ''; PL '  queries that ERROR:'; foreach ($q in ($qErr | Select-Object -First 15)) { PL ("    {0} / {1}: {2}" -f $q.Dashboard, $q.Panel, $q.LiveError) } }
if ($vEmpty.Count) { PL ''; PL '  variables resolving to nothing:'; foreach ($v in $vEmpty) { PL ("    {0} / `${1}  {2}" -f $v.Dashboard, $v.Variable, $v.Query) } }
if ($recentEdits.Count) { PL ''; PL '  edited in the last 14 days:'; foreach ($r in ($recentEdits | Select-Object -First 15)) { PL ("    {0}  v{1}  {2}  {3}" -f (Stamp $r.Updated), $r.Version, $r.UpdatedBy, $r.Title) } }
PL ''; PL '  dashboards by folder:'
foreach ($grp in ($index | Group-Object Folder | Sort-Object Name)) { PL ("    {0} ({1}): {2}" -f $grp.Name, $grp.Count, (($grp.Group | Sort-Object Title | ForEach-Object { $_.Title }) -join '; ')) }
PL ('=' * 78); PL '  END OF SUMMARY'; PL ('=' * 78)
($L -join "`r`n") | Out-File -LiteralPath (Join-Path $OutputPath 'SUMMARY.txt') -Encoding UTF8
Write-Host ($L -join "`n")
try { ($L -join "`r`n") | Set-Clipboard; Write-Host "  (summary is on the clipboard and in SUMMARY.txt)" -ForegroundColor Cyan } catch {}
Write-Host "Done. Open $(Join-Path $OutputPath 'ANALYSIS.md')" -ForegroundColor Green
