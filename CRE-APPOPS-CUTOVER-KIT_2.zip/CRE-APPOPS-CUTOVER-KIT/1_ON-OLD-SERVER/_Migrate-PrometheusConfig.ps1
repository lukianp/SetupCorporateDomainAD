<#
.SYNOPSIS
  Moves a Prometheus instance to a new server and proves the new one returns the same data as the
  old one before anybody repoints DNS. Three modes: Export, Import, Compare. Read only until -Apply.

.DESCRIPTION
  The APPOPS lift runs old and new side by side and cuts over with a DNS change. That plan rests on
  one question nobody could previously answer: does the new Prometheus actually return the same
  series as the old one? -Mode Compare answers it. Everything else here exists to get you to the
  point where you can ask it.

  -Mode Export    ON THE OLD SERVER. Captures prometheus.yml verbatim, every file_sd target JSON and
                  rule file it references, the service definition (binary, flags, retention), the
                  live target list with per target health, and the complete metric name list. That
                  metric name list is the acceptance baseline: a dashboard panel goes blank when a
                  metric family stops existing, so the list is what actually predicts breakage.

  -Mode Import    ON THE NEW SERVER. Places the config and target files, and reports exactly what
                  must change and where. It does NOT rewrite the YAML silently. PowerShell has no
                  YAML parser you can rely on being present, and text surgery on YAML is how you get
                  a config that loads and means something different. Instead it shows you the edit,
                  makes it on request, and then lets Prometheus itself validate by refusing to start.

  -Mode Compare   FROM ANYWHERE THAT CAN REACH BOTH. The cutover gate. Compares target lists, metric
                  name lists and canary query values between the two instances and returns GO or
                  NO-GO. Run it repeatedly during the parallel run; run it again immediately before
                  the DNS repoint.

  Text first throughout. Every mode prints one pasteable report and writes it to C:\Migration.
  Nothing needs to leave the perimeter.

.PARAMETER Mode           Export | Import | Compare
.PARAMETER CaptureFolder  Import: the folder produced by -Mode Export.
.PARAMETER OldUrl         Compare: the old Prometheus, e.g. http://SRVCRE1APPOPS01:9090
.PARAMETER NewUrl         Compare: the new Prometheus, e.g. http://localhost:9090
.PARAMETER PrometheusUrl  Export: defaults to http://localhost:9090
.PARAMETER Tolerance      Compare: fractional difference allowed on canary values. Default 0.15.
.PARAMETER AddRenameBridge Import: insert the wmi_ to windows_ metric_relabel_configs block.
.PARAMETER Apply          Import: write files and make edits. Without it, nothing is written.
.PARAMETER Sanitize       Mask host and domain names in the report.

.EXAMPLE
  # 1. on the old server
  .\Migrate-PrometheusConfig.ps1 -Mode Export

  # 2. copy C:\Migration\promcapture-* to the new server, then
  .\Migrate-PrometheusConfig.ps1 -Mode Import -CaptureFolder C:\Migration\promcapture-... -AddRenameBridge
  .\Migrate-PrometheusConfig.ps1 -Mode Import -CaptureFolder C:\Migration\promcapture-... -AddRenameBridge -Apply

  # 3. during the parallel run, and again before the DNS repoint
  .\Migrate-PrometheusConfig.ps1 -Mode Compare -OldUrl http://SRVCRE1APPOPS01:9090 -NewUrl http://localhost:9090
#>
[CmdletBinding()]
param(
    [ValidateSet('Export', 'Import', 'Compare')]
    [string] $Mode = 'Export',
    [string] $CaptureFolder,
    [string] $PrometheusUrl = 'http://localhost:9090',
    [string] $OldUrl,
    [string] $NewUrl,
    [double] $Tolerance = 0.15,
    [switch] $AddRenameBridge,
    [switch] $Apply,
    [switch] $Sanitize
)
$ErrorActionPreference = 'Continue'
$Version = '1.1'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
New-Item -ItemType Directory -Force -Path C:\Migration | Out-Null
$ReportPath = "C:\Migration\PROMCFG-$Mode-$env:COMPUTERNAME-$stamp.txt"

# ------------------------------------------------------------------ report plumbing
$R = New-Object System.Collections.ArrayList
$Blockers = New-Object System.Collections.ArrayList
$Warns    = New-Object System.Collections.ArrayList
$Changes  = New-Object System.Collections.ArrayList
function RptLine { param($t = '') [void]$R.Add($t) }
function RptHead { param($t) RptLine ''; RptLine ('=' * 78); RptLine "  $t"; RptLine ('=' * 78) }
function RptSub  { param($t) RptLine ''; RptLine ("-- $t " + ('-' * [Math]::Max(0, 74 - $t.Length))) }
function RptKV   { param($k, $v) RptLine ("  {0,-30}: {1}" -f $k, $v) }
function Blocker { param($t, $fix = '') [void]$Blockers.Add([pscustomobject]@{ P = $t; F = $fix }); Write-Host "  BLOCKER $t" -ForegroundColor Red }
function Warn    { param($t, $fix = '') [void]$Warns.Add([pscustomobject]@{ P = $t; F = $fix }); Write-Host "  WARN    $t" -ForegroundColor Yellow }
function Changed { param($t) [void]$Changes.Add($t); Write-Host "  DONE    $t" -ForegroundColor Green }
function Stamp   { param($v) if ($v -is [datetime]) { return ($v.ToUniversalTime().ToString('s') + 'Z') } return "$v" }
function SizeOf  { param([double]$b) if ($b -ge 1GB) { return ('{0:n2} GB' -f ($b / 1GB)) } if ($b -ge 1MB) { return ('{0:n1} MB' -f ($b / 1MB)) } return ('{0:n0} KB' -f ($b / 1KB)) }
function TrimTo  { param($s, [int]$n = 100) $t = ("$s" -replace '\s+', ' ').Trim(); if ($t.Length -le $n) { $t } else { $t.Substring(0, $n - 2) + '..' } }
$script:T0 = Get-Date
function Step { param($w) Write-Host ("  [{0,4:n0}s] {1} ..." -f (New-TimeSpan -Start $script:T0 -End (Get-Date)).TotalSeconds, $w) -ForegroundColor DarkGray }
$script:Map = @{}
function Mask { param($s)
    if (-not $Sanitize -or -not $s) { return $s }
    $t = "$s"
    foreach ($k in ($script:Map.Keys | Sort-Object Length -Descending)) { $t = [regex]::Replace($t, [regex]::Escape($k), $script:Map[$k], 'IgnoreCase') }
    return $t }
function Should-Do { param([string]$What)
    if (-not $Apply) { RptLine ("    would: {0}" -f (Mask $What)); return $false }
    return $true }

function Invoke-PromApi {
    <#
      Prometheus 2.4.3 is a 2018 build. /api/v1/targets and /api/v1/status/config both exist from
      2.2, so both ends of this migration answer the same endpoints. Anything newer than that is
      probed and allowed to fail rather than assumed.
    #>
    param([string]$Base, [string]$Path, [int]$TimeoutSec = 30)
    try {
        $u = ($Base.TrimEnd('/')) + $Path
        $resp = Invoke-WebRequest $u -UseBasicParsing -TimeoutSec $TimeoutSec
        return ($resp.Content | ConvertFrom-Json)
    } catch { return $null }
}
function Get-PromMetricNames {
    param([string]$Base)
    $apiRes = Invoke-PromApi $Base '/api/v1/label/__name__/values' 90
    if ($apiRes -and $apiRes.status -eq 'success') { return @($apiRes.data) }
    return $null
}
function Get-PromTargets {
    param([string]$Base)
    $apiRes = Invoke-PromApi $Base '/api/v1/targets' 60
    if (-not $apiRes -or $apiRes.status -ne 'success') { return $null }
    return @($apiRes.data.activeTargets | ForEach-Object {
        [pscustomobject]@{
            Job       = "$($_.labels.job)"
            Instance  = "$($_.labels.instance)"
            Health    = "$($_.health)"
            ScrapeUrl = "$($_.scrapeUrl)"
            LastError = "$($_.lastError)"
        }
    })
}
function Invoke-PromQuery {
    param([string]$Base, [string]$Query)
    $apiRes = Invoke-PromApi $Base ('/api/v1/query?query=' + [uri]::EscapeDataString($Query)) 60
    if (-not $apiRes -or $apiRes.status -ne 'success') { return $null }
    return $apiRes.data.result
}
function Get-ScalarResult {
    # a query that returns one number. Returns $null if it returned nothing or many things.
    param([string]$Base, [string]$Query)
    $res = Invoke-PromQuery $Base $Query
    if ($null -eq $res) { return $null }
    $arr = @($res)
    if ($arr.Count -ne 1) { return $null }
    try { return [double]$arr[0].value[1] } catch { return $null }
}

# the queries compared between old and new. Deliberately cheap: counts and self metrics, nothing
# that walks the whole TSDB. A 2018 Prometheus will happily fall over on count({__name__=~".+"}).
$CanaryQueries = [ordered]@{
    'targets up'              = 'count(up == 1)'
    'targets down'            = 'count(up == 0)'
    'distinct jobs'           = 'count(count by (job) (up))'
    'head series'             = 'prometheus_tsdb_head_series'
    'exporters answering'     = 'count(up{job=~".*exporter.*|.*windows.*|.*wmi.*"} == 1)'
    'textfile files exposed'  = 'count(count by (instance) ({__name__=~"(wmi|windows)_textfile_mtime_seconds"}))'
    'textfile scrape errors'  = 'sum({__name__=~"(wmi|windows)_textfile_scrape_error"})'
}

# Compare only reads two HTTP endpoints, so it does not need elevation and does not need Windows.
# Export and Import read service definitions and write files, so they do.
if ($Mode -ne 'Compare') {
    $isAdmin = $false
    try { $isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator) }
    catch { throw "-Mode $Mode reads Windows service definitions and must run on Windows." }
    if (-not $isAdmin) { throw "Run -Mode $Mode in an ELEVATED PowerShell." }
}

if ($Sanitize) { $script:Map[$env:COMPUTERNAME] = 'THIS-HOST'; try { $script:Map["$((Get-CimInstance Win32_ComputerSystem).Domain)"] = 'DOM.LOCAL' } catch {} }

Write-Host ''
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ("  Migrate-PrometheusConfig {0}  MODE: {1}" -f $Version, $Mode.ToUpper()) -ForegroundColor Cyan
if ($Mode -eq 'Import') { Write-Host ("  {0}" -f $(if ($Apply) { 'APPLY' } else { 'DRY RUN - add -Apply to write anything' })) -ForegroundColor $(if ($Apply) { 'Yellow' } else { 'DarkGray' }) }
Write-Host '  =========================================================' -ForegroundColor Cyan
Write-Host ''

RptHead "PROMETHEUS CONFIG MIGRATION - $Mode"
RptKV 'Generated' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
RptKV 'Script'    "Migrate-PrometheusConfig $Version"
RptKV 'Host'      (Mask $env:COMPUTERNAME)

# ==================================================================== EXPORT
if ($Mode -eq 'Export') {

    $OutDir = "C:\Migration\promcapture-$env:COMPUTERNAME-$stamp"
    New-Item -ItemType Directory -Force -Path $OutDir | Out-Null
    RptKV 'Capture folder' $OutDir

    Step 'service definition'
    RptSub '1. the service, as Windows actually runs it'
    $svc = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
             Where-Object { $_.Name -match 'prometheus' -or $_.PathName -match 'prometheus\.exe' }) | Select-Object -First 1
    $cfgPath = $null; $dataDir = $null; $retention = $null; $binPath = $null; $workDir = $null; $listen = $null
    if (-not $svc) {
        Blocker 'no Prometheus service found on this host' 'Check the service name, or run this on the server that actually hosts Prometheus'
    } else {
        RptKV 'Service name'  $svc.Name
        RptKV 'State / start' ("{0} / {1}" -f $svc.State, $svc.StartMode)
        RptKV 'Account'       (Mask $svc.StartName)
        RptLine ("  PathName:")
        RptLine ("    {0}" -f (Mask $svc.PathName))
        $pn = "$($svc.PathName)"
        # NSSM wraps the real binary, so the flags may live in the registry rather than PathName
        if ($pn -match '(?i)nssm') {
            RptLine '    (NSSM wrapper detected - the real arguments are in the registry, read below)'
            $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$($svc.Name)\Parameters"
            if (Test-Path $key) {
                $p = Get-ItemProperty -Path $key -ErrorAction SilentlyContinue
                foreach ($n in 'Application', 'AppParameters', 'AppDirectory', 'AppStdout', 'AppStderr', 'AppEnvironmentExtra') {
                    if ($p.$n) { RptKV "  nssm $n" (Mask (@($p.$n) -join ' | ')) }
                }
                $pn = "$($p.Application) $($p.AppParameters)"
                $workDir = "$($p.AppDirectory)"
            } else {
                Blocker "NSSM wrapper but no Parameters key at $key" 'The service definition is incomplete. Read it with nssm.exe dump <name> and pass the config path by hand.'
            }
        }
        if ($pn -match '--config\.file[=\s]+"([^"]+)"|--config\.file[=\s]+([^\s"]+)')            { $cfgPath   = "$($Matches[1])$($Matches[2])" }
        if ($pn -match '--storage\.tsdb\.path[=\s]+"([^"]+)"|--storage\.tsdb\.path[=\s]+([^\s"]+)') { $dataDir   = "$($Matches[1])$($Matches[2])" }
        if ($pn -match '--storage\.tsdb\.retention(?:\.time)?[=\s]+"?([^"\s]+)"?') { $retention = $Matches[1] }
        if ($pn -match '--web\.listen-address[=\s]+"?([^"\s]+)"?') { $listen = $Matches[1] }
        if ($pn -match '^\s*"([^"]+prometheus\.exe)"|^\s*(\S+prometheus\.exe)') { $binPath = "$($Matches[1])$($Matches[2])" }
        # a relative flag resolves against the process working directory: NSSM AppDirectory, else the exe folder
        if (-not $workDir -and $binPath) { $workDir = Split-Path -Parent $binPath }
        if ($cfgPath -and -not [System.IO.Path]::IsPathRooted($cfgPath) -and $workDir) { $cfgPath = Join-Path $workDir $cfgPath }
        if ($dataDir -and -not [System.IO.Path]::IsPathRooted($dataDir) -and $workDir) { $dataDir = Join-Path $workDir $dataDir }
        if (-not $dataDir -and $workDir) { $dataDir = Join-Path $workDir 'data' }
        RptKV 'Working directory' (Mask $workDir)
        RptKV 'Config file' $(if ($cfgPath) { Mask $cfgPath } else { 'NOT FOUND IN FLAGS - defaults to prometheus.yml in the working directory' })
        RptKV 'TSDB path'   (Mask $dataDir)
        RptKV 'Listen'      $(if ($listen) { $listen } else { '(default :9090)' })
        if ($listen -match ':(\d+)$' -and $PrometheusUrl -eq 'http://localhost:9090' -and $Matches[1] -ne '9090') { $PrometheusUrl = "http://localhost:$($Matches[1])"; RptKV 'API URL' "$PrometheusUrl (from --web.listen-address)" }
        RptKV 'Retention'   $(if ($retention) { $retention } else { 'NOT SET - Prometheus default applies (15d on 2.x)' })
        if (-not $retention) {
            Warn 'no explicit retention flag' 'The parallel run duration is set from the retention window. Confirm the effective value before booking the cutover.'
        }
        if ($binPath -and (Test-Path -LiteralPath $binPath)) {
            $fv = (Get-Item -LiteralPath $binPath).VersionInfo.FileVersion
            RptKV 'Binary version (file)' $(if ($fv) { $fv } else { '(not stamped - Go binaries often are not)' })
        }
    }

    # version: prometheus_build_info exists on every 2.x; /status/buildinfo only from 2.14; --version always
    $apiVersion = $null
    $bi = Invoke-PromApi $PrometheusUrl '/api/v1/status/buildinfo' 20
    if ($bi -and $bi.data) { $apiVersion = "$($bi.data.version)"; RptKV 'Version (API)' ("{0} (go {1})" -f $bi.data.version, $bi.data.goVersion) }
    else {
        $bq = Invoke-PromQuery $PrometheusUrl 'prometheus_build_info'
        if ($bq -and @($bq).Count) { $m0 = @($bq)[0].metric; $apiVersion = "$($m0.version)"; RptKV 'Version (prometheus_build_info)' ("{0} (go {1}, rev {2})" -f $m0.version, $m0.goversion, $m0.revision) }
        else { RptLine '  (no version from the API: buildinfo needs 2.14+, prometheus_build_info returned nothing)' }
    }
    if (-not $apiVersion -and $binPath -and (Test-Path -LiteralPath $binPath)) {
        try { $vt = (& $binPath --version 2>&1 | Out-String); if ($vt -match 'prometheus, version ([0-9][0-9.]*)') { $apiVersion = $Matches[1]; RptKV 'Version (--version)' $apiVersion } } catch {}
    }
    # effective flags from the running process beat the command line parse
    $fl = Invoke-PromApi $PrometheusUrl '/api/v1/status/flags' 20
    if ($fl -and $fl.data) {
        $er = "$($fl.data.'storage.tsdb.retention.time')"; if (-not $er -or $er -eq '0s') { $er = "$($fl.data.'storage.tsdb.retention')" }
        if ($er -and $er -ne '0s') { $retention = $er; RptKV 'Retention (API)' $er }
        $ec = "$($fl.data.'config.file')"; if ($ec) { if (-not [System.IO.Path]::IsPathRooted($ec) -and $workDir) { $ec = Join-Path $workDir $ec }; if ($cfgPath -and $ec -ne $cfgPath) { Warn "the running process reports config.file=$ec, the service definition resolves to $cfgPath" 'Trust the API. The service definition was changed after the last restart.' }; if (-not $cfgPath) { $cfgPath = $ec } }
        $ed = "$($fl.data.'storage.tsdb.path')"; if ($ed) { if (-not [System.IO.Path]::IsPathRooted($ed) -and $workDir) { $ed = Join-Path $workDir $ed }; if (-not $dataDir) { $dataDir = $ed } }
    }
    $rt = Invoke-PromApi $PrometheusUrl '/api/v1/status/runtimeinfo' 15
    if ($rt -and $rt.data) { RptKV 'Started' (Stamp $rt.data.startTime); RptKV 'Last config reload' ("{0} ok={1}" -f (Stamp $rt.data.lastConfigTime), $rt.data.reloadConfigSuccess); if ("$($rt.data.reloadConfigSuccess)" -eq 'False') { Blocker 'the last config reload FAILED: the running config is not the file on disk' 'Fix prometheus.yml on the old server and reload before capturing, or the capture carries a broken config.' } }
    # TSDB on disk: the oldest block says what the retention really is
    if ($dataDir -and (Test-Path -LiteralPath $dataDir)) {
        $blocks = @(Get-ChildItem -LiteralPath $dataDir -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^[0-9A-Z]{26}$' })
        $minT = $null; $maxT = $null
        foreach ($b in $blocks) { $mp = Join-Path $b.FullName 'meta.json'; if (Test-Path -LiteralPath $mp) { try { $mj = Get-Content -LiteralPath $mp -Raw | ConvertFrom-Json; if ($null -eq $minT -or [long]$mj.minTime -lt $minT) { $minT = [long]$mj.minTime }; if ($null -eq $maxT -or [long]$mj.maxTime -gt $maxT) { $maxT = [long]$mj.maxTime } } catch {} } }
        $tsdbBytes = 0; try { $tsdbBytes = (Get-ChildItem -LiteralPath $dataDir -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object -Property Length -Sum).Sum } catch {}
        RptKV 'TSDB size on disk' ('{0}, {1} blocks' -f (SizeOf $tsdbBytes), $blocks.Count)
        if ($null -ne $minT) { $oldest = ([DateTimeOffset]::FromUnixTimeMilliseconds($minT)).UtcDateTime; $dataDays = [math]::Round(((Get-Date).ToUniversalTime() - $oldest).TotalDays, 1); RptKV 'Oldest sample on disk' ("{0}Z ({1} days)" -f $oldest.ToString('s'), $dataDays) }
        if ($null -ne $maxT) { RptKV 'Newest block boundary' (([DateTimeOffset]::FromUnixTimeMilliseconds($maxT)).UtcDateTime.ToString('s') + 'Z') }
    } elseif ($dataDir) { Warn "TSDB path $dataDir does not exist" 'The working directory resolution is wrong or the data lives elsewhere. Find it by hand: the size sets the disk on the replacement.' }

    Step 'config file'
    RptSub '2. prometheus.yml'
    if (-not $cfgPath) { $cfgPath = $(if ($binPath) { Join-Path (Split-Path $binPath -Parent) 'prometheus.yml' } else { $null }) }
    $cfgText = $null
    if ($cfgPath -and (Test-Path -LiteralPath $cfgPath)) {
        $cfgText = Get-Content -LiteralPath $cfgPath -Raw
        Copy-Item -LiteralPath $cfgPath -Destination (Join-Path $OutDir 'prometheus.yml') -Force
        RptKV 'Captured' (Join-Path $OutDir 'prometheus.yml')
        RptKV 'Size'     ("{0} bytes, {1} lines" -f $cfgText.Length, @($cfgText -split "`n").Count)
        # job names, purely for the report. No YAML parsing is attempted anywhere in this script.
        $jobs = @([regex]::Matches($cfgText, '(?m)^\s*-?\s*job_name:\s*[''"]?([^''"\r\n#]+)') | ForEach-Object { $_.Groups[1].Value.Trim() })
        RptKV 'Scrape jobs'  $jobs.Count
        foreach ($j in $jobs) { RptLine ("     {0}" -f (Mask $j)) }
        $hasBridge = ($cfgText -match 'metric_relabel_configs')
        RptKV 'Has metric_relabel_configs' $hasBridge
        $live = (($cfgText -split "`r?`n") | Where-Object { $_ -notmatch '^\s*#' }) -join "`n"
        $amLive = [bool]($live -match '(?ms)^alerting:.*?alertmanagers:')
        $amComment = [bool]($cfgText -match '(?m)^\s*#.*alertmanager' -or $cfgText -match '(?m)^\s*#.*9093')
        RptKV 'Alertmanager configured' $(if ($amLive) { 'YES (live)' } elseif ($amComment) { 'no (present but commented out)' } else { 'no' })
        RptKV 'remote_write / remote_read' ("{0} / {1}" -f @([regex]::Matches($live, '(?m)^\s*remote_write:')).Count, @([regex]::Matches($live, '(?m)^\s*remote_read:')).Count)
        RptKV 'basic_auth / tls / https' ("{0} / {1} / {2}" -f [bool]($live -match '(?m)^\s*basic_auth:'), [bool]($live -match '(?m)^\s*tls_config:'), [bool]($live -match '(?m)^\s*scheme:\s*https'))
        if ($live -match '(?m)^\s*scrape_interval:\s*(\S+)') { RptKV 'Global scrape_interval' $Matches[1] }
        if ($live -match '(?m)^\s*evaluation_interval:\s*(\S+)') { RptKV 'Global evaluation_interval' $Matches[1] }
        if ($live -match '(?m)^\s*remote_write:') { Warn 'remote_write is configured' 'Two instances writing the same series to one remote during the parallel run double count. Disable remote_write on the new instance until cutover.' }
        if ($cfgText -match [regex]::Escape($env:COMPUTERNAME)) { Warn 'prometheus.yml names this host' 'Decide per entry on the replacement: a self scrape becomes localhost; a scrape OF this host stays until decommission.' }
        $secrets = @([regex]::Matches($live, '(?im)^\s*(password|bearer_token|secret|client_secret|api_key)\s*:\s*\S')).Count
        if ($secrets) { Warn "prometheus.yml carries $secrets clear text secret value(s)" 'They travel with the file copy. Note it on the change; do not paste this file outside the perimeter.' }
        $cfgHash = (Get-FileHash -LiteralPath $cfgPath -Algorithm SHA256).Hash
        RptKV 'SHA256' $cfgHash
    } else {
        Blocker "prometheus.yml not found$(if ($cfgPath) { " at $cfgPath" })" 'Locate it from the service definition above and pass it by hand'
    }

    Step 'referenced files'
    RptSub '3. files the config points at'
    $refs = New-Object System.Collections.ArrayList
    $refHashes = New-Object System.Collections.ArrayList
    if ($cfgText) {
        foreach ($pat in @('(?m)^\s*-\s*[''"]?([^''"\r\n#]+\.(?:json|yml|yaml))[''"]?\s*$',
                           '(?m)files:\s*\[([^\]]+)\]')) {
            foreach ($m in [regex]::Matches($cfgText, $pat)) {
                foreach ($cand in ($m.Groups[1].Value -split ',')) {
                    $c = $cand.Trim().Trim('"', "'")
                    if ($c) { [void]$refs.Add($c) }
                }
            }
        }
    }
    $refs = @($refs | Sort-Object -Unique)
    RptKV 'Referenced paths' $refs.Count
    $cfgDir = $(if ($cfgPath) { Split-Path $cfgPath -Parent } else { $null })
    $copied = 0
    New-Item -ItemType Directory -Force -Path (Join-Path $OutDir 'referenced') | Out-Null
    foreach ($ref in $refs) {
        # a relative path in prometheus.yml resolves against the config's own directory
        $resolved = $ref
        if (-not [System.IO.Path]::IsPathRooted($ref) -and $cfgDir) { $resolved = Join-Path $cfgDir $ref }
        $hits = @()
        try { $hits = @(Get-Item -Path $resolved -ErrorAction Stop) } catch {}
        if (-not $hits.Count) {
            RptLine ("     {0,-58} MISSING" -f (Mask $ref))
            Warn "$(Mask $ref) is referenced by prometheus.yml but does not exist" 'Either a glob that matches nothing today, or a genuine broken reference. Check before the new server inherits it.'
            continue
        }
        foreach ($h in $hits) {
            $hh = ''; try { $hh = (Get-FileHash -LiteralPath $h.FullName -Algorithm SHA256).Hash.Substring(0, 12) } catch {}
            RptLine ("     {0,-58} {1,7} bytes  {2}  {3}" -f (Mask $h.FullName), $h.Length, $h.LastWriteTime.ToString('yyyy-MM-dd'), $hh)
            Copy-Item -LiteralPath $h.FullName -Destination (Join-Path $OutDir "referenced\$($h.Name)") -Force
            [void]$refHashes.Add([pscustomobject]@{ file = $h.Name; source = $h.FullName; bytes = $h.Length; modified = $h.LastWriteTime.ToString('s'); sha256 = $hh })
            $copied++
            if ($h.Name -match '\.json$') {
                try {
                    $tj = Get-Content -LiteralPath $h.FullName -Raw | ConvertFrom-Json
                    foreach ($grp in @($tj)) { foreach ($tt in @($grp.targets)) {
                        if ("$tt" -match '(?i)SERVERURL|:PORT$|#\{|<|>') { Warn "$($h.Name) contains placeholder target '$tt'" 'Never a real host. Remove it from the copy on the replacement.' }
                        if ($env:COMPUTERNAME -and "$tt" -match [regex]::Escape($env:COMPUTERNAME)) { RptLine ("       target names THIS host: {0}" -f (Mask "$tt")) }
                    } }
                } catch { Warn "$($h.Name) is not valid JSON: Prometheus ignores the whole file" 'Fix it before it is copied, or the replacement inherits an empty job.' }
            }
        }
    }
    RptKV 'Copied into capture' $copied
    # safety net: every small non data file in the config directory, in case the regex above missed a
    # reference (a rule file named oddly, a consoles folder, a TLS cert). Nothing under the TSDB path.
    if ($cfgDir -and (Test-Path -LiteralPath $cfgDir)) {
        $treeDir = Join-Path $OutDir 'configtree'
        New-Item -ItemType Directory -Force -Path $treeDir | Out-Null
        $treeN = 0
        foreach ($f in @(Get-ChildItem -LiteralPath $cfgDir -Recurse -File -ErrorAction SilentlyContinue | Where-Object { $_.Length -lt 5MB -and $_.Extension -notmatch '(?i)^\.(exe|dll|db|log|zip|msi|pdb)$' -and -not ($dataDir -and $_.FullName.StartsWith($dataDir, [StringComparison]::OrdinalIgnoreCase)) -and $_.FullName -notmatch '(?i)\\(wal|chunks_head)\\' -and $_.Directory.Name -notmatch '^[0-9A-Z]{26}$' })) {
            $rel = $f.FullName.Substring($cfgDir.Length).TrimStart('\')
            $dest = Join-Path $treeDir $rel
            $dd = Split-Path -Parent $dest; if (-not (Test-Path -LiteralPath $dd)) { New-Item -ItemType Directory -Force -Path $dd | Out-Null }
            Copy-Item -LiteralPath $f.FullName -Destination $dest -Force -ErrorAction SilentlyContinue
            $treeN++
            if ($treeN -ge 400) { break }
        }
        RptKV 'Config tree safety copy' ("{0} file(s) under configtree\ (everything small and non data beside prometheus.yml)" -f $treeN)
    }

    Step 'live targets'
    RptSub '4. what it is scraping right now'
    $tg = Get-PromTargets $PrometheusUrl
    if ($null -eq $tg) {
        Blocker "no answer from $PrometheusUrl/api/v1/targets" 'Prometheus must be running for the export to capture the baseline. Start it and re-run.'
    } else {
        foreach ($t in $tg) {
            $cls = 'up'
            if ($t.Health -ne 'up') {
                $le = $t.LastError
                if ($t.Instance -match '(?i)SERVERURL|:PORT$|#\{|<|>|example|placeholder') { $cls = 'PLACEHOLDER' }
                elseif ($le -match '(?i)no such host|name resolution|could not resolve') { $cls = 'DNS' }
                elseif ($le -match '(?i)connection refused|actively refused|forcibly closed') { $cls = 'REFUSED' }
                elseif ($le -match '(?i)timeout|deadline exceeded') { $cls = 'TIMEOUT' }
                elseif ($le -match '(?i)certificate|tls|x509') { $cls = 'TLS' }
                elseif ($le -match '(?i)401|403|unauthori') { $cls = 'AUTH' }
                elseif ($le -match '(?i)server returned HTTP status|404') { $cls = 'HTTP' }
                else { $cls = 'OTHER' }
            }
            $t | Add-Member -NotePropertyName Class -NotePropertyValue $cls -Force
            $t | Add-Member -NotePropertyName Dns -NotePropertyValue '' -Force
            $t | Add-Member -NotePropertyName Tcp -NotePropertyValue '' -Force
        }
        $up   = @($tg | Where-Object Health -eq 'up')
        $down = @($tg | Where-Object Health -ne 'up')
        RptKV 'Targets total' $tg.Count
        RptKV 'Up'            $up.Count
        RptKV 'Down'          $down.Count
        # DNS and TCP truth for the down ones, bounded, so each register entry says WHY
        $probe = @($down | Where-Object { $_.Class -in 'DNS', 'REFUSED', 'TIMEOUT', 'OTHER' } | ForEach-Object { $_.Instance } | Sort-Object -Unique | Select-Object -First 60)
        if ($probe.Count) {
            Step "probing $($probe.Count) down target(s)"
            $pj = $null
            try {
                $pj = Start-Job -ArgumentList (,@($probe)) -ScriptBlock {
                    param($list)
                    $o = @{}
                    foreach ($i in $list) {
                        $hn = $i; $pt = 0
                        if ($i -match '^\[?([^\]:]+)\]?:(\d+)$') { $hn = $Matches[1]; $pt = [int]$Matches[2] }
                        $probeRes = @{ dns = ''; tcp = '' }
                        try { $ips = [System.Net.Dns]::GetHostAddresses($hn); $probeRes.dns = (@($ips | ForEach-Object { $_.IPAddressToString }) -join ' ') } catch { $probeRes.dns = 'NXDOMAIN' }
                        if ($probeRes.dns -ne 'NXDOMAIN' -and $pt) {
                            try { $c = New-Object System.Net.Sockets.TcpClient; $ar = $c.BeginConnect($hn, $pt, $null, $null)
                                  if ($ar.AsyncWaitHandle.WaitOne(3000)) { try { $c.EndConnect($ar); $probeRes.tcp = 'open' } catch { $probeRes.tcp = 'refused' } } else { $probeRes.tcp = 'timeout' }
                                  $c.Close() } catch { $probeRes.tcp = 'refused' }
                        }
                        $o[$i] = $probeRes
                    }
                    $o
                }
                if (Wait-Job $pj -Timeout 150) { $pres = Receive-Job $pj -ErrorAction SilentlyContinue; if ($pres) { foreach ($d in $down) { if ($pres.ContainsKey($d.Instance)) { $d.Dns = "$($pres[$d.Instance].dns)"; $d.Tcp = "$($pres[$d.Instance].tcp)" } } } }
                else { RptLine '     (probe timed out; DNS/TCP columns incomplete)' }
            } catch {} finally { if ($pj) { Stop-Job $pj -ErrorAction SilentlyContinue; Remove-Job $pj -Force -ErrorAction SilentlyContinue } }
        }
        $tg | Select-Object Job, Instance, Health, Class, Dns, Tcp, ScrapeUrl, LastError |
            Export-Csv (Join-Path $OutDir 'targets.csv') -NoTypeInformation
        $ips = @()
        try { $ips = @(Get-CimInstance Win32_NetworkAdapterConfiguration -Filter 'IPEnabled=TRUE' -ErrorAction SilentlyContinue | ForEach-Object { @($_.IPAddress) } | Where-Object { $_ -and $_ -notmatch ':' }) } catch {}
        RptKV 'Scrapes come FROM' (Mask ($ips -join ', '))
        RptLine '     Every UP target has an inbound exporter rule that admits that address. The replacement has a new one.'
        RptLine ''
        RptLine '  by job:'
        foreach ($g in ($tg | Group-Object Job | Sort-Object Name)) {
            $u = @($g.Group | Where-Object Health -eq 'up').Count
            RptLine ("     {0,-38} {1,3} up / {2,3} total" -f (Mask $g.Name), $u, $g.Count)
        }
        if ($down.Count) {
            RptLine ''
            RptLine '  DOWN right now (these are pre-existing, not caused by the migration):'
            RptLine ("     {0,-12} {1,-40} {2,-16} {3,-8} {4}" -f 'CLASS', 'INSTANCE', 'DNS', 'TCP', 'ERROR')
            foreach ($d in ($down | Sort-Object Class, Instance | Select-Object -First 40)) {
                RptLine ("     {0,-12} {1,-40} {2,-16} {3,-8} {4}" -f $d.Class, (Mask $d.Instance), (TrimTo $d.Dns 16), $d.Tcp, (TrimTo $d.LastError 50))
            }
            if ($down.Count -gt 40) { RptLine ("     ... and {0} more, see targets.csv" -f ($down.Count - 40)) }
            $byClass = ($down | Group-Object Class | Sort-Object Name | ForEach-Object { "$($_.Name)=$($_.Count)" }) -join ', '
            Warn "$($down.Count) target(s) are already down on the OLD server ($byClass)" 'PLACEHOLDER and DNS: remove from the target files. REFUSED with TCP refused: exporter stopped on a live host. TIMEOUT: firewall. Decide each before the gate runs, or it compares against a broken baseline.'
            $selfDown = @($down | Where-Object { $env:COMPUTERNAME -and $_.Instance -match [regex]::Escape($env:COMPUTERNAME) })
            if ($selfDown.Count) { Warn "this host's own exporter target is down: $($selfDown[0].Instance)" 'The self scrape must work on the replacement; fix the exporter here first so the gate has a baseline.' }
        }
    }

    Step 'metric name baseline'
    RptSub '5. metric families - THIS is the acceptance baseline'
    $names = Get-PromMetricNames $PrometheusUrl
    if ($null -eq $names) {
        Warn 'could not read the metric name list' 'Compare mode loses its most useful check without it. Confirm /api/v1/label/__name__/values answers on this instance.'
    } else {
        RptKV 'Distinct metric families' $names.Count
        $names | Sort-Object | Set-Content (Join-Path $OutDir 'metric-names.txt') -Encoding utf8
        $wmi = @($names | Where-Object { $_ -like 'wmi_*' }).Count
        $win = @($names | Where-Object { $_ -like 'windows_*' }).Count
        RptKV '  wmi_* families'     $wmi
        RptKV '  windows_* families' $win
        RptLine ''
        RptLine '    A dashboard panel goes blank when the metric family behind it stops existing.'
        RptLine '    Compare mode diffs this list between old and new, so it predicts blank panels'
        RptLine '    before a human opens the dashboard and finds them.'
    }

    Step 'canary values'
    RptSub '6. canary values'
    $canary = [ordered]@{}
    foreach ($k in $CanaryQueries.Keys) {
        $v = Get-ScalarResult $PrometheusUrl $CanaryQueries[$k]
        $canary[$k] = $v
        RptLine ("     {0,-26} {1}" -f $k, $(if ($null -eq $v) { '(no single value returned)' } else { $v }))
    }
    $canary | ConvertTo-Json -Depth 4 | Set-Content (Join-Path $OutDir 'canary.json') -Encoding utf8

    # manifest ties it together for Import and Compare
    [pscustomobject]@{
        host        = $env:COMPUTERNAME
        capturedAt  = (Get-Date).ToString('s')
        service     = $(if ($svc) { $svc.Name } else { $null })
        binPath     = $binPath
        configPath  = $cfgPath
        dataDir     = $dataDir
        retention   = $retention
        version     = $apiVersion
        workDir     = $workDir
        listen      = $listen
        apiUrl      = $PrometheusUrl
        configSha256 = $(if ($cfgText) { $cfgHash } else { $null })
        referenced  = @($refHashes)
        sourceIPs   = @($ips)
        jobCount    = $(if ($cfgText) { @([regex]::Matches($cfgText, '(?m)^\s*-?\s*job_name:')).Count } else { 0 })
        targetCount = $(if ($tg) { $tg.Count } else { 0 })
        targetsUp   = $(if ($tg) { @($tg | Where-Object Health -eq 'up').Count } else { 0 })
        downByClass = $(if ($tg) { $h = @{}; foreach ($g in ($tg | Where-Object Health -ne 'up' | Group-Object Class)) { $h[$g.Name] = $g.Count }; $h } else { @{} })
        metricCount = $(if ($names) { $names.Count } else { 0 })
        tool        = "Migrate-PrometheusConfig $Version"
    } | ConvertTo-Json -Depth 6 | Set-Content (Join-Path $OutDir 'manifest.json') -Encoding utf8

    RptSub 'next'
    RptLine "  1. Copy $OutDir to the new server."
    RptLine '  2. Run -Mode Import there. It will not write anything without -Apply.'
    RptLine '  3. Start the new Prometheus and let it run alongside this one.'
    RptLine '  4. Run -Mode Compare from anywhere that can reach both. That is the cutover gate.'
}

# ==================================================================== IMPORT
if ($Mode -eq 'Import') {

    if (-not $CaptureFolder -or -not (Test-Path -LiteralPath $CaptureFolder)) {
        throw "Pass -CaptureFolder pointing at the folder produced by -Mode Export."
    }
    RptKV 'Capture folder' $CaptureFolder

    $MO = $null
    $mf = Join-Path $CaptureFolder 'manifest.json'
    if (Test-Path -LiteralPath $mf) { try { $MO = Get-Content -LiteralPath $mf -Raw | ConvertFrom-Json } catch {} }
    if ($MO) {
        RptKV 'Source host'      (Mask $MO.host)
        RptKV 'Source version'   $(if ($MO.version) { $MO.version } else { 'unknown' })
        RptKV 'Source config'    $MO.configPath
        RptKV 'Source retention' $(if ($MO.retention) { $MO.retention } else { 'not set' })
        RptKV 'Source targets'   $MO.targetCount
        RptKV 'Source metrics'   $MO.metricCount
    }

    Step 'this host'
    RptSub '1. Prometheus on this host'
    $svc = @(Get-CimInstance Win32_Service -ErrorAction SilentlyContinue |
             Where-Object { $_.Name -match 'prometheus' -or $_.PathName -match 'prometheus\.exe' }) | Select-Object -First 1
    $localCfg = $null; $localBin = $null
    if (-not $svc) {
        Blocker 'no Prometheus service on this host' 'Install Prometheus at the version recorded in the capture manifest, wrapped with NSSM, before running Import.'
    } else {
        $pn = "$($svc.PathName)"
        if ($pn -match '(?i)nssm') {
            $key = "HKLM:\SYSTEM\CurrentControlSet\Services\$($svc.Name)\Parameters"
            if (Test-Path $key) { $p = Get-ItemProperty -Path $key -EA SilentlyContinue; $pn = "$($p.Application) $($p.AppParameters)" }
        }
        if ($pn -match '--config\.file[=\s]+"?([^"\s]+)"?') { $localCfg = $Matches[1] }
        if ($pn -match '^\s*"?([^"]+prometheus\.exe)"?')    { $localBin = $Matches[1] }
        RptKV 'Service'     $svc.Name
        RptKV 'State'       $svc.State
        RptKV 'Config file' $(if ($localCfg) { $localCfg } else { 'not in flags' })
        if (-not $localCfg -and $localBin) { $localCfg = Join-Path (Split-Path $localBin -Parent) 'prometheus.yml' }
        $lbi = Invoke-PromApi 'http://localhost:9090' '/api/v1/status/buildinfo' 15
        if ($lbi -and $lbi.data) {
            RptKV 'Version here' $lbi.data.version
            if ($MO -and $MO.version -and $lbi.data.version -ne $MO.version) {
                Warn "version differs: source $($MO.version), here $($lbi.data.version)" 'Not automatically wrong. If this is a deliberate upgrade, record it on the change. If it is not, you have installed the wrong build.'
            }
        }
    }
    if (-not $localCfg) { Blocker 'cannot determine where prometheus.yml belongs on this host' 'Fix the service definition first' }

    Step 'config placement'
    RptSub '2. config'
    $srcCfg = Join-Path $CaptureFolder 'prometheus.yml'
    $cfgText = $null
    if (-not (Test-Path -LiteralPath $srcCfg)) {
        Blocker 'prometheus.yml missing from the capture' 'Re-run -Mode Export on the old server'
    } else {
        $cfgText = Get-Content -LiteralPath $srcCfg -Raw
        RptKV 'Source config lines' @($cfgText -split "`n").Count
        if ($localCfg -and (Test-Path -LiteralPath $localCfg)) {
            $cur = Get-Content -LiteralPath $localCfg -Raw
            if ($cur -eq $cfgText) { RptLine '    the config here is already identical to the source' }
            else { RptLine ("    a DIFFERENT config already exists at {0}; it will be backed up as .bak before replacement" -f (Mask $localCfg)) }
        }
        if ($localCfg -and (Should-Do "write prometheus.yml to $localCfg")) {
            if (Test-Path -LiteralPath $localCfg) { Copy-Item -LiteralPath $localCfg -Destination "$localCfg.bak-$stamp" -Force }
            $cfgText | Set-Content -LiteralPath $localCfg -Encoding utf8
            Changed "wrote $(Mask $localCfg)"
        }
    }

    Step 'referenced files'
    RptSub '3. target and rule files'
    $refDir = Join-Path $CaptureFolder 'referenced'
    if (-not (Test-Path -LiteralPath $refDir)) { RptLine '    (none captured)' }
    else {
        $cfgDir = $(if ($localCfg) { Split-Path $localCfg -Parent } else { $null })
        foreach ($f in @(Get-ChildItem -LiteralPath $refDir -File -EA SilentlyContinue)) {
            # place them beside the config, which is where a relative reference resolves
            $dest = $(if ($cfgDir) { Join-Path $cfgDir $f.Name } else { $null })
            RptLine ("     {0,-44} -> {1}" -f $f.Name, (Mask $dest))
            if ($dest -and (Should-Do "place $($f.Name)")) {
                if (Test-Path -LiteralPath $dest) { Copy-Item -LiteralPath $dest -Destination "$dest.bak-$stamp" -Force }
                Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
                Changed "placed $($f.Name)"
            }
        }
        RptLine ''
        RptLine '    Check every target JSON for the OLD server listed as a scrape target of itself.'
        RptLine '    That entry must become the new hostname, or the new Prometheus scrapes the old box'
        RptLine '    and reports its health as if it were this one.'
        foreach ($f in @(Get-ChildItem -LiteralPath $refDir -File -Filter *.json -EA SilentlyContinue)) {
            $t = Get-Content -LiteralPath $f.FullName -Raw
            if ($MO -and $MO.host -and $t -match [regex]::Escape("$($MO.host)")) {
                RptLine ("     [CHECK] {0} contains the old hostname {1}" -f $f.Name, (Mask $MO.host))
                Warn "$($f.Name) names the old server" "Decide per entry: keep it (the old box is still a legitimate target during the parallel run) or repoint it. Do not blanket replace."
            }
        }
    }

    Step 'metric rename bridge'
    RptSub '4. the wmi_ to windows_ bridge'
    $bridge = @'
    metric_relabel_configs:
      - source_labels: [__name__]
        regex: 'windows_(.*)'
        target_label: __name__
        replacement: 'wmi_${1}'
        action: replace
'@
    if ($cfgText -and $cfgText -match 'metric_relabel_configs') {
        RptLine '    already present in the source config, nothing to add'
    } elseif (-not $AddRenameBridge) {
        RptLine '    NOT added. Pass -AddRenameBridge to have this script show and make the edit.'
        Warn 'the metric rename bridge is not in the config' 'Every dashboard querying wmi_* goes blank against a modern exporter without it.'
    } else {
        RptLine '    This block belongs under EACH scrape_config job that scrapes a windows_exporter:'
        RptLine ''
        foreach ($l in ($bridge -split "`r?`n")) { RptLine ("      {0}" -f $l) }
        RptLine ''
        RptLine '    This script does NOT insert it for you. PowerShell has no dependable YAML parser,'
        RptLine '    and text surgery on YAML produces files that load and mean something else. Add it'
        RptLine '    by hand under the right jobs, then let Prometheus validate by refusing to start.'
        Warn 'metric rename bridge needs a hand edit' 'Add the block above under each windows_exporter scrape job, then restart Prometheus and confirm it starts.'
    }

    Step 'validate'
    RptSub '5. validation'
    RptLine '    Prometheus validates its own config on start. That is the only validator that counts.'
    RptLine ''
    RptLine '      Restart-Service <prometheus service>'
    RptLine '      Start-Sleep 10'
    RptLine '      Invoke-WebRequest http://localhost:9090/-/healthy -UseBasicParsing'
    RptLine ''
    RptLine '    If it will not start, read the service log. NSSM writes stdout and stderr where its'
    RptLine '    AppStdout and AppStderr registry values point. A config error names the line number.'
    $pt = $(if ($localBin) { Join-Path (Split-Path $localBin -Parent) 'promtool.exe' } else { $null })
    if ($pt -and (Test-Path -LiteralPath $pt)) {
        RptLine ''
        RptLine ("    promtool is present. Check the config without restarting the service:")
        RptLine ("      & '{0}' check config '{1}'" -f $pt, $localCfg)
    }

    RptSub 'next'
    RptLine '  1. Make the hand edits flagged above.'
    RptLine '  2. Start Prometheus here. Confirm it starts and stays up.'
    RptLine '  3. Let it run alongside the old one for the retention window.'
    RptLine '  4. Run -Mode Compare. Do not book the DNS repoint until it returns GO.'
}

# ==================================================================== COMPARE
if ($Mode -eq 'Compare') {

    if (-not $OldUrl -or -not $NewUrl) { throw 'Pass -OldUrl and -NewUrl, e.g. -OldUrl http://SRVCRE1APPOPS01:9090 -NewUrl http://localhost:9090' }
    RptKV 'Old instance' (Mask $OldUrl)
    RptKV 'New instance' (Mask $NewUrl)
    RptKV 'Tolerance'    ("{0:P0} on canary values" -f $Tolerance)

    Step 'reachability'
    RptSub '1. both instances answer'
    $reach = $true
    foreach ($pair in @(@{ N = 'old'; U = $OldUrl }, @{ N = 'new'; U = $NewUrl })) {
        $bi = Invoke-PromApi $pair.U '/api/v1/status/buildinfo' 20
        $tgProbe = Invoke-PromApi $pair.U '/api/v1/targets' 30
        $ok = [bool]$tgProbe
        RptLine ("     {0,-6} {1,-44} {2}" -f $pair.N, (Mask $pair.U),
                 $(if ($ok) { "OK$(if ($bi -and $bi.data) { "  v$($bi.data.version)" })" } else { '*** NO ANSWER ***' }))
        if (-not $ok) { $reach = $false; Blocker "$($pair.N) instance at $(Mask $pair.U) did not answer" 'Both must be reachable for the comparison to mean anything' }
    }

    if ($reach) {
        Step 'targets'
        RptSub '2. scrape targets - anything up on OLD must be up on NEW'
        $oldT = Get-PromTargets $OldUrl
        $newT = Get-PromTargets $NewUrl
        RptKV 'Old targets' ("{0} total, {1} up" -f $oldT.Count, @($oldT | Where-Object Health -eq 'up').Count)
        RptKV 'New targets' ("{0} total, {1} up" -f $newT.Count, @($newT | Where-Object Health -eq 'up').Count)

        $newByInst = @{}
        foreach ($t in $newT) { $newByInst["$($t.Instance)"] = $t }
        $oldByInst = @{}
        foreach ($t in $oldT) { $oldByInst["$($t.Instance)"] = $t }

        $regressed = @()   # up on old, not up on new. The blocker.
        $missing   = @()   # on old, absent from new entirely
        $extra     = @()   # on new, not on old
        foreach ($t in $oldT) {
            $n = $newByInst["$($t.Instance)"]
            if (-not $n) { if ($t.Health -eq 'up') { $missing += $t }; continue }
            if ($t.Health -eq 'up' -and $n.Health -ne 'up') { $regressed += $n }
        }
        foreach ($t in $newT) { if (-not $oldByInst["$($t.Instance)"]) { $extra += $t } }

        RptLine ''
        RptKV 'Up on old, DOWN on new'    $regressed.Count
        RptKV 'Up on old, MISSING on new' $missing.Count
        RptKV 'On new but not on old'     $extra.Count

        foreach ($t in ($regressed | Select-Object -First 25)) {
            RptLine ("     DOWN    {0,-42} {1}" -f (Mask $t.Instance), (TrimTo $t.LastError 58))
        }
        foreach ($t in ($missing | Select-Object -First 25)) {
            RptLine ("     MISSING {0,-42} job={1}" -f (Mask $t.Instance), (Mask $t.Job))
        }
        foreach ($t in ($extra | Select-Object -First 10)) {
            RptLine ("     extra   {0,-42} job={1} ({2})" -f (Mask $t.Instance), (Mask $t.Job), $t.Health)
        }

        if ($regressed.Count) {
            Blocker "$($regressed.Count) target(s) are up on the old server and down on the new one" `
                    'Almost always the inbound 9182 rule on that host still names the old Prometheus IP. Fix the firewall, not the config.'
        }
        if ($missing.Count) {
            Blocker "$($missing.Count) target(s) the old server scrapes are absent from the new config" `
                    'The file_sd target JSON did not come across in full, or a glob resolves differently here.'
        }
        if ($extra.Count) {
            Warn "$($extra.Count) target(s) exist only on the new server" 'Expected if you added the new host to its own target list. Confirm nothing else crept in.'
        }

        Step 'metric families'
        RptSub '3. metric families - this predicts blank dashboard panels'
        $oldN = Get-PromMetricNames $OldUrl
        $newN = Get-PromMetricNames $NewUrl
        if ($null -eq $oldN -or $null -eq $newN) {
            Warn 'could not read the metric name list from one or both instances' 'The strongest check in this script is unavailable. Check /api/v1/label/__name__/values on each.'
        } else {
            RptKV 'Old families' $oldN.Count
            RptKV 'New families' $newN.Count
            $newSet = New-Object 'System.Collections.Generic.HashSet[string]' ([StringComparer]::Ordinal)
            foreach ($n in $newN) { [void]$newSet.Add($n) }
            $renamed = 0
            $gone    = New-Object System.Collections.ArrayList
            foreach ($n in $oldN) {
                if ($newSet.Contains($n)) { continue }
                # the estate's known rename: wmi_x becomes windows_x
                $alt = $null
                if ($n -like 'wmi_*') { $alt = 'windows_' + $n.Substring(4) }
                if ($alt -and $newSet.Contains($alt)) { $renamed++; continue }
                [void]$gone.Add($n)
            }
            RptKV 'Renamed wmi_ to windows_' $renamed
            RptKV 'GONE with no counterpart'  $gone.Count
            if ($gone.Count) {
                RptLine ''
                foreach ($n in ($gone | Sort-Object | Select-Object -First 40)) { RptLine ("       GONE {0}" -f $n) }
                if ($gone.Count -gt 40) { RptLine ("       ... and {0} more" -f ($gone.Count - 40)) }
                Blocker "$($gone.Count) metric families exist on the old server and not on the new one" `
                        'Every dashboard panel and alert rule querying one of these is blank on the new instance. Search the dashboard JSON for each name before cutting over.'
            } else {
                RptLine ''
                RptLine '     Every metric family on the old server exists on the new one, directly or via'
                RptLine '     the wmi_ to windows_ rename. No panel loses its data source in the move.'
            }
        }

        Step 'canary values'
        RptSub '4. canary values, old against new'
        RptLine ("     {0,-26} {1,>14} {2,>14}  {3}" -f 'QUERY', 'OLD', 'NEW', 'VERDICT')
        $canaryBad = 0
        foreach ($k in $CanaryQueries.Keys) {
            $o = Get-ScalarResult $OldUrl $CanaryQueries[$k]
            $n = Get-ScalarResult $NewUrl $CanaryQueries[$k]
            $verdict = ''
            if ($null -eq $o -and $null -eq $n) { $verdict = 'both empty' }
            elseif ($null -eq $o) { $verdict = 'old empty' }
            elseif ($null -eq $n) { $verdict = '*** NEW EMPTY ***'; $canaryBad++ }
            else {
                $den = [Math]::Max([Math]::Abs($o), 1)
                $diff = [Math]::Abs($o - $n) / $den
                if ($diff -le $Tolerance) { $verdict = ("match ({0:P0})" -f $diff) }
                else { $verdict = ("*** DIFFERS {0:P0} ***" -f $diff); $canaryBad++ }
            }
            RptLine ("     {0,-26} {1,14} {2,14}  {3}" -f $k,
                     $(if ($null -eq $o) { '-' } else { $o }), $(if ($null -eq $n) { '-' } else { $n }), $verdict)
        }
        if ($canaryBad) {
            Warn "$canaryBad canary value(s) differ by more than the tolerance" `
                 'Head series will legitimately differ during a parallel run because the new TSDB is younger. Target counts and textfile counts should not.'
        }
        RptLine ''
        RptLine '     head series is EXPECTED to differ during a parallel run: the new TSDB is younger.'
        RptLine '     targets up, distinct jobs and textfile files exposed are the ones that must match.'
        RptLine '     textfile scrape errors must be 0 on the new instance whatever the old one says.'
    }

    RptSub 'the cutover gate'
    if ($Blockers.Count -eq 0) {
        RptLine '  GO. The new instance sees the same targets and serves the same metric families as'
        RptLine '  the old one. The DNS repoint can be booked.'
        RptLine ''
        RptLine '  Run this again immediately before the repoint. A firewall rule or a target file can'
        RptLine '  change between the decision and the window.'
    } else {
        RptLine '  NO-GO. Do not repoint DNS. The blockers below each mean a dashboard panel or an'
        RptLine '  alert rule is blank on the new instance.'
    }
}

# ==================================================================== verdict
RptSub 'VERDICT'
if ($Blockers.Count -eq 0) {
    RptLine $(if ($Mode -eq 'Compare') { '  GO' } elseif ($Apply) { '  DONE' } else { '  No blockers.' })
} else {
    RptLine ("  NO-GO - {0} blocker(s):" -f $Blockers.Count)
    $idx = 0
    foreach ($b in $Blockers) { $idx++; RptLine ("   {0,2}. {1}" -f $idx, (Mask $b.P)); if ($b.F) { RptLine ("       fix: {0}" -f (Mask $b.F)) } }
}
if ($Warns.Count) {
    RptLine ''; RptLine '  Warnings:'
    $idx = 0
    foreach ($w in $Warns) { $idx++; RptLine ("   {0,2}. {1}" -f $idx, (Mask $w.P)); if ($w.F) { RptLine ("       {0}" -f (Mask $w.F)) } }
}
if ($Changes.Count) {
    RptLine ''; RptLine '  Changed this run:'
    foreach ($c in $Changes) { RptLine "    + $(Mask $c)" }
}
RptHead 'END OF REPORT'
RptLine '  Paste this whole report back to continue.'

$reportText = ($R -join "`r`n")
$reportText | Set-Content -LiteralPath $ReportPath -Encoding utf8
Write-Host $reportText
try { $reportText | Set-Clipboard; Write-Host "`nReport on the CLIPBOARD and saved to: $ReportPath" -ForegroundColor Cyan }
catch { Write-Host "`nReport saved to: $ReportPath" -ForegroundColor Cyan }
