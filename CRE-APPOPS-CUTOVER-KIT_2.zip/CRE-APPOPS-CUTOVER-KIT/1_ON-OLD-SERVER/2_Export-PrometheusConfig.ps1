<#
.SYNOPSIS
  STEP 2: capture the Prometheus config, targets and metric baseline from the OLD server

  Thin wrapper. The engine is _Migrate-PrometheusConfig.ps1 in this folder, which serves three
  steps. One copy means a fix reaches all three; three copies means one of them silently rots.
  Every switch you pass to this script is forwarded to the engine unchanged.

  NOTE ON THE IMPLEMENTATION: this deliberately uses the automatic $args and @args splatting, and
  deliberately has NO param() block and NO [CmdletBinding()]. The obvious-looking alternative,
  param([Parameter(ValueFromRemainingArguments)]$Forward) then @Forward, binds the collected
  arguments POSITIONALLY rather than by name, so "-CaptureFolder C:\x -Apply" arrives at the engine
  as three positional values and fails with a type conversion error on an unrelated parameter.
  Verified both ways before shipping. Do not "tidy" this into a param block.

.EXAMPLE
  .\2_Export-PrometheusConfig.ps1
#>

$engine = Join-Path $PSScriptRoot '_Migrate-PrometheusConfig.ps1'
if (-not (Test-Path -LiteralPath $engine)) {
    throw "_Migrate-PrometheusConfig.ps1 is missing from $PSScriptRoot. Copy the whole folder, not single files."
}
& $engine -Mode Export @args
