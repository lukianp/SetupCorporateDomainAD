<#
    FOSMigrate.psm1 - shared library for the Windows 2012 -> 2025 migration suite.

    Everything in here exists because something in the CRE cutover went wrong without it:

      Invoke-FosTimeout   a diagnostic that hangs is worse than one that says "skipped". Two runs
                          stalled for hours on gpresult, schtasks /S and an unbounded event query.
      Start-FosStep       a heartbeat, so a slow section is distinguishable from a hung one.
      Write-FosReport     ONE pasteable text report. Zips do not leave the perimeter.
      Add-FosMask         de-identified output when the report has to travel.
      Test-FosInList      DOMAIN\name vs bare SAM comparison. Getting this wrong made a diagnostic
                          report two accounts as missing a right that the same report listed them
                          as holding.
      Get-FosUserRight    reads rights properly via secedit rather than guessing.

    Import with:  Import-Module "$PSScriptRoot\FOSMigrate.psm1" -Force
#>

$script:Report   = New-Object System.Collections.ArrayList
$script:Findings = New-Object System.Collections.ArrayList
$script:MaskMap  = @{}
$script:Sanitize = $false
$script:T0       = Get-Date
$script:Quiet    = $false

# ------------------------------------------------------------------ report
function New-FosReport {
    [CmdletBinding()]
    param([switch]$Sanitize, [switch]$Quiet)
    $script:Report   = New-Object System.Collections.ArrayList
    $script:Findings = New-Object System.Collections.ArrayList
    $script:MaskMap  = @{}
    $script:Sanitize = [bool]$Sanitize
    $script:Quiet    = [bool]$Quiet
    $script:T0       = Get-Date
}
function Add-FosLine { param([string]$Text = '') [void]$script:Report.Add($Text) }
function Add-FosHead { param([string]$Text) Add-FosLine ''; Add-FosLine ('=' * 78); Add-FosLine "  $Text"; Add-FosLine ('=' * 78) }
function Add-FosSub  { param([string]$Text) Add-FosLine ''; Add-FosLine ("-- $Text " + ('-' * [Math]::Max(0, 74 - $Text.Length))) }
function Add-FosKV   { param([string]$Key, $Value) Add-FosLine ("  {0,-28}: {1}" -f $Key, $Value) }

function Add-FosTable {
    <#
      Rows are objects; Columns is an ordered hashtable of PropertyName = width. Addressing columns
      by property name rather than position - PowerShell flattens nested arrays on the way into a
      parameter, so positional rows silently lose their shape.
    #>
    [CmdletBinding()]
    param([object[]]$Rows, [System.Collections.Specialized.OrderedDictionary]$Columns, [string]$Indent = '  ')
    $fmt = ($Indent + ((0..($Columns.Count - 1) | ForEach-Object { "{$_,-$(@($Columns.Values)[$_])}" }) -join ' '))
    Add-FosLine ($fmt -f @($Columns.Keys))
    Add-FosLine ($Indent + ('-' * (((@($Columns.Values) | Measure-Object -Sum).Sum) + $Columns.Count)))
    if (-not $Rows -or @($Rows).Count -eq 0) { Add-FosLine "$Indent(none)"; return }
    foreach ($r in @($Rows)) {
        $vals = @()
        $i = 0
        foreach ($k in $Columns.Keys) {
            $v = $null
            if ($r -is [System.Collections.IDictionary]) { $v = $r[$k] } else { $v = $r.$k }
            $vals += (Format-FosTrim (Get-FosMask $v) @($Columns.Values)[$i]); $i++
        }
        Add-FosLine ($fmt -f $vals)
    }
}

function Format-FosTrim {
    param($Value, [int]$Max = 100)
    $t = ("$Value" -replace '\s+', ' ').Trim()
    if ($t.Length -le $Max) { return $t }
    return $t.Substring(0, [Math]::Max(1, $Max - 2)) + '..'
}
function Format-FosSize {
    param([double]$Bytes)
    if ($Bytes -ge 1GB) { return ('{0:n1} GB' -f ($Bytes / 1GB)) }
    if ($Bytes -ge 1MB) { return ('{0:n1} MB' -f ($Bytes / 1MB)) }
    if ($Bytes -ge 1KB) { return ('{0:n0} KB' -f ($Bytes / 1KB)) }
    return "$([int]$Bytes) B"
}

function Add-FosFinding {
    [CmdletBinding()]
    param(
        [ValidateSet('blocker', 'warn', 'info', 'done')] [string]$Severity,
        [string]$Area, [string]$Problem, [string]$Fix = ''
    )
    [void]$script:Findings.Add([pscustomobject]@{ Severity = $Severity; Area = $Area; Problem = $Problem; Fix = $Fix })
    if ($script:Quiet) { return }
    $c = switch ($Severity) { 'blocker' { 'Red' } 'warn' { 'Yellow' } 'done' { 'Green' } default { 'DarkGray' } }
    Write-Host ("  {0,-8} {1}" -f $Severity.ToUpper(), (Get-FosMask $Problem)) -ForegroundColor $c
}
function Get-FosFindings { param([string]$Severity) if ($Severity) { @($script:Findings | Where-Object { $_.Severity -eq $Severity }) } else { @($script:Findings) } }

function Add-FosFindingSummary {
    <# The end of every report: what is broken, numbered, with the fix next to it. #>
    Add-FosSub 'FINDINGS'
    foreach ($sev in 'blocker', 'warn') {
        $items = @(Get-FosFindings $sev)
        if (-not $items.Count) { continue }
        Add-FosLine ''
        Add-FosLine ("  {0} ({1})" -f $sev.ToUpper(), $items.Count)
        $n = 0
        foreach ($f in $items) {
            $n++
            Add-FosLine ("   {0,2}. [{1}] {2}" -f $n, $f.Area, (Get-FosMask $f.Problem))
            if ($f.Fix) { Add-FosLine ("       fix: {0}" -f (Get-FosMask $f.Fix)) }
        }
    }
    $d = @(Get-FosFindings 'done')
    if ($d.Count) {
        Add-FosLine ''
        Add-FosLine ("  CHANGED ({0})" -f $d.Count)
        foreach ($f in $d) { Add-FosLine ("    + {0}" -f (Get-FosMask $f.Problem)) }
    }
    if (-not (Get-FosFindings 'blocker').Count -and -not (Get-FosFindings 'warn').Count) {
        Add-FosLine '  nothing outstanding'
    }
}

function Write-FosReport {
    [CmdletBinding()]
    param([string]$Path, [switch]$NoConsole)
    $rendered = ($script:Report -join "`r`n")
    if ($Path) {
        $dir = Split-Path -Parent $Path
        if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
        $rendered | Set-Content -LiteralPath $Path -Encoding utf8
    }
    if (-not $NoConsole) { Write-Host $rendered }
    try { $rendered | Set-Clipboard; if ($Path) { Write-Host "`nReport on the CLIPBOARD and saved to: $Path" -ForegroundColor Cyan } }
    catch { if ($Path) { Write-Host "`nReport saved to: $Path" -ForegroundColor Cyan } }
    return $rendered
}

# ------------------------------------------------------------------ progress + safety
function Start-FosStep {
    param([string]$What)
    if ($script:Quiet) { return }
    Write-Host ("  [{0,5:n0}s] {1} ..." -f (New-TimeSpan -Start $script:T0 -End (Get-Date)).TotalSeconds, $What) -ForegroundColor DarkGray
}

function Invoke-FosTimeout {
    <#
      Runs a scriptblock in a background job and gives up after TimeoutSec. Use this for ANYTHING
      that talks to a domain controller, another machine, a share, or an event log - all of which
      can block indefinitely on a freshly built or partly joined server.
      The scriptblock runs in its own runspace, so pass state via -ArgumentList, not closure.
    #>
    [CmdletBinding()]
    param([scriptblock]$Script, [int]$TimeoutSec = 60, $Default = $null, [string]$What = 'command', [object[]]$ArgumentList = @())
    $j = $null
    try {
        $j = Start-Job -ScriptBlock $Script -ArgumentList $ArgumentList
        if (Wait-Job $j -Timeout $TimeoutSec) {
            $r = Receive-Job $j -ErrorAction SilentlyContinue
            return $r
        }
        if (-not $script:Quiet) { Write-Host ("  (skipped: {0} did not return within {1}s)" -f $What, $TimeoutSec) -ForegroundColor DarkYellow }
        Add-FosFinding -Severity info -Area 'collection' -Problem "$What timed out after ${TimeoutSec}s - that section of the report is incomplete"
        return $Default
    } catch {
        return $Default
    } finally {
        if ($j) { Stop-Job $j -ErrorAction SilentlyContinue; Remove-Job $j -Force -ErrorAction SilentlyContinue }
    }
}

function Test-FosAdmin {
    return ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}
function Assert-FosAdmin { if (-not (Test-FosAdmin)) { throw 'Run this in an ELEVATED PowerShell.' } }

# ------------------------------------------------------------------ sanitising
function Add-FosMask {
    param([string]$Real, [string]$Token)
    if (-not $script:Sanitize -or -not $Real) { return }
    if (-not $script:MaskMap.ContainsKey($Real)) { $script:MaskMap[$Real] = $Token }
}
function Get-FosMask {
    param($Text)
    if (-not $script:Sanitize -or -not $Text) { return $Text }
    $t = "$Text"
    foreach ($k in ($script:MaskMap.Keys | Sort-Object Length -Descending)) {
        $t = [regex]::Replace($t, [regex]::Escape($k), $script:MaskMap[$k], 'IgnoreCase')
    }
    # keep the RID so two accounts stay distinguishable, drop the domain identifier
    return [regex]::Replace($t, 'S-1-5-21-[\d-]+-(\d+)', 'SID-x-$1')
}
function Get-FosSanitizeState { return $script:Sanitize }

# ------------------------------------------------------------------ principals and rights
function ConvertTo-FosSam { param($Principal) (("$Principal" -split '\\')[-1]).Trim() }

function Test-FosInList {
    <#
      Is this account in this list of principals? The list usually holds DOMAIN\name while the
      account is often a bare SAM name; -ieq between the two forms never matches, which is exactly
      how a diagnostic came to report an account as lacking a right it plainly held.
    #>
    param($Account, [string[]]$List, [switch]$IncludeWellKnownGroups)
    if (-not $List) { return $false }
    $sam = ConvertTo-FosSam $Account
    foreach ($p in $List) {
        if (-not $p) { continue }
        if ($p -ieq "$Account") { return $true }
        if ((ConvertTo-FosSam $p) -ieq $sam) { return $true }
        if ($IncludeWellKnownGroups -and $p -match '(?i)\\(Users|Everyone|Authenticated Users)$') { return $true }
    }
    return $false
}

function Resolve-FosPrincipal {
    param($Principal)
    $v = "$Principal".Trim()
    if ($v -match '^\*?(S-1-[0-9-]+)$') {
        try { return (New-Object System.Security.Principal.SecurityIdentifier($Matches[1])).Translate([System.Security.Principal.NTAccount]).Value }
        catch { return $Matches[1] }
    }
    return $v
}

function Export-FosSecurityPolicy {
    <# One secedit export, cached, so eight right lookups do not run secedit eight times. #>
    param([switch]$Force)
    if ($script:SecPol -and -not $Force) { return $script:SecPol }
    $inf = Join-Path ([IO.Path]::GetTempPath()) ('secpol-' + [guid]::NewGuid().ToString('N') + '.inf')
    try { $null = & secedit /export /cfg $inf /quiet 2>&1 } catch {}
    $script:SecPol = @()
    if (Test-Path -LiteralPath $inf) { $script:SecPol = @(Get-Content -LiteralPath $inf -ErrorAction SilentlyContinue) }
    Remove-Item -LiteralPath $inf -ErrorAction SilentlyContinue
    return $script:SecPol
}

function Get-FosUserRight {
    <# Resolved principal names holding a right, e.g. SeBatchLogonRight. #>
    param([string]$Name)
    $pol = Export-FosSecurityPolicy
    $line = @($pol | Where-Object { $_ -match "^\s*$Name\s*=" })
    if (-not $line) { return @() }
    return @((($line[0] -split '=', 2)[1] -split ',') | ForEach-Object { Resolve-FosPrincipal $_ } | Where-Object { $_ })
}

function Get-FosAllUserRights {
    <# Every privilege in the policy, resolved. This is the part of a server nobody documents. #>
    $pol = Export-FosSecurityPolicy
    $out = [ordered]@{}
    $inSection = $false
    foreach ($l in $pol) {
        if ($l -match '^\[Privilege Rights\]') { $inSection = $true; continue }
        if ($l -match '^\[') { $inSection = $false; continue }
        if (-not $inSection) { continue }
        if ($l -match '^\s*(Se\w+)\s*=\s*(.*)$') {
            $out[$Matches[1]] = @(($Matches[2] -split ',') | ForEach-Object { Resolve-FosPrincipal $_ } | Where-Object { $_ })
        }
    }
    return $out
}

function Grant-FosUserRight {
    <#
      Adds principals to a right without disturbing the ones already there. Returns $true only if a
      re-read confirms it took - secedit can report success and change nothing when a GPO owns the
      setting, and a silent no-op here is a task that fails at 3am with 0x80070569.
    #>
    [CmdletBinding(SupportsShouldProcess = $true)]
    param([string]$Name = 'SeBatchLogonRight', [string[]]$Accounts)
    $current = Get-FosUserRight $Name
    $need = @($Accounts | Where-Object { -not (Test-FosInList $_ $current) })
    if (-not $need.Count) { return $true }
    $sids = @()
    foreach ($p in @($current + $need)) {
        try { $sids += (New-Object System.Security.Principal.NTAccount($p)).Translate([System.Security.Principal.SecurityIdentifier]).Value }
        catch { Add-FosFinding -Severity warn -Area 'rights' -Problem "cannot resolve '$p' to a SID - it will be left out of the $Name grant" }
    }
    $sids = @($sids | Sort-Object -Unique | Where-Object { $_ })
    if (-not $sids.Count) { return $false }
    if (-not $PSCmdlet.ShouldProcess($Name, "Grant to $($need -join ', ')")) { return $false }
    $inf = Join-Path ([IO.Path]::GetTempPath()) ('grant-' + [guid]::NewGuid().ToString('N') + '.inf')
    $db  = Join-Path ([IO.Path]::GetTempPath()) ('grant-' + [guid]::NewGuid().ToString('N') + '.sdb')
    @('[Unicode]', 'Unicode=yes', '[Version]', 'signature="$CHICAGO$"', 'Revision=1', '[Privilege Rights]',
      ("$Name = " + (($sids | ForEach-Object { "*$_" }) -join ','))) | Set-Content -LiteralPath $inf -Encoding Unicode
    $null = & secedit /configure /db $db /cfg $inf /areas USER_RIGHTS /quiet 2>&1
    Remove-Item -LiteralPath $inf, $db -ErrorAction SilentlyContinue
    $script:SecPol = $null          # bust the cache or we re-read the pre-change policy
    $null = Export-FosSecurityPolicy -Force
    $after = Get-FosUserRight $Name
    $ok = $true
    foreach ($a in $need) {
        if (Test-FosInList $a $after) { Add-FosFinding -Severity done -Area 'rights' -Problem "granted $Name to $a" }
        else { $ok = $false; Add-FosFinding -Severity blocker -Area 'rights' -Problem "grant of $Name to $a did not take" -Fix 'A GPO probably owns this setting - add the account there instead' }
    }
    return $ok
}

function Test-FosRightIsGpoManaged {
    <# A local grant that a GPO overwrites at the next refresh is worse than no grant: it works
       today and the tasks stop tomorrow with no obvious trigger. #>
    param([string]$Pattern = 'SeBatchLogonRight|Log on as a batch job')
    $gp = Invoke-FosTimeout { (& gpresult /scope computer /v 2>&1 | Out-String) } 90 '' 'gpresult'
    if (-not $gp) { return $null }
    return [bool]($gp -match $Pattern)
}

# ------------------------------------------------------------------ manifest
function Save-FosManifest {
    param($Object, [string]$Path)
    $dir = Split-Path -Parent $Path
    if ($dir -and -not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
    $Object | ConvertTo-Json -Depth 12 | Set-Content -LiteralPath $Path -Encoding utf8
}
function Import-FosManifest {
    param([string]$Path)
    if (-not (Test-Path -LiteralPath $Path)) { throw "No manifest at $Path" }
    return (Get-Content -LiteralPath $Path -Raw | ConvertFrom-Json)
}

# ------------------------------------------------------------------ noise filters
# The point of a capture is what somebody INSTALLED, not what Windows ships with. These patterns
# are deliberately conservative: it is better to leave one Microsoft component in the list than to
# hide the one third-party agent that turns out to matter.
$script:JunkSoftware = @(
    '^Update for ', '^Security Update', '^Hotfix for', '^Microsoft Visual C\+\+ \d{4}.*Redistributable',
    '^Microsoft \.NET Framework \d', '^Windows Software Development Kit', '^Microsoft Policy Platform',
    '^Microsoft Visual Studio .* Tools for Office Runtime', '^Microsoft Help Viewer',
    '^Microsoft SQL Server \d+ (Setup|Native|Common|Batch|Browser|RsFx)', '^Microsoft ODBC Driver \d+ for SQL Server$',
    '^Microsoft Edge(WebView|Update)?$', '^Microsoft OneDrive$', '^Windows Driver Package'
)
function Test-FosIsJunkSoftware { param([string]$Name) foreach ($p in $script:JunkSoftware) { if ($Name -match $p) { return $true } } return $false }

# Services are NOT filtered by name. "windows_exporter" starts with "windows", and a name-pattern
# filter cheerfully hides the single most important service on an APPMON box. Decide on the binary
# path instead: anything running from outside %SystemRoot% was installed by somebody, and an
# explicit keep-list catches the few that do live in system directories.
$script:KeepServices = 'exporter|grafana|prometheus|nssm|octopus|splunk|nagios|zabbix|datadog|newrelic|dynatrace|sql|iis|w3svc|msmq|tomcat|jboss|rabbit|redis|elastic|logstash|filebeat|winlogbeat'
function Test-FosIsJunkService {
    <# $Service: anything with Name / PathName (Win32_Service) - or pass -Name and -PathName. #>
    param($Service, [string]$Name, [string]$PathName)
    if ($Service) { $Name = "$($Service.Name)"; $PathName = "$($Service.PathName)" }
    if ($Name -match $script:KeepServices -or $PathName -match $script:KeepServices) { return $false }
    $exe = $PathName
    if ($exe -match '^"([^"]+)"') { $exe = $Matches[1] } elseif ($exe -match '^(\S+\.exe)') { $exe = $Matches[1] }
    if (-not $exe) { return $false }               # unknown path: keep it, do not guess it away
    $sysRoot = [regex]::Escape($env:SystemRoot)
    return [bool]($exe -match "^$sysRoot\\")
}

function Get-FosInstalledSoftware {
    <# Both registry views; MSI and non-MSI. Get-Package/Win32_Product are avoided on purpose -
       Win32_Product triggers an MSI self-repair on every product it touches. #>
    param([switch]$IncludeJunk)
    $keys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*'
    )
    $all = @()
    foreach ($k in $keys) {
        $all += @(Get-ItemProperty -Path $k -ErrorAction SilentlyContinue |
                  Where-Object { $_.DisplayName -and -not $_.SystemComponent -and -not $_.ParentKeyName } |
                  ForEach-Object {
                      [pscustomobject]@{
                          Name = "$($_.DisplayName)"; Version = "$($_.DisplayVersion)"; Publisher = "$($_.Publisher)"
                          Installed = "$($_.InstallDate)"; Location = "$($_.InstallLocation)"
                          Arch = $(if ($k -match 'WOW6432') { 'x86' } else { 'x64' })
                      } })
    }
    $all = @($all | Sort-Object Name, Version -Unique)
    if ($IncludeJunk) { return $all }
    return @($all | Where-Object { -not (Test-FosIsJunkSoftware $_.Name) })
}

# ------------------------------------------------------------------ config and http
function Get-FosIniEffective {
    <# Grafana layers custom.ini over defaults.ini. Reading only one of them tells you nothing about
       what the server is actually doing - which is how a Grafana "on 9000" turned out to be on 3000. #>
    param([string[]]$Paths)
    $eff = [ordered]@{}
    foreach ($p in $Paths) {
        if (-not $p -or -not (Test-Path -LiteralPath $p)) { continue }
        $section = ''
        foreach ($line in (Get-Content -LiteralPath $p -ErrorAction SilentlyContinue)) {
            $l = $line.Trim()
            if ($l -match '^[;#]' -or -not $l) { continue }
            if ($l -match '^\[(.+)\]$') { $section = $Matches[1]; continue }
            if ($l -match '^([^=]+?)\s*=\s*(.*)$') { $eff["$section.$($Matches[1].Trim())"] = $Matches[2].Trim() }
        }
    }
    return $eff
}

function Invoke-FosWeb {
    param([string]$Url, [hashtable]$Headers = @{}, [pscredential]$Credential, [int]$TimeoutSec = 20)
    try {
        $p = @{ Uri = $Url; UseBasicParsing = $true; TimeoutSec = $TimeoutSec; ErrorAction = 'Stop' }
        if ($Headers.Count) { $p.Headers = $Headers }
        if ($Credential) { $p.Credential = $Credential }
        return (Invoke-WebRequest @p).Content
    } catch { return $null }
}

function Invoke-FosWebDirect {
    <#
      HTTP GET with the proxy forced OFF. Invoke-WebRequest honours the calling user's WinINET proxy,
      and on a box with a proxy set and no bypass for local addresses a call to localhost or to the
      Azure IMDS address goes out to the proxy and fails. Returns @{ ok; status; body; error }.
      Never throws.
    #>
    param([string]$Url, [hashtable]$Headers = @{}, [int]$TimeoutSec = 10)
    $r = [ordered]@{ ok = $false; status = 0; body = $null; error = '' }
    try {
        $req = [System.Net.HttpWebRequest]::Create($Url)
        $req.Method = 'GET'
        $req.Proxy = $null
        $req.Timeout = $TimeoutSec * 1000
        $req.ReadWriteTimeout = $TimeoutSec * 1000
        $req.KeepAlive = $false
        foreach ($k in $Headers.Keys) { $req.Headers[$k] = "$($Headers[$k])" }
        $resp = $req.GetResponse()
        $r.status = [int]$resp.StatusCode
        $sr = New-Object System.IO.StreamReader($resp.GetResponseStream())
        $r.body = $sr.ReadToEnd()
        $sr.Close(); $resp.Close()
        $r.ok = $true
    } catch [System.Net.WebException] {
        $r.error = "$($_.Exception.Message)"
        # a 4xx/5xx still carries a body (Grafana puts the datasource health message in a 400), keep it
        try {
            $er = $_.Exception.Response
            if ($er) {
                $r.status = [int]$er.StatusCode
                $es = New-Object System.IO.StreamReader($er.GetResponseStream()); $r.body = $es.ReadToEnd(); $es.Close(); $er.Close()
            }
        } catch {}
    } catch { $r.error = "$($_.Exception.Message)" }
    return $r
}

function Get-FosNssmParameters {
    <#
      NSSM keeps the real service definition under Services\<name>\Parameters. Win32_Service.PathName
      is just nssm.exe. Returns $null when the service is not NSSM wrapped or the key is absent.
    #>
    param([string]$Name)
    $regKey = "HKLM:\SYSTEM\CurrentControlSet\Services\$Name\Parameters"
    if (-not (Test-Path -LiteralPath $regKey)) { return $null }
    $p = Get-ItemProperty -Path $regKey -ErrorAction SilentlyContinue
    if (-not $p -or -not $p.Application) { return $null }
    $o = [ordered]@{ application = "$($p.Application)"; appParameters = "$($p.AppParameters)"; appDirectory = "$($p.AppDirectory)" }
    foreach ($n in 'AppStdout', 'AppStderr', 'AppRotateFiles', 'AppRotateBytes', 'AppExit', 'AppRestartDelay', 'AppStopMethodSkip', 'AppPriority', 'AppNoConsole') {
        if ($null -ne $p.$n) { $o[$n.Substring(0, 1).ToLower() + $n.Substring(1)] = "$($p.$n)" }
    }
    $env = @()
    foreach ($n in 'AppEnvironment', 'AppEnvironmentExtra') {
        if ($p.$n) { $env += @($p.$n | ForEach-Object { "$_" }) }
    }
    $o.environment = @($env | Where-Object { $_ })
    # AppExit is a subkey: AppExit\(Default) = Restart|Ignore|Exit|Suicide, AppExit\<code> per code
    $ek = Join-Path $regKey 'AppExit'
    if (Test-Path -LiteralPath $ek) {
        $ev = Get-ItemProperty -Path $ek -ErrorAction SilentlyContinue
        if ($ev -and $ev.'(default)') { $o.appExitDefault = "$($ev.'(default)')" }
    }
    return $o
}

function Resolve-FosServiceCommand {
    <#
      The command line a service ACTUALLY runs. For an NSSM wrapped service this is
      Application + AppParameters from the registry; for anything else it is PathName.
    #>
    param([string]$Name, [string]$PathName)
    $cmd = "$PathName"
    if ($cmd -notmatch '(?i)nssm') { return $cmd }
    $p = Get-FosNssmParameters -Name $Name
    if (-not $p) { return $cmd }
    $app = $p.application
    if ($app -match '\s') { $app = "`"$app`"" }
    return ("$app $($p.appParameters)").Trim()
}

function Get-FosExeFromCommand {
    param([string]$Command)
    $c = "$Command".Trim()
    if ($c -match '^"([^"]+\.exe)"') { return $Matches[1] }
    if ($c -match '^(\S+\.exe)') { return $Matches[1] }
    if ($c -match '^"([^"]+)"') { return $Matches[1] }
    if ($c -match '^(\S+)') { return $Matches[1] }
    return ''
}

function Get-FosFlag {
    <# --name=value | --name value | --name="value" | --name "value". Returns '' when absent. #>
    param([string]$Command, [string]$Flag)
    $f = [regex]::Escape($Flag)
    if ($Command -match "(?:^|\s)$f(?:=|\s+)`"([^`"]+)`"") { return $Matches[1] }
    if ($Command -match "(?:^|\s)$f(?:=|\s+)'([^']+)'")   { return $Matches[1] }
    if ($Command -match "(?:^|\s)$f(?:=|\s+)([^\s`"']+)")  { return $Matches[1] }
    return ''
}

function ConvertFrom-FosJwtPayload {
    <# Decodes the payload of a JWT without validating it. Used to read a Grafana Enterprise
       licence: the licensed URL and expiry live in the payload. Returns $null on any failure. #>
    param([string]$Token)
    try {
        $parts = "$Token".Trim() -split '\.'
        if ($parts.Count -lt 2) { return $null }
        $b = $parts[1].Replace('-', '+').Replace('_', '/')
        switch ($b.Length % 4) { 2 { $b += '==' } 3 { $b += '=' } }
        $json = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b))
        return ($json | ConvertFrom-Json)
    } catch { return $null }
}

function ConvertTo-FosStamp {
    <# ConvertFrom-Json turns ISO strings into DateTime on some builds and leaves them alone on
       others; the report then shows one in local culture and the other in ISO. One format. #>
    param($Value)
    if ($null -eq $Value) { return '' }
    if ($Value -is [datetime]) { return $Value.ToUniversalTime().ToString('s') + 'Z' }
    return "$Value"
}

function Get-FosRedactedText {
    <# Masks secret VALUES in ini / yaml / toml text while keeping the keys, so the config can go
       into a report. Key names are matched, not values, so a password of "changeme" is still hidden. #>
    param([string]$Text)
    if (-not $Text) { return $Text }
    # [ \t] not \s around the separator: \s matches a newline, and the redaction then swallowed the
    # line AFTER an empty "password =" entry, which on a Grafana ini was the next [section] header.
    $rx = '(?im)^([ \t]*(?:[A-Za-z0-9_.\-]*)(?:password|passwd|pwd|secret|secret_key|token|api_key|apikey|client_secret|bind_password|private_key|license_token|connection_string|connstr|credentials|auth_token)[A-Za-z0-9_.\-]*[ \t]*[=:][ \t]*)(?![ \t]*$)([^\r\n]*)$'
    return [regex]::Replace($Text, $rx, '${1}***REDACTED***')
}

function Test-FosHoldsRight {
    <#
      Three state check: YES / NO / UNKNOWN. A right is usually held through BUILTIN\Administrators
      or a domain group, not by name, so a name only match says NO for accounts that plainly hold
      it. UNKNOWN means the group membership could not be resolved; never write policy on UNKNOWN.
    #>
    param([string]$Account, [string]$Right = 'SeBatchLogonRight')
    if (-not $Account) { return 'UNKNOWN' }
    if ($Account -match '^(?:NT AUTHORITY\\)?(SYSTEM|LOCAL SERVICE|NETWORK SERVICE)$') { return 'YES' }
    $holders = @(Get-FosUserRight $Right)
    if (-not $holders.Count) { return 'UNKNOWN' }
    if (Test-FosInList $Account $holders) { return 'YES' }
    $groups = @($holders | Where-Object { $_ -match '^(BUILTIN|NT AUTHORITY)\\' -or $_ -notmatch '\\' })
    $unknown = $false
    foreach ($g in $groups) {
        $gn = ConvertTo-FosSam $g
        $members = $null
        try { $members = @(Get-LocalGroupMember -Group $gn -ErrorAction Stop | ForEach-Object { "$($_.Name)" }) } catch { $unknown = $true; continue }
        if (Test-FosInList $Account $members) { return 'YES' }
    }
    $domainGroups = @($holders | Where-Object { $_ -match '\\' -and $_ -notmatch '^(BUILTIN|NT AUTHORITY)\\' })
    if ($domainGroups.Count) { $unknown = $true }     # cannot expand domain groups without AD access
    if ($unknown) { return 'UNKNOWN' }
    return 'NO'
}

function Get-FosEstablishedByPort {
    <# Who is talking to this box right now, per listening port. The answer to "who depends on
       this server" that no document has. #>
    param([int[]]$Ports)
    $out = @()
    try {
        $conns = @(Get-NetTCPConnection -State Established -ErrorAction Stop | Where-Object { $Ports -contains [int]$_.LocalPort })
        foreach ($g in ($conns | Group-Object LocalPort)) {
            $remotes = @($g.Group | ForEach-Object { "$($_.RemoteAddress)" } | Where-Object { $_ -notin '127.0.0.1', '::1' } | Sort-Object -Unique)
            $out += [ordered]@{ port = [int]$g.Name; connections = $g.Count; remoteAddresses = $remotes }
        }
    } catch {}
    return @($out)
}

function Resolve-FosReverseDns {
    param([string[]]$Addresses, [int]$TimeoutSec = 20)
    if (-not $Addresses -or -not $Addresses.Count) { return @{} }
    $r = Invoke-FosTimeout {
        param($addrs)
        $h = @{}
        foreach ($a in $addrs) { try { $h[$a] = [System.Net.Dns]::GetHostEntry($a).HostName } catch { $h[$a] = '' } }
        $h
    } $TimeoutSec @{} 'reverse DNS' -ArgumentList (,@($Addresses))
    if (-not $r) { return @{} }
    return $r
}

Export-ModuleMember -Function New-FosReport, Add-FosLine, Add-FosHead, Add-FosSub, Add-FosKV, Add-FosTable,
    Format-FosTrim, Format-FosSize, Add-FosFinding, Get-FosFindings, Add-FosFindingSummary, Write-FosReport,
    Start-FosStep, Invoke-FosTimeout, Test-FosAdmin, Assert-FosAdmin, Add-FosMask, Get-FosMask, Get-FosSanitizeState,
    ConvertTo-FosSam, Test-FosInList, Resolve-FosPrincipal, Export-FosSecurityPolicy, Get-FosUserRight,
    Get-FosAllUserRights, Grant-FosUserRight, Test-FosRightIsGpoManaged, Save-FosManifest, Import-FosManifest,
    Test-FosIsJunkSoftware, Test-FosIsJunkService, Get-FosInstalledSoftware, Get-FosIniEffective, Invoke-FosWeb,
    Invoke-FosWebDirect, Get-FosNssmParameters, Resolve-FosServiceCommand, Get-FosExeFromCommand, Get-FosFlag,
    ConvertFrom-FosJwtPayload, Get-FosRedactedText, Test-FosHoldsRight, Get-FosEstablishedByPort, Resolve-FosReverseDns, ConvertTo-FosStamp
