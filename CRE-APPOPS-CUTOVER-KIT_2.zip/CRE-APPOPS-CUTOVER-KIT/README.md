# CRE APPOPS cutover kit

`SRVCRE1APPOPS01` to the new CRE server. Grafana 10.4.19 + Prometheus 2.8.1 + exporter + scheduled
tasks. TSDB 3.41 GB, 10 scrape endpoints.

CRE is the smallest full stack in the estate and has no production impact. Run it here first, then
the same sequence on `SRVFOSAPPOPS01` where 103 hosts and every dashboard user are downstream.

## Copy the folders to the machines they are named after

```
1_ON-OLD-SERVER\     ->  SRVCRE1APPOPS01     steps 1 to 4,  read only
2_ON-NEW-SERVER\     ->  the new CRE server  steps 5 to 13
REFERENCE\           ->  wherever you like
```

Copy the WHOLE folder to each machine. The scripts import `FOSMigrate.psm1` from beside themselves
and the wrappers call `_Migrate-PrometheusConfig.ps1` from beside themselves. Single files do not
work on their own.

Each folder has its own `RUN-ORDER.md`. Read that one, not this one, when you are at the keyboard.

## Full sequence

| # | Where | Script | Gate |
|---|---|---|---|
| 1 | old | `1_Invoke-ServerCapture.ps1 -GrafanaApiKey <token>` | v2.0, see 1_ON-OLD-SERVER\RUN-ORDER.md for what to paste back |
| 2 | old | `2_Export-PrometheusConfig.ps1` | Prometheus must be running |
| 3 | old | `3_Export-GrafanaContent.ps1` | |
| 4 | old | `4_Test-PromFiles.ps1` | |
| 5 | new | `5_Invoke-ServerCapture.ps1 -OldServer SRVCRE1APPOPS01 -GrafanaApiKey <token>` | |
| 6 | new | `6_Compare-ServerBaseline.ps1` | **must return GO** |
| 7 | new | `7_Repair-MonitoringHost.ps1 -Apply` | |
| 8 | new | `8_Import-PrometheusConfig.ps1` | needs one hand edit |
| 9 | new | `9_Import-GrafanaContent.ps1` | |
| 10 | new | `10_Import-CrossEnvTasks.ps1` | |
| 11 | new | `11_Test-MonitoringHost.ps1` | |
| 12 | new | `12_Test-PromFiles.ps1` | |
| 13 | new | `13_Test-CutoverGate.ps1` | **must return GO before the DNS repoint** |

Between 8 and 9, start Prometheus on the new server and write down the time. That is when the
parallel run begins, and the earliest safe cutover is that time plus the retention window.

## Nothing here is destructive

Steps 1 to 6 and 11 to 13 are read only. Every script writes a pasteable text report; nothing needs to leave the perimeter. Steps 7 to 10 do nothing without `-Apply`, back up every
file they replace, and register every task DISABLED.

The old server is untouched throughout. Backout is a DNS change and takes about a minute.

## Three files serve more than one step

`_Migrate-PrometheusConfig.ps1` is the engine behind steps 2, 8 and 13. The numbered files are thin
wrappers that call it with the right mode. One copy per machine means a fix reaches every step that
uses it. Do not delete the underscore file and do not run it directly.

`FOSMigrate.psm1` is the shared library the suite scripts import. Same rule.

## Two things that will bite

**The metric rename.** wmi_exporter 0.4.3 names everything `wmi_*`. The current windows_exporter
names it `windows_*`. Without the `metric_relabel_configs` bridge that step 8 prints, every
dashboard querying `wmi_*` goes blank. Step 13 is what proves the bridge worked.

**One bad `.prom` file takes down all of them.** The current exporter rejects a malformed file whole
and sets `windows_textfile_scrape_error` to 1, while every service still shows green. Steps 4 and 12
catch it.

## Open before you start

`SRVCREAPPOPS01` versus `SRVCREAPPMON01` is unresolved, and it determines whether CRE is three boxes
or four. Settle it before planning the tranche. See `REFERENCE\CRE-APPOPS-CUTOVER.md`.
